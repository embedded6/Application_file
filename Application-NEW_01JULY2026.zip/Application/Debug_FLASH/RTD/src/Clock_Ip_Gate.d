RTD/src/Clock_Ip_Gate.o: ../RTD/src/Clock_Ip_Gate.c \
 ../RTD/include/Clock_Ip_Private.h ../RTD/include/Clock_Ip.h \
 ../RTD/include/Clock_Ip_Types.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Platform_Types.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/PlatformTypes.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler_Cfg.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/CompilerDefinition.h \
 C\:/Users/user/workspaceS32DS.3.6.3/Application.zip_expanded/Application/generate/include/Clock_Ip_Cfg_Defines.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_MC_CGM.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_COMMON.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/BasicTypes.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_FIRC.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SIRC.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_FXOSC.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SXOSC.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_PLL.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_MC_ME.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_PRAMC.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_FLASH.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_CMU_FC.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SYSTICK.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_EMIOS.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_RTC.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_CONFIGURATION_GPR.h \
 C\:/Users/user/workspaceS32DS.3.6.3/Application.zip_expanded/Application/generate/include/Clock_Ip_Cfg.h \
 ../RTD/include/Clock_Ip_Types.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcu_MemMap.h \
 ../RTD/include/Clock_Ip_Specific.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcal.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Soc_Ips.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/IpVersionMacros.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Reg_eSys.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/OsIf_Internal.h \
 C\:/Users/user/workspaceS32DS.3.6.3/Application.zip_expanded/Application/generate/include/OsIf_Cfg.h \
 C\:/Users/user/workspaceS32DS.3.6.3/Application.zip_expanded/Application/generate/include/OsIf_ArchCfg.h
../RTD/include/Clock_Ip_Private.h:
../RTD/include/Clock_Ip.h:
../RTD/include/Clock_Ip_Types.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Platform_Types.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/PlatformTypes.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler_Cfg.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/CompilerDefinition.h:
C\:/Users/user/workspaceS32DS.3.6.3/Application.zip_expanded/Application/generate/include/Clock_Ip_Cfg_Defines.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_MC_CGM.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_COMMON.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/BasicTypes.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_FIRC.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SIRC.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_FXOSC.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SXOSC.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_PLL.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_MC_ME.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_PRAMC.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_FLASH.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_CMU_FC.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SYSTICK.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_EMIOS.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_RTC.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_CONFIGURATION_GPR.h:
C\:/Users/user/workspaceS32DS.3.6.3/Application.zip_expanded/Application/generate/include/Clock_Ip_Cfg.h:
../RTD/include/Clock_Ip_Types.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcu_MemMap.h:
../RTD/include/Clock_Ip_Specific.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcal.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Soc_Ips.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/IpVersionMacros.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Reg_eSys.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/OsIf_Internal.h:
C\:/Users/user/workspaceS32DS.3.6.3/Application.zip_expanded/Application/generate/include/OsIf_Cfg.h:
C\:/Users/user/workspaceS32DS.3.6.3/Application.zip_expanded/Application/generate/include/OsIf_ArchCfg.h:
