Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_67/196:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_67/195:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_66/194:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_66/193:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_65/192:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_65/191:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_64/190:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_64/189:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_63/188:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_63/187:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_62/186:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_62/185:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_61/184:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_61/183:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_60/182:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_60/181:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_56/180:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_56/179:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_55/178:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_55/177:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_54/176:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_54/175:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_53/174:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_53/173:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_52/172:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_52/171:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_51/170:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_51/169:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_50/168:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_50/167:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_46/166:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_46/165:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_45/164:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_45/163:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_44/162:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_44/161:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_43/160:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_43/159:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_42/158:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_42/157:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_41/156:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_41/155:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_40/154:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_40/153:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_39/152:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_39/151:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_38/150:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_38/149:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_36/148:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_36/147:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_35/146:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_35/145:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_31/144:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_31/143:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_30/142:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_30/141:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_29/140:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_29/139:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_28/138:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_28/137:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_27/136:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_27/135:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_26/134:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_26/133:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_25/132:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_25/131:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_24/130:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_24/129:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_23/128:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_23/127:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_22/126:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_22/125:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_21/124:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_21/123:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_17/122:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_17/121:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_12/120:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_12/119:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_11/118:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_11/117:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_10/116:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_10/115:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_07/114:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_07/113:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_06/112:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_06/111:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_05/110:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_05/109:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_04/108:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_04/107:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_03/106:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_03/105:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_02/104:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_02/103:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_01/102:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_01/101:


Creating summary for SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_00/100:


Creating summary for SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_00/99:


Creating summary for Gpt_schm_read_msr/98:



========== IPA-SRA IPA stage ==========

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_67/196:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_67/196->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_67/195:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_67/195->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_66/194:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_66/194->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_66/193:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_66/193->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_65/192:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_65/192->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_65/191:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_65/191->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_64/190:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_64/190->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_64/189:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_64/189->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_63/188:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_63/188->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_63/187:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_63/187->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_62/186:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_62/186->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_62/185:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_62/185->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_61/184:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_61/184->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_61/183:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_61/183->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_60/182:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_60/182->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_60/181:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_60/181->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_56/180:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_56/180->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_56/179:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_56/179->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_55/178:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_55/178->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_55/177:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_55/177->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_54/176:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_54/176->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_54/175:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_54/175->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_53/174:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_53/174->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_53/173:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_53/173->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_52/172:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_52/172->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_52/171:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_52/171->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_51/170:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_51/170->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_51/169:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_51/169->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_50/168:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_50/168->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_50/167:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_50/167->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_46/166:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_46/166->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_46/165:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_46/165->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_45/164:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_45/164->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_45/163:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_45/163->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_44/162:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_44/162->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_44/161:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_44/161->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_43/160:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_43/160->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_43/159:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_43/159->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_42/158:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_42/158->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_42/157:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_42/157->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_41/156:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_41/156->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_41/155:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_41/155->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_40/154:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_40/154->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_40/153:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_40/153->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_39/152:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_39/152->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_39/151:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_39/151->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_38/150:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_38/150->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_38/149:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_38/149->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_36/148:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_36/148->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_36/147:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_36/147->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_35/146:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_35/146->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_35/145:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_35/145->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_31/144:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_31/144->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_31/143:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_31/143->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_30/142:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_30/142->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_30/141:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_30/141->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_29/140:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_29/140->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_29/139:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_29/139->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_28/138:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_28/138->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_28/137:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_28/137->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_27/136:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_27/136->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_27/135:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_27/135->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_26/134:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_26/134->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_26/133:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_26/133->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_25/132:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_25/132->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_25/131:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_25/131->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_24/130:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_24/130->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_24/129:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_24/129->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_23/128:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_23/128->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_23/127:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_23/127->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_22/126:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_22/126->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_22/125:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_22/125->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_21/124:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_21/124->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_21/123:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_21/123->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_17/122:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_17/122->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_17/121:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_17/121->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_12/120:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_12/120->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_12/119:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_12/119->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_11/118:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_11/118->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_11/117:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_11/117->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_10/116:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_10/116->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_10/115:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_10/115->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_07/114:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_07/114->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_07/113:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_07/113->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_06/112:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_06/112->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_06/111:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_06/111->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_05/110:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_05/110->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_05/109:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_05/109->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_04/108:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_04/108->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_04/107:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_04/107->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_03/106:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_03/106->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_03/105:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_03/105->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_02/104:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_02/104->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_02/103:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_02/103->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_01/102:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_01/102->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_01/101:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_01/101->Sys_GetCoreID/197:

Summary for node SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_00/100:
  No parameter information. 

  Summary for edge SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_00/100->Sys_GetCoreID/197:

Summary for node SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_00/99:
  No parameter information. 

  Summary for edge SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_00/99->Sys_GetCoreID/197:

Summary for node Gpt_schm_read_msr/98:
  Returns value
  No parameter information. 



Function Gpt_schm_read_msr/98 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_00/99 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_00/100 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_01/101 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_01/102 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_02/103 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_02/104 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_03/105 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_03/106 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_04/107 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_04/108 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_05/109 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_05/110 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_06/111 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_06/112 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_07/113 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_07/114 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_10/115 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_10/116 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_11/117 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_11/118 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_12/119 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_12/120 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_17/121 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_17/122 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_21/123 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_21/124 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_22/125 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_22/126 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_23/127 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_23/128 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_24/129 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_24/130 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_25/131 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_25/132 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_26/133 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_26/134 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_27/135 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_27/136 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_28/137 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_28/138 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_29/139 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_29/140 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_30/141 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_30/142 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_31/143 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_31/144 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_35/145 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_35/146 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_36/147 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_36/148 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_38/149 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_38/150 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_39/151 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_39/152 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_40/153 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_40/154 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_41/155 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_41/156 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_42/157 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_42/158 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_43/159 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_43/160 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_44/161 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_44/162 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_45/163 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_45/164 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_46/165 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_46/166 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_50/167 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_50/168 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_51/169 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_51/170 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_52/171 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_52/172 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_53/173 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_53/174 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_54/175 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_54/176 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_55/177 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_55/178 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_56/179 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_56/180 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_60/181 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_60/182 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_61/183 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_61/184 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_62/185 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_62/186 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_63/187 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_63/188 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_64/189 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_64/190 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_65/191 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_65/192 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_66/193 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_66/194 disqualified because it cannot be made local.
Function SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_67/195 disqualified because it cannot be made local.
Function SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_67/196 disqualified because it cannot be made local.

========== IPA-SRA decisions ==========

========== IPA SRA IPA analysis done ==========


Reclaiming functions:
Reclaiming variables:
Clearing address taken flags:
Symbol table:

Sys_GetCoreID/197 (Sys_GetCoreID) @05fd4540
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_67/196 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_67/195 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_66/194 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_66/193 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_65/192 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_65/191 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_64/190 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_64/189 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_63/188 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_63/187 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_62/186 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_62/185 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_61/184 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_61/183 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_60/182 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_60/181 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_56/180 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_56/179 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_55/178 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_55/177 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_54/176 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_54/175 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_53/174 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_53/173 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_52/172 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_52/171 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_51/170 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_51/169 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_50/168 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_50/167 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_46/166 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_46/165 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_45/164 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_45/163 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_44/162 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_44/161 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_43/160 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_43/159 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_42/158 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_42/157 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_41/156 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_41/155 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_40/154 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_40/153 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_39/152 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_39/151 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_38/150 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_38/149 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_36/148 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_36/147 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_35/146 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_35/145 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_31/144 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_31/143 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_30/142 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_30/141 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_29/140 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_29/139 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_28/138 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_28/137 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_27/136 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_27/135 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_26/134 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_26/133 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_25/132 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_25/131 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_24/130 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_24/129 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_23/128 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_23/127 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_22/126 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_22/125 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_21/124 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_21/123 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_17/122 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_17/121 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_12/120 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_12/119 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_11/118 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_11/117 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_10/116 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_10/115 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_07/114 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_07/113 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_06/112 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_06/111 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_05/110 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_05/109 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_04/108 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_04/107 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_03/106 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_03/105 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_02/104 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_02/103 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_01/102 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_01/101 (1073741824 (estimated locally),1.00 per call) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_00/100 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_00/99 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_67/196 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_67) @05fced20
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_67/97 (read) reentry_guard_GPT_EXCLUSIVE_AREA_67/97 (write) msr_GPT_EXCLUSIVE_AREA_67/96 (read) reentry_guard_GPT_EXCLUSIVE_AREA_67/97 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_67/195 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_67) @05fce7e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_67/97 (read) msr_GPT_EXCLUSIVE_AREA_67/96 (write) msr_GPT_EXCLUSIVE_AREA_67/96 (read) reentry_guard_GPT_EXCLUSIVE_AREA_67/97 (read) reentry_guard_GPT_EXCLUSIVE_AREA_67/97 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_66/194 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_66) @05fce2a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_66/95 (read) reentry_guard_GPT_EXCLUSIVE_AREA_66/95 (write) msr_GPT_EXCLUSIVE_AREA_66/94 (read) reentry_guard_GPT_EXCLUSIVE_AREA_66/95 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_66/193 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_66) @05fceee0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_66/95 (read) msr_GPT_EXCLUSIVE_AREA_66/94 (write) msr_GPT_EXCLUSIVE_AREA_66/94 (read) reentry_guard_GPT_EXCLUSIVE_AREA_66/95 (read) reentry_guard_GPT_EXCLUSIVE_AREA_66/95 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_65/192 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_65) @05fcec40
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_65/93 (read) reentry_guard_GPT_EXCLUSIVE_AREA_65/93 (write) msr_GPT_EXCLUSIVE_AREA_65/92 (read) reentry_guard_GPT_EXCLUSIVE_AREA_65/93 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_65/191 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_65) @05fce9a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_65/93 (read) msr_GPT_EXCLUSIVE_AREA_65/92 (write) msr_GPT_EXCLUSIVE_AREA_65/92 (read) reentry_guard_GPT_EXCLUSIVE_AREA_65/93 (read) reentry_guard_GPT_EXCLUSIVE_AREA_65/93 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_64/190 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_64) @05fce700
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_64/91 (read) reentry_guard_GPT_EXCLUSIVE_AREA_64/91 (write) msr_GPT_EXCLUSIVE_AREA_64/90 (read) reentry_guard_GPT_EXCLUSIVE_AREA_64/91 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_64/189 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_64) @05fce460
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_64/91 (read) msr_GPT_EXCLUSIVE_AREA_64/90 (write) msr_GPT_EXCLUSIVE_AREA_64/90 (read) reentry_guard_GPT_EXCLUSIVE_AREA_64/91 (read) reentry_guard_GPT_EXCLUSIVE_AREA_64/91 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_63/188 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_63) @05fce1c0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_63/89 (read) reentry_guard_GPT_EXCLUSIVE_AREA_63/89 (write) msr_GPT_EXCLUSIVE_AREA_63/88 (read) reentry_guard_GPT_EXCLUSIVE_AREA_63/89 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_63/187 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_63) @05fc7d20
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_63/89 (read) msr_GPT_EXCLUSIVE_AREA_63/88 (write) msr_GPT_EXCLUSIVE_AREA_63/88 (read) reentry_guard_GPT_EXCLUSIVE_AREA_63/89 (read) reentry_guard_GPT_EXCLUSIVE_AREA_63/89 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_62/186 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_62) @05fc77e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_62/87 (read) reentry_guard_GPT_EXCLUSIVE_AREA_62/87 (write) msr_GPT_EXCLUSIVE_AREA_62/86 (read) reentry_guard_GPT_EXCLUSIVE_AREA_62/87 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_62/185 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_62) @05fc72a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_62/87 (read) msr_GPT_EXCLUSIVE_AREA_62/86 (write) msr_GPT_EXCLUSIVE_AREA_62/86 (read) reentry_guard_GPT_EXCLUSIVE_AREA_62/87 (read) reentry_guard_GPT_EXCLUSIVE_AREA_62/87 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_61/184 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_61) @05fc7ee0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_61/85 (read) reentry_guard_GPT_EXCLUSIVE_AREA_61/85 (write) msr_GPT_EXCLUSIVE_AREA_61/84 (read) reentry_guard_GPT_EXCLUSIVE_AREA_61/85 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_61/183 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_61) @05fc7c40
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_61/85 (read) msr_GPT_EXCLUSIVE_AREA_61/84 (write) msr_GPT_EXCLUSIVE_AREA_61/84 (read) reentry_guard_GPT_EXCLUSIVE_AREA_61/85 (read) reentry_guard_GPT_EXCLUSIVE_AREA_61/85 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_60/182 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_60) @05fc79a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_60/83 (read) reentry_guard_GPT_EXCLUSIVE_AREA_60/83 (write) msr_GPT_EXCLUSIVE_AREA_60/82 (read) reentry_guard_GPT_EXCLUSIVE_AREA_60/83 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_60/181 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_60) @05fc7700
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_60/83 (read) msr_GPT_EXCLUSIVE_AREA_60/82 (write) msr_GPT_EXCLUSIVE_AREA_60/82 (read) reentry_guard_GPT_EXCLUSIVE_AREA_60/83 (read) reentry_guard_GPT_EXCLUSIVE_AREA_60/83 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_56/180 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_56) @05fc7460
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_56/81 (read) reentry_guard_GPT_EXCLUSIVE_AREA_56/81 (write) msr_GPT_EXCLUSIVE_AREA_56/80 (read) reentry_guard_GPT_EXCLUSIVE_AREA_56/81 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_56/179 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_56) @05fc71c0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_56/81 (read) msr_GPT_EXCLUSIVE_AREA_56/80 (write) msr_GPT_EXCLUSIVE_AREA_56/80 (read) reentry_guard_GPT_EXCLUSIVE_AREA_56/81 (read) reentry_guard_GPT_EXCLUSIVE_AREA_56/81 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_55/178 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_55) @05fbed20
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_55/79 (read) reentry_guard_GPT_EXCLUSIVE_AREA_55/79 (write) msr_GPT_EXCLUSIVE_AREA_55/78 (read) reentry_guard_GPT_EXCLUSIVE_AREA_55/79 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_55/177 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_55) @05fbe7e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_55/79 (read) msr_GPT_EXCLUSIVE_AREA_55/78 (write) msr_GPT_EXCLUSIVE_AREA_55/78 (read) reentry_guard_GPT_EXCLUSIVE_AREA_55/79 (read) reentry_guard_GPT_EXCLUSIVE_AREA_55/79 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_54/176 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_54) @05fbe2a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_54/77 (read) reentry_guard_GPT_EXCLUSIVE_AREA_54/77 (write) msr_GPT_EXCLUSIVE_AREA_54/76 (read) reentry_guard_GPT_EXCLUSIVE_AREA_54/77 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_54/175 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_54) @05fbeee0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_54/77 (read) msr_GPT_EXCLUSIVE_AREA_54/76 (write) msr_GPT_EXCLUSIVE_AREA_54/76 (read) reentry_guard_GPT_EXCLUSIVE_AREA_54/77 (read) reentry_guard_GPT_EXCLUSIVE_AREA_54/77 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_53/174 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_53) @05fbec40
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_53/75 (read) reentry_guard_GPT_EXCLUSIVE_AREA_53/75 (write) msr_GPT_EXCLUSIVE_AREA_53/74 (read) reentry_guard_GPT_EXCLUSIVE_AREA_53/75 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_53/173 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_53) @05fbe9a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_53/75 (read) msr_GPT_EXCLUSIVE_AREA_53/74 (write) msr_GPT_EXCLUSIVE_AREA_53/74 (read) reentry_guard_GPT_EXCLUSIVE_AREA_53/75 (read) reentry_guard_GPT_EXCLUSIVE_AREA_53/75 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_52/172 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_52) @05fbe700
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_52/73 (read) reentry_guard_GPT_EXCLUSIVE_AREA_52/73 (write) msr_GPT_EXCLUSIVE_AREA_52/72 (read) reentry_guard_GPT_EXCLUSIVE_AREA_52/73 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_52/171 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_52) @05fbe460
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_52/73 (read) msr_GPT_EXCLUSIVE_AREA_52/72 (write) msr_GPT_EXCLUSIVE_AREA_52/72 (read) reentry_guard_GPT_EXCLUSIVE_AREA_52/73 (read) reentry_guard_GPT_EXCLUSIVE_AREA_52/73 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_51/170 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_51) @05fbe1c0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_51/71 (read) reentry_guard_GPT_EXCLUSIVE_AREA_51/71 (write) msr_GPT_EXCLUSIVE_AREA_51/70 (read) reentry_guard_GPT_EXCLUSIVE_AREA_51/71 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_51/169 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_51) @05fb7d20
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_51/71 (read) msr_GPT_EXCLUSIVE_AREA_51/70 (write) msr_GPT_EXCLUSIVE_AREA_51/70 (read) reentry_guard_GPT_EXCLUSIVE_AREA_51/71 (read) reentry_guard_GPT_EXCLUSIVE_AREA_51/71 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_50/168 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_50) @05fb77e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_50/69 (read) reentry_guard_GPT_EXCLUSIVE_AREA_50/69 (write) msr_GPT_EXCLUSIVE_AREA_50/68 (read) reentry_guard_GPT_EXCLUSIVE_AREA_50/69 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_50/167 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_50) @05fb72a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_50/69 (read) msr_GPT_EXCLUSIVE_AREA_50/68 (write) msr_GPT_EXCLUSIVE_AREA_50/68 (read) reentry_guard_GPT_EXCLUSIVE_AREA_50/69 (read) reentry_guard_GPT_EXCLUSIVE_AREA_50/69 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_46/166 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_46) @05fb7ee0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_46/67 (read) reentry_guard_GPT_EXCLUSIVE_AREA_46/67 (write) msr_GPT_EXCLUSIVE_AREA_46/66 (read) reentry_guard_GPT_EXCLUSIVE_AREA_46/67 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_46/165 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_46) @05fb7c40
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_46/67 (read) msr_GPT_EXCLUSIVE_AREA_46/66 (write) msr_GPT_EXCLUSIVE_AREA_46/66 (read) reentry_guard_GPT_EXCLUSIVE_AREA_46/67 (read) reentry_guard_GPT_EXCLUSIVE_AREA_46/67 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_45/164 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_45) @05fb79a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_45/65 (read) reentry_guard_GPT_EXCLUSIVE_AREA_45/65 (write) msr_GPT_EXCLUSIVE_AREA_45/64 (read) reentry_guard_GPT_EXCLUSIVE_AREA_45/65 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_45/163 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_45) @05fb7700
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_45/65 (read) msr_GPT_EXCLUSIVE_AREA_45/64 (write) msr_GPT_EXCLUSIVE_AREA_45/64 (read) reentry_guard_GPT_EXCLUSIVE_AREA_45/65 (read) reentry_guard_GPT_EXCLUSIVE_AREA_45/65 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_44/162 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_44) @05fb7460
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_44/63 (read) reentry_guard_GPT_EXCLUSIVE_AREA_44/63 (write) msr_GPT_EXCLUSIVE_AREA_44/62 (read) reentry_guard_GPT_EXCLUSIVE_AREA_44/63 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_44/161 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_44) @05fb71c0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_44/63 (read) msr_GPT_EXCLUSIVE_AREA_44/62 (write) msr_GPT_EXCLUSIVE_AREA_44/62 (read) reentry_guard_GPT_EXCLUSIVE_AREA_44/63 (read) reentry_guard_GPT_EXCLUSIVE_AREA_44/63 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_43/160 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_43) @05faed20
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_43/61 (read) reentry_guard_GPT_EXCLUSIVE_AREA_43/61 (write) msr_GPT_EXCLUSIVE_AREA_43/60 (read) reentry_guard_GPT_EXCLUSIVE_AREA_43/61 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_43/159 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_43) @05fae7e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_43/61 (read) msr_GPT_EXCLUSIVE_AREA_43/60 (write) msr_GPT_EXCLUSIVE_AREA_43/60 (read) reentry_guard_GPT_EXCLUSIVE_AREA_43/61 (read) reentry_guard_GPT_EXCLUSIVE_AREA_43/61 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_42/158 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_42) @05fae2a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_42/59 (read) reentry_guard_GPT_EXCLUSIVE_AREA_42/59 (write) msr_GPT_EXCLUSIVE_AREA_42/58 (read) reentry_guard_GPT_EXCLUSIVE_AREA_42/59 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_42/157 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_42) @05faeee0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_42/59 (read) msr_GPT_EXCLUSIVE_AREA_42/58 (write) msr_GPT_EXCLUSIVE_AREA_42/58 (read) reentry_guard_GPT_EXCLUSIVE_AREA_42/59 (read) reentry_guard_GPT_EXCLUSIVE_AREA_42/59 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_41/156 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_41) @05faec40
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_41/57 (read) reentry_guard_GPT_EXCLUSIVE_AREA_41/57 (write) msr_GPT_EXCLUSIVE_AREA_41/56 (read) reentry_guard_GPT_EXCLUSIVE_AREA_41/57 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_41/155 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_41) @05fae9a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_41/57 (read) msr_GPT_EXCLUSIVE_AREA_41/56 (write) msr_GPT_EXCLUSIVE_AREA_41/56 (read) reentry_guard_GPT_EXCLUSIVE_AREA_41/57 (read) reentry_guard_GPT_EXCLUSIVE_AREA_41/57 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_40/154 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_40) @05fae700
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_40/55 (read) reentry_guard_GPT_EXCLUSIVE_AREA_40/55 (write) msr_GPT_EXCLUSIVE_AREA_40/54 (read) reentry_guard_GPT_EXCLUSIVE_AREA_40/55 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_40/153 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_40) @05fae460
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_40/55 (read) msr_GPT_EXCLUSIVE_AREA_40/54 (write) msr_GPT_EXCLUSIVE_AREA_40/54 (read) reentry_guard_GPT_EXCLUSIVE_AREA_40/55 (read) reentry_guard_GPT_EXCLUSIVE_AREA_40/55 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_39/152 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_39) @05fae1c0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_39/53 (read) reentry_guard_GPT_EXCLUSIVE_AREA_39/53 (write) msr_GPT_EXCLUSIVE_AREA_39/52 (read) reentry_guard_GPT_EXCLUSIVE_AREA_39/53 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_39/151 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_39) @05fa4d20
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_39/53 (read) msr_GPT_EXCLUSIVE_AREA_39/52 (write) msr_GPT_EXCLUSIVE_AREA_39/52 (read) reentry_guard_GPT_EXCLUSIVE_AREA_39/53 (read) reentry_guard_GPT_EXCLUSIVE_AREA_39/53 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_38/150 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_38) @05fa47e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_38/51 (read) reentry_guard_GPT_EXCLUSIVE_AREA_38/51 (write) msr_GPT_EXCLUSIVE_AREA_38/50 (read) reentry_guard_GPT_EXCLUSIVE_AREA_38/51 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_38/149 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_38) @05fa42a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_38/51 (read) msr_GPT_EXCLUSIVE_AREA_38/50 (write) msr_GPT_EXCLUSIVE_AREA_38/50 (read) reentry_guard_GPT_EXCLUSIVE_AREA_38/51 (read) reentry_guard_GPT_EXCLUSIVE_AREA_38/51 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_36/148 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_36) @05fa4ee0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_36/49 (read) reentry_guard_GPT_EXCLUSIVE_AREA_36/49 (write) msr_GPT_EXCLUSIVE_AREA_36/48 (read) reentry_guard_GPT_EXCLUSIVE_AREA_36/49 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_36/147 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_36) @05fa4c40
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_36/49 (read) msr_GPT_EXCLUSIVE_AREA_36/48 (write) msr_GPT_EXCLUSIVE_AREA_36/48 (read) reentry_guard_GPT_EXCLUSIVE_AREA_36/49 (read) reentry_guard_GPT_EXCLUSIVE_AREA_36/49 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_35/146 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_35) @05fa49a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_35/47 (read) reentry_guard_GPT_EXCLUSIVE_AREA_35/47 (write) msr_GPT_EXCLUSIVE_AREA_35/46 (read) reentry_guard_GPT_EXCLUSIVE_AREA_35/47 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_35/145 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_35) @05fa4700
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_35/47 (read) msr_GPT_EXCLUSIVE_AREA_35/46 (write) msr_GPT_EXCLUSIVE_AREA_35/46 (read) reentry_guard_GPT_EXCLUSIVE_AREA_35/47 (read) reentry_guard_GPT_EXCLUSIVE_AREA_35/47 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_31/144 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_31) @05fa4460
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_31/45 (read) reentry_guard_GPT_EXCLUSIVE_AREA_31/45 (write) msr_GPT_EXCLUSIVE_AREA_31/44 (read) reentry_guard_GPT_EXCLUSIVE_AREA_31/45 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_31/143 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_31) @05fa41c0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_31/45 (read) msr_GPT_EXCLUSIVE_AREA_31/44 (write) msr_GPT_EXCLUSIVE_AREA_31/44 (read) reentry_guard_GPT_EXCLUSIVE_AREA_31/45 (read) reentry_guard_GPT_EXCLUSIVE_AREA_31/45 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_30/142 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_30) @05f9ed20
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_30/43 (read) reentry_guard_GPT_EXCLUSIVE_AREA_30/43 (write) msr_GPT_EXCLUSIVE_AREA_30/42 (read) reentry_guard_GPT_EXCLUSIVE_AREA_30/43 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_30/141 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_30) @05f9e7e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_30/43 (read) msr_GPT_EXCLUSIVE_AREA_30/42 (write) msr_GPT_EXCLUSIVE_AREA_30/42 (read) reentry_guard_GPT_EXCLUSIVE_AREA_30/43 (read) reentry_guard_GPT_EXCLUSIVE_AREA_30/43 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_29/140 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_29) @05f9e2a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_29/41 (read) reentry_guard_GPT_EXCLUSIVE_AREA_29/41 (write) msr_GPT_EXCLUSIVE_AREA_29/40 (read) reentry_guard_GPT_EXCLUSIVE_AREA_29/41 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_29/139 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_29) @05f9eee0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_29/41 (read) msr_GPT_EXCLUSIVE_AREA_29/40 (write) msr_GPT_EXCLUSIVE_AREA_29/40 (read) reentry_guard_GPT_EXCLUSIVE_AREA_29/41 (read) reentry_guard_GPT_EXCLUSIVE_AREA_29/41 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_28/138 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_28) @05f9ec40
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_28/39 (read) reentry_guard_GPT_EXCLUSIVE_AREA_28/39 (write) msr_GPT_EXCLUSIVE_AREA_28/38 (read) reentry_guard_GPT_EXCLUSIVE_AREA_28/39 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_28/137 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_28) @05f9e9a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_28/39 (read) msr_GPT_EXCLUSIVE_AREA_28/38 (write) msr_GPT_EXCLUSIVE_AREA_28/38 (read) reentry_guard_GPT_EXCLUSIVE_AREA_28/39 (read) reentry_guard_GPT_EXCLUSIVE_AREA_28/39 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_27/136 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_27) @05f9e700
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_27/37 (read) reentry_guard_GPT_EXCLUSIVE_AREA_27/37 (write) msr_GPT_EXCLUSIVE_AREA_27/36 (read) reentry_guard_GPT_EXCLUSIVE_AREA_27/37 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_27/135 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_27) @05f9e460
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_27/37 (read) msr_GPT_EXCLUSIVE_AREA_27/36 (write) msr_GPT_EXCLUSIVE_AREA_27/36 (read) reentry_guard_GPT_EXCLUSIVE_AREA_27/37 (read) reentry_guard_GPT_EXCLUSIVE_AREA_27/37 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_26/134 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_26) @05f9e1c0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_26/35 (read) reentry_guard_GPT_EXCLUSIVE_AREA_26/35 (write) msr_GPT_EXCLUSIVE_AREA_26/34 (read) reentry_guard_GPT_EXCLUSIVE_AREA_26/35 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_26/133 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_26) @05f4cd20
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_26/35 (read) msr_GPT_EXCLUSIVE_AREA_26/34 (write) msr_GPT_EXCLUSIVE_AREA_26/34 (read) reentry_guard_GPT_EXCLUSIVE_AREA_26/35 (read) reentry_guard_GPT_EXCLUSIVE_AREA_26/35 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_25/132 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_25) @05f4c7e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_25/33 (read) reentry_guard_GPT_EXCLUSIVE_AREA_25/33 (write) msr_GPT_EXCLUSIVE_AREA_25/32 (read) reentry_guard_GPT_EXCLUSIVE_AREA_25/33 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_25/131 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_25) @05f4c2a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_25/33 (read) msr_GPT_EXCLUSIVE_AREA_25/32 (write) msr_GPT_EXCLUSIVE_AREA_25/32 (read) reentry_guard_GPT_EXCLUSIVE_AREA_25/33 (read) reentry_guard_GPT_EXCLUSIVE_AREA_25/33 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_24/130 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_24) @05f4cee0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_24/31 (read) reentry_guard_GPT_EXCLUSIVE_AREA_24/31 (write) msr_GPT_EXCLUSIVE_AREA_24/30 (read) reentry_guard_GPT_EXCLUSIVE_AREA_24/31 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_24/129 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_24) @05f4cc40
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_24/31 (read) msr_GPT_EXCLUSIVE_AREA_24/30 (write) msr_GPT_EXCLUSIVE_AREA_24/30 (read) reentry_guard_GPT_EXCLUSIVE_AREA_24/31 (read) reentry_guard_GPT_EXCLUSIVE_AREA_24/31 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_23/128 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_23) @05f4c9a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_23/29 (read) reentry_guard_GPT_EXCLUSIVE_AREA_23/29 (write) msr_GPT_EXCLUSIVE_AREA_23/28 (read) reentry_guard_GPT_EXCLUSIVE_AREA_23/29 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_23/127 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_23) @05f4c700
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_23/29 (read) msr_GPT_EXCLUSIVE_AREA_23/28 (write) msr_GPT_EXCLUSIVE_AREA_23/28 (read) reentry_guard_GPT_EXCLUSIVE_AREA_23/29 (read) reentry_guard_GPT_EXCLUSIVE_AREA_23/29 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_22/126 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_22) @05f4c460
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_22/27 (read) reentry_guard_GPT_EXCLUSIVE_AREA_22/27 (write) msr_GPT_EXCLUSIVE_AREA_22/26 (read) reentry_guard_GPT_EXCLUSIVE_AREA_22/27 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_22/125 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_22) @05f4c1c0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_22/27 (read) msr_GPT_EXCLUSIVE_AREA_22/26 (write) msr_GPT_EXCLUSIVE_AREA_22/26 (read) reentry_guard_GPT_EXCLUSIVE_AREA_22/27 (read) reentry_guard_GPT_EXCLUSIVE_AREA_22/27 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_21/124 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_21) @05f47d20
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_21/25 (read) reentry_guard_GPT_EXCLUSIVE_AREA_21/25 (write) msr_GPT_EXCLUSIVE_AREA_21/24 (read) reentry_guard_GPT_EXCLUSIVE_AREA_21/25 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_21/123 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_21) @05f477e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_21/25 (read) msr_GPT_EXCLUSIVE_AREA_21/24 (write) msr_GPT_EXCLUSIVE_AREA_21/24 (read) reentry_guard_GPT_EXCLUSIVE_AREA_21/25 (read) reentry_guard_GPT_EXCLUSIVE_AREA_21/25 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_17/122 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_17) @05f472a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_17/23 (read) reentry_guard_GPT_EXCLUSIVE_AREA_17/23 (write) msr_GPT_EXCLUSIVE_AREA_17/22 (read) reentry_guard_GPT_EXCLUSIVE_AREA_17/23 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_17/121 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_17) @05f47ee0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_17/23 (read) msr_GPT_EXCLUSIVE_AREA_17/22 (write) msr_GPT_EXCLUSIVE_AREA_17/22 (read) reentry_guard_GPT_EXCLUSIVE_AREA_17/23 (read) reentry_guard_GPT_EXCLUSIVE_AREA_17/23 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_12/120 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_12) @05f47c40
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_12/21 (read) reentry_guard_GPT_EXCLUSIVE_AREA_12/21 (write) msr_GPT_EXCLUSIVE_AREA_12/20 (read) reentry_guard_GPT_EXCLUSIVE_AREA_12/21 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_12/119 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_12) @05f479a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_12/21 (read) msr_GPT_EXCLUSIVE_AREA_12/20 (write) msr_GPT_EXCLUSIVE_AREA_12/20 (read) reentry_guard_GPT_EXCLUSIVE_AREA_12/21 (read) reentry_guard_GPT_EXCLUSIVE_AREA_12/21 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_11/118 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_11) @05f47700
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_11/19 (read) reentry_guard_GPT_EXCLUSIVE_AREA_11/19 (write) msr_GPT_EXCLUSIVE_AREA_11/18 (read) reentry_guard_GPT_EXCLUSIVE_AREA_11/19 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_11/117 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_11) @05f47460
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_11/19 (read) msr_GPT_EXCLUSIVE_AREA_11/18 (write) msr_GPT_EXCLUSIVE_AREA_11/18 (read) reentry_guard_GPT_EXCLUSIVE_AREA_11/19 (read) reentry_guard_GPT_EXCLUSIVE_AREA_11/19 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_10/116 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_10) @05f471c0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_10/17 (read) reentry_guard_GPT_EXCLUSIVE_AREA_10/17 (write) msr_GPT_EXCLUSIVE_AREA_10/16 (read) reentry_guard_GPT_EXCLUSIVE_AREA_10/17 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_10/115 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_10) @05f0ad20
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_10/17 (read) msr_GPT_EXCLUSIVE_AREA_10/16 (write) msr_GPT_EXCLUSIVE_AREA_10/16 (read) reentry_guard_GPT_EXCLUSIVE_AREA_10/17 (read) reentry_guard_GPT_EXCLUSIVE_AREA_10/17 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_07/114 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_07) @05f0a7e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_07/15 (read) reentry_guard_GPT_EXCLUSIVE_AREA_07/15 (write) msr_GPT_EXCLUSIVE_AREA_07/14 (read) reentry_guard_GPT_EXCLUSIVE_AREA_07/15 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_07/113 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_07) @05f0a2a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_07/15 (read) msr_GPT_EXCLUSIVE_AREA_07/14 (write) msr_GPT_EXCLUSIVE_AREA_07/14 (read) reentry_guard_GPT_EXCLUSIVE_AREA_07/15 (read) reentry_guard_GPT_EXCLUSIVE_AREA_07/15 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_06/112 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_06) @05f0aee0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_06/13 (read) reentry_guard_GPT_EXCLUSIVE_AREA_06/13 (write) msr_GPT_EXCLUSIVE_AREA_06/12 (read) reentry_guard_GPT_EXCLUSIVE_AREA_06/13 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_06/111 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_06) @05f0ac40
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_06/13 (read) msr_GPT_EXCLUSIVE_AREA_06/12 (write) msr_GPT_EXCLUSIVE_AREA_06/12 (read) reentry_guard_GPT_EXCLUSIVE_AREA_06/13 (read) reentry_guard_GPT_EXCLUSIVE_AREA_06/13 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_05/110 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_05) @05f0a9a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_05/11 (read) reentry_guard_GPT_EXCLUSIVE_AREA_05/11 (write) msr_GPT_EXCLUSIVE_AREA_05/10 (read) reentry_guard_GPT_EXCLUSIVE_AREA_05/11 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_05/109 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_05) @05f0a700
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_05/11 (read) msr_GPT_EXCLUSIVE_AREA_05/10 (write) msr_GPT_EXCLUSIVE_AREA_05/10 (read) reentry_guard_GPT_EXCLUSIVE_AREA_05/11 (read) reentry_guard_GPT_EXCLUSIVE_AREA_05/11 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_04/108 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_04) @05f0a460
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_04/9 (read) reentry_guard_GPT_EXCLUSIVE_AREA_04/9 (write) msr_GPT_EXCLUSIVE_AREA_04/8 (read) reentry_guard_GPT_EXCLUSIVE_AREA_04/9 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_04/107 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_04) @05f0a1c0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_04/9 (read) msr_GPT_EXCLUSIVE_AREA_04/8 (write) msr_GPT_EXCLUSIVE_AREA_04/8 (read) reentry_guard_GPT_EXCLUSIVE_AREA_04/9 (read) reentry_guard_GPT_EXCLUSIVE_AREA_04/9 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_03/106 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_03) @05f05ee0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_03/7 (read) reentry_guard_GPT_EXCLUSIVE_AREA_03/7 (write) msr_GPT_EXCLUSIVE_AREA_03/6 (read) reentry_guard_GPT_EXCLUSIVE_AREA_03/7 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_03/105 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_03) @05f059a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_03/7 (read) msr_GPT_EXCLUSIVE_AREA_03/6 (write) msr_GPT_EXCLUSIVE_AREA_03/6 (read) reentry_guard_GPT_EXCLUSIVE_AREA_03/7 (read) reentry_guard_GPT_EXCLUSIVE_AREA_03/7 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_02/104 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_02) @05f05460
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_02/5 (read) reentry_guard_GPT_EXCLUSIVE_AREA_02/5 (write) msr_GPT_EXCLUSIVE_AREA_02/4 (read) reentry_guard_GPT_EXCLUSIVE_AREA_02/5 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_02/103 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_02) @05f05e00
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_02/5 (read) msr_GPT_EXCLUSIVE_AREA_02/4 (write) msr_GPT_EXCLUSIVE_AREA_02/4 (read) reentry_guard_GPT_EXCLUSIVE_AREA_02/5 (read) reentry_guard_GPT_EXCLUSIVE_AREA_02/5 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_01/102 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_01) @05f05b60
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_01/3 (read) reentry_guard_GPT_EXCLUSIVE_AREA_01/3 (write) msr_GPT_EXCLUSIVE_AREA_01/2 (read) reentry_guard_GPT_EXCLUSIVE_AREA_01/3 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_01/101 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_01) @05f058c0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_01/3 (read) msr_GPT_EXCLUSIVE_AREA_01/2 (write) msr_GPT_EXCLUSIVE_AREA_01/2 (read) reentry_guard_GPT_EXCLUSIVE_AREA_01/3 (read) reentry_guard_GPT_EXCLUSIVE_AREA_01/3 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_00/100 (SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_00) @05f05620
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_00/1 (read) reentry_guard_GPT_EXCLUSIVE_AREA_00/1 (write) msr_GPT_EXCLUSIVE_AREA_00/0 (read) reentry_guard_GPT_EXCLUSIVE_AREA_00/1 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_00/99 (SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_00) @05f05380
  Type: function definition analyzed
  Visibility: externally_visible public
  References: reentry_guard_GPT_EXCLUSIVE_AREA_00/1 (read) msr_GPT_EXCLUSIVE_AREA_00/0 (write) msr_GPT_EXCLUSIVE_AREA_00/0 (read) reentry_guard_GPT_EXCLUSIVE_AREA_00/1 (read) reentry_guard_GPT_EXCLUSIVE_AREA_00/1 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Sys_GetCoreID/197 (1073741824 (estimated locally),1.00 per call) 
Gpt_schm_read_msr/98 (Gpt_schm_read_msr) @05effe00
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 
reentry_guard_GPT_EXCLUSIVE_AREA_67/97 (reentry_guard_GPT_EXCLUSIVE_AREA_67) @05ebf798
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_67/195 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_67/195 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_67/195 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_67/196 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_67/196 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_67/196 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_67/96 (msr_GPT_EXCLUSIVE_AREA_67) @05ebf708
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_67/195 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_67/195 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_67/196 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_66/95 (reentry_guard_GPT_EXCLUSIVE_AREA_66) @05ebf678
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_66/193 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_66/193 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_66/193 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_66/194 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_66/194 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_66/194 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_66/94 (msr_GPT_EXCLUSIVE_AREA_66) @05ebf5e8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_66/193 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_66/193 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_66/194 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_65/93 (reentry_guard_GPT_EXCLUSIVE_AREA_65) @05ebf558
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_65/191 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_65/191 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_65/191 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_65/192 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_65/192 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_65/192 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_65/92 (msr_GPT_EXCLUSIVE_AREA_65) @05ebf4c8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_65/191 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_65/191 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_65/192 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_64/91 (reentry_guard_GPT_EXCLUSIVE_AREA_64) @05ebf438
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_64/189 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_64/189 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_64/189 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_64/190 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_64/190 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_64/190 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_64/90 (msr_GPT_EXCLUSIVE_AREA_64) @05ebf3a8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_64/189 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_64/189 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_64/190 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_63/89 (reentry_guard_GPT_EXCLUSIVE_AREA_63) @05ebf318
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_63/187 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_63/187 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_63/187 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_63/188 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_63/188 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_63/188 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_63/88 (msr_GPT_EXCLUSIVE_AREA_63) @05ebf288
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_63/187 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_63/187 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_63/188 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_62/87 (reentry_guard_GPT_EXCLUSIVE_AREA_62) @05ebf1f8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_62/185 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_62/185 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_62/185 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_62/186 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_62/186 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_62/186 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_62/86 (msr_GPT_EXCLUSIVE_AREA_62) @05ebf168
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_62/185 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_62/185 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_62/186 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_61/85 (reentry_guard_GPT_EXCLUSIVE_AREA_61) @05ebf0d8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_61/183 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_61/183 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_61/183 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_61/184 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_61/184 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_61/184 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_61/84 (msr_GPT_EXCLUSIVE_AREA_61) @05ebf048
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_61/183 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_61/183 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_61/184 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_60/83 (reentry_guard_GPT_EXCLUSIVE_AREA_60) @05ebdf78
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_60/181 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_60/181 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_60/181 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_60/182 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_60/182 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_60/182 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_60/82 (msr_GPT_EXCLUSIVE_AREA_60) @05ebdee8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_60/181 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_60/181 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_60/182 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_56/81 (reentry_guard_GPT_EXCLUSIVE_AREA_56) @05ebde58
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_56/179 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_56/179 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_56/179 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_56/180 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_56/180 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_56/180 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_56/80 (msr_GPT_EXCLUSIVE_AREA_56) @05ebddc8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_56/179 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_56/179 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_56/180 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_55/79 (reentry_guard_GPT_EXCLUSIVE_AREA_55) @05ebdd38
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_55/177 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_55/177 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_55/177 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_55/178 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_55/178 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_55/178 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_55/78 (msr_GPT_EXCLUSIVE_AREA_55) @05ebdca8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_55/177 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_55/177 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_55/178 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_54/77 (reentry_guard_GPT_EXCLUSIVE_AREA_54) @05ebdc18
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_54/175 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_54/175 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_54/175 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_54/176 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_54/176 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_54/176 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_54/76 (msr_GPT_EXCLUSIVE_AREA_54) @05ebdb88
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_54/175 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_54/175 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_54/176 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_53/75 (reentry_guard_GPT_EXCLUSIVE_AREA_53) @05ebdaf8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_53/173 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_53/173 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_53/173 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_53/174 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_53/174 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_53/174 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_53/74 (msr_GPT_EXCLUSIVE_AREA_53) @05ebda68
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_53/173 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_53/173 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_53/174 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_52/73 (reentry_guard_GPT_EXCLUSIVE_AREA_52) @05ebd9d8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_52/171 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_52/171 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_52/171 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_52/172 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_52/172 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_52/172 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_52/72 (msr_GPT_EXCLUSIVE_AREA_52) @05ebd948
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_52/171 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_52/171 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_52/172 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_51/71 (reentry_guard_GPT_EXCLUSIVE_AREA_51) @05ebd8b8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_51/169 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_51/169 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_51/169 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_51/170 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_51/170 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_51/170 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_51/70 (msr_GPT_EXCLUSIVE_AREA_51) @05ebd828
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_51/169 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_51/169 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_51/170 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_50/69 (reentry_guard_GPT_EXCLUSIVE_AREA_50) @05ebd798
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_50/167 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_50/167 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_50/167 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_50/168 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_50/168 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_50/168 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_50/68 (msr_GPT_EXCLUSIVE_AREA_50) @05ebd708
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_50/167 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_50/167 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_50/168 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_46/67 (reentry_guard_GPT_EXCLUSIVE_AREA_46) @05ebd678
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_46/165 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_46/165 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_46/165 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_46/166 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_46/166 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_46/166 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_46/66 (msr_GPT_EXCLUSIVE_AREA_46) @05ebd5e8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_46/165 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_46/165 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_46/166 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_45/65 (reentry_guard_GPT_EXCLUSIVE_AREA_45) @05ebd558
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_45/163 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_45/163 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_45/163 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_45/164 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_45/164 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_45/164 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_45/64 (msr_GPT_EXCLUSIVE_AREA_45) @05ebd4c8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_45/163 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_45/163 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_45/164 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_44/63 (reentry_guard_GPT_EXCLUSIVE_AREA_44) @05ebd438
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_44/161 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_44/161 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_44/161 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_44/162 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_44/162 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_44/162 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_44/62 (msr_GPT_EXCLUSIVE_AREA_44) @05ebd3a8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_44/161 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_44/161 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_44/162 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_43/61 (reentry_guard_GPT_EXCLUSIVE_AREA_43) @05ebd318
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_43/159 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_43/159 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_43/159 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_43/160 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_43/160 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_43/160 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_43/60 (msr_GPT_EXCLUSIVE_AREA_43) @05ebd288
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_43/159 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_43/159 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_43/160 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_42/59 (reentry_guard_GPT_EXCLUSIVE_AREA_42) @05ebd1f8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_42/157 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_42/157 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_42/157 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_42/158 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_42/158 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_42/158 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_42/58 (msr_GPT_EXCLUSIVE_AREA_42) @05ebd168
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_42/157 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_42/157 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_42/158 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_41/57 (reentry_guard_GPT_EXCLUSIVE_AREA_41) @05ebd0d8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_41/155 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_41/155 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_41/155 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_41/156 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_41/156 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_41/156 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_41/56 (msr_GPT_EXCLUSIVE_AREA_41) @05ebd048
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_41/155 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_41/155 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_41/156 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_40/55 (reentry_guard_GPT_EXCLUSIVE_AREA_40) @05eb7f78
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_40/153 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_40/153 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_40/153 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_40/154 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_40/154 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_40/154 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_40/54 (msr_GPT_EXCLUSIVE_AREA_40) @05eb7ee8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_40/153 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_40/153 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_40/154 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_39/53 (reentry_guard_GPT_EXCLUSIVE_AREA_39) @05eb7e58
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_39/151 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_39/151 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_39/151 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_39/152 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_39/152 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_39/152 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_39/52 (msr_GPT_EXCLUSIVE_AREA_39) @05eb7dc8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_39/151 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_39/151 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_39/152 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_38/51 (reentry_guard_GPT_EXCLUSIVE_AREA_38) @05eb7d38
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_38/149 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_38/149 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_38/149 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_38/150 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_38/150 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_38/150 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_38/50 (msr_GPT_EXCLUSIVE_AREA_38) @05eb7ca8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_38/149 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_38/149 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_38/150 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_36/49 (reentry_guard_GPT_EXCLUSIVE_AREA_36) @05eb7c18
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_36/147 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_36/147 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_36/147 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_36/148 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_36/148 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_36/148 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_36/48 (msr_GPT_EXCLUSIVE_AREA_36) @05eb7b88
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_36/147 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_36/147 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_36/148 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_35/47 (reentry_guard_GPT_EXCLUSIVE_AREA_35) @05eb7af8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_35/145 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_35/145 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_35/145 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_35/146 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_35/146 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_35/146 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_35/46 (msr_GPT_EXCLUSIVE_AREA_35) @05eb7a68
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_35/145 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_35/145 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_35/146 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_31/45 (reentry_guard_GPT_EXCLUSIVE_AREA_31) @05eb79d8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_31/143 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_31/143 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_31/143 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_31/144 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_31/144 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_31/144 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_31/44 (msr_GPT_EXCLUSIVE_AREA_31) @05eb7948
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_31/143 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_31/143 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_31/144 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_30/43 (reentry_guard_GPT_EXCLUSIVE_AREA_30) @05eb78b8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_30/141 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_30/141 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_30/141 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_30/142 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_30/142 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_30/142 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_30/42 (msr_GPT_EXCLUSIVE_AREA_30) @05eb7828
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_30/141 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_30/141 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_30/142 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_29/41 (reentry_guard_GPT_EXCLUSIVE_AREA_29) @05eb7798
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_29/139 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_29/139 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_29/139 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_29/140 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_29/140 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_29/140 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_29/40 (msr_GPT_EXCLUSIVE_AREA_29) @05eb7708
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_29/139 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_29/139 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_29/140 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_28/39 (reentry_guard_GPT_EXCLUSIVE_AREA_28) @05eb7678
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_28/137 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_28/137 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_28/137 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_28/138 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_28/138 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_28/138 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_28/38 (msr_GPT_EXCLUSIVE_AREA_28) @05eb75e8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_28/137 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_28/137 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_28/138 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_27/37 (reentry_guard_GPT_EXCLUSIVE_AREA_27) @05eb7558
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_27/135 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_27/135 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_27/135 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_27/136 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_27/136 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_27/136 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_27/36 (msr_GPT_EXCLUSIVE_AREA_27) @05eb74c8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_27/135 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_27/135 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_27/136 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_26/35 (reentry_guard_GPT_EXCLUSIVE_AREA_26) @05eb7438
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_26/133 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_26/133 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_26/133 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_26/134 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_26/134 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_26/134 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_26/34 (msr_GPT_EXCLUSIVE_AREA_26) @05eb73a8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_26/133 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_26/133 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_26/134 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_25/33 (reentry_guard_GPT_EXCLUSIVE_AREA_25) @05eb7318
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_25/131 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_25/131 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_25/131 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_25/132 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_25/132 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_25/132 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_25/32 (msr_GPT_EXCLUSIVE_AREA_25) @05eb7288
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_25/131 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_25/131 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_25/132 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_24/31 (reentry_guard_GPT_EXCLUSIVE_AREA_24) @05eb71f8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_24/129 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_24/129 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_24/129 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_24/130 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_24/130 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_24/130 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_24/30 (msr_GPT_EXCLUSIVE_AREA_24) @05eb7168
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_24/129 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_24/129 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_24/130 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_23/29 (reentry_guard_GPT_EXCLUSIVE_AREA_23) @05eb70d8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_23/127 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_23/127 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_23/127 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_23/128 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_23/128 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_23/128 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_23/28 (msr_GPT_EXCLUSIVE_AREA_23) @05eb7048
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_23/127 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_23/127 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_23/128 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_22/27 (reentry_guard_GPT_EXCLUSIVE_AREA_22) @05eb2f78
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_22/125 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_22/125 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_22/125 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_22/126 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_22/126 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_22/126 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_22/26 (msr_GPT_EXCLUSIVE_AREA_22) @05eb2ee8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_22/125 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_22/125 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_22/126 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_21/25 (reentry_guard_GPT_EXCLUSIVE_AREA_21) @05eb2e58
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_21/123 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_21/123 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_21/123 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_21/124 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_21/124 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_21/124 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_21/24 (msr_GPT_EXCLUSIVE_AREA_21) @05eb2dc8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_21/123 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_21/123 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_21/124 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_17/23 (reentry_guard_GPT_EXCLUSIVE_AREA_17) @05eb2d38
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_17/121 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_17/121 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_17/121 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_17/122 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_17/122 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_17/122 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_17/22 (msr_GPT_EXCLUSIVE_AREA_17) @05eb2ca8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_17/121 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_17/121 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_17/122 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_12/21 (reentry_guard_GPT_EXCLUSIVE_AREA_12) @05eb2c18
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_12/119 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_12/119 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_12/119 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_12/120 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_12/120 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_12/120 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_12/20 (msr_GPT_EXCLUSIVE_AREA_12) @05eb2b88
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_12/119 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_12/119 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_12/120 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_11/19 (reentry_guard_GPT_EXCLUSIVE_AREA_11) @05eb2af8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_11/117 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_11/117 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_11/117 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_11/118 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_11/118 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_11/118 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_11/18 (msr_GPT_EXCLUSIVE_AREA_11) @05eb2a68
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_11/117 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_11/117 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_11/118 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_10/17 (reentry_guard_GPT_EXCLUSIVE_AREA_10) @05eb29d8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_10/115 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_10/115 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_10/115 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_10/116 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_10/116 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_10/116 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_10/16 (msr_GPT_EXCLUSIVE_AREA_10) @05eb2948
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_10/115 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_10/115 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_10/116 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_07/15 (reentry_guard_GPT_EXCLUSIVE_AREA_07) @05eb28b8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_07/113 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_07/113 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_07/113 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_07/114 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_07/114 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_07/114 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_07/14 (msr_GPT_EXCLUSIVE_AREA_07) @05eb2828
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_07/113 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_07/113 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_07/114 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_06/13 (reentry_guard_GPT_EXCLUSIVE_AREA_06) @05eb2798
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_06/111 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_06/111 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_06/111 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_06/112 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_06/112 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_06/112 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_06/12 (msr_GPT_EXCLUSIVE_AREA_06) @05eb2708
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_06/111 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_06/111 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_06/112 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_05/11 (reentry_guard_GPT_EXCLUSIVE_AREA_05) @05eb2678
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_05/109 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_05/109 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_05/109 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_05/110 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_05/110 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_05/110 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_05/10 (msr_GPT_EXCLUSIVE_AREA_05) @05eb25e8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_05/109 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_05/109 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_05/110 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_04/9 (reentry_guard_GPT_EXCLUSIVE_AREA_04) @05eb2558
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_04/107 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_04/107 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_04/107 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_04/108 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_04/108 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_04/108 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_04/8 (msr_GPT_EXCLUSIVE_AREA_04) @05eb24c8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_04/107 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_04/107 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_04/108 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_03/7 (reentry_guard_GPT_EXCLUSIVE_AREA_03) @05eb2438
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_03/105 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_03/105 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_03/105 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_03/106 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_03/106 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_03/106 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_03/6 (msr_GPT_EXCLUSIVE_AREA_03) @05eb23a8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_03/105 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_03/105 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_03/106 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_02/5 (reentry_guard_GPT_EXCLUSIVE_AREA_02) @05eb2318
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_02/103 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_02/103 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_02/103 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_02/104 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_02/104 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_02/104 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_02/4 (msr_GPT_EXCLUSIVE_AREA_02) @05eb2288
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_02/103 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_02/103 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_02/104 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_01/3 (reentry_guard_GPT_EXCLUSIVE_AREA_01) @05eb21f8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_01/101 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_01/101 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_01/101 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_01/102 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_01/102 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_01/102 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_01/2 (msr_GPT_EXCLUSIVE_AREA_01) @05eb2168
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_01/101 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_01/101 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_01/102 (read) 
  Availability: available
  Varpool flags:
reentry_guard_GPT_EXCLUSIVE_AREA_00/1 (reentry_guard_GPT_EXCLUSIVE_AREA_00) @05eb20d8
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_00/99 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_00/99 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_00/99 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_00/100 (read) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_00/100 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_00/100 (read) 
  Availability: available
  Varpool flags:
msr_GPT_EXCLUSIVE_AREA_00/0 (msr_GPT_EXCLUSIVE_AREA_00) @05eb2048
  Type: variable definition analyzed
  Visibility: force_output prevailing_def_ironly
  References: 
  Referring: SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_00/99 (read) SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_00/99 (write) SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_00/100 (read) 
  Availability: available
  Varpool flags:
SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_67 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_67[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_67[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_67[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_67[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_67 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_67[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_67[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_67[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_67[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_67[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_66 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_66[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_66[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_66[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_66[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_66 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_66[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_66[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_66[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_66[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_66[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_65 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_65[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_65[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_65[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_65[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_65 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_65[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_65[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_65[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_65[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_65[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_64 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_64[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_64[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_64[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_64[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_64 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_64[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_64[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_64[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_64[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_64[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_63 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_63[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_63[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_63[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_63[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_63 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_63[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_63[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_63[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_63[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_63[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_62 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_62[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_62[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_62[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_62[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_62 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_62[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_62[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_62[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_62[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_62[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_61 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_61[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_61[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_61[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_61[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_61 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_61[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_61[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_61[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_61[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_61[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_60 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_60[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_60[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_60[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_60[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_60 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_60[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_60[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_60[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_60[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_60[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_56 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_56[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_56[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_56[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_56[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_56 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_56[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_56[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_56[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_56[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_56[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_55 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_55[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_55[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_55[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_55[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_55 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_55[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_55[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_55[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_55[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_55[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_54 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_54[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_54[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_54[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_54[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_54 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_54[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_54[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_54[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_54[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_54[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_53 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_53[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_53[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_53[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_53[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_53 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_53[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_53[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_53[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_53[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_53[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_52 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_52[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_52[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_52[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_52[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_52 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_52[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_52[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_52[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_52[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_52[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_51 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_51[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_51[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_51[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_51[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_51 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_51[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_51[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_51[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_51[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_51[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_50 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_50[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_50[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_50[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_50[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_50 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_50[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_50[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_50[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_50[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_50[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_46 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_46[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_46[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_46[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_46[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_46 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_46[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_46[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_46[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_46[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_46[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_45 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_45[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_45[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_45[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_45[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_45 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_45[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_45[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_45[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_45[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_45[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_44 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_44[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_44[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_44[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_44[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_44 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_44[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_44[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_44[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_44[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_44[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_43 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_43[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_43[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_43[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_43[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_43 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_43[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_43[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_43[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_43[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_43[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_42 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_42[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_42[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_42[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_42[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_42 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_42[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_42[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_42[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_42[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_42[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_41 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_41[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_41[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_41[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_41[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_41 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_41[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_41[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_41[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_41[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_41[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_40 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_40[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_40[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_40[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_40[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_40 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_40[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_40[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_40[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_40[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_40[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_39 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_39[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_39[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_39[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_39[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_39 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_39[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_39[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_39[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_39[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_39[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_38 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_38[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_38[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_38[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_38[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_38 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_38[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_38[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_38[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_38[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_38[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_36 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_36[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_36[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_36[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_36[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_36 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_36[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_36[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_36[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_36[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_36[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_35 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_35[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_35[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_35[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_35[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_35 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_35[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_35[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_35[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_35[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_35[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_31 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_31[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_31[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_31[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_31[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_31 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_31[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_31[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_31[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_31[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_31[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_30 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_30[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_30[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_30[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_30[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_30 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_30[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_30[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_30[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_30[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_30[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_29 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_29[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_29[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_29[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_29[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_29 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_29[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_29[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_29[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_29[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_29[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_28 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_28[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_28[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_28[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_28[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_28 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_28[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_28[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_28[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_28[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_28[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_27 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_27[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_27[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_27[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_27[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_27 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_27[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_27[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_27[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_27[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_27[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_26 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_26[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_26[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_26[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_26[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_26 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_26[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_26[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_26[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_26[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_26[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_25 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_25[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_25[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_25[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_25[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_25 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_25[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_25[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_25[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_25[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_25[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_24 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_24[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_24[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_24[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_24[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_24 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_24[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_24[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_24[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_24[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_24[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_23 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_23[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_23[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_23[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_23[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_23 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_23[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_23[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_23[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_23[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_23[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_22 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_22[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_22[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_22[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_22[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_22 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_22[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_22[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_22[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_22[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_22[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_21 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_21[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_21[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_21[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_21[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_21 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_21[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_21[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_21[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_21[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_21[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_17 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_17[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_17[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_17[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_17[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_17 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_17[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_17[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_17[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_17[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_17[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_12 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_12[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_12[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_12[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_12[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_12 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_12[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_12[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_12[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_12[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_12[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_11 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_11[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_11[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_11[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_11[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_11 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_11[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_11[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_11[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_11[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_11[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_10 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_10[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_10[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_10[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_10[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_10 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_10[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_10[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_10[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_10[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_10[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_07 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_07[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_07[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_07[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_07[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_07 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_07[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_07[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_07[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_07[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_07[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_06 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_06[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_06[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_06[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_06[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_06 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_06[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_06[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_06[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_06[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_06[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_05 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_05[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_05[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_05[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_05[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_05 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_05[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_05[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_05[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_05[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_05[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_04 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_04[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_04[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_04[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_04[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_04 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_04[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_04[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_04[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_04[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_04[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_03 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_03[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_03[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_03[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_03[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_03 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_03[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_03[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_03[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_03[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_03[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_02 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_02[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_02[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_02[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_02[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_02 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_02[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_02[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_02[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_02[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_02[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_01 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_01[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_01[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_01[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_01[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_01 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_01[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_01[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_01[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_01[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_01[u32CoreId_10] ={v} _6;
  return;

}


SchM_Exit_Gpt_GPT_EXCLUSIVE_AREA_00 ()
{
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_00[u32CoreId_10];
  _3 = _2 + 4294967295;
  reentry_guard_GPT_EXCLUSIVE_AREA_00[u32CoreId_10] ={v} _3;
  # DEBUG BEGIN_STMT
  _4 ={v} msr_GPT_EXCLUSIVE_AREA_00[u32CoreId_10];
  _5 = _4 & 1;
  if (_5 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  _6 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_00[u32CoreId_10];
  if (_6 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsie i");

  <bb 5> [local count: 1073741824]:
  return;

}


SchM_Enter_Gpt_GPT_EXCLUSIVE_AREA_00 ()
{
  register uint32 reg_tmp;
  uint32 u32CoreId;
  unsigned char _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Sys_GetCoreID ();
  u32CoreId_10 = (uint32) _1;
  # DEBUG u32CoreId => u32CoreId_10
  # DEBUG BEGIN_STMT
  _2 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_00[u32CoreId_10];
  if (_2 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  # DEBUG INLINE_ENTRY Gpt_schm_read_msr
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_14);
  # DEBUG reg_tmp => reg_tmp_14
  # DEBUG BEGIN_STMT
  # DEBUG reg_tmp => NULL
  msr_GPT_EXCLUSIVE_AREA_00[u32CoreId_10] ={v} reg_tmp_14;
  # DEBUG BEGIN_STMT
  _3 ={v} msr_GPT_EXCLUSIVE_AREA_00[u32CoreId_10];
  _4 = _3 & 1;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" cpsid i");

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _5 ={v} reentry_guard_GPT_EXCLUSIVE_AREA_00[u32CoreId_10];
  _6 = _5 + 1;
  reentry_guard_GPT_EXCLUSIVE_AREA_00[u32CoreId_10] ={v} _6;
  return;

}


Gpt_schm_read_msr ()
{
  register uint32 reg_tmp;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__(" mrs %0, primask " : "=r" reg_tmp_1);
  # DEBUG reg_tmp => reg_tmp_1
  # DEBUG BEGIN_STMT
  return reg_tmp_1;

}


