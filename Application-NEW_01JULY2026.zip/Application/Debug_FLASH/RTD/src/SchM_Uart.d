RTD/src/SchM_Uart.o: ../RTD/src/SchM_Uart.c \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Std_Types.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Platform_Types.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/PlatformTypes.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler_Cfg.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/CompilerDefinition.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcal.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Soc_Ips.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/IpVersionMacros.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Reg_eSys.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/OsIf_Internal.h \
 C\:/Users/user/workspaceS32DS.3.6.3/Application.zip_expanded/Application/generate/include/OsIf_Cfg.h \
 C\:/Users/user/workspaceS32DS.3.6.3/Application.zip_expanded/Application/generate/include/OsIf_ArchCfg.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SYSTICK.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_COMMON.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/BasicTypes.h \
 ../RTD/include/OsIf.h ../RTD/include/OsIf_Internal.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Base_MemMap.h \
 ../RTD/include/SchM_Uart.h \
 C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Rte_MemMap.h
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Std_Types.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Platform_Types.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/PlatformTypes.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler_Cfg.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/CompilerDefinition.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcal.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Soc_Ips.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/IpVersionMacros.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Reg_eSys.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/OsIf_Internal.h:
C\:/Users/user/workspaceS32DS.3.6.3/Application.zip_expanded/Application/generate/include/OsIf_Cfg.h:
C\:/Users/user/workspaceS32DS.3.6.3/Application.zip_expanded/Application/generate/include/OsIf_ArchCfg.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SYSTICK.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_COMMON.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/BasicTypes.h:
../RTD/include/OsIf.h:
../RTD/include/OsIf_Internal.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Base_MemMap.h:
../RTD/include/SchM_Uart.h:
C\:/NXP/S32DS.3.6.3/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Rte_MemMap.h:
