Creating summary for Tspc_Port_Ip_ConfigureObeGroup/2:
  Descriptor for parameter 0 cfgCountD.6345
    not a candidate for splitting
  Descriptor for parameter 1 configD.6346
    not a candidate for splitting


Creating summary for Tspc_Port_Ip_EnableObeGroup/1:
  Descriptor for parameter 0 groupD.6341
    not a candidate for splitting


Creating summary for DevAssert/0:
  Descriptor for parameter 0 xD.6220
    not a candidate for splitting



========== IPA-SRA IPA stage ==========

Summary for node Tspc_Port_Ip_ConfigureObeGroup/2:
  Descriptor for parameter 0:
    not a candidate for splitting
  Descriptor for parameter 1:
    not a candidate for splitting

  Summary for edge Tspc_Port_Ip_ConfigureObeGroup/2->SchM_Exit_Port_PORT_EXCLUSIVE_AREA_10/6:
    return value ignored
  Summary for edge Tspc_Port_Ip_ConfigureObeGroup/2->SchM_Enter_Port_PORT_EXCLUSIVE_AREA_10/5:
    return value ignored
  Summary for edge Tspc_Port_Ip_ConfigureObeGroup/2->DevAssert/0:
    return value ignored
  Summary for edge Tspc_Port_Ip_ConfigureObeGroup/2->DevAssert/0:
    return value ignored

Summary for node Tspc_Port_Ip_EnableObeGroup/1:
  Descriptor for parameter 0:
    not a candidate for splitting

  Summary for edge Tspc_Port_Ip_EnableObeGroup/1->SchM_Exit_Port_PORT_EXCLUSIVE_AREA_09/4:
    return value ignored
  Summary for edge Tspc_Port_Ip_EnableObeGroup/1->SchM_Enter_Port_PORT_EXCLUSIVE_AREA_09/3:
    return value ignored
  Summary for edge Tspc_Port_Ip_EnableObeGroup/1->DevAssert/0:
    return value ignored

Summary for node DevAssert/0:
  Descriptor for parameter 0:
    not a candidate for splitting



Function Tspc_Port_Ip_EnableObeGroup/1 disqualified because it cannot be made local.
Function Tspc_Port_Ip_ConfigureObeGroup/2 disqualified because it cannot be made local.

========== IPA-SRA decisions ==========

========== IPA SRA IPA analysis done ==========


Reclaiming functions:
Reclaiming variables:
Clearing address taken flags:
Symbol table:

SchM_Exit_Port_PORT_EXCLUSIVE_AREA_10/6 (SchM_Exit_Port_PORT_EXCLUSIVE_AREA_10) @06096ee0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Tspc_Port_Ip_ConfigureObeGroup/2 (118111600 (estimated locally),1.00 per call) 
  Calls: 
SchM_Enter_Port_PORT_EXCLUSIVE_AREA_10/5 (SchM_Enter_Port_PORT_EXCLUSIVE_AREA_10) @06096380
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Tspc_Port_Ip_ConfigureObeGroup/2 (118111600 (estimated locally),1.00 per call) 
  Calls: 
SchM_Exit_Port_PORT_EXCLUSIVE_AREA_09/4 (SchM_Exit_Port_PORT_EXCLUSIVE_AREA_09) @06096d20
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Tspc_Port_Ip_EnableObeGroup/1 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
SchM_Enter_Port_PORT_EXCLUSIVE_AREA_09/3 (SchM_Enter_Port_PORT_EXCLUSIVE_AREA_09) @06096c40
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Tspc_Port_Ip_EnableObeGroup/1 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Tspc_Port_Ip_ConfigureObeGroup/2 (Tspc_Port_Ip_ConfigureObeGroup) @06096700
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:118111600 (estimated locally) body optimize_size
  Called by: 
  Calls: SchM_Exit_Port_PORT_EXCLUSIVE_AREA_10/6 (118111600 (estimated locally),1.00 per call) SchM_Enter_Port_PORT_EXCLUSIVE_AREA_10/5 (118111600 (estimated locally),1.00 per call) DevAssert/0 (955630225 (estimated locally),8.09 per call) DevAssert/0 (118111600 (estimated locally),1.00 per call) 
Tspc_Port_Ip_EnableObeGroup/1 (Tspc_Port_Ip_EnableObeGroup) @060962a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: SchM_Exit_Port_PORT_EXCLUSIVE_AREA_09/4 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Port_PORT_EXCLUSIVE_AREA_09/3 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) 
DevAssert/0 (DevAssert) @060a8620
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:21262216 (estimated locally) body local optimize_size
  Called by: Tspc_Port_Ip_ConfigureObeGroup/2 (955630225 (estimated locally),8.09 per call) Tspc_Port_Ip_ConfigureObeGroup/2 (118111600 (estimated locally),1.00 per call) Tspc_Port_Ip_EnableObeGroup/1 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Tspc_Port_Ip_ConfigureObeGroup (uint32 cfgCount, const struct Tspc_Port_Ip_ObeGroupConfig * config)
{
  uint8 groupConfig;
  uint32 i;
  _Bool _1;
  long unsigned int _2;
  const struct Tspc_Port_Ip_ObeGroupConfig * _3;
  unsigned char _4;
  _Bool _5;
  unsigned char _6;
  long unsigned int _7;
  long unsigned int _8;
  long unsigned int _9;
  long unsigned int _10;
  long unsigned int _11;
  const struct Tspc_Port_Ip_ObeGroupConfig * _12;
  unsigned char _13;
  long unsigned int _14;
  unsigned int _15;
  unsigned int _16;
  long unsigned int _17;
  long unsigned int _18;
  long unsigned int _19;
  long unsigned int _20;
  unsigned int _21;
  unsigned int _22;
  long unsigned int _23;
  long unsigned int _24;
  long unsigned int _25;
  long unsigned int _26;
  long unsigned int _28;

  <bb 2> [local count: 118111600]:
  # DEBUG BEGIN_STMT
  _1 = config_35(D) != 0B;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  # DEBUG tspcBase => 1076641792B
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG groupConfig => 0
  # DEBUG BEGIN_STMT
  # DEBUG i => 0
  goto <bb 4>; [100.00%]

  <bb 3> [local count: 955630225]:
  # DEBUG BEGIN_STMT
  _2 = i_29 * 8;
  _3 = config_35(D) + _2;
  _4 = _3->obeGroupSelect;
  _5 = _4 <= 2;
  DevAssert (_5);
  # DEBUG BEGIN_STMT
  _6 = _3->obeGroupSelect;
  groupConfig_47 = _6 | groupConfig_31;
  # DEBUG groupConfig => groupConfig_47
  # DEBUG BEGIN_STMT
  i_48 = i_29 + 1;
  # DEBUG i => i_48

  <bb 4> [local count: 1073741824]:
  # i_29 = PHI <0(2), i_48(3)>
  # groupConfig_31 = PHI <0(2), groupConfig_47(3)>
  # DEBUG groupConfig => groupConfig_31
  # DEBUG i => i_29
  # DEBUG BEGIN_STMT
  if (i_29 < cfgCount_38(D))
    goto <bb 3>; [89.00%]
  else
    goto <bb 5>; [11.00%]

  <bb 5> [local count: 118111600]:
  # groupConfig_27 = PHI <groupConfig_31(4)>
  # DEBUG BEGIN_STMT
  SchM_Enter_Port_PORT_EXCLUSIVE_AREA_10 ();
  # DEBUG BEGIN_STMT
  _7 ={v} MEM[(struct TSPC_Type *)1076641792B].GRP_EN;
  _8 = (long unsigned int) groupConfig_27;
  _9 = ~_8;
  _10 = _7 & _9;
  MEM[(struct TSPC_Type *)1076641792B].GRP_EN ={v} _10;
  # DEBUG BEGIN_STMT
  # DEBUG i => 0
  goto <bb 12>; [100.00%]

  <bb 6> [local count: 955630225]:
  # DEBUG BEGIN_STMT
  _11 = i_30 * 8;
  _12 = config_35(D) + _11;
  _13 = _12->obeGroupSelect;
  if (_13 != 0)
    goto <bb 7>; [50.00%]
  else
    goto <bb 11>; [50.00%]

  <bb 7> [local count: 477815112]:
  # DEBUG BEGIN_STMT
  _14 = _12->obeGroupIndex;
  if (_14 != 65535)
    goto <bb 8>; [66.00%]
  else
    goto <bb 11>; [34.00%]

  <bb 8> [local count: 315357972]:
  # DEBUG BEGIN_STMT
  if (_14 > 31)
    goto <bb 9>; [50.00%]
  else
    goto <bb 10>; [50.00%]

  <bb 9> [local count: 157678986]:
  # DEBUG BEGIN_STMT
  _15 = (unsigned int) _13;
  _16 = _15 + 4294967295;
  _17 ={v} MEM[(struct TSPC_Type *)1076641792B].GROUP[_16].GRP_OBE2;
  _18 = _14 + 4294967264;
  _19 = 1 << _18;
  _20 = _17 | _19;
  MEM[(struct TSPC_Type *)1076641792B].GROUP[_16].GRP_OBE2 ={v} _20;
  goto <bb 11>; [100.00%]

  <bb 10> [local count: 157678986]:
  # DEBUG BEGIN_STMT
  _21 = (unsigned int) _13;
  _22 = _21 + 4294967295;
  _23 ={v} MEM[(struct TSPC_Type *)1076641792B].GROUP[_22].GRP_OBE1;
  _24 = 1 << _14;
  _25 = _23 | _24;
  MEM[(struct TSPC_Type *)1076641792B].GROUP[_22].GRP_OBE1 ={v} _25;

  <bb 11> [local count: 955630225]:
  # DEBUG BEGIN_STMT
  i_45 = i_30 + 1;
  # DEBUG i => i_45

  <bb 12> [local count: 1073741824]:
  # i_30 = PHI <0(5), i_45(11)>
  # DEBUG i => i_30
  # DEBUG BEGIN_STMT
  if (i_30 < cfgCount_38(D))
    goto <bb 6>; [89.00%]
  else
    goto <bb 13>; [11.00%]

  <bb 13> [local count: 118111600]:
  # DEBUG BEGIN_STMT
  _26 ={v} MEM[(struct TSPC_Type *)1076641792B].GRP_EN;
  _28 = _8 | _26;
  MEM[(struct TSPC_Type *)1076641792B].GRP_EN ={v} _28;
  # DEBUG BEGIN_STMT
  SchM_Exit_Port_PORT_EXCLUSIVE_AREA_10 ();
  return;

}


Tspc_Port_Ip_EnableObeGroup (uint8 group)
{
  unsigned char _1;
  _Bool _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG tspcBase => 1076641792B
  # DEBUG BEGIN_STMT
  _1 = group_8(D) + 255;
  _2 = _1 <= 1;
  DevAssert (_2);
  # DEBUG BEGIN_STMT
  SchM_Enter_Port_PORT_EXCLUSIVE_AREA_09 ();
  # DEBUG BEGIN_STMT
  if (group_8(D) == 1)
    goto <bb 3>; [34.00%]
  else
    goto <bb 4>; [66.00%]

  <bb 3> [local count: 365072224]:
  # DEBUG BEGIN_STMT
  _3 ={v} MEM[(struct TSPC_Type *)1076641792B].GRP_EN;
  _4 = _3 | 1;
  MEM[(struct TSPC_Type *)1076641792B].GRP_EN ={v} _4;
  goto <bb 5>; [100.00%]

  <bb 4> [local count: 708669601]:
  # DEBUG BEGIN_STMT
  _5 ={v} MEM[(struct TSPC_Type *)1076641792B].GRP_EN;
  _6 = _5 | 2;
  MEM[(struct TSPC_Type *)1076641792B].GRP_EN ={v} _6;

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  SchM_Exit_Port_PORT_EXCLUSIVE_AREA_09 ();
  return;

}


DevAssert (volatile boolean x)
{
  _Bool x.0_1;

  <bb 2> [local count: 21262216]:
  # DEBUG BEGIN_STMT
  x.0_1 ={v} x;
  if (x.0_1 != 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 5> [local count: 10631108]:

  <bb 3> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__("BKPT #0");
  # DEBUG BEGIN_STMT

  <bb 6> [local count: 1073741824]:
  goto <bb 3>; [100.00%]

  <bb 4> [local count: 10631108]:
  # DEBUG BEGIN_STMT
  return;

}


