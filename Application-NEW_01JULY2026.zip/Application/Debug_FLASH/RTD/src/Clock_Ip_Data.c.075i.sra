
========== IPA-SRA IPA stage ==========



========== IPA-SRA decisions ==========

========== IPA SRA IPA analysis done ==========


Reclaiming functions:
Reclaiming variables:
Clearing address taken flags:
Symbol table:

Clock_Ip_axGateInfo/28 (Clock_Ip_axGateInfo) @0638e9d8
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_axFeatureExtensions/27 (Clock_Ip_axFeatureExtensions) @06386750
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_aeHwDfsName/26 (Clock_Ip_aeHwDfsName) @063863f0
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_aeHwPllName/25 (Clock_Ip_aeHwPllName) @063863a8
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_aeSourceTypeClockName/24 (Clock_Ip_aeSourceTypeClockName) @06386360
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_apxMcMeTriggerPartitions/23 (Clock_Ip_apxMcMeTriggerPartitions) @063862d0
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_apxMcMeGetPartitions/22 (Clock_Ip_apxMcMeGetPartitions) @06386288
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_apxMcMeSetPartitions/21 (Clock_Ip_apxMcMeSetPartitions) @06386240
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_axCmuInfo/20 (Clock_Ip_axCmuInfo) @063861f8
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_aeCmuNames/19 (Clock_Ip_aeCmuNames) @06386168
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_apxCmu/18 (Clock_Ip_apxCmu) @06386120
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_pxPll/17 (Clock_Ip_pxPll) @06386090
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_apxXosc/16 (Clock_Ip_apxXosc) @06386048
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_apxCgmPcfs/15 (Clock_Ip_apxCgmPcfs) @06386000
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_apxCgm/14 (Clock_Ip_apxCgm) @0621df78
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au16SelectorEntryRtcHardwareValue/13 (Clock_Ip_au16SelectorEntryRtcHardwareValue) @0621dd38
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au16SelectorEntryHardwareValue/12 (Clock_Ip_au16SelectorEntryHardwareValue) @0621dca8
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8SoftwareMuxResetValue/11 (Clock_Ip_au8SoftwareMuxResetValue) @0621dc18
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8ClockFeatures/10 (Clock_Ip_au8ClockFeatures) @0621db88
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8CmuCallbackIndex/9 (Clock_Ip_au8CmuCallbackIndex) @0621dea0
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8PcfsCallbackIndex/8 (Clock_Ip_au8PcfsCallbackIndex) @0621de10
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8SelectorCallbackIndex/7 (Clock_Ip_au8SelectorCallbackIndex) @0621dd80
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8PllCallbackIndex/6 (Clock_Ip_au8PllCallbackIndex) @0621dcf0
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8FractionalDividerCallbackIndex/5 (Clock_Ip_au8FractionalDividerCallbackIndex) @0621dc60
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8GateCallbackIndex/4 (Clock_Ip_au8GateCallbackIndex) @0621dbd0
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8IrcoscCallbackIndex/3 (Clock_Ip_au8IrcoscCallbackIndex) @0621db40
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8XoscCallbackIndex/2 (Clock_Ip_au8XoscCallbackIndex) @0621dab0
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8DividerTriggerCallbackIndex/1 (Clock_Ip_au8DividerTriggerCallbackIndex) @0621da20
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8DividerCallbackIndex/0 (Clock_Ip_au8DividerCallbackIndex) @0621d990
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
