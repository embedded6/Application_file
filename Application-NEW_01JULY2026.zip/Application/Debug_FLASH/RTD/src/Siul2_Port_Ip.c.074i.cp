
IPA constant propagation start:
Determining dynamic type for call: Siul2_Port_Ip_GetMSCRConfiguration (config_32(D), base_25(D), pin_27(D));
  Starting walk at: Siul2_Port_Ip_GetMSCRConfiguration (config_32(D), base_25(D), pin_27(D));
  instance pointer: config_32(D)  Outer instance pointer: config_32(D) offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
Determining dynamic type for call: Siul2_Port_Ip_GetMSCRConfiguration (config_32(D), base_25(D), pin_27(D));
  Starting walk at: Siul2_Port_Ip_GetMSCRConfiguration (config_32(D), base_25(D), pin_27(D));
  instance pointer: base_25(D)  Outer instance pointer: base_25(D) offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
Determining dynamic type for call: Siul2_Port_Ip_PinInit (_7);
  Starting walk at: Siul2_Port_Ip_PinInit (_7);
  instance pointer: _7  Outer instance pointer: _9 offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
Determining dynamic type for call: Siul2_Port_Ip_PinInit (_2);
  Starting walk at: Siul2_Port_Ip_PinInit (_2);
  instance pointer: _2  Outer instance pointer: _2 offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Siul2_Port_Ip_PinInit (_2);
Determining dynamic type for call: Siul2_Port_Ip_WriteIMCRConfiguration (config_44(D));
  Starting walk at: Siul2_Port_Ip_WriteIMCRConfiguration (config_44(D));
  instance pointer: config_44(D)  Outer instance pointer: config_44(D) offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_1);
Determining dynamic type for call: Siul2_Port_Ip_WriteDCMConfiguration (config_44(D));
  Starting walk at: Siul2_Port_Ip_WriteDCMConfiguration (config_44(D));
  instance pointer: config_44(D)  Outer instance pointer: config_44(D) offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Siul2_Port_Ip_WriteIMCRConfiguration (config_44(D));
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_1);

IPA structures before propagation:

Jump functions:
  Jump functions of caller  SchM_Exit_Port_PORT_EXCLUSIVE_AREA_04/22:
  Jump functions of caller  SchM_Enter_Port_PORT_EXCLUSIVE_AREA_04/21:
  Jump functions of caller  SchM_Exit_Port_PORT_EXCLUSIVE_AREA_03/20:
  Jump functions of caller  SchM_Enter_Port_PORT_EXCLUSIVE_AREA_03/19:
  Jump functions of caller  SchM_Exit_Port_PORT_EXCLUSIVE_AREA_02/18:
  Jump functions of caller  SchM_Enter_Port_PORT_EXCLUSIVE_AREA_02/17:
  Jump functions of caller  SchM_Exit_Port_PORT_EXCLUSIVE_AREA_01/16:
  Jump functions of caller  SchM_Enter_Port_PORT_EXCLUSIVE_AREA_01/15:
  Jump functions of caller  Siul2_Port_Ip_GetPinConfiguration/14:
    callsite  Siul2_Port_Ip_GetPinConfiguration/14 -> Siul2_Port_Ip_GetMSCRConfiguration/7 : 
       param 0: PASS THROUGH: 1, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 2: PASS THROUGH: 2, op nop_expr
         value: 0x0, mask: 0xffff
         Unknown VR
    callsite  Siul2_Port_Ip_GetPinConfiguration/14 -> DevAssert/0 : 
       param 0: PASS THROUGH: 2, op le_expr 15
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Siul2_Port_Ip_GetPinConfiguration/14 -> DevAssert/0 : 
       param 0: PASS THROUGH: 0, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Siul2_Port_Ip_RevertPinConfiguration/13:
    callsite  Siul2_Port_Ip_RevertPinConfiguration/13 -> Siul2_Port_Ip_PinInit/4 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Siul2_Port_Ip_RevertPinConfiguration/13 -> DevAssert/0 : 
       param 0: PASS THROUGH: 1, op le_expr 15
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Siul2_Port_Ip_RevertPinConfiguration/13 -> DevAssert/0 : 
       param 0: PASS THROUGH: 0, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Siul2_Port_Ip_SetPinDirection/12:
    callsite  Siul2_Port_Ip_SetPinDirection/12 -> SchM_Exit_Port_PORT_EXCLUSIVE_AREA_04/22 : 
       no arg info
    callsite  Siul2_Port_Ip_SetPinDirection/12 -> SchM_Enter_Port_PORT_EXCLUSIVE_AREA_04/21 : 
       no arg info
    callsite  Siul2_Port_Ip_SetPinDirection/12 -> DevAssert/0 : 
       param 0: PASS THROUGH: 1, op le_expr 15
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Siul2_Port_Ip_SetPinDirection/12 -> DevAssert/0 : 
       param 0: PASS THROUGH: 0, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Siul2_Port_Ip_SetInputBuffer/11:
    callsite  Siul2_Port_Ip_SetInputBuffer/11 -> SchM_Exit_Port_PORT_EXCLUSIVE_AREA_03/20 : 
       no arg info
    callsite  Siul2_Port_Ip_SetInputBuffer/11 -> SchM_Enter_Port_PORT_EXCLUSIVE_AREA_03/19 : 
       no arg info
    callsite  Siul2_Port_Ip_SetInputBuffer/11 -> DevAssert/0 : 
       param 0: PASS THROUGH: 1, op le_expr 15
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Siul2_Port_Ip_SetOutputBuffer/10:
    callsite  Siul2_Port_Ip_SetOutputBuffer/10 -> SchM_Exit_Port_PORT_EXCLUSIVE_AREA_02/18 : 
       no arg info
    callsite  Siul2_Port_Ip_SetOutputBuffer/10 -> SchM_Enter_Port_PORT_EXCLUSIVE_AREA_02/17 : 
       no arg info
    callsite  Siul2_Port_Ip_SetOutputBuffer/10 -> DevAssert/0 : 
       param 0: PASS THROUGH: 1, op le_expr 15
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Siul2_Port_Ip_SetOutputBuffer/10 -> DevAssert/0 : 
       param 0: PASS THROUGH: 0, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Siul2_Port_Ip_SetPullSel/9:
    callsite  Siul2_Port_Ip_SetPullSel/9 -> SchM_Exit_Port_PORT_EXCLUSIVE_AREA_01/16 : 
       no arg info
    callsite  Siul2_Port_Ip_SetPullSel/9 -> SchM_Enter_Port_PORT_EXCLUSIVE_AREA_01/15 : 
       no arg info
    callsite  Siul2_Port_Ip_SetPullSel/9 -> DevAssert/0 : 
       param 0: PASS THROUGH: 1, op le_expr 15
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Siul2_Port_Ip_SetPullSel/9 -> DevAssert/0 : 
       param 0: PASS THROUGH: 0, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Siul2_Port_Ip_Init/8:
    callsite  Siul2_Port_Ip_Init/8 -> Siul2_Port_Ip_PinInit/4 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  Siul2_Port_Ip_GetMSCRConfiguration/7:
  Jump functions of caller  Siul2_Port_Ip_WriteIMCRConfiguration/6:
  Jump functions of caller  Siul2_Port_Ip_WriteDCMConfiguration/5:
  Jump functions of caller  Siul2_Port_Ip_PinInit/4:
    callsite  Siul2_Port_Ip_PinInit/4 -> Siul2_Port_Ip_WriteDCMConfiguration/5 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  Siul2_Port_Ip_PinInit/4 -> Siul2_Port_Ip_WriteIMCRConfiguration/6 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  Siul2_Port_Ip_PinInit/4 -> DevAssert/0 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Siul2_Port_Ip_PinInit/4 -> DevAssert/0 : 
       param 0: PASS THROUGH: 0, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  DevAssert/0:

 Propagating constants:

Not considering Siul2_Port_Ip_GetPinConfiguration/14 for cloning; -fipa-cp-clone disabled.
Not considering Siul2_Port_Ip_RevertPinConfiguration/13 for cloning; -fipa-cp-clone disabled.
Not considering Siul2_Port_Ip_SetPinDirection/12 for cloning; -fipa-cp-clone disabled.
Not considering Siul2_Port_Ip_SetInputBuffer/11 for cloning; -fipa-cp-clone disabled.
Not considering Siul2_Port_Ip_SetOutputBuffer/10 for cloning; -fipa-cp-clone disabled.
Not considering Siul2_Port_Ip_SetPullSel/9 for cloning; -fipa-cp-clone disabled.
Not considering Siul2_Port_Ip_Init/8 for cloning; -fipa-cp-clone disabled.

overall_size: 394

IPA lattices after all propagation:

Lattices:
  Node: Siul2_Port_Ip_GetPinConfiguration/14:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Siul2_Port_Ip_RevertPinConfiguration/13:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Siul2_Port_Ip_SetPinDirection/12:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Siul2_Port_Ip_SetInputBuffer/11:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [3]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [4]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Siul2_Port_Ip_SetOutputBuffer/10:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [3]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Siul2_Port_Ip_SetPullSel/9:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Siul2_Port_Ip_Init/8:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Siul2_Port_Ip_GetMSCRConfiguration/7:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Siul2_Port_Ip_WriteIMCRConfiguration/6:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Siul2_Port_Ip_WriteDCMConfiguration/5:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Siul2_Port_Ip_PinInit/4:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: DevAssert/0:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE

IPA decision stage:


IPA constant propagation end

Reclaiming functions:
Reclaiming variables:
Clearing address taken flags:
Symbol table:

SchM_Exit_Port_PORT_EXCLUSIVE_AREA_04/22 (SchM_Exit_Port_PORT_EXCLUSIVE_AREA_04) @0621c000
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Siul2_Port_Ip_SetPinDirection/12 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
SchM_Enter_Port_PORT_EXCLUSIVE_AREA_04/21 (SchM_Enter_Port_PORT_EXCLUSIVE_AREA_04) @0613eee0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Siul2_Port_Ip_SetPinDirection/12 (1073741809 (estimated locally),1.00 per call) 
  Calls: 
SchM_Exit_Port_PORT_EXCLUSIVE_AREA_03/20 (SchM_Exit_Port_PORT_EXCLUSIVE_AREA_03) @0613ed20
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Siul2_Port_Ip_SetInputBuffer/11 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
SchM_Enter_Port_PORT_EXCLUSIVE_AREA_03/19 (SchM_Enter_Port_PORT_EXCLUSIVE_AREA_03) @0613ec40
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Siul2_Port_Ip_SetInputBuffer/11 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
SchM_Exit_Port_PORT_EXCLUSIVE_AREA_02/18 (SchM_Exit_Port_PORT_EXCLUSIVE_AREA_02) @0613ea80
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Siul2_Port_Ip_SetOutputBuffer/10 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
SchM_Enter_Port_PORT_EXCLUSIVE_AREA_02/17 (SchM_Enter_Port_PORT_EXCLUSIVE_AREA_02) @0613e9a0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Siul2_Port_Ip_SetOutputBuffer/10 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
SchM_Exit_Port_PORT_EXCLUSIVE_AREA_01/16 (SchM_Exit_Port_PORT_EXCLUSIVE_AREA_01) @0613e7e0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Siul2_Port_Ip_SetPullSel/9 (74417756 (estimated locally),0.88 per call) 
  Calls: 
SchM_Enter_Port_PORT_EXCLUSIVE_AREA_01/15 (SchM_Enter_Port_PORT_EXCLUSIVE_AREA_01) @0613e700
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Siul2_Port_Ip_SetPullSel/9 (85048864 (estimated locally),1.00 per call) 
  Calls: 
Siul2_Port_Ip_GetPinConfiguration/14 (Siul2_Port_Ip_GetPinConfiguration) @06134540
  Type: function definition analyzed
  Visibility: externally_visible public
  References: pPort_Setting/2 (read) u32MaxPinConfigured/3 (read) 
  Referring: 
  Availability: available
  Function flags: count:114863530 (estimated locally) body optimize_size
  Called by: 
  Calls: Siul2_Port_Ip_GetMSCRConfiguration/7 (55807731 (estimated locally),0.49 per call) DevAssert/0 (114863530 (estimated locally),1.00 per call) DevAssert/0 (114863530 (estimated locally),1.00 per call) 
Siul2_Port_Ip_RevertPinConfiguration/13 (Siul2_Port_Ip_RevertPinConfiguration) @06134d20
  Type: function definition analyzed
  Visibility: externally_visible public
  References: pPort_Setting/2 (read) u32MaxPinConfigured/3 (read) 
  Referring: 
  Availability: available
  Function flags: count:114863530 (estimated locally) body optimize_size
  Called by: 
  Calls: Siul2_Port_Ip_PinInit/4 (55807731 (estimated locally),0.49 per call) DevAssert/0 (114863530 (estimated locally),1.00 per call) DevAssert/0 (114863530 (estimated locally),1.00 per call) 
Siul2_Port_Ip_SetPinDirection/12 (Siul2_Port_Ip_SetPinDirection) @061349a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741809 (estimated locally) body optimize_size
  Called by: 
  Calls: SchM_Exit_Port_PORT_EXCLUSIVE_AREA_04/22 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Port_PORT_EXCLUSIVE_AREA_04/21 (1073741809 (estimated locally),1.00 per call) DevAssert/0 (1073741809 (estimated locally),1.00 per call) DevAssert/0 (1073741809 (estimated locally),1.00 per call) 
Siul2_Port_Ip_SetInputBuffer/11 (Siul2_Port_Ip_SetInputBuffer) @06134460
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: SchM_Exit_Port_PORT_EXCLUSIVE_AREA_03/20 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Port_PORT_EXCLUSIVE_AREA_03/19 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) 
Siul2_Port_Ip_SetOutputBuffer/10 (Siul2_Port_Ip_SetOutputBuffer) @06134000
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: SchM_Exit_Port_PORT_EXCLUSIVE_AREA_02/18 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Port_PORT_EXCLUSIVE_AREA_02/17 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) 
Siul2_Port_Ip_SetPullSel/9 (Siul2_Port_Ip_SetPullSel) @061aa1c0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:85048864 (estimated locally) body optimize_size
  Called by: 
  Calls: SchM_Exit_Port_PORT_EXCLUSIVE_AREA_01/16 (74417756 (estimated locally),0.88 per call) SchM_Enter_Port_PORT_EXCLUSIVE_AREA_01/15 (85048864 (estimated locally),1.00 per call) DevAssert/0 (85048864 (estimated locally),1.00 per call) DevAssert/0 (85048864 (estimated locally),1.00 per call) 
Siul2_Port_Ip_Init/8 (Siul2_Port_Ip_Init) @061aac40
  Type: function definition analyzed
  Visibility: externally_visible public
  References: pPort_Setting/2 (write) u32MaxPinConfigured/3 (write) 
  Referring: 
  Availability: available
  Function flags: count:118111600 (estimated locally) body optimize_size
  Called by: 
  Calls: Siul2_Port_Ip_PinInit/4 (955630225 (estimated locally),8.09 per call) 
Siul2_Port_Ip_GetMSCRConfiguration/7 (Siul2_Port_Ip_GetMSCRConfiguration) @061aa9a0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: Siul2_Port_Ip_GetPinConfiguration/14 (55807731 (estimated locally),0.49 per call) 
  Calls: 
Siul2_Port_Ip_WriteIMCRConfiguration/6 (Siul2_Port_Ip_WriteIMCRConfiguration) @061aa700
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:350860932 (estimated locally) body local optimize_size
  Called by: Siul2_Port_Ip_PinInit/4 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Siul2_Port_Ip_WriteDCMConfiguration/5 (Siul2_Port_Ip_WriteDCMConfiguration) @061aa380
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:357878152 (estimated locally) body local optimize_size
  Called by: Siul2_Port_Ip_PinInit/4 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Siul2_Port_Ip_PinInit/4 (Siul2_Port_Ip_PinInit) @061aa0e0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: Siul2_Port_Ip_RevertPinConfiguration/13 (55807731 (estimated locally),0.49 per call) Siul2_Port_Ip_Init/8 (955630225 (estimated locally),8.09 per call) 
  Calls: Siul2_Port_Ip_WriteDCMConfiguration/5 (1073741824 (estimated locally),1.00 per call) Siul2_Port_Ip_WriteIMCRConfiguration/6 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) 
u32MaxPinConfigured/3 (u32MaxPinConfigured) @0611b510
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: Siul2_Port_Ip_Init/8 (write) Siul2_Port_Ip_RevertPinConfiguration/13 (read) Siul2_Port_Ip_GetPinConfiguration/14 (read) 
  Availability: available
  Varpool flags:
pPort_Setting/2 (pPort_Setting) @0611b480
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: Siul2_Port_Ip_Init/8 (write) Siul2_Port_Ip_RevertPinConfiguration/13 (read) Siul2_Port_Ip_GetPinConfiguration/14 (read) 
  Availability: available
  Varpool flags:
Port_au32Siul2BaseAddr/1 (Port_au32Siul2BaseAddr) @0611b3f0
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
DevAssert/0 (DevAssert) @060c11c0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:21262216 (estimated locally) body local optimize_size
  Called by: Siul2_Port_Ip_GetPinConfiguration/14 (114863530 (estimated locally),1.00 per call) Siul2_Port_Ip_GetPinConfiguration/14 (114863530 (estimated locally),1.00 per call) Siul2_Port_Ip_RevertPinConfiguration/13 (114863530 (estimated locally),1.00 per call) Siul2_Port_Ip_RevertPinConfiguration/13 (114863530 (estimated locally),1.00 per call) Siul2_Port_Ip_SetPinDirection/12 (1073741809 (estimated locally),1.00 per call) Siul2_Port_Ip_SetPinDirection/12 (1073741809 (estimated locally),1.00 per call) Siul2_Port_Ip_SetInputBuffer/11 (1073741824 (estimated locally),1.00 per call) Siul2_Port_Ip_SetOutputBuffer/10 (1073741824 (estimated locally),1.00 per call) Siul2_Port_Ip_SetOutputBuffer/10 (1073741824 (estimated locally),1.00 per call) Siul2_Port_Ip_SetPullSel/9 (85048864 (estimated locally),1.00 per call) Siul2_Port_Ip_SetPullSel/9 (85048864 (estimated locally),1.00 per call) Siul2_Port_Ip_PinInit/4 (1073741824 (estimated locally),1.00 per call) Siul2_Port_Ip_PinInit/4 (1073741824 (estimated locally),1.00 per call) 
  Calls: 

;; Function DevAssert (DevAssert, funcdef_no=0, decl_uid=6207, cgraph_uid=1, symbol_order=0)

Modification phase of node DevAssert/0
DevAssert (volatile boolean x)
{
  _Bool x.0_1;

  <bb 2> [local count: 21262216]:
  # DEBUG BEGIN_STMT
  x.0_1 ={v} x;
  if (x.0_1 != 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 5> [local count: 10631108]:

  <bb 3> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__("BKPT #0");
  # DEBUG BEGIN_STMT

  <bb 6> [local count: 1073741824]:
  goto <bb 3>; [100.00%]

  <bb 4> [local count: 10631108]:
  # DEBUG BEGIN_STMT
  return;

}



;; Function Siul2_Port_Ip_PinInit (Siul2_Port_Ip_PinInit, funcdef_no=1, decl_uid=6356, cgraph_uid=2, symbol_order=4)

Modification phase of node Siul2_Port_Ip_PinInit/4
Siul2_Port_Ip_PinInit (const struct Siul2_Port_Ip_PinSettingsConfig * config)
{
  uint32 pinsValues;
  _Bool _1;
  long unsigned int _2;
  _Bool _3;
  <unnamed type> _4;
  long unsigned int _5;
  long unsigned int _6;
  <unnamed type> _7;
  long unsigned int _8;
  long unsigned int _9;
  <unnamed type> _10;
  long unsigned int _11;
  long unsigned int _12;
  <unnamed type> _13;
  long unsigned int _14;
  long unsigned int _15;
  <unnamed type> _16;
  long unsigned int _17;
  long unsigned int _18;
  <unnamed type> _19;
  long unsigned int _20;
  long unsigned int _21;
  <unnamed type> _22;
  long unsigned int _23;
  long unsigned int _24;
  <unnamed type> _25;
  long unsigned int _26;
  long unsigned int _27;
  <unnamed type> _28;
  long unsigned int _29;
  long unsigned int _30;
  <unnamed type> _31;
  long unsigned int _32;
  unsigned char _33;
  long unsigned int _34;
  short unsigned int _35;
  short unsigned int _36;
  long unsigned int _37;
  long unsigned int _38;
  volatile uint8 * _39;
  struct SIUL2_Type * _40;
  long unsigned int _41;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG pinsValues => 0
  # DEBUG BEGIN_STMT
  # DEBUG siulInstance => 0
  # DEBUG BEGIN_STMT
  _1 = config_44(D) != 0B;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _2 = config_44(D)->pinPortIdx;
  _3 = _2 <= 154;
  DevAssert (_3);
  # DEBUG BEGIN_STMT
  # DEBUG siulInstance => 0
  # DEBUG BEGIN_STMT
  _4 = config_44(D)->pullConfig;
  if (_4 != 2)
    goto <bb 3>; [66.00%]
  else
    goto <bb 4>; [34.00%]

  <bb 3> [local count: 708669601]:
  # DEBUG BEGIN_STMT
  # DEBUG pinsValues => 8192
  # DEBUG BEGIN_STMT
  _5 = _4 << 11;
  _6 = _5 & 2048;
  pinsValues_48 = _6 | 8192;
  # DEBUG pinsValues => pinsValues_48

  <bb 4> [local count: 1073741824]:
  # pinsValues_42 = PHI <0(2), pinsValues_48(3)>
  # DEBUG pinsValues => pinsValues_42
  # DEBUG BEGIN_STMT
  _7 = config_44(D)->outputBuffer;
  _8 = _7 << 21;
  _9 = _8 & 2097152;
  pinsValues_49 = _9 | pinsValues_42;
  # DEBUG pinsValues => pinsValues_49
  # DEBUG BEGIN_STMT
  _10 = config_44(D)->invert;
  _11 = _10 << 17;
  _12 = _11 & 131072;
  pinsValues_50 = _12 | pinsValues_49;
  # DEBUG pinsValues => pinsValues_50
  # DEBUG BEGIN_STMT
  _13 = config_44(D)->pullKeep;
  _14 = _13 << 16;
  _15 = _14 & 65536;
  pinsValues_51 = _15 | pinsValues_50;
  # DEBUG pinsValues => pinsValues_51
  # DEBUG BEGIN_STMT
  _16 = config_44(D)->driveStrength;
  _17 = _16 << 8;
  _18 = _17 & 256;
  pinsValues_52 = _18 | pinsValues_51;
  # DEBUG pinsValues => pinsValues_52
  # DEBUG BEGIN_STMT
  _19 = config_44(D)->inputFilter;
  _20 = _19 << 6;
  _21 = _20 & 64;
  pinsValues_53 = _21 | pinsValues_52;
  # DEBUG pinsValues => pinsValues_53
  # DEBUG BEGIN_STMT
  _22 = config_44(D)->inputBuffer;
  _23 = _22 << 19;
  _24 = _23 & 524288;
  pinsValues_54 = _24 | pinsValues_53;
  # DEBUG pinsValues => pinsValues_54
  # DEBUG BEGIN_STMT
  _25 = config_44(D)->slewRateCtrlSel;
  _26 = _25 << 14;
  _27 = _26 & 16384;
  pinsValues_55 = _27 | pinsValues_54;
  # DEBUG pinsValues => pinsValues_55
  # DEBUG BEGIN_STMT
  _28 = config_44(D)->safeMode;
  _29 = _28 << 5;
  _30 = _29 & 32;
  pinsValues_56 = _30 | pinsValues_55;
  # DEBUG pinsValues => pinsValues_56
  # DEBUG BEGIN_STMT
  _31 = config_44(D)->mux;
  _32 = _31 & 7;
  pinsValues_57 = _32 | pinsValues_56;
  # DEBUG pinsValues => pinsValues_57
  # DEBUG BEGIN_STMT
  if (_31 == 0)
    goto <bb 5>; [50.00%]
  else
    goto <bb 8>; [50.00%]

  <bb 5> [local count: 536870913]:
  if (_7 == 1)
    goto <bb 6>; [34.00%]
  else
    goto <bb 8>; [66.00%]

  <bb 6> [local count: 182536112]:
  # DEBUG BEGIN_STMT
  _33 = config_44(D)->initValue;
  if (_33 != 2)
    goto <bb 7>; [66.00%]
  else
    goto <bb 8>; [34.00%]

  <bb 7> [local count: 120473833]:
  # DEBUG BEGIN_STMT
  _34 = config_44(D)->pinPortIdx;
  _35 = (short unsigned int) _34;
  _36 = _35 ^ 3;
  _37 = (long unsigned int) _36;
  _38 = _37 + 1076433664;
  _39 = (volatile uint8 *) _38;
  *_39 ={v} _33;

  <bb 8> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _40 = config_44(D)->base;
  _41 = config_44(D)->pinPortIdx;
  _40->MSCR[_41] ={v} pinsValues_57;
  # DEBUG BEGIN_STMT
  Siul2_Port_Ip_WriteIMCRConfiguration (config_44(D));
  # DEBUG BEGIN_STMT
  Siul2_Port_Ip_WriteDCMConfiguration (config_44(D));
  return;

}



;; Function Siul2_Port_Ip_Init (Siul2_Port_Ip_Init, funcdef_no=5, decl_uid=6228, cgraph_uid=6, symbol_order=8)

Modification phase of node Siul2_Port_Ip_Init/8
Siul2_Port_Ip_Init (uint32 pinCount, const struct Siul2_Port_Ip_PinSettingsConfig * config)
{
  uint32 i;
  long unsigned int _1;
  const struct Siul2_Port_Ip_PinSettingsConfig * _2;

  <bb 2> [local count: 118111600]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  pPort_Setting = config_6(D);
  # DEBUG BEGIN_STMT
  u32MaxPinConfigured = pinCount_8(D);
  # DEBUG BEGIN_STMT
  # DEBUG i => 0
  goto <bb 4>; [100.00%]

  <bb 3> [local count: 955630225]:
  # DEBUG BEGIN_STMT
  _1 = i_3 * 124;
  _2 = config_6(D) + _1;
  Siul2_Port_Ip_PinInit (_2);
  # DEBUG BEGIN_STMT
  i_11 = i_3 + 1;
  # DEBUG i => i_11

  <bb 4> [local count: 1073741824]:
  # i_3 = PHI <0(2), i_11(3)>
  # DEBUG i => i_3
  # DEBUG BEGIN_STMT
  if (i_3 < pinCount_8(D))
    goto <bb 3>; [89.00%]
  else
    goto <bb 5>; [11.00%]

  <bb 5> [local count: 118111600]:
  # DEBUG BEGIN_STMT
  return 0;

}



;; Function Siul2_Port_Ip_SetPullSel (Siul2_Port_Ip_SetPullSel, funcdef_no=6, decl_uid=6214, cgraph_uid=7, symbol_order=9)

Modification phase of node Siul2_Port_Ip_SetPullSel/9
Siul2_Port_Ip_SetPullSel (struct Siul2_Port_Ip_PortType * const base, uint16 pin, Siul2_Port_Ip_PortPullConfig pullConfig)
{
  volatile boolean x;
  uint32 regVal;
  _Bool _1;
  _Bool _2;
  int _3;
  long unsigned int _4;
  long unsigned int _5;
  int _6;
  int _7;
  long unsigned int _23;
  _Bool x.0_25;

  <bb 2> [local count: 85048864]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _1 = base_9(D) != 0B;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _2 = pin_12(D) <= 15;
  DevAssert (_2);
  # DEBUG BEGIN_STMT
  # DEBUG pueVal => 8192
  # DEBUG BEGIN_STMT
  # DEBUG pusVal => 2048
  # DEBUG BEGIN_STMT
  SchM_Enter_Port_PORT_EXCLUSIVE_AREA_01 ();
  # DEBUG BEGIN_STMT
  switch (pullConfig_15(D)) <default: <L3> [25.00%], case 0: <L1> [25.00%], case 1: <L2> [25.00%], case 2: <L0> [25.00%]>

  <bb 3> [local count: 21262216]:
<L0>:
  # DEBUG BEGIN_STMT
  _3 = (int) pin_12(D);
  _4 ={v} base_9(D)->MSCR[_3];
  _5 = _4 & 4294959103;
  base_9(D)->MSCR[_3] ={v} _5;
  # DEBUG BEGIN_STMT
  goto <bb 8>; [100.00%]

  <bb 4> [local count: 21262216]:
<L1>:
  # DEBUG BEGIN_STMT
  _6 = (int) pin_12(D);
  regVal_20 ={v} base_9(D)->MSCR[_6];
  # DEBUG regVal => regVal_20
  # DEBUG BEGIN_STMT
  # DEBUG regVal => regVal_20 | 8192
  # DEBUG BEGIN_STMT
  _23 = regVal_20 & 4294965247;
  regVal_21 = _23 | 8192;
  # DEBUG regVal => regVal_21
  # DEBUG BEGIN_STMT
  base_9(D)->MSCR[_6] ={v} regVal_21;
  # DEBUG BEGIN_STMT
  goto <bb 8>; [100.00%]

  <bb 5> [local count: 21262216]:
<L2>:
  # DEBUG BEGIN_STMT
  _7 = (int) pin_12(D);
  regVal_17 ={v} base_9(D)->MSCR[_7];
  # DEBUG regVal => regVal_17
  # DEBUG BEGIN_STMT
  # DEBUG regVal => regVal_17 | 8192
  # DEBUG BEGIN_STMT
  regVal_18 = regVal_17 | 10240;
  # DEBUG regVal => regVal_18
  # DEBUG BEGIN_STMT
  base_9(D)->MSCR[_7] ={v} regVal_18;
  # DEBUG BEGIN_STMT
  goto <bb 8>; [100.00%]

  <bb 6> [local count: 21262216]:
<L3>:
  # DEBUG BEGIN_STMT
  x ={v} 0;
  # DEBUG x => x
  # DEBUG INLINE_ENTRY DevAssert
  # DEBUG BEGIN_STMT
  x.0_25 ={v} x;
  if (x.0_25 != 0)
    goto <bb 8>; [50.00%]
  else
    goto <bb 9>; [50.00%]

  <bb 9> [local count: 10631108]:

  <bb 7> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__("BKPT #0");
  # DEBUG BEGIN_STMT

  <bb 10> [local count: 1073741824]:
  goto <bb 7>; [100.00%]

  <bb 8> [local count: 74417756]:
  # DEBUG x => NULL
  # DEBUG BEGIN_STMT
  SchM_Exit_Port_PORT_EXCLUSIVE_AREA_01 ();
  return;

}



;; Function Siul2_Port_Ip_SetOutputBuffer (Siul2_Port_Ip_SetOutputBuffer, funcdef_no=7, decl_uid=6219, cgraph_uid=8, symbol_order=10)

Modification phase of node Siul2_Port_Ip_SetOutputBuffer/10
Siul2_Port_Ip_SetOutputBuffer (struct Siul2_Port_Ip_PortType * const base, uint16 pin, boolean enable, Siul2_Port_Ip_PortMux mux)
{
  _Bool _1;
  _Bool _2;
  int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;
  long unsigned int _7;
  long unsigned int _8;
  long unsigned int _9;
  long unsigned int _10;
  long unsigned int _11;
  long unsigned int _12;
  long unsigned int iftmp.3_13;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = base_14(D) != 0B;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _2 = pin_17(D) <= 15;
  DevAssert (_2);
  # DEBUG BEGIN_STMT
  SchM_Enter_Port_PORT_EXCLUSIVE_AREA_02 ();
  # DEBUG BEGIN_STMT
  _3 = (int) pin_17(D);
  _4 ={v} base_14(D)->MSCR[_3];
  _5 = _4 & 4292870143;
  base_14(D)->MSCR[_3] ={v} _5;
  # DEBUG BEGIN_STMT
  _6 ={v} base_14(D)->MSCR[_3];
  if (enable_21(D) != 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 3>; [50.00%]

  <bb 3> [local count: 536870913]:

  <bb 4> [local count: 1073741824]:
  # iftmp.3_13 = PHI <2097152(2), 0(3)>
  _7 = _6 | iftmp.3_13;
  base_14(D)->MSCR[_3] ={v} _7;
  # DEBUG BEGIN_STMT
  _8 ={v} base_14(D)->MSCR[_3];
  _9 = _8 & 4294967288;
  base_14(D)->MSCR[_3] ={v} _9;
  # DEBUG BEGIN_STMT
  _10 ={v} base_14(D)->MSCR[_3];
  _11 = mux_24(D) & 7;
  _12 = _10 | _11;
  base_14(D)->MSCR[_3] ={v} _12;
  # DEBUG BEGIN_STMT
  SchM_Exit_Port_PORT_EXCLUSIVE_AREA_02 ();
  return;

}



;; Function Siul2_Port_Ip_SetInputBuffer (Siul2_Port_Ip_SetInputBuffer, funcdef_no=8, decl_uid=6225, cgraph_uid=9, symbol_order=11)

Modification phase of node Siul2_Port_Ip_SetInputBuffer/11
Siul2_Port_Ip_SetInputBuffer (struct Siul2_Port_Ip_PortType * const base, uint16 pin, boolean enable, uint32 inputMuxReg, Siul2_Port_Ip_PortInputMux inputMux)
{
  uint32 imcrVal;
  struct SIUL2_Type * siul2Base;
  _Bool _1;
  int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;
  long unsigned int _7;
  long unsigned int _8;
  long unsigned int iftmp.4_10;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG siul2Base => 4294967295B
  # DEBUG BEGIN_STMT
  # DEBUG imcrRegIdx => inputMuxReg_13(D)
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _1 = pin_14(D) <= 15;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  SchM_Enter_Port_PORT_EXCLUSIVE_AREA_03 ();
  # DEBUG BEGIN_STMT
  if (base_18(D) != 0B)
    goto <bb 3>; [70.00%]
  else
    goto <bb 6>; [30.00%]

  <bb 3> [local count: 751619281]:
  # DEBUG BEGIN_STMT
  _2 = (int) pin_14(D);
  _3 ={v} base_18(D)->MSCR[_2];
  _4 = _3 & 4294443007;
  base_18(D)->MSCR[_2] ={v} _4;
  # DEBUG BEGIN_STMT
  _5 ={v} base_18(D)->MSCR[_2];
  if (enable_20(D) != 0)
    goto <bb 5>; [50.00%]
  else
    goto <bb 4>; [50.00%]

  <bb 4> [local count: 375809640]:

  <bb 5> [local count: 751619281]:
  # iftmp.4_10 = PHI <524288(3), 0(4)>
  _6 = _5 | iftmp.4_10;
  base_18(D)->MSCR[_2] ={v} _6;

  <bb 6> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  if (inputMux_22(D) != 16)
    goto <bb 7>; [66.00%]
  else
    goto <bb 11>; [34.00%]

  <bb 7> [local count: 708669601]:
  # DEBUG BEGIN_STMT
  if (inputMuxReg_13(D) <= 511)
    goto <bb 8>; [50.00%]
  else
    goto <bb 9>; [50.00%]

  <bb 8> [local count: 354334800]:
  # DEBUG BEGIN_STMT
  # DEBUG siul2Base => 1076428800B

  <bb 9> [local count: 708669601]:
  # siul2Base_9 = PHI <4294967295B(7), 1076428800B(8)>
  # DEBUG siul2Base => siul2Base_9
  # DEBUG BEGIN_STMT
  if (inputMuxReg_13(D) <= 408)
    goto <bb 10>; [50.00%]
  else
    goto <bb 11>; [50.00%]

  <bb 10> [local count: 354334800]:
  # DEBUG BEGIN_STMT
  _7 = inputMuxReg_13(D);
  imcrVal_23 ={v} siul2Base_9->IMCR[_7];
  # DEBUG imcrVal => imcrVal_23
  # DEBUG BEGIN_STMT
  imcrVal_24 = imcrVal_23 & 4294967280;
  # DEBUG imcrVal => imcrVal_24
  # DEBUG BEGIN_STMT
  _8 = inputMux_22(D) & 15;
  imcrVal_25 = _8 | imcrVal_24;
  # DEBUG imcrVal => imcrVal_25
  # DEBUG BEGIN_STMT
  siul2Base_9->IMCR[_7] ={v} imcrVal_25;

  <bb 11> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  SchM_Exit_Port_PORT_EXCLUSIVE_AREA_03 ();
  return;

}



;; Function Siul2_Port_Ip_SetPinDirection (Siul2_Port_Ip_SetPinDirection, funcdef_no=9, decl_uid=6232, cgraph_uid=10, symbol_order=12)

Modification phase of node Siul2_Port_Ip_SetPinDirection/12
Siul2_Port_Ip_SetPinDirection (struct Siul2_Port_Ip_PortType * const base, uint16 pin, Siul2_Port_Ip_PortDirectionType direction)
{
  _Bool _1;
  _Bool _2;
  int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;
  long unsigned int _7;
  int _8;
  long unsigned int _9;
  long unsigned int _10;
  long unsigned int _11;
  long unsigned int _12;
  int _13;
  long unsigned int _14;
  long unsigned int _15;
  int _16;
  long unsigned int _17;
  long unsigned int _18;

  <bb 2> [local count: 1073741809]:
  # DEBUG BEGIN_STMT
  _1 = base_20(D) != 0B;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _2 = pin_23(D) <= 15;
  DevAssert (_2);
  # DEBUG BEGIN_STMT
  SchM_Enter_Port_PORT_EXCLUSIVE_AREA_04 ();
  # DEBUG BEGIN_STMT
  switch (direction_26(D)) <default: <L6> [20.00%], case 0: <L0> [20.00%], case 1: <L1> [20.00%], case 2: <L2> [20.00%], case 3: <L3> [20.00%]>

  <bb 3> [local count: 214748365]:
<L0>:
  # DEBUG BEGIN_STMT
  _3 = (int) pin_23(D);
  _4 ={v} base_20(D)->MSCR[_3];
  _5 = _4 & 4292870143;
  base_20(D)->MSCR[_3] ={v} _5;
  # DEBUG BEGIN_STMT
  _6 ={v} base_20(D)->MSCR[_3];
  _7 = _6 | 524288;
  base_20(D)->MSCR[_3] ={v} _7;
  # DEBUG BEGIN_STMT
  goto <bb 7>; [100.00%]

  <bb 4> [local count: 214748365]:
<L1>:
  # DEBUG BEGIN_STMT
  _8 = (int) pin_23(D);
  _9 ={v} base_20(D)->MSCR[_8];
  _10 = _9 & 4294443007;
  base_20(D)->MSCR[_8] ={v} _10;
  # DEBUG BEGIN_STMT
  _11 ={v} base_20(D)->MSCR[_8];
  _12 = _11 | 2097152;
  base_20(D)->MSCR[_8] ={v} _12;
  # DEBUG BEGIN_STMT
  goto <bb 7>; [100.00%]

  <bb 5> [local count: 214748365]:
<L2>:
  # DEBUG BEGIN_STMT
  _13 = (int) pin_23(D);
  _14 ={v} base_20(D)->MSCR[_13];
  _15 = _14 | 2621440;
  base_20(D)->MSCR[_13] ={v} _15;
  # DEBUG BEGIN_STMT
  goto <bb 7>; [100.00%]

  <bb 6> [local count: 214748365]:
<L3>:
  # DEBUG BEGIN_STMT
  _16 = (int) pin_23(D);
  _17 ={v} base_20(D)->MSCR[_16];
  _18 = _17 & 4292345855;
  base_20(D)->MSCR[_16] ={v} _18;
  # DEBUG BEGIN_STMT

  <bb 7> [local count: 1073741824]:
<L6>:
  # DEBUG BEGIN_STMT
  SchM_Exit_Port_PORT_EXCLUSIVE_AREA_04 ();
  return;

}



;; Function Siul2_Port_Ip_RevertPinConfiguration (Siul2_Port_Ip_RevertPinConfiguration, funcdef_no=10, decl_uid=6235, cgraph_uid=11, symbol_order=13)

Modification phase of node Siul2_Port_Ip_RevertPinConfiguration/13
Siul2_Port_Ip_RevertPinConfiguration (const struct Siul2_Port_Ip_PortType * const base, uint16 pin)
{
  uint32 u32MscrId;
  uint32 portNumber;
  uint32 MaxPinConfigured;
  const struct Siul2_Port_Ip_PinSettingsConfig * ConfigPtr;
  uint32 u32RegVal;
  uint16 u16PinIdx;
  _Bool _1;
  _Bool _2;
  long unsigned int base.5_3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;
  const struct Siul2_Port_Ip_PinSettingsConfig * _7;
  unsigned int _8;
  const struct Siul2_Port_Ip_PinSettingsConfig * _9;
  long unsigned int _10;
  int _11;
  long unsigned int _12;

  <bb 2> [local count: 114863530]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG u32RegVal => 4294967295
  # DEBUG BEGIN_STMT
  ConfigPtr_17 = pPort_Setting;
  # DEBUG ConfigPtr => ConfigPtr_17
  # DEBUG BEGIN_STMT
  MaxPinConfigured_18 = u32MaxPinConfigured;
  # DEBUG MaxPinConfigured => MaxPinConfigured_18
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _1 = base_19(D) != 0B;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _2 = pin_21(D) <= 15;
  DevAssert (_2);
  # DEBUG BEGIN_STMT
  base.5_3 = (long unsigned int) base_19(D);
  _4 = base.5_3 + 3218537920;
  portNumber_23 = _4 >> 6;
  # DEBUG portNumber => portNumber_23
  # DEBUG BEGIN_STMT
  _5 = portNumber_23 << 4;
  _6 = (long unsigned int) pin_21(D);
  u32MscrId_24 = _5 + _6;
  # DEBUG u32MscrId => u32MscrId_24
  # DEBUG BEGIN_STMT
  # DEBUG u16PinIdx => 0
  goto <bb 6>; [100.00%]

  <bb 3> [local count: 1014686026]:
  # DEBUG BEGIN_STMT
  _8 = _12 * 124;
  _9 = ConfigPtr_17 + _8;
  _10 = _9->pinPortIdx;
  if (_10 == u32MscrId_24)
    goto <bb 4>; [5.50%]
  else
    goto <bb 5>; [94.50%]

  <bb 4> [local count: 55807731]:
  # _7 = PHI <_9(3)>
  # DEBUG BEGIN_STMT
  Siul2_Port_Ip_PinInit (_7);
  # DEBUG BEGIN_STMT
  _11 = (int) pin_21(D);
  u32RegVal_27 ={v} base_19(D)->MSCR[_11];
  # DEBUG u32RegVal => u32RegVal_27
  # DEBUG BEGIN_STMT
  goto <bb 7>; [100.00%]

  <bb 5> [local count: 958878296]:
  # DEBUG BEGIN_STMT
  u16PinIdx_25 = u16PinIdx_13 + 1;
  # DEBUG u16PinIdx => u16PinIdx_25

  <bb 6> [local count: 1073741824]:
  # u16PinIdx_13 = PHI <0(2), u16PinIdx_25(5)>
  # DEBUG u16PinIdx => u16PinIdx_13
  # DEBUG BEGIN_STMT
  _12 = (long unsigned int) u16PinIdx_13;
  if (_12 < MaxPinConfigured_18)
    goto <bb 3>; [94.50%]
  else
    goto <bb 7>; [5.50%]

  <bb 7> [local count: 114863531]:
  # u32RegVal_14 = PHI <u32RegVal_27(4), 4294967295(6)>
  # DEBUG u32RegVal => u32RegVal_14
  # DEBUG BEGIN_STMT
  return u32RegVal_14;

}



;; Function Siul2_Port_Ip_GetPinConfiguration (Siul2_Port_Ip_GetPinConfiguration, funcdef_no=11, decl_uid=6239, cgraph_uid=12, symbol_order=14)

Modification phase of node Siul2_Port_Ip_GetPinConfiguration/14
Siul2_Port_Ip_GetPinConfiguration (const struct Siul2_Port_Ip_PortType * const base, struct Siul2_Port_Ip_PinSettingsConfig * config, uint16 pin)
{
  uint8 inputMuxIterator;
  uint16 u16PinIdx;
  uint32 u32MscrId;
  uint32 portNumber;
  uint32 MaxPinConfigured;
  const struct Siul2_Port_Ip_PinSettingsConfig * ConfigPtr;
  _Bool _1;
  _Bool _2;
  long unsigned int base.7_3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;
  const struct Siul2_Port_Ip_PinSettingsConfig * _7;
  unsigned int _8;
  const struct Siul2_Port_Ip_PinSettingsConfig * _9;
  long unsigned int _10;
  long unsigned int _11;
  struct SIUL2_Type * _12;
  unsigned char _13;
  int _14;
  long unsigned int _15;
  <unnamed type> _16;
  long unsigned int _17;

  <bb 2> [local count: 114863530]:
  # DEBUG BEGIN_STMT
  ConfigPtr_23 = pPort_Setting;
  # DEBUG ConfigPtr => ConfigPtr_23
  # DEBUG BEGIN_STMT
  MaxPinConfigured_24 = u32MaxPinConfigured;
  # DEBUG MaxPinConfigured => MaxPinConfigured_24
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _1 = base_25(D) != 0B;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _2 = pin_27(D) <= 15;
  DevAssert (_2);
  # DEBUG BEGIN_STMT
  # DEBUG u32MscrBase => 1076429376
  # DEBUG BEGIN_STMT
  base.7_3 = (long unsigned int) base_25(D);
  _4 = base.7_3 + 3218537920;
  portNumber_29 = _4 >> 6;
  # DEBUG portNumber => portNumber_29
  # DEBUG BEGIN_STMT
  _5 = portNumber_29 << 4;
  _6 = (long unsigned int) pin_27(D);
  u32MscrId_30 = _5 + _6;
  # DEBUG u32MscrId => u32MscrId_30
  # DEBUG BEGIN_STMT
  # DEBUG u16PinIdx => 0
  goto <bb 9>; [100.00%]

  <bb 3> [local count: 1014686026]:
  # DEBUG BEGIN_STMT
  _8 = _17 * 124;
  _9 = ConfigPtr_23 + _8;
  _10 = _9->pinPortIdx;
  if (_10 == u32MscrId_30)
    goto <bb 4>; [5.50%]
  else
    goto <bb 8>; [94.50%]

  <bb 4> [local count: 55807731]:
  # _7 = PHI <_9(3)>
  # _11 = PHI <_10(3)>
  # DEBUG BEGIN_STMT
  _12 = _7->base;
  config_32(D)->base = _12;
  # DEBUG BEGIN_STMT
  config_32(D)->pinPortIdx = _11;
  # DEBUG BEGIN_STMT
  _13 = _7->initValue;
  config_32(D)->initValue = _13;
  # DEBUG BEGIN_STMT
  # DEBUG inputMuxIterator => 0
  goto <bb 6>; [100.00%]

  <bb 5> [local count: 446512067]:
  # DEBUG BEGIN_STMT
  _14 = (int) inputMuxIterator_19;
  _15 = _7->inputMuxReg[_14];
  config_32(D)->inputMuxReg[_14] = _15;
  # DEBUG BEGIN_STMT
  _16 = _7->inputMux[_14];
  config_32(D)->inputMux[_14] = _16;
  # DEBUG BEGIN_STMT
  inputMuxIterator_39 = inputMuxIterator_19 + 1;
  # DEBUG inputMuxIterator => inputMuxIterator_39

  <bb 6> [local count: 502319798]:
  # inputMuxIterator_19 = PHI <0(4), inputMuxIterator_39(5)>
  # DEBUG inputMuxIterator => inputMuxIterator_19
  # DEBUG BEGIN_STMT
  if (inputMuxIterator_19 != 8)
    goto <bb 5>; [88.89%]
  else
    goto <bb 7>; [11.11%]

  <bb 7> [local count: 55807731]:
  # DEBUG BEGIN_STMT
  Siul2_Port_Ip_GetMSCRConfiguration (config_32(D), base_25(D), pin_27(D));
  # DEBUG BEGIN_STMT
  goto <bb 10>; [100.00%]

  <bb 8> [local count: 958878296]:
  # DEBUG BEGIN_STMT
  u16PinIdx_31 = u16PinIdx_18 + 1;
  # DEBUG u16PinIdx => u16PinIdx_31

  <bb 9> [local count: 1073741824]:
  # u16PinIdx_18 = PHI <0(2), u16PinIdx_31(8)>
  # DEBUG u16PinIdx => u16PinIdx_18
  # DEBUG BEGIN_STMT
  _17 = (long unsigned int) u16PinIdx_18;
  if (_17 < MaxPinConfigured_24)
    goto <bb 3>; [94.50%]
  else
    goto <bb 10>; [5.50%]

  <bb 10> [local count: 114863531]:
  return;

}


