
IPA constant propagation start:

IPA structures before propagation:

Jump functions:
  Jump functions of caller  SchM_Exit_Dio_DIO_EXCLUSIVE_AREA_01/13:
  Jump functions of caller  SchM_Enter_Dio_DIO_EXCLUSIVE_AREA_01/12:
  Jump functions of caller  Siul2_Dio_Ip_MaskedWritePins/11:
    callsite  Siul2_Dio_Ip_MaskedWritePins/11 -> Siul2_Dio_Ip_Rev_Bit_16/2 : 
       param 0: PASS THROUGH: 2, op nop_expr
         value: 0x0, mask: 0xffff
         Unknown VR
    callsite  Siul2_Dio_Ip_MaskedWritePins/11 -> Siul2_Dio_Ip_Rev_Bit_16/2 : 
       param 0: PASS THROUGH: 3, op nop_expr
         value: 0x0, mask: 0xffff
         Unknown VR
  Jump functions of caller  Siul2_Dio_Ip_ReadPin/10:
    callsite  Siul2_Dio_Ip_ReadPin/10 -> Siul2_Dio_Ip_Rev_Bit_16/2 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffff
         Unknown VR
    callsite  Siul2_Dio_Ip_ReadPin/10 -> DevAssert/0 : 
       param 0: PASS THROUGH: 1, op le_expr 15
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Siul2_Dio_Ip_ReadPin/10 -> DevAssert/0 : 
       param 0: PASS THROUGH: 0, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Siul2_Dio_Ip_ReadPins/9:
    callsite  Siul2_Dio_Ip_ReadPins/9 -> Siul2_Dio_Ip_Rev_Bit_16/2 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffff
         Unknown VR
    callsite  Siul2_Dio_Ip_ReadPins/9 -> DevAssert/0 : 
       param 0: PASS THROUGH: 0, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Siul2_Dio_Ip_TogglePins/8:
    callsite  Siul2_Dio_Ip_TogglePins/8 -> Siul2_Dio_Ip_Rev_Bit_16/2 : 
       param 0: PASS THROUGH: 1, op nop_expr
         value: 0x0, mask: 0xffff
         Unknown VR
    callsite  Siul2_Dio_Ip_TogglePins/8 -> DevAssert/0 : 
       param 0: PASS THROUGH: 0, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Siul2_Dio_Ip_ClearPins/7:
    callsite  Siul2_Dio_Ip_ClearPins/7 -> Siul2_Dio_Ip_Rev_Bit_16/2 : 
       param 0: PASS THROUGH: 1, op nop_expr
         value: 0x0, mask: 0xffff
         Unknown VR
    callsite  Siul2_Dio_Ip_ClearPins/7 -> DevAssert/0 : 
       param 0: PASS THROUGH: 0, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Siul2_Dio_Ip_SetPins/6:
    callsite  Siul2_Dio_Ip_SetPins/6 -> Siul2_Dio_Ip_Rev_Bit_16/2 : 
       param 0: PASS THROUGH: 1, op nop_expr
         value: 0x0, mask: 0xffff
         Unknown VR
    callsite  Siul2_Dio_Ip_SetPins/6 -> DevAssert/0 : 
       param 0: PASS THROUGH: 0, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Siul2_Dio_Ip_GetPinsOutput/5:
    callsite  Siul2_Dio_Ip_GetPinsOutput/5 -> Siul2_Dio_Ip_Rev_Bit_16/2 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffff
         Unknown VR
    callsite  Siul2_Dio_Ip_GetPinsOutput/5 -> DevAssert/0 : 
       param 0: PASS THROUGH: 0, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Siul2_Dio_Ip_WritePins/4:
    callsite  Siul2_Dio_Ip_WritePins/4 -> Siul2_Dio_Ip_Rev_Bit_16/2 : 
       param 0: PASS THROUGH: 1, op nop_expr
         value: 0x0, mask: 0xffff
         Unknown VR
    callsite  Siul2_Dio_Ip_WritePins/4 -> DevAssert/0 : 
       param 0: PASS THROUGH: 0, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Siul2_Dio_Ip_WritePin/3:
    callsite  Siul2_Dio_Ip_WritePin/3 -> SchM_Exit_Dio_DIO_EXCLUSIVE_AREA_01/13 : 
       no arg info
    callsite  Siul2_Dio_Ip_WritePin/3 -> SchM_Enter_Dio_DIO_EXCLUSIVE_AREA_01/12 : 
       no arg info
    callsite  Siul2_Dio_Ip_WritePin/3 -> DevAssert/0 : 
       param 0: PASS THROUGH: 2, op le_expr 1
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Siul2_Dio_Ip_WritePin/3 -> DevAssert/0 : 
       param 0: PASS THROUGH: 1, op le_expr 15
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Siul2_Dio_Ip_WritePin/3 -> DevAssert/0 : 
       param 0: PASS THROUGH: 0, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Siul2_Dio_Ip_Rev_Bit_16/2:
  Jump functions of caller  DevAssert/0:

 Propagating constants:

Not considering Siul2_Dio_Ip_MaskedWritePins/11 for cloning; -fipa-cp-clone disabled.
Not considering Siul2_Dio_Ip_ReadPin/10 for cloning; -fipa-cp-clone disabled.
Not considering Siul2_Dio_Ip_ReadPins/9 for cloning; -fipa-cp-clone disabled.
Not considering Siul2_Dio_Ip_TogglePins/8 for cloning; -fipa-cp-clone disabled.
Not considering Siul2_Dio_Ip_ClearPins/7 for cloning; -fipa-cp-clone disabled.
Not considering Siul2_Dio_Ip_SetPins/6 for cloning; -fipa-cp-clone disabled.
Not considering Siul2_Dio_Ip_GetPinsOutput/5 for cloning; -fipa-cp-clone disabled.
Not considering Siul2_Dio_Ip_WritePins/4 for cloning; -fipa-cp-clone disabled.
Not considering Siul2_Dio_Ip_WritePin/3 for cloning; -fipa-cp-clone disabled.

overall_size: 143

IPA lattices after all propagation:

Lattices:
  Node: Siul2_Dio_Ip_MaskedWritePins/11:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [3]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Siul2_Dio_Ip_ReadPin/10:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Siul2_Dio_Ip_ReadPins/9:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Siul2_Dio_Ip_TogglePins/8:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Siul2_Dio_Ip_ClearPins/7:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Siul2_Dio_Ip_SetPins/6:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Siul2_Dio_Ip_GetPinsOutput/5:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Siul2_Dio_Ip_WritePins/4:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Siul2_Dio_Ip_WritePin/3:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Siul2_Dio_Ip_Rev_Bit_16/2:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: DevAssert/0:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE

IPA decision stage:


IPA constant propagation end

Reclaiming functions:
Reclaiming variables:
Clearing address taken flags:
Symbol table:

SchM_Exit_Dio_DIO_EXCLUSIVE_AREA_01/13 (SchM_Exit_Dio_DIO_EXCLUSIVE_AREA_01) @05e772a0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Siul2_Dio_Ip_WritePin/3 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
SchM_Enter_Dio_DIO_EXCLUSIVE_AREA_01/12 (SchM_Enter_Dio_DIO_EXCLUSIVE_AREA_01) @05e771c0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Siul2_Dio_Ip_WritePin/3 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Siul2_Dio_Ip_MaskedWritePins/11 (Siul2_Dio_Ip_MaskedWritePins) @05e63620
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Siul2_Dio_Ip_au32BaseAdresses/1 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Siul2_Dio_Ip_Rev_Bit_16/2 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_Rev_Bit_16/2 (1073741824 (estimated locally),1.00 per call) 
Siul2_Dio_Ip_ReadPin/10 (Siul2_Dio_Ip_ReadPin) @05e630e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Siul2_Dio_Ip_Rev_Bit_16/2 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) 
Siul2_Dio_Ip_ReadPins/9 (Siul2_Dio_Ip_ReadPins) @05e63d20
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Siul2_Dio_Ip_Rev_Bit_16/2 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) 
Siul2_Dio_Ip_TogglePins/8 (Siul2_Dio_Ip_TogglePins) @05e63a80
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Siul2_Dio_Ip_Rev_Bit_16/2 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) 
Siul2_Dio_Ip_ClearPins/7 (Siul2_Dio_Ip_ClearPins) @05e637e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Siul2_Dio_Ip_Rev_Bit_16/2 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) 
Siul2_Dio_Ip_SetPins/6 (Siul2_Dio_Ip_SetPins) @05e63540
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Siul2_Dio_Ip_Rev_Bit_16/2 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) 
Siul2_Dio_Ip_GetPinsOutput/5 (Siul2_Dio_Ip_GetPinsOutput) @05e632a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Siul2_Dio_Ip_Rev_Bit_16/2 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) 
Siul2_Dio_Ip_WritePins/4 (Siul2_Dio_Ip_WritePins) @05e63000
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Siul2_Dio_Ip_Rev_Bit_16/2 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) 
Siul2_Dio_Ip_WritePin/3 (Siul2_Dio_Ip_WritePin) @05e58b60
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: SchM_Exit_Dio_DIO_EXCLUSIVE_AREA_01/13 (1073741824 (estimated locally),1.00 per call) SchM_Enter_Dio_DIO_EXCLUSIVE_AREA_01/12 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) DevAssert/0 (1073741824 (estimated locally),1.00 per call) 
Siul2_Dio_Ip_Rev_Bit_16/2 (Siul2_Dio_Ip_Rev_Bit_16) @05e58d20
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:119292720 (estimated locally) body local optimize_size
  Called by: Siul2_Dio_Ip_MaskedWritePins/11 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_MaskedWritePins/11 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_ReadPin/10 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_ReadPins/9 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_TogglePins/8 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_ClearPins/7 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_SetPins/6 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_GetPinsOutput/5 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_WritePins/4 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Siul2_Dio_Ip_au32BaseAdresses/1 (Siul2_Dio_Ip_au32BaseAdresses) @05e57f30
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: Siul2_Dio_Ip_MaskedWritePins/11 (read) 
  Availability: available
  Varpool flags: initialized
DevAssert/0 (DevAssert) @05e58620
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:21262216 (estimated locally) body local optimize_size
  Called by: Siul2_Dio_Ip_ReadPin/10 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_ReadPin/10 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_ReadPins/9 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_TogglePins/8 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_ClearPins/7 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_SetPins/6 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_GetPinsOutput/5 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_WritePins/4 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_WritePin/3 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_WritePin/3 (1073741824 (estimated locally),1.00 per call) Siul2_Dio_Ip_WritePin/3 (1073741824 (estimated locally),1.00 per call) 
  Calls: 

;; Function DevAssert (DevAssert, funcdef_no=0, decl_uid=6079, cgraph_uid=1, symbol_order=0)

Modification phase of node DevAssert/0
DevAssert (volatile boolean x)
{
  _Bool x.0_1;

  <bb 2> [local count: 21262216]:
  # DEBUG BEGIN_STMT
  x.0_1 ={v} x;
  if (x.0_1 != 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 5> [local count: 10631108]:

  <bb 3> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__("BKPT #0");
  # DEBUG BEGIN_STMT

  <bb 6> [local count: 1073741824]:
  goto <bb 3>; [100.00%]

  <bb 4> [local count: 10631108]:
  # DEBUG BEGIN_STMT
  return;

}



;; Function Siul2_Dio_Ip_Rev_Bit_16 (Siul2_Dio_Ip_Rev_Bit_16, funcdef_no=1, decl_uid=6084, cgraph_uid=2, symbol_order=2)

Modification phase of node Siul2_Dio_Ip_Rev_Bit_16/2
Siul2_Dio_Ip_Rev_Bit_16 (uint16 value)
{
  uint16 ret;
  uint8 i;
  int _1;
  int _2;
  int _3;
  unsigned int _4;
  unsigned int _5;
  unsigned int _6;
  unsigned int _7;
  unsigned int _8;
  short unsigned int _9;
  int _11;
  unsigned int _12;
  unsigned int _13;
  unsigned int _14;
  short unsigned int _15;
  short unsigned int _16;

  <bb 2> [local count: 119292720]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG ret => 0
  # DEBUG BEGIN_STMT
  # DEBUG i => 0
  goto <bb 4>; [100.00%]

  <bb 3> [local count: 954449105]:
  # DEBUG BEGIN_STMT
  _1 = (int) value_20(D);
  _2 = (int) i_17;
  _3 = _1 >> _2;
  _4 = (unsigned int) _3;
  _5 = _4 & 1;
  _6 = (unsigned int) i_17;
  _7 = 15 - _6;
  _8 = _5 << _7;
  _9 = (short unsigned int) _8;
  _11 = _1 << _2;
  _12 = (unsigned int) _11;
  _13 = _12 & 32768;
  _14 = _13 >> _7;
  _15 = (short unsigned int) _14;
  _16 = _9 | _15;
  ret_21 = _16 | ret_18;
  # DEBUG ret => ret_21
  # DEBUG BEGIN_STMT
  i_22 = i_17 + 1;
  # DEBUG i => i_22

  <bb 4> [local count: 1073741824]:
  # i_17 = PHI <0(2), i_22(3)>
  # ret_18 = PHI <0(2), ret_21(3)>
  # DEBUG ret => ret_18
  # DEBUG i => i_17
  # DEBUG BEGIN_STMT
  if (i_17 != 8)
    goto <bb 3>; [88.89%]
  else
    goto <bb 5>; [11.11%]

  <bb 5> [local count: 119292720]:
  # ret_10 = PHI <ret_18(4)>
  # DEBUG BEGIN_STMT
  return ret_10;

}



;; Function Siul2_Dio_Ip_WritePin (Siul2_Dio_Ip_WritePin, funcdef_no=2, decl_uid=6032, cgraph_uid=3, symbol_order=3)

Modification phase of node Siul2_Dio_Ip_WritePin/3
Siul2_Dio_Ip_WritePin (struct Siul2_Dio_Ip_GpioType * const base, Siul2_Dio_Ip_PinsChannelType pin, Siul2_Dio_Ip_PinsLevelType value)
{
  Siul2_Dio_Ip_PinsChannelType pinsValues;
  _Bool _1;
  _Bool _2;
  _Bool _3;
  unsigned int _4;
  unsigned int _5;
  int _6;
  short unsigned int _7;
  short unsigned int _8;
  unsigned int _9;
  unsigned int _10;
  short unsigned int _11;
  unsigned char _25;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = base_12(D) != 0B;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _2 = pin_15(D) <= 15;
  DevAssert (_2);
  # DEBUG BEGIN_STMT
  _3 = value_17(D) <= 1;
  DevAssert (_3);
  # DEBUG BEGIN_STMT
  SchM_Enter_Dio_DIO_EXCLUSIVE_AREA_01 ();
  # DEBUG BEGIN_STMT
  pinsValues_20 ={v} base_12(D)->PGPDO;
  # DEBUG pinsValues => pinsValues_20
  # DEBUG BEGIN_STMT
  _4 = (unsigned int) pin_15(D);
  _5 = 15 - _4;
  _6 = 1 << _5;
  _7 = (short unsigned int) _6;
  _8 = ~_7;
  pinsValues_21 = _8 & pinsValues_20;
  # DEBUG pinsValues => pinsValues_21
  # DEBUG BEGIN_STMT
  _25 = value_17(D) & 1;
  _9 = (unsigned int) _25;
  _10 = _9 << _5;
  _11 = (short unsigned int) _10;
  pinsValues_22 = _11 | pinsValues_21;
  # DEBUG pinsValues => pinsValues_22
  # DEBUG BEGIN_STMT
  base_12(D)->PGPDO ={v} pinsValues_22;
  # DEBUG BEGIN_STMT
  SchM_Exit_Dio_DIO_EXCLUSIVE_AREA_01 ();
  return;

}



;; Function Siul2_Dio_Ip_WritePins (Siul2_Dio_Ip_WritePins, funcdef_no=3, decl_uid=6035, cgraph_uid=4, symbol_order=4)

Modification phase of node Siul2_Dio_Ip_WritePins/4
Siul2_Dio_Ip_WritePins (struct Siul2_Dio_Ip_GpioType * const base, Siul2_Dio_Ip_PinsChannelType pins)
{
  _Bool _1;
  short unsigned int _2;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = base_3(D) != 0B;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _2 = Siul2_Dio_Ip_Rev_Bit_16 (pins_6(D));
  base_3(D)->PGPDO ={v} _2;
  return;

}



;; Function Siul2_Dio_Ip_GetPinsOutput (Siul2_Dio_Ip_GetPinsOutput, funcdef_no=4, decl_uid=6037, cgraph_uid=5, symbol_order=5)

Modification phase of node Siul2_Dio_Ip_GetPinsOutput/5
Siul2_Dio_Ip_GetPinsOutput (const struct Siul2_Dio_Ip_GpioType * const base)
{
  Siul2_Dio_Ip_PinsChannelType returnValue;
  _Bool _1;
  short unsigned int _2;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = base_3(D) != 0B;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  # DEBUG returnValue => 0
  # DEBUG BEGIN_STMT
  _2 ={v} base_3(D)->PGPDO;
  returnValue_6 = Siul2_Dio_Ip_Rev_Bit_16 (_2);
  # DEBUG returnValue => returnValue_6
  # DEBUG BEGIN_STMT
  return returnValue_6;

}



;; Function Siul2_Dio_Ip_SetPins (Siul2_Dio_Ip_SetPins, funcdef_no=5, decl_uid=6040, cgraph_uid=6, symbol_order=6)

Modification phase of node Siul2_Dio_Ip_SetPins/6
Siul2_Dio_Ip_SetPins (struct Siul2_Dio_Ip_GpioType * const base, Siul2_Dio_Ip_PinsChannelType pins)
{
  _Bool _1;
  short unsigned int _2;
  short unsigned int _3;
  short unsigned int _8;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = base_4(D) != 0B;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _8 = Siul2_Dio_Ip_Rev_Bit_16 (pins_7(D));
  _2 ={v} base_4(D)->PGPDO;
  _3 = _2 | _8;
  base_4(D)->PGPDO ={v} _3;
  return;

}



;; Function Siul2_Dio_Ip_ClearPins (Siul2_Dio_Ip_ClearPins, funcdef_no=6, decl_uid=6043, cgraph_uid=7, symbol_order=7)

Modification phase of node Siul2_Dio_Ip_ClearPins/7
Siul2_Dio_Ip_ClearPins (struct Siul2_Dio_Ip_GpioType * const base, Siul2_Dio_Ip_PinsChannelType pins)
{
  _Bool _1;
  short unsigned int _2;
  short unsigned int _3;
  short unsigned int _4;
  short unsigned int _9;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = base_5(D) != 0B;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _2 = Siul2_Dio_Ip_Rev_Bit_16 (pins_8(D));
  _9 = ~_2;
  _3 ={v} base_5(D)->PGPDO;
  _4 = _3 & _9;
  base_5(D)->PGPDO ={v} _4;
  return;

}



;; Function Siul2_Dio_Ip_TogglePins (Siul2_Dio_Ip_TogglePins, funcdef_no=7, decl_uid=6046, cgraph_uid=8, symbol_order=8)

Modification phase of node Siul2_Dio_Ip_TogglePins/8
Siul2_Dio_Ip_TogglePins (struct Siul2_Dio_Ip_GpioType * const base, Siul2_Dio_Ip_PinsChannelType pins)
{
  _Bool _1;
  short unsigned int _2;
  short unsigned int _3;
  short unsigned int _8;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = base_4(D) != 0B;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _8 = Siul2_Dio_Ip_Rev_Bit_16 (pins_7(D));
  _2 ={v} base_4(D)->PGPDO;
  _3 = _2 ^ _8;
  base_4(D)->PGPDO ={v} _3;
  return;

}



;; Function Siul2_Dio_Ip_ReadPins (Siul2_Dio_Ip_ReadPins, funcdef_no=8, decl_uid=6048, cgraph_uid=9, symbol_order=9)

Modification phase of node Siul2_Dio_Ip_ReadPins/9
Siul2_Dio_Ip_ReadPins (const struct Siul2_Dio_Ip_GpioType * const base)
{
  Siul2_Dio_Ip_PinsChannelType returnValue;
  _Bool _1;
  short unsigned int _2;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = base_3(D) != 0B;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  # DEBUG returnValue => 0
  # DEBUG BEGIN_STMT
  _2 ={v} base_3(D)->PGPDI;
  returnValue_6 = Siul2_Dio_Ip_Rev_Bit_16 (_2);
  # DEBUG returnValue => returnValue_6
  # DEBUG BEGIN_STMT
  return returnValue_6;

}



;; Function Siul2_Dio_Ip_ReadPin (Siul2_Dio_Ip_ReadPin, funcdef_no=9, decl_uid=6056, cgraph_uid=10, symbol_order=10)

Modification phase of node Siul2_Dio_Ip_ReadPin/10
Siul2_Dio_Ip_ReadPin (const struct Siul2_Dio_Ip_GpioType * const base, Siul2_Dio_Ip_PinsChannelType pin)
{
  Siul2_Dio_Ip_PinsLevelType returnValue;
  _Bool _1;
  _Bool _2;
  short unsigned int _3;
  short unsigned int _4;
  int _5;
  int _6;
  int _7;
  int _8;
  int _9;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = base_10(D) != 0B;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _2 = pin_13(D) <= 15;
  DevAssert (_2);
  # DEBUG BEGIN_STMT
  # DEBUG returnValue => 0
  # DEBUG BEGIN_STMT
  _3 ={v} base_10(D)->PGPDI;
  _4 = Siul2_Dio_Ip_Rev_Bit_16 (_3);
  _5 = (int) _4;
  _6 = (int) pin_13(D);
  _7 = 1 << _6;
  _8 = _5 & _7;
  _9 = _8 >> _6;
  returnValue_15 = (Siul2_Dio_Ip_PinsLevelType) _9;
  # DEBUG returnValue => returnValue_15
  # DEBUG BEGIN_STMT
  return returnValue_15;

}



;; Function Siul2_Dio_Ip_MaskedWritePins (Siul2_Dio_Ip_MaskedWritePins, funcdef_no=10, decl_uid=6053, cgraph_uid=11, symbol_order=11)

Modification phase of node Siul2_Dio_Ip_MaskedWritePins/11
Siul2_Dio_Ip_MaskedWritePins (uint8 u8Siul2Instance, uint8 u8PortId, Siul2_Dio_Ip_PinsChannelType pins, Siul2_Dio_Ip_PinsChannelType mask)
{
  uint32 pinsRev;
  uint32 maskRev;
  struct SIUL2_Type * base;
  int _1;
  long unsigned int _2;
  short unsigned int _3;
  short unsigned int _4;
  long unsigned int _5;
  int _6;
  long unsigned int _7;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = (int) u8Siul2Instance_8(D);
  _2 = Siul2_Dio_Ip_au32BaseAdresses[_1];
  base_10 = (struct SIUL2_Type *) _2;
  # DEBUG base => base_10
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _3 = Siul2_Dio_Ip_Rev_Bit_16 (mask_11(D));
  maskRev_12 = (uint32) _3;
  # DEBUG maskRev => maskRev_12
  # DEBUG BEGIN_STMT
  _4 = Siul2_Dio_Ip_Rev_Bit_16 (pins_13(D));
  pinsRev_14 = (uint32) _4;
  # DEBUG pinsRev => pinsRev_14
  # DEBUG BEGIN_STMT
  _5 = maskRev_12 << 16;
  _6 = (int) u8PortId_15(D);
  _7 = _5 | pinsRev_14;
  base_10->MPGPDO[_6] ={v} _7;
  return;

}


