
IPA constant propagation start:
Determining dynamic type for call: UART_PutStr ("\r\nAPP: application code has been running\r\n");
  Starting walk at: UART_PutStr ("\r\nAPP: application code has been running\r\n");
  instance pointer: "\r\nAPP: application code has been running\r\n"  Outer instance pointer: "\r\nAPP: application code has been running\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_PutStr ("APP: heartbeat #");
  Starting walk at: UART_PutStr ("APP: heartbeat #");
  instance pointer: "APP: heartbeat #"  Outer instance pointer: "APP: heartbeat #" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_PutStr ("\r\n");
  Starting walk at: UART_PutStr ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 

IPA structures before propagation:

Jump functions:
  Jump functions of caller  UART_PutChar.part.0/46:
    callsite  UART_PutChar.part.0/46 -> Lpuart_Uart_Ip_GetTransmitStatus/45 : 
       no arg info
  Jump functions of caller  Lpuart_Uart_Ip_GetTransmitStatus/45:
  Jump functions of caller  Lpuart_Uart_Ip_AsyncSend/44:
  Jump functions of caller  Lpuart_Uart_Ip_Init/42:
  Jump functions of caller  IntCtrl_Ip_ConfigIrqRouting/40:
  Jump functions of caller  IntCtrl_Ip_Init/38:
  Jump functions of caller  Siul2_Port_Ip_Init/36:
  Jump functions of caller  Clock_Ip_Init/34:
  Jump functions of caller  main/33:
    callsite  main/33 -> UART_PutStr/29 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/33 -> UART_PutUint32Dec/30 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  main/33 -> UART_PutStr/29 : 
       param 0: CONST: "APP: heartbeat #"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/33 -> Delay_Ms/31 : 
       param 0: CONST: 1000
         value: 0x3e8, mask: 0x0
         Unknown VR
    callsite  main/33 -> UART_PutStr/29 : 
       param 0: CONST: "\r\nAPP: application code has been running\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/33 -> Lpuart_Uart_Ip_Init/42 : 
       no arg info
    callsite  main/33 -> IntCtrl_Ip_ConfigIrqRouting/40 : 
       no arg info
    callsite  main/33 -> IntCtrl_Ip_Init/38 : 
       no arg info
    callsite  main/33 -> Siul2_Port_Ip_Init/36 : 
       no arg info
    callsite  main/33 -> Clock_Ip_Init/34 : 
       no arg info
  Jump functions of caller  PitNotification/32:
  Jump functions of caller  Delay_Ms/31:
  Jump functions of caller  UART_PutUint32Dec/30:
    callsite  UART_PutUint32Dec/30 -> UART_PutChar/28 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  UART_PutUint32Dec/30 -> UART_PutChar/28 : 
       param 0: CONST: 48
         value: 0x30, mask: 0x0
         Unknown VR
  Jump functions of caller  UART_PutStr/29:
    callsite  UART_PutStr/29 -> UART_PutChar/28 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xff
         Unknown VR
  Jump functions of caller  UART_PutChar/28:
    callsite  UART_PutChar/28 -> UART_PutChar.part.0/46 : 
    callsite  UART_PutChar/28 -> Lpuart_Uart_Ip_AsyncSend/44 : 
       no arg info

 Propagating constants:


overall_size: 100
 - context independent values, size: 13, time_benefit: 65.000000
     Decided to specialize for all known contexts, code not going to grow.

IPA lattices after all propagation:

Lattices:
  Node: UART_PutChar.part.0/46:
  Node: main/33:
  Node: PitNotification/32:
  Node: Delay_Ms/31:
    param [0]: 1000 [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x3e8, mask = 0x0
         uint32_t [1000, 1000]
        AGGS VARIABLE
  Node: UART_PutUint32Dec/30:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: UART_PutStr/29:
    param [0]: "\r\n" [loc_time: 1, loc_size: 9, prop_time: 0, prop_size: 0]
               "APP: heartbeat #" [loc_time: 1, loc_size: 9, prop_time: 0, prop_size: 0]
               "\r\nAPP: application code has been running\r\n" [loc_time: 1, loc_size: 9, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         const char * [1B, +INF]
        AGGS VARIABLE
  Node: UART_PutChar/28:
    param [0]: VARIABLE
               48 [loc_time: 1, loc_size: 11, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE

IPA decision stage:

 - Creating a specialized node of Delay_Ms/31 for all known contexts.
    replacing param #0 ms with const 1000
Propagated bits info for function Delay_Ms.constprop/47:
 param 0: value = 0x3e8, mask = 0x0
Propagated bits info for function Delay_Ms/31:
 param 0: value = 0x3e8, mask = 0x0

IPA constant propagation end

Reclaiming functions: Delay_Ms/31
Reclaiming variables:
Clearing address taken flags:
Symbol table:

Delay_Ms.constprop.0/47 (Delay_Ms.constprop) @0867bc40
  Type: function definition analyzed
  Visibility:
  References: 
  Referring: 
  Clone of Delay_Ms/31
  Availability: local
  Function flags: count:14598063 (estimated locally) local optimize_size
  Called by: main/33 (528857910 (estimated locally),33.33 per call) 
  Calls: 
UART_PutChar.part.0/46 (UART_PutChar.part.0) @071329a0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly artificial
  References: 
  Referring: 
  Availability: local
  Function flags: count:118111600 (estimated locally) body local split_part optimize_size
  Called by: UART_PutChar/28 (118111600 (estimated locally),0.50 per call) 
  Calls: Lpuart_Uart_Ip_GetTransmitStatus/45 (1073741824 (estimated locally),9.09 per call) 
Lpuart_Uart_Ip_GetTransmitStatus/45 (Lpuart_Uart_Ip_GetTransmitStatus) @0867b460
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: UART_PutChar.part.0/46 (1073741824 (estimated locally),9.09 per call) 
  Calls: 
Lpuart_Uart_Ip_AsyncSend/44 (Lpuart_Uart_Ip_AsyncSend) @0867b380
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: UART_PutChar/28 (236223200 (estimated locally),1.00 per call) 
  Calls: 
Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS/43 (Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS) @08675870
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/33 (addr) 
  Availability: not_available
  Varpool flags: read-only
Lpuart_Uart_Ip_Init/42 (Lpuart_Uart_Ip_Init) @08672000
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/33 (5236217 (estimated locally),0.33 per call) 
  Calls: 
intRouteConfig/41 (intRouteConfig) @086757e0
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/33 (addr) 
  Availability: not_available
  Varpool flags: read-only
IntCtrl_Ip_ConfigIrqRouting/40 (IntCtrl_Ip_ConfigIrqRouting) @08672ee0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/33 (5236217 (estimated locally),0.33 per call) 
  Calls: 
IntCtrlConfig_0/39 (IntCtrlConfig_0) @08675750
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/33 (addr) 
  Availability: not_available
  Varpool flags: read-only
IntCtrl_Ip_Init/38 (IntCtrl_Ip_Init) @08672e00
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/33 (5236217 (estimated locally),0.33 per call) 
  Calls: 
g_pin_mux_InitConfigArr0/37 (g_pin_mux_InitConfigArr0) @086756c0
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/33 (addr) 
  Availability: not_available
  Varpool flags: read-only
Siul2_Port_Ip_Init/36 (Siul2_Port_Ip_Init) @08672d20
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/33 (5236217 (estimated locally),0.33 per call) 
  Calls: 
Clock_Ip_aClockConfig/35 (Clock_Ip_aClockConfig) @08675630
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/33 (addr) 
  Availability: not_available
  Varpool flags: read-only
Clock_Ip_Init/34 (Clock_Ip_Init) @08672c40
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/33 (15867325 (estimated locally),1.00 per call) 
  Calls: 
main/33 (main) @08672700
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Clock_Ip_aClockConfig/35 (addr) g_pin_mux_InitConfigArr0/37 (addr) IntCtrlConfig_0/39 (addr) intRouteConfig/41 (addr) Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS/43 (addr) 
  Referring: 
  Availability: available
  Function flags: count:15867325 (estimated locally) body only_called_at_startup executed_once optimize_size
  Called by: 
  Calls: UART_PutStr/29 (528857910 (estimated locally),33.33 per call) UART_PutUint32Dec/30 (528857910 (estimated locally),33.33 per call) UART_PutStr/29 (528857910 (estimated locally),33.33 per call) Delay_Ms.constprop.0/47 (528857910 (estimated locally),33.33 per call) UART_PutStr/29 (5236217 (estimated locally),0.33 per call) Lpuart_Uart_Ip_Init/42 (5236217 (estimated locally),0.33 per call) IntCtrl_Ip_ConfigIrqRouting/40 (5236217 (estimated locally),0.33 per call) IntCtrl_Ip_Init/38 (5236217 (estimated locally),0.33 per call) Siul2_Port_Ip_Init/36 (5236217 (estimated locally),0.33 per call) Clock_Ip_Init/34 (15867325 (estimated locally),1.00 per call) 
PitNotification/32 (PitNotification) @08672460
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 
Delay_Ms/31 (Delay_Ms) @086721c0
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:14598063 (estimated locally) body optimize_size
  Called by: 
  Calls: 
UART_PutUint32Dec/30 (UART_PutUint32Dec) @072efd20
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:148083751 (estimated locally) body local optimize_size
  Called by: main/33 (528857910 (estimated locally),33.33 per call) 
  Calls: UART_PutChar/28 (955630225 (estimated locally),6.45 per call) UART_PutChar/28 (29972151 (estimated locally),0.20 per call) 
UART_PutStr/29 (UART_PutStr) @072efee0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:118111600 (estimated locally) body local optimize_size
  Called by: main/33 (528857910 (estimated locally),33.33 per call) main/33 (528857910 (estimated locally),33.33 per call) main/33 (5236217 (estimated locally),0.33 per call) 
  Calls: UART_PutChar/28 (955630225 (estimated locally),8.09 per call) 
UART_PutChar/28 (UART_PutChar) @072efc40
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:236223200 (estimated locally) body local optimize_size
  Called by: UART_PutStr/29 (955630225 (estimated locally),8.09 per call) UART_PutUint32Dec/30 (955630225 (estimated locally),6.45 per call) UART_PutUint32Dec/30 (29972151 (estimated locally),0.20 per call) 
  Calls: UART_PutChar.part.0/46 (118111600 (estimated locally),0.50 per call) Lpuart_Uart_Ip_AsyncSend/44 (236223200 (estimated locally),1.00 per call) 

;; Function UART_PutChar (UART_PutChar, funcdef_no=28, decl_uid=9768, cgraph_uid=29, symbol_order=28)

Modification phase of node UART_PutChar/28
UART_PutChar (uint8_t ch)
{
  Lpuart_Uart_Ip_StatusType txStatus;

  <bb 2> [local count: 236223200]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  txStatus_4 = Lpuart_Uart_Ip_AsyncSend (2, &ch, 1);
  # DEBUG txStatus => txStatus_4
  # DEBUG BEGIN_STMT
  if (txStatus_4 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 4>; [50.00%]

  <bb 3> [local count: 118111600]:
  UART_PutChar.part.0 ();

  <bb 4> [local count: 236223200]:
  return;

}



;; Function UART_PutStr (UART_PutStr, funcdef_no=29, decl_uid=9770, cgraph_uid=30, symbol_order=29)

Modification phase of node UART_PutStr/29
Setting nonnull for 0
UART_PutStr (const char * s)
{
  char _1;

  <bb 2> [local count: 118111600]:
  # DEBUG BEGIN_STMT
  goto <bb 4>; [100.00%]

  <bb 3> [local count: 955630225]:
  # DEBUG BEGIN_STMT
  UART_PutChar (_1);
  # DEBUG BEGIN_STMT
  s_7 = s_2 + 1;
  # DEBUG s => s_7

  <bb 4> [local count: 1073741824]:
  # s_2 = PHI <s_4(D)(2), s_7(3)>
  # DEBUG s => s_2
  # DEBUG BEGIN_STMT
  _1 = *s_2;
  if (_1 != 0)
    goto <bb 3>; [89.00%]
  else
    goto <bb 5>; [11.00%]

  <bb 5> [local count: 118111600]:
  return;

}



;; Function PitNotification (PitNotification, funcdef_no=32, decl_uid=9810, cgraph_uid=33, symbol_order=32)

Modification phase of node PitNotification/32
PitNotification ()
{
  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  return;

}



;; Function main (main, funcdef_no=33, decl_uid=9813, cgraph_uid=34, symbol_order=33) (executed once)

Modification phase of node main/33
main ()
{
  uint32_t heartbeat;
  Clock_Ip_StatusType clkSt;

  <bb 2> [local count: 15867325]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  MEM[(volatile uint32_t *)3758157064B] ={v} 4505600;
  # DEBUG BEGIN_STMT
  __asm__ __volatile__("dsb" :  :  : "memory");
  # DEBUG BEGIN_STMT
  __asm__ __volatile__("isb" :  :  : "memory");
  # DEBUG BEGIN_STMT
  clkSt_9 = Clock_Ip_Init (&Clock_Ip_aClockConfig[0]);
  # DEBUG clkSt => clkSt_9
  # DEBUG BEGIN_STMT
  if (clkSt_9 != 0)
    goto <bb 6>; [67.00%]
  else
    goto <bb 4>; [33.00%]

  <bb 6> [local count: 10631108]:

  <bb 3> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__("nop");
  # DEBUG BEGIN_STMT

  <bb 7> [local count: 1073741824]:
  goto <bb 3>; [100.00%]

  <bb 4> [local count: 5236217]:
  # DEBUG BEGIN_STMT
  Siul2_Port_Ip_Init (3, &g_pin_mux_InitConfigArr0);
  # DEBUG BEGIN_STMT
  IntCtrl_Ip_Init (&IntCtrlConfig_0);
  # DEBUG BEGIN_STMT
  IntCtrl_Ip_ConfigIrqRouting (&intRouteConfig);
  # DEBUG BEGIN_STMT
  Lpuart_Uart_Ip_Init (2, &Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS);
  # DEBUG BEGIN_STMT
  UART_PutStr ("\r\nAPP: application code has been running\r\n");
  # DEBUG BEGIN_STMT
  # DEBUG heartbeat => 0

  <bb 5> [local count: 528857910]:
  # heartbeat_1 = PHI <0(4), heartbeat_19(8)>
  # DEBUG heartbeat => heartbeat_1
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  Delay_Ms (1000);
  # DEBUG BEGIN_STMT
  UART_PutStr ("APP: heartbeat #");
  # DEBUG BEGIN_STMT
  UART_PutUint32Dec (heartbeat_1);
  # DEBUG BEGIN_STMT
  UART_PutStr ("\r\n");
  # DEBUG BEGIN_STMT
  heartbeat_19 = heartbeat_1 + 1;
  # DEBUG heartbeat => heartbeat_19
  # DEBUG BEGIN_STMT

  <bb 8> [local count: 528857910]:
  goto <bb 5>; [100.00%]

}


