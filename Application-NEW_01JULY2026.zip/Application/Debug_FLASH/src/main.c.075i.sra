Creating summary for UART_PutChar.part.0/46:


Creating summary for main/33:


Creating summary for PitNotification/32:


Creating summary for Delay_Ms/31:
  Descriptor for parameter 0 msD.9799
    not a candidate for splitting


Creating summary for UART_PutUint32Dec/30:
  Descriptor for parameter 0 vD.9788
    not a candidate for splitting


Creating summary for UART_PutStr/29:
  Descriptor for parameter 0 sD.9782
    not a candidate for splitting


Creating summary for UART_PutChar/28:
  Descriptor for parameter 0 chD.9775
    not a candidate for splitting



========== IPA-SRA IPA stage ==========

Summary for node Delay_Ms.constprop/47:
  Descriptor for parameter 0:
    not a candidate for splitting


Summary for node UART_PutChar.part.0/46:
  No parameter information. 

  Summary for edge UART_PutChar.part.0/46->Lpuart_Uart_Ip_GetTransmitStatus/45:

Summary for node main/33:
  Returns value
  No parameter information. 

  Summary for edge main/33->UART_PutStr/29:
    return value ignored
  Summary for edge main/33->UART_PutUint32Dec/30:
    return value ignored
  Summary for edge main/33->UART_PutStr/29:
    return value ignored
  Summary for edge main/33->Delay_Ms.constprop/47:
    return value ignored
  Summary for edge main/33->UART_PutStr/29:
    return value ignored
  Summary for edge main/33->Lpuart_Uart_Ip_Init/42:
    return value ignored
  Summary for edge main/33->IntCtrl_Ip_ConfigIrqRouting/40:
    return value ignored
  Summary for edge main/33->IntCtrl_Ip_Init/38:
    return value ignored
  Summary for edge main/33->Siul2_Port_Ip_Init/36:
    return value ignored
  Summary for edge main/33->Clock_Ip_Init/34:

Summary for node PitNotification/32:
  No parameter information. 


Summary for node UART_PutUint32Dec/30:
  Descriptor for parameter 0:
    not a candidate for splitting

  Summary for edge UART_PutUint32Dec/30->UART_PutChar/28:
    return value ignored
  Summary for edge UART_PutUint32Dec/30->UART_PutChar/28:
    return value ignored

Summary for node UART_PutStr/29:
  Descriptor for parameter 0:
    not a candidate for splitting

  Summary for edge UART_PutStr/29->UART_PutChar/28:
    return value ignored
    Parameter 0:
      Scalar param sources: 0

Summary for node UART_PutChar/28:
  Descriptor for parameter 0:
    not a candidate for splitting

  Summary for edge UART_PutChar/28->UART_PutChar.part.0/46:
    return value ignored
  Summary for edge UART_PutChar/28->Lpuart_Uart_Ip_AsyncSend/44:


Function PitNotification/32 disqualified because it cannot be made local.
Function main/33 disqualified because it cannot be made local.

========== IPA-SRA decisions ==========

========== IPA SRA IPA analysis done ==========


Reclaiming functions:
Reclaiming variables:
Clearing address taken flags:
Symbol table:

Delay_Ms.constprop.0/47 (Delay_Ms.constprop) @0867bc40
  Type: function definition analyzed
  Visibility:
  References: 
  Referring: 
  Clone of Delay_Ms/31
  Availability: local
  Function flags: count:14598063 (estimated locally) local optimize_size
  Called by: main/33 (528857910 (estimated locally),33.33 per call) 
  Calls: 
UART_PutChar.part.0/46 (UART_PutChar.part.0) @071329a0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly artificial
  References: 
  Referring: 
  Availability: local
  Function flags: count:118111600 (estimated locally) body local split_part optimize_size
  Called by: UART_PutChar/28 (118111600 (estimated locally),0.50 per call) 
  Calls: Lpuart_Uart_Ip_GetTransmitStatus/45 (1073741824 (estimated locally),9.09 per call) 
Lpuart_Uart_Ip_GetTransmitStatus/45 (Lpuart_Uart_Ip_GetTransmitStatus) @0867b460
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: UART_PutChar.part.0/46 (1073741824 (estimated locally),9.09 per call) 
  Calls: 
Lpuart_Uart_Ip_AsyncSend/44 (Lpuart_Uart_Ip_AsyncSend) @0867b380
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: UART_PutChar/28 (236223200 (estimated locally),1.00 per call) 
  Calls: 
Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS/43 (Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS) @08675870
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/33 (addr) 
  Availability: not_available
  Varpool flags: read-only
Lpuart_Uart_Ip_Init/42 (Lpuart_Uart_Ip_Init) @08672000
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/33 (5236217 (estimated locally),0.33 per call) 
  Calls: 
intRouteConfig/41 (intRouteConfig) @086757e0
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/33 (addr) 
  Availability: not_available
  Varpool flags: read-only
IntCtrl_Ip_ConfigIrqRouting/40 (IntCtrl_Ip_ConfigIrqRouting) @08672ee0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/33 (5236217 (estimated locally),0.33 per call) 
  Calls: 
IntCtrlConfig_0/39 (IntCtrlConfig_0) @08675750
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/33 (addr) 
  Availability: not_available
  Varpool flags: read-only
IntCtrl_Ip_Init/38 (IntCtrl_Ip_Init) @08672e00
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/33 (5236217 (estimated locally),0.33 per call) 
  Calls: 
g_pin_mux_InitConfigArr0/37 (g_pin_mux_InitConfigArr0) @086756c0
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/33 (addr) 
  Availability: not_available
  Varpool flags: read-only
Siul2_Port_Ip_Init/36 (Siul2_Port_Ip_Init) @08672d20
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/33 (5236217 (estimated locally),0.33 per call) 
  Calls: 
Clock_Ip_aClockConfig/35 (Clock_Ip_aClockConfig) @08675630
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/33 (addr) 
  Availability: not_available
  Varpool flags: read-only
Clock_Ip_Init/34 (Clock_Ip_Init) @08672c40
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/33 (15867325 (estimated locally),1.00 per call) 
  Calls: 
main/33 (main) @08672700
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Clock_Ip_aClockConfig/35 (addr) g_pin_mux_InitConfigArr0/37 (addr) IntCtrlConfig_0/39 (addr) intRouteConfig/41 (addr) Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS/43 (addr) 
  Referring: 
  Availability: available
  Function flags: count:15867325 (estimated locally) body only_called_at_startup executed_once optimize_size
  Called by: 
  Calls: UART_PutStr/29 (528857910 (estimated locally),33.33 per call) UART_PutUint32Dec/30 (528857910 (estimated locally),33.33 per call) UART_PutStr/29 (528857910 (estimated locally),33.33 per call) Delay_Ms.constprop.0/47 (528857910 (estimated locally),33.33 per call) UART_PutStr/29 (5236217 (estimated locally),0.33 per call) Lpuart_Uart_Ip_Init/42 (5236217 (estimated locally),0.33 per call) IntCtrl_Ip_ConfigIrqRouting/40 (5236217 (estimated locally),0.33 per call) IntCtrl_Ip_Init/38 (5236217 (estimated locally),0.33 per call) Siul2_Port_Ip_Init/36 (5236217 (estimated locally),0.33 per call) Clock_Ip_Init/34 (15867325 (estimated locally),1.00 per call) 
PitNotification/32 (PitNotification) @08672460
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 
Delay_Ms/31 (Delay_Ms) @086721c0
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:14598063 (estimated locally) body optimize_size
  Called by: 
  Calls: 
UART_PutUint32Dec/30 (UART_PutUint32Dec) @072efd20
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:148083751 (estimated locally) body local optimize_size
  Called by: main/33 (528857910 (estimated locally),33.33 per call) 
  Calls: UART_PutChar/28 (955630225 (estimated locally),6.45 per call) UART_PutChar/28 (29972151 (estimated locally),0.20 per call) 
UART_PutStr/29 (UART_PutStr) @072efee0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:118111600 (estimated locally) body local optimize_size
  Called by: main/33 (528857910 (estimated locally),33.33 per call) main/33 (528857910 (estimated locally),33.33 per call) main/33 (5236217 (estimated locally),0.33 per call) 
  Calls: UART_PutChar/28 (955630225 (estimated locally),8.09 per call) 
UART_PutChar/28 (UART_PutChar) @072efc40
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:236223200 (estimated locally) body local optimize_size
  Called by: UART_PutStr/29 (955630225 (estimated locally),8.09 per call) UART_PutUint32Dec/30 (955630225 (estimated locally),6.45 per call) UART_PutUint32Dec/30 (29972151 (estimated locally),0.20 per call) 
  Calls: UART_PutChar.part.0/46 (118111600 (estimated locally),0.50 per call) Lpuart_Uart_Ip_AsyncSend/44 (236223200 (estimated locally),1.00 per call) 
UART_PutChar.part.0 ()
{
  uint32_t bytesRemaining;
  Lpuart_Uart_Ip_StatusType txStatus;
  uint8_t ch;

  <bb 5> [local count: 118111600]:

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  txStatus_1 = Lpuart_Uart_Ip_GetTransmitStatus (2, &bytesRemaining);
  # DEBUG txStatus => txStatus_1
  # DEBUG BEGIN_STMT
  if (txStatus_1 == 2)
    goto <bb 3>; [89.00%]
  else
    goto <bb 4>; [11.00%]

  <bb 3> [local count: 955630225]:
  goto <bb 2>; [100.00%]

  <bb 4> [local count: 118111600]:
  bytesRemaining ={v} {CLOBBER};
  return;

}


main ()
{
  uint32_t heartbeat;
  Clock_Ip_StatusType clkSt;

  <bb 2> [local count: 15867325]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  MEM[(volatile uint32_t *)3758157064B] ={v} 4505600;
  # DEBUG BEGIN_STMT
  __asm__ __volatile__("dsb" :  :  : "memory");
  # DEBUG BEGIN_STMT
  __asm__ __volatile__("isb" :  :  : "memory");
  # DEBUG BEGIN_STMT
  clkSt_9 = Clock_Ip_Init (&Clock_Ip_aClockConfig[0]);
  # DEBUG clkSt => clkSt_9
  # DEBUG BEGIN_STMT
  if (clkSt_9 != 0)
    goto <bb 6>; [67.00%]
  else
    goto <bb 4>; [33.00%]

  <bb 6> [local count: 10631108]:

  <bb 3> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__("nop");
  # DEBUG BEGIN_STMT

  <bb 7> [local count: 1073741824]:
  goto <bb 3>; [100.00%]

  <bb 4> [local count: 5236217]:
  # DEBUG BEGIN_STMT
  Siul2_Port_Ip_Init (3, &g_pin_mux_InitConfigArr0);
  # DEBUG BEGIN_STMT
  IntCtrl_Ip_Init (&IntCtrlConfig_0);
  # DEBUG BEGIN_STMT
  IntCtrl_Ip_ConfigIrqRouting (&intRouteConfig);
  # DEBUG BEGIN_STMT
  Lpuart_Uart_Ip_Init (2, &Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS);
  # DEBUG BEGIN_STMT
  UART_PutStr ("\r\nAPP: application code has been running\r\n");
  # DEBUG BEGIN_STMT
  # DEBUG heartbeat => 0

  <bb 5> [local count: 528857910]:
  # heartbeat_1 = PHI <0(4), heartbeat_19(8)>
  # DEBUG heartbeat => heartbeat_1
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  Delay_Ms (1000);
  # DEBUG BEGIN_STMT
  UART_PutStr ("APP: heartbeat #");
  # DEBUG BEGIN_STMT
  UART_PutUint32Dec (heartbeat_1);
  # DEBUG BEGIN_STMT
  UART_PutStr ("\r\n");
  # DEBUG BEGIN_STMT
  heartbeat_19 = heartbeat_1 + 1;
  # DEBUG heartbeat => heartbeat_19
  # DEBUG BEGIN_STMT

  <bb 8> [local count: 528857910]:
  goto <bb 5>; [100.00%]

}


PitNotification ()
{
  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  return;

}


UART_PutUint32Dec (uint32_t v)
{
  int32_t n;
  char digits[10];
  long unsigned int _1;
  char _2;
  char _3;
  char _4;

  <bb 2> [local count: 148083751]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG n => 0
  # DEBUG BEGIN_STMT
  if (v_11(D) == 0)
    goto <bb 3>; [20.24%]
  else
    goto <bb 11>; [79.76%]

  <bb 11> [local count: 118111600]:
  goto <bb 5>; [100.00%]

  <bb 3> [local count: 29972151]:
  # DEBUG BEGIN_STMT
  UART_PutChar (48);
  # DEBUG BEGIN_STMT
  digits ={v} {CLOBBER};
  goto <bb 9>; [100.00%]

  <bb 4> [local count: 955630225]:
  # DEBUG BEGIN_STMT
  _1 = v_5 % 10;
  _2 = (char) _1;
  _3 = _2 + 48;
  digits[n_6] = _3;
  # DEBUG BEGIN_STMT
  v_17 = v_5 / 10;
  # DEBUG v => v_17
  # DEBUG BEGIN_STMT
  n_18 = n_6 + 1;
  # DEBUG n => n_18

  <bb 5> [local count: 1073741824]:
  # v_5 = PHI <v_17(4), v_11(D)(11)>
  # n_6 = PHI <n_18(4), 0(11)>
  # DEBUG n => n_6
  # DEBUG v => v_5
  # DEBUG BEGIN_STMT
  if (v_5 != 0)
    goto <bb 4>; [89.00%]
  else
    goto <bb 10>; [11.00%]

  <bb 10> [local count: 118111600]:
  goto <bb 7>; [100.00%]

  <bb 6> [local count: 955630225]:
  # DEBUG BEGIN_STMT
  n_14 = n_7 + -1;
  # DEBUG n => n_14
  # DEBUG BEGIN_STMT
  _4 = digits[n_14];
  UART_PutChar (_4);

  <bb 7> [local count: 1073741824]:
  # n_7 = PHI <n_14(6), n_6(10)>
  # DEBUG n => n_7
  # DEBUG BEGIN_STMT
  if (n_7 > 0)
    goto <bb 6>; [89.00%]
  else
    goto <bb 8>; [11.00%]

  <bb 8> [local count: 118111600]:
  digits ={v} {CLOBBER};

  <bb 9> [local count: 148083751]:
  return;

}


UART_PutStr (const char * s)
{
  char _1;

  <bb 2> [local count: 118111600]:
  # DEBUG BEGIN_STMT
  goto <bb 4>; [100.00%]

  <bb 3> [local count: 955630225]:
  # DEBUG BEGIN_STMT
  UART_PutChar (_1);
  # DEBUG BEGIN_STMT
  s_7 = s_2 + 1;
  # DEBUG s => s_7

  <bb 4> [local count: 1073741824]:
  # s_2 = PHI <s_4(D)(2), s_7(3)>
  # DEBUG s => s_2
  # DEBUG BEGIN_STMT
  _1 = *s_2;
  if (_1 != 0)
    goto <bb 3>; [89.00%]
  else
    goto <bb 5>; [11.00%]

  <bb 5> [local count: 118111600]:
  return;

}


UART_PutChar (uint8_t ch)
{
  Lpuart_Uart_Ip_StatusType txStatus;

  <bb 2> [local count: 236223200]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  txStatus_4 = Lpuart_Uart_Ip_AsyncSend (2, &ch, 1);
  # DEBUG txStatus => txStatus_4
  # DEBUG BEGIN_STMT
  if (txStatus_4 == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 4>; [50.00%]

  <bb 3> [local count: 118111600]:
  UART_PutChar.part.0 ();

  <bb 4> [local count: 236223200]:
  return;

}


