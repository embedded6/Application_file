
IPA constant propagation start:

IPA structures before propagation:

Jump functions:
  Jump functions of caller  PitNotification/2:

 Propagating constants:


overall_size: 0

IPA lattices after all propagation:

Lattices:

IPA decision stage:


IPA constant propagation end

Reclaiming functions:
Reclaiming variables:
Clearing address taken flags:
Symbol table:

PitNotification/2 (PitNotification) @05e412a0
  Type: function
  Visibility: external public
  Address is taken.
  References: 
  Referring: PIT_0_ChannelConfig_PB/1 (addr) 
  Availability: not_available
  Function flags: optimize_size
  Called by: 
  Calls: 
PIT_0_ChannelConfig_PB/1 (PIT_0_ChannelConfig_PB) @05e45b88
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: PitNotification/2 (addr) 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
PIT_0_InitConfig_PB/0 (PIT_0_InitConfig_PB) @05e45af8
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
