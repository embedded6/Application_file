/*==================================================================================================
*   Project              : RTD AUTOSAR 4.4
*   Platform             : CORTEXM
*   Peripheral           : FLEXIO
*   Dependencies         : 
*
*   Autosar Version      : 4.4.0
*   Autosar Revision     : ASR_REL_4_4_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 2.0.0
*   Build Version        : S32K3_RTD_2_0_0_D2203_ASR_REL_4_4_REV_0000_20220331
*
*   (c) Copyright 2020 - 2022 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/
/**
*   @file Flexio_Uart_Ip_PBcfg.c
*   @defgroup flexio_uart_ip Flexio UART IPL
*   @addtogroup  flexio_uart_ip Flexio UART IPL
*   @{
*/


#ifdef __cplusplus
extern "C"
{
#endif

/*==================================================================================================
                                         INCLUDE FILES
 1) system and project includes
 2) needed interfaces from external units
 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Flexio_Uart_Ip_Cfg.h"
#include "StandardTypes.h"
#if (FLEXIO_UART_IP_HAS_DMA_ENABLED == STD_ON)
#include "Dma_Ip.h"
#endif
/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_VENDOR_ID_C                     43
#define FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_AR_RELEASE_MAJOR_VERSION_C      4
#define FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_AR_RELEASE_MINOR_VERSION_C      4
#define FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_AR_RELEASE_REVISION_VERSION_C   0
#define FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_SW_MAJOR_VERSION_C              2
#define FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_SW_MINOR_VERSION_C              0
#define FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_SW_PATCH_VERSION_C              0


/*==================================================================================================
                                      FILE VERSION CHECKS
==================================================================================================*/

/* Checks against Flexio_Uart_Ip_Cfg.h */
#if (FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_VENDOR_ID_C != FLEXIO_UART_IP_CFG_VENDOR_ID)
    #error "Flexio_Uart_Ip_Sa_BOARD_InitPeripherals_PBcfg.c and Flexio_Uart_Ip_Cfg.h have different vendor ids"
#endif
#if ((FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_AR_RELEASE_MAJOR_VERSION_C    != FLEXIO_UART_IP_CFG_AR_RELEASE_MAJOR_VERSION)|| \
     (FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_AR_RELEASE_MINOR_VERSION_C    != FLEXIO_UART_IP_CFG_AR_RELEASE_MINOR_VERSION)|| \
     (FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_AR_RELEASE_REVISION_VERSION_C != FLEXIO_UART_IP_CFG_AR_RELEASE_REVISION_VERSION))
     #error "AUTOSAR Version Numbers of Flexio_Uart_Ip_Sa_BOARD_InitPeripherals_PBcfg.c and Flexio_Uart_Ip_Cfg.h are different"
#endif
#if ((FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_SW_MAJOR_VERSION_C != FLEXIO_UART_IP_CFG_SW_MAJOR_VERSION)|| \
     (FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_SW_MINOR_VERSION_C != FLEXIO_UART_IP_CFG_SW_MINOR_VERSION)|| \
     (FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_SW_PATCH_VERSION_C != FLEXIO_UART_IP_CFG_SW_PATCH_VERSION))
    #error "Software Version Numbers of Flexio_Uart_Ip_Sa_BOARD_InitPeripherals_PBcfg.c and Flexio_Uart_Ip_Cfg.h are different"
#endif

#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if current file and StandardTypes.h header file are of the same Autosar version */
    #if ((FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_AR_RELEASE_MAJOR_VERSION_C != STD_AR_RELEASE_MAJOR_VERSION) || \
         (FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_AR_RELEASE_MINOR_VERSION_C != STD_AR_RELEASE_MINOR_VERSION))
        #error "AutoSar Version Numbers of Flexio_Uart_Ip_BOARD_InitPeripherals_PBcfg.c and StandardTypes.h are different"
    #endif
    /* Checks against Dma_Ip.h */
    #if (FLEXIO_UART_IP_HAS_DMA_ENABLED == STD_ON)
        #if ((FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_AR_RELEASE_MAJOR_VERSION_C != DMA_IP_AR_RELEASE_MAJOR_VERSION) || \
             (FLEXIO_UART_IP_SA_PBCFG_BOARD_INITPERIPHERALS_AR_RELEASE_MINOR_VERSION_C != DMA_IP_AR_RELEASE_MINOR_VERSION))
            #error "AutoSar Version Numbers of Flexio_Uart_Ip_BOARD_InitPeripherals_PBcfg.c and Dma_Ip.h are different"
        #endif
    #endif
#endif
/*==================================================================================================
                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/

/*==================================================================================================
                                       LOCAL CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/

/*==================================================================================================
                                       LOCAL VARIABLES
==================================================================================================*/

/*==================================================================================================
                                       GLOBAL CONSTANTS
==================================================================================================*/

#define UART_START_SEC_VAR_CLEARED_UNSPECIFIED_NO_CACHEABLE
#include "Uart_MemMap.h"
extern Flexio_Uart_Ip_StateStructureType Flexio_Uart_Ip_apStateStructure[FLEXIO_UART_IP_NUMBER_OF_SHIFTER_AND_TIMER];

#define UART_STOP_SEC_VAR_CLEARED_UNSPECIFIED_NO_CACHEABLE
#include "Uart_MemMap.h"
#define UART_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Uart_MemMap.h"

/**
* @brief          Hardware configuration for Flexio Uart Hardware - Configuration:
*
* @api
*/
const Flexio_Uart_Ip_UserConfigType Flexio_Uart_Ip_xHwConfigPB_0_BOARD_INITPERIPHERALS =
{
    /*!< Flexio Uart Channel has been configured */
    0U,
    /*!< Driver type: Interrupts/DMA */
    FLEXIO_UART_IP_DRIVER_TYPE_INTERRUPTS,
    /*!< Baudrate divider */
    20U,
    /*!< The source of the Timer decrement and the source of the Shift clock */
    FLEXIO_TIMER_DECREMENT_FXIO_CLK_DIV_16,
    /*!< Baud rate in hertz */
    119047U,
    /*!< Number of bits per word */
    FLEXIO_UART_IP_8_BITS_PER_CHAR,
    /*!< Driver direction: Tx or Rx */
    FLEXIO_UART_IP_DIRECTION_TX,
    /*!< Flexio pin to use as Tx or Rx pin */
    2U,
    /* Callback to invoke for data transmit/receive.*/
    NULL_PTR,
    /* Callback parameter pointer.*/
    NULL_PTR,
#if (FLEXIO_UART_IP_HAS_DMA_ENABLED == STD_ON)
    /* DMA channel number for DMA-based. */
    255,
#endif
    /* Runtime state structure refference */
    &Flexio_Uart_Ip_apStateStructure[0U]
};

const Flexio_Uart_Ip_UserConfigType Flexio_Uart_Ip_xHwConfigPB_1_BOARD_INITPERIPHERALS =
{
    /*!< Flexio Uart Channel has been configured */
    1U,
    /*!< Driver type: Interrupts/DMA */
    FLEXIO_UART_IP_DRIVER_TYPE_INTERRUPTS,
    /*!< Baudrate divider */
    129U,
    /*!< The source of the Timer decrement and the source of the Shift clock */
    FLEXIO_TIMER_DECREMENT_FXIO_CLK_DIV_16,
    /*!< Baud rate in hertz */
    19230U,
    /*!< Number of bits per word */
    FLEXIO_UART_IP_8_BITS_PER_CHAR,
    /*!< Driver direction: Tx or Rx */
    FLEXIO_UART_IP_DIRECTION_RX,
    /*!< Flexio pin to use as Tx or Rx pin */
    3U,
    /* Callback to invoke for data transmit/receive.*/
    NULL_PTR,
    /* Callback parameter pointer.*/
    NULL_PTR,
#if (FLEXIO_UART_IP_HAS_DMA_ENABLED == STD_ON)
    /* DMA channel number for DMA-based. */
    255,
#endif
    /* Runtime state structure refference */
    &Flexio_Uart_Ip_apStateStructure[1U]
};



#define UART_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Uart_MemMap.h"

/*==================================================================================================
                                       GLOBAL VARIABLES
==================================================================================================*/

/*==================================================================================================
                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/

/*==================================================================================================
                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
                                       GLOBAL FUNCTIONS
==================================================================================================*/

#ifdef __cplusplus
}

/** @} */

#endif

