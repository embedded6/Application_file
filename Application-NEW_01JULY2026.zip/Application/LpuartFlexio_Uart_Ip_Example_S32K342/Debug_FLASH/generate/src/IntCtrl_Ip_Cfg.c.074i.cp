
IPA constant propagation start:

IPA structures before propagation:

Jump functions:
  Jump functions of caller  LPUART_UART_IP_2_IRQHandler/6:
  Jump functions of caller  MCL_FLEXIO_ISR/5:
  Jump functions of caller  undefined_handler/4:

 Propagating constants:


overall_size: 0

IPA lattices after all propagation:

Lattices:

IPA decision stage:


IPA constant propagation end

Reclaiming functions:
Reclaiming variables:
Clearing address taken flags:
Symbol table:

LPUART_UART_IP_2_IRQHandler/6 (LPUART_UART_IP_2_IRQHandler) @05f211c0
  Type: function
  Visibility: external public
  Address is taken.
  References: 
  Referring: aIrqRouteConfig/2 (addr) 
  Availability: not_available
  Function flags: optimize_size
  Called by: 
  Calls: 
MCL_FLEXIO_ISR/5 (MCL_FLEXIO_ISR) @05f210e0
  Type: function
  Visibility: external public
  Address is taken.
  References: 
  Referring: aIrqRouteConfig/2 (addr) 
  Availability: not_available
  Function flags: optimize_size
  Called by: 
  Calls: 
undefined_handler/4 (undefined_handler) @05edce00
  Type: function
  Visibility: external public
  Address is taken.
  References: 
  Referring: aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) aIrqRouteConfig/2 (addr) 
  Availability: not_available
  Function flags: optimize_size
  Called by: 
  Calls: 
intRouteConfig/3 (intRouteConfig) @05ee0d80
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: aIrqRouteConfig/2 (addr) 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
aIrqRouteConfig/2 (aIrqRouteConfig) @05ee0d38
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly
  References: undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) MCL_FLEXIO_ISR/5 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) LPUART_UART_IP_2_IRQHandler/6 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) undefined_handler/4 (addr) 
  Referring: intRouteConfig/3 (addr) 
  Availability: available
  Varpool flags: initialized read-only const-value-known
IntCtrlConfig_0/1 (IntCtrlConfig_0) @05ee0c60
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: aIrqConfiguration1/0 (addr) 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
aIrqConfiguration1/0 (aIrqConfiguration1) @05ee0c18
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: IntCtrlConfig_0/1 (addr) 
  Availability: available
  Varpool flags: initialized read-only const-value-known
