
========== IPA-SRA IPA stage ==========



========== IPA-SRA decisions ==========

========== IPA SRA IPA analysis done ==========


Reclaiming functions:
Reclaiming variables:
Clearing address taken flags:
Symbol table:

C40ConfigSet_BOARD_InitPeripherals_InitCfg/0 (C40ConfigSet_BOARD_InitPeripherals_InitCfg) @06a45a20
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
