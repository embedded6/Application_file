
========== IPA-SRA IPA stage ==========



========== IPA-SRA decisions ==========

========== IPA SRA IPA analysis done ==========


Reclaiming functions:
Reclaiming variables:
Clearing address taken flags:
Symbol table:

Flexio_Uart_Ip_apStateStructure/2 (Flexio_Uart_Ip_apStateStructure) @05e5b708
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: Flexio_Uart_Ip_xHwConfigPB_0_BOARD_INITPERIPHERALS/0 (addr) Flexio_Uart_Ip_xHwConfigPB_1_BOARD_INITPERIPHERALS/1 (addr) 
  Availability: not_available
  Varpool flags:
Flexio_Uart_Ip_xHwConfigPB_1_BOARD_INITPERIPHERALS/1 (Flexio_Uart_Ip_xHwConfigPB_1_BOARD_INITPERIPHERALS) @05e5b558
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: Flexio_Uart_Ip_apStateStructure/2 (addr) 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Flexio_Uart_Ip_xHwConfigPB_0_BOARD_INITPERIPHERALS/0 (Flexio_Uart_Ip_xHwConfigPB_0_BOARD_INITPERIPHERALS) @05e5b4c8
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: Flexio_Uart_Ip_apStateStructure/2 (addr) 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
