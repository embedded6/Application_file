RTD/src/Tspc_Port_Ip.o: ../RTD/src/Tspc_Port_Ip.c \
 ../RTD/include/Tspc_Port_Ip.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/board/Tspc_Port_Ip_Cfg.h \
 ../RTD/include/Tspc_Port_Ip_Types.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Platform_Types.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/PlatformTypes.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler_Cfg.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/CompilerDefinition.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_TSPC.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_COMMON.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/BasicTypes.h \
 ../RTD/include/Tspc_Port_Ip_Types.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/board/Siul2_Port_Ip_Cfg.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SIUL2.h \
 ../RTD/include/Siul2_Port_Ip_Types.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Siul2_Port_Ip_Defines.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_DCM_GPR.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Port_MemMap.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Devassert.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcal.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Soc_Ips.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/IpVersionMacros.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Reg_eSys.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/OsIf_Internal.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/OsIf_Cfg.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/OsIf_ArchCfg.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SYSTICK.h \
 ../RTD/include/SchM_Port.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Rte_MemMap.h
../RTD/include/Tspc_Port_Ip.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/board/Tspc_Port_Ip_Cfg.h:
../RTD/include/Tspc_Port_Ip_Types.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Platform_Types.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/PlatformTypes.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler_Cfg.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/CompilerDefinition.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_TSPC.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_COMMON.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/BasicTypes.h:
../RTD/include/Tspc_Port_Ip_Types.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/board/Siul2_Port_Ip_Cfg.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SIUL2.h:
../RTD/include/Siul2_Port_Ip_Types.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Siul2_Port_Ip_Defines.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_DCM_GPR.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Port_MemMap.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Devassert.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcal.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Soc_Ips.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/IpVersionMacros.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Reg_eSys.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/OsIf_Internal.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/OsIf_Cfg.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/OsIf_ArchCfg.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SYSTICK.h:
../RTD/include/SchM_Port.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Rte_MemMap.h:
