RTD/src/Flexio_Uart_Ip.o: ../RTD/src/Flexio_Uart_Ip.c \
 ../RTD/include/Flexio_Uart_Ip_HwAccess.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Platform_Types.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/PlatformTypes.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler_Cfg.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/CompilerDefinition.h \
 ../RTD/include/Flexio_Uart_Ip_Types.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Flexio_Uart_Ip_Defines.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcal.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Soc_Ips.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/IpVersionMacros.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Reg_eSys.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/OsIf_Internal.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/OsIf_Cfg.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/OsIf_ArchCfg.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SYSTICK.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_COMMON.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/BasicTypes.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_FLEXIO.h \
 ../RTD/include/OsIf.h ../RTD/include/OsIf_Internal.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Base_MemMap.h \
 ../RTD/include/Flexio_Mcl_Ip_HwAccess.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Flexio_Mcl_Ip_Cfg_DeviceRegisters.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Flexio_Mcl_Ip_Cfg_Defines.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Flexio_Uart_Ip_CfgDefines.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcl_MemMap.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Uart_MemMap.h \
 ../RTD/include/Flexio_Uart_Ip_Irq.h ../RTD/include/Flexio_Uart_Ip.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Flexio_Uart_Ip_Cfg.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Flexio_Uart_Ip_Sa_BOARD_InitPeripherals_PBcfg.h \
 ../RTD/include/Flexio_Uart_Ip_Types.h ../RTD/include/SchM_Uart.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Rte_MemMap.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Devassert.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcal.h
../RTD/include/Flexio_Uart_Ip_HwAccess.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Platform_Types.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/PlatformTypes.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler_Cfg.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/CompilerDefinition.h:
../RTD/include/Flexio_Uart_Ip_Types.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Flexio_Uart_Ip_Defines.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcal.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Soc_Ips.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/IpVersionMacros.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Reg_eSys.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/OsIf_Internal.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/OsIf_Cfg.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/OsIf_ArchCfg.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SYSTICK.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_COMMON.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/BasicTypes.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_FLEXIO.h:
../RTD/include/OsIf.h:
../RTD/include/OsIf_Internal.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Base_MemMap.h:
../RTD/include/Flexio_Mcl_Ip_HwAccess.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Flexio_Mcl_Ip_Cfg_DeviceRegisters.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Flexio_Mcl_Ip_Cfg_Defines.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Flexio_Uart_Ip_CfgDefines.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcl_MemMap.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Uart_MemMap.h:
../RTD/include/Flexio_Uart_Ip_Irq.h:
../RTD/include/Flexio_Uart_Ip.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Flexio_Uart_Ip_Cfg.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Flexio_Uart_Ip_Sa_BOARD_InitPeripherals_PBcfg.h:
../RTD/include/Flexio_Uart_Ip_Types.h:
../RTD/include/SchM_Uart.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Rte_MemMap.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Devassert.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcal.h:
