
========== IPA-SRA IPA stage ==========



========== IPA-SRA decisions ==========

========== IPA SRA IPA analysis done ==========


Reclaiming functions:
Reclaiming variables:
Clearing address taken flags:
Symbol table:

Clock_Ip_axGateInfo/28 (Clock_Ip_axGateInfo) @061859d8
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_axFeatureExtensions/27 (Clock_Ip_axFeatureExtensions) @0617d750
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_aeHwDfsName/26 (Clock_Ip_aeHwDfsName) @0617d3f0
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_aeHwPllName/25 (Clock_Ip_aeHwPllName) @0617d3a8
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_aeSourceTypeClockName/24 (Clock_Ip_aeSourceTypeClockName) @0617d360
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_apxMcMeTriggerPartitions/23 (Clock_Ip_apxMcMeTriggerPartitions) @0617d2d0
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_apxMcMeGetPartitions/22 (Clock_Ip_apxMcMeGetPartitions) @0617d288
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_apxMcMeSetPartitions/21 (Clock_Ip_apxMcMeSetPartitions) @0617d240
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_axCmuInfo/20 (Clock_Ip_axCmuInfo) @0617d1f8
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_aeCmuNames/19 (Clock_Ip_aeCmuNames) @0617d168
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_apxCmu/18 (Clock_Ip_apxCmu) @0617d120
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_pxPll/17 (Clock_Ip_pxPll) @0617d090
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_apxXosc/16 (Clock_Ip_apxXosc) @0617d048
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_apxCgmPcfs/15 (Clock_Ip_apxCgmPcfs) @0617d000
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_apxCgm/14 (Clock_Ip_apxCgm) @060f2f78
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au16SelectorEntryRtcHardwareValue/13 (Clock_Ip_au16SelectorEntryRtcHardwareValue) @060f2d38
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au16SelectorEntryHardwareValue/12 (Clock_Ip_au16SelectorEntryHardwareValue) @060f2ca8
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8SoftwareMuxResetValue/11 (Clock_Ip_au8SoftwareMuxResetValue) @060f2c18
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8ClockFeatures/10 (Clock_Ip_au8ClockFeatures) @060f2b88
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8CmuCallbackIndex/9 (Clock_Ip_au8CmuCallbackIndex) @060f2ea0
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8PcfsCallbackIndex/8 (Clock_Ip_au8PcfsCallbackIndex) @060f2e10
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8SelectorCallbackIndex/7 (Clock_Ip_au8SelectorCallbackIndex) @060f2d80
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8PllCallbackIndex/6 (Clock_Ip_au8PllCallbackIndex) @060f2cf0
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8FractionalDividerCallbackIndex/5 (Clock_Ip_au8FractionalDividerCallbackIndex) @060f2c60
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8GateCallbackIndex/4 (Clock_Ip_au8GateCallbackIndex) @060f2bd0
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8IrcoscCallbackIndex/3 (Clock_Ip_au8IrcoscCallbackIndex) @060f2b40
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8XoscCallbackIndex/2 (Clock_Ip_au8XoscCallbackIndex) @060f2ab0
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8DividerTriggerCallbackIndex/1 (Clock_Ip_au8DividerTriggerCallbackIndex) @060f2a20
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
Clock_Ip_au8DividerCallbackIndex/0 (Clock_Ip_au8DividerCallbackIndex) @060f2990
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
