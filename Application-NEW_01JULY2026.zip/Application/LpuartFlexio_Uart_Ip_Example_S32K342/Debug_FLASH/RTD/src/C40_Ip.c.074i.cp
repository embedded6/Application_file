
IPA constant propagation start:
Determining dynamic type for call: C40_Ip_SetSeedMisr (MisrSeedValues_54(D));
  Starting walk at: C40_Ip_SetSeedMisr (MisrSeedValues_54(D));
  instance pointer: MisrSeedValues_54(D)  Outer instance pointer: MisrSeedValues_54(D) offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:C40_Ip_UTestCheckBreakpoint (BreakPoints_48(D));
  Function call may change dynamic type:ReturnCode_40 = C40_Ip_MainInterfaceWriteJobAddress (SelectBlock_29(D), DomainIdValue_38(D));
  Function call may change dynamic type:_5 = OsIf_GetCounter (0);
  Function call may change dynamic type:_4 = OsIf_MicrosToTicks (2147483647, 0);
  Function call may change dynamic type:ReturnCode_31 = C40_Ip_UTestCheckBusy ();
Determining dynamic type for call: ReturnCode_14 = C40_Ip_CheckUserTestStatusExecution (MisrExpectedValues_9(D), TestResult_10(D));
  Starting walk at: ReturnCode_14 = C40_Ip_CheckUserTestStatusExecution (MisrExpectedValues_9(D), TestResult_10(D));
  instance pointer: MisrExpectedValues_9(D)  Outer instance pointer: MisrExpectedValues_9(D) offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: ReturnCode_14 = C40_Ip_CheckUserTestStatusExecution (MisrExpectedValues_9(D), TestResult_10(D));
  Starting walk at: ReturnCode_14 = C40_Ip_CheckUserTestStatusExecution (MisrExpectedValues_9(D), TestResult_10(D));
  instance pointer: TestResult_10(D)  Outer instance pointer: TestResult_10(D) offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: C40_Ip_SetSeedMisr (MisrSeedValues_48(D));
  Starting walk at: C40_Ip_SetSeedMisr (MisrSeedValues_48(D));
  instance pointer: MisrSeedValues_48(D)  Outer instance pointer: MisrSeedValues_48(D) offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:C40_Ip_UTestCheckBreakpoint (BreakPoints_46(D));
  Function call may change dynamic type:ReturnCode_36 = C40_Ip_MainInterfaceWriteJobAddress (SelectBlock_25(D), DomainIdValue_34(D));
  Function call may change dynamic type:_5 = OsIf_GetCounter (0);
  Function call may change dynamic type:_4 = OsIf_MicrosToTicks (2147483647, 0);
  Function call may change dynamic type:ReturnCode_27 = C40_Ip_UTestCheckBusy ();
Determining dynamic type for call: C40_Ip_CheckLockDomainID_CheckRegister (VirtualSector_16(D), &CheckRegister, &TempLockMasterRegister);
  Starting walk at: C40_Ip_CheckLockDomainID_CheckRegister (VirtualSector_16(D), &CheckRegister, &TempLockMasterRegister);
  instance pointer: &CheckRegister  Outer instance pointer: CheckRegister offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: C40_Ip_CheckLockDomainID_CheckRegister (VirtualSector_16(D), &CheckRegister, &TempLockMasterRegister);
  Starting walk at: C40_Ip_CheckLockDomainID_CheckRegister (VirtualSector_16(D), &CheckRegister, &TempLockMasterRegister);
  instance pointer: &TempLockMasterRegister  Outer instance pointer: TempLockMasterRegister offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: ReturnCode_24 = C40_Ip_MainInterfaceWritePreCheck (LogicalAddress_13(D), Length_21(D), SourceAddressPtr_22(D));
  Starting walk at: ReturnCode_24 = C40_Ip_MainInterfaceWritePreCheck (LogicalAddress_13(D), Length_21(D), SourceAddressPtr_22(D));
  instance pointer: SourceAddressPtr_22(D)  Outer instance pointer: SourceAddressPtr_22(D) offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:_2 = OsIf_GetCounter (0);
  Function call may change dynamic type:_1 = OsIf_MicrosToTicks (2147483647, 0);
Determining dynamic type for call: C40_Ip_MainInterfaceFillDataBuff (LocationWriteDataRegs_30, SourceAddressPtr_22(D), Length_21(D));
  Starting walk at: C40_Ip_MainInterfaceFillDataBuff (LocationWriteDataRegs_30, SourceAddressPtr_22(D), Length_21(D));
  instance pointer: SourceAddressPtr_22(D)  Outer instance pointer: SourceAddressPtr_22(D) offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:ReturnCode_24 = C40_Ip_MainInterfaceWritePreCheck (LogicalAddress_13(D), Length_21(D), SourceAddressPtr_22(D));
  Function call may change dynamic type:_2 = OsIf_GetCounter (0);
  Function call may change dynamic type:_1 = OsIf_MicrosToTicks (2147483647, 0);
  Function call may change dynamic type:ReturnCode_28 = C40_Ip_MainInterfaceWriteJobAddress (LogicalAddress_13(D), DomainIdValue_26(D));
  Function call may change dynamic type:C40_Ip_ClearAllErrorFlagsMainInterface ();
  Function call may change dynamic type:C40_Ip_ClearInterlockWrite ();
Determining dynamic type for call: ReadSize_13 = C40_Ip_CompareBlank (ReadAddress_2, SizeLeft_3, &CompareResult);
  Starting walk at: ReadSize_13 = C40_Ip_CompareBlank (ReadAddress_2, SizeLeft_3, &CompareResult);
  instance pointer: &CompareResult  Outer instance pointer: CompareResult offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:C40_Ip_FlashAccessCalloutStart ();
  Function call may change dynamic type:C40_Ip_ClearAllErrorFlagsMainInterface ();
  Function call may change dynamic type:Status_16 = C40_Ip_CheckReadCompareStatus (ReadAddress_2, CompareResult.30_1);
  Function call may change dynamic type:C40_Ip_FlashAccessCalloutFinish ();
  Function call may change dynamic type:ReadSize_13 = C40_Ip_CompareBlank (ReadAddress_2, SizeLeft_3, &CompareResult);
  Function call may change dynamic type:C40_Ip_FlashAccessCalloutStart ();
  Function call may change dynamic type:C40_Ip_ClearAllErrorFlagsMainInterface ();
Determining dynamic type for call: ReadSize_16 = C40_Ip_CompareData (ReadAddress_2, DataAddress_3, SizeLeft_4, &CompareResult);
  Starting walk at: ReadSize_16 = C40_Ip_CompareData (ReadAddress_2, DataAddress_3, SizeLeft_4, &CompareResult);
  instance pointer: &CompareResult  Outer instance pointer: CompareResult offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:C40_Ip_FlashAccessCalloutStart ();
  Function call may change dynamic type:C40_Ip_ClearAllErrorFlagsMainInterface ();
  Function call may change dynamic type:Status_19 = C40_Ip_CheckReadCompareStatus (ReadAddress_2, CompareResult.29_1);
  Function call may change dynamic type:C40_Ip_FlashAccessCalloutFinish ();
  Function call may change dynamic type:ReadSize_16 = C40_Ip_CompareData (ReadAddress_2, DataAddress_3, SizeLeft_4, &CompareResult);
  Function call may change dynamic type:C40_Ip_FlashAccessCalloutStart ();
  Function call may change dynamic type:C40_Ip_ClearAllErrorFlagsMainInterface ();
Determining dynamic type for call: C40_Ip_ProgramVerify (LogicalAddress_3(D), SourceAddressPtr_6(D), Length_4(D));
  Starting walk at: C40_Ip_ProgramVerify (LogicalAddress_3(D), SourceAddressPtr_6(D), Length_4(D));
  instance pointer: SourceAddressPtr_6(D)  Outer instance pointer: SourceAddressPtr_6(D) offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: ReadSize_17 = C40_Ip_ReadData (ReadAddress_1, DesAddressPtr_2, SizeLeft_3);
  Starting walk at: ReadSize_17 = C40_Ip_ReadData (ReadAddress_1, DesAddressPtr_2, SizeLeft_3);
  instance pointer: DesAddressPtr_2  Outer instance pointer: DesAddressPtr_2 offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:C40_Ip_FlashAccessCalloutStart ();
  Function call may change dynamic type:C40_Ip_ClearAllErrorFlagsMainInterface ();
  Function call may change dynamic type:Status_20 = C40_Ip_CheckReadCompareStatus (ReadAddress_1, 1);
  Function call may change dynamic type:C40_Ip_FlashAccessCalloutFinish ();
  Function call may change dynamic type:ReadSize_17 = C40_Ip_ReadData (ReadAddress_1, DesAddressPtr_2, SizeLeft_3);
  Function call may change dynamic type:C40_Ip_FlashAccessCalloutStart ();
  Function call may change dynamic type:C40_Ip_ClearAllErrorFlagsMainInterface ();

IPA structures before propagation:

Jump functions:
  Jump functions of caller  C40_Ip_GetSectorNumberFromAddress.part.0/105:
  Jump functions of caller  C40_Ip_ClearLockProtect.part.0/103:
  Jump functions of caller  C40_Ip_GetLock.part.0/102:
    callsite  C40_Ip_GetLock.part.0/102 -> C40_Ip_GetLockProtect/28 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  C40_Ip_SetLockProtect.part.0/101:
  Jump functions of caller  C40_Ip_MainInterfaceHVJobStatus.part.0/100:
    callsite  C40_Ip_MainInterfaceHVJobStatus.part.0/100 -> OsIf_GetElapsed/79 : 
       no arg info
  Jump functions of caller  C40_Ip_CheckSelecBlock.part.0/91:
  Jump functions of caller  C40_Ip_UTestCheckBusy.part.0/90:
  Jump functions of caller  C40_Ip_SetSeedMisr.part.0/80:
  Jump functions of caller  OsIf_GetElapsed/79:
  Jump functions of caller  OsIf_GetCounter/78:
  Jump functions of caller  OsIf_MicrosToTicks/77:
  Jump functions of caller  C40_Ip_FlashAccessCalloutFinish/71:
    indirect simple callsite, calling param -1, offset 0, for stmt _2 ();
  Jump functions of caller  C40_Ip_FlashAccessCalloutStart/70:
    indirect simple callsite, calling param -1, offset 0, for stmt _2 ();
  Jump functions of caller  C40_Ip_SetAsyncMode/69:
  Jump functions of caller  C40_Ip_GetFailedAddress/68:
  Jump functions of caller  C40_Ip_UserMarginReadCheck/67:
    callsite  C40_Ip_UserMarginReadCheck/67 -> C40_Ip_SetSeedMisr/20 : 
       param 0: PASS THROUGH: 3, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  C40_Ip_UserMarginReadCheck/67 -> C40_Ip_UTestCheckBreakpoint/58 : 
       param 0: PASS THROUGH: 1, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  C40_Ip_UserMarginReadCheck/67 -> C40_Ip_MainInterfaceWriteJobAddress/37 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: PASS THROUGH: 4, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  C40_Ip_UserMarginReadCheck/67 -> OsIf_GetCounter/78 : 
       no arg info
    callsite  C40_Ip_UserMarginReadCheck/67 -> OsIf_MicrosToTicks/77 : 
       no arg info
    callsite  C40_Ip_UserMarginReadCheck/67 -> C40_Ip_UTestCheckBusy/57 : 
    callsite  C40_Ip_UserMarginReadCheck/67 -> C40_Ip_CheckSelecBlock/60 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  C40_Ip_ArrayIntegrityCheckResume/66:
    callsite  C40_Ip_ArrayIntegrityCheckResume/66 -> C40_Ip_ArrayIntegrityResumeBroken/65 : 
    callsite  C40_Ip_ArrayIntegrityCheckResume/66 -> C40_Ip_ArrayIntegrityResumeSuppened/64 : 
  Jump functions of caller  C40_Ip_ArrayIntegrityResumeBroken/65:
  Jump functions of caller  C40_Ip_ArrayIntegrityResumeSuppened/64:
  Jump functions of caller  C40_Ip_ArrayIntegrityCheckSuspend/63:
  Jump functions of caller  C40_Ip_CheckUserTestStatusExecution/62:
  Jump functions of caller  C40_Ip_CheckUserTestStatus/61:
    callsite  C40_Ip_CheckUserTestStatus/61 -> C40_Ip_CheckUserTestStatusExecution/62 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: PASS THROUGH: 1, op nop_expr
         Aggregate passed by reference:
           offset: 0, type: C40_Ip_UtestStateType, CONST: 0
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  C40_Ip_CheckSelecBlock/60:
    callsite  C40_Ip_CheckSelecBlock/60 -> C40_Ip_CheckSelecBlock.part.0/91 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  C40_Ip_ArrayIntegrityCheck/59:
    callsite  C40_Ip_ArrayIntegrityCheck/59 -> C40_Ip_SetSeedMisr/20 : 
       param 0: PASS THROUGH: 3, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  C40_Ip_ArrayIntegrityCheck/59 -> C40_Ip_UTestCheckBreakpoint/58 : 
       param 0: PASS THROUGH: 2, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  C40_Ip_ArrayIntegrityCheck/59 -> C40_Ip_MainInterfaceWriteJobAddress/37 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: PASS THROUGH: 4, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  C40_Ip_ArrayIntegrityCheck/59 -> OsIf_GetCounter/78 : 
       no arg info
    callsite  C40_Ip_ArrayIntegrityCheck/59 -> OsIf_MicrosToTicks/77 : 
       no arg info
    callsite  C40_Ip_ArrayIntegrityCheck/59 -> C40_Ip_UTestCheckBusy/57 : 
    callsite  C40_Ip_ArrayIntegrityCheck/59 -> C40_Ip_CheckSelecBlock/60 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  C40_Ip_UTestCheckBreakpoint/58:
  Jump functions of caller  C40_Ip_UTestCheckBusy/57:
    callsite  C40_Ip_UTestCheckBusy/57 -> C40_Ip_UTestCheckBusy.part.0/90 : 
  Jump functions of caller  C40_Ip_GetBlockNumberFromAddress/56:
    callsite  C40_Ip_GetBlockNumberFromAddress/56 -> C40_Ip_GetCodeBlockNumber/55 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  C40_Ip_GetCodeBlockNumber/55:
  Jump functions of caller  C40_Ip_GetSectorNumberFromAddress/54:
    callsite  C40_Ip_GetSectorNumberFromAddress/54 -> C40_Ip_GetSectorNumberFromAddress.part.0/105 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  C40_Ip_CheckLockDomainID_CheckRegister/53:
  Jump functions of caller  C40_Ip_GetBaseAddressOfSector/52:
  Jump functions of caller  C40_Ip_CheckLockDomainID/51:
    callsite  C40_Ip_CheckLockDomainID/51 -> C40_Ip_CheckLockDomainID_CheckRegister/53 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: UNKNOWN
         Aggregate passed by reference:
           offset: 0, type: uint32, CONST: 0
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 2: UNKNOWN
         Aggregate passed by reference:
           offset: 0, type: uint32, CONST: 0
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
  Jump functions of caller  C40_Ip_GetSectorID/50:
  Jump functions of caller  C40_Ip_MainInterfaceHVJobStatus/49:
    callsite  C40_Ip_MainInterfaceHVJobStatus/49 -> C40_Ip_MainInterfaceHVJobStatus.part.0/100 : 
  Jump functions of caller  C40_Ip_MainInterfaceWriteStatus/48:
    callsite  C40_Ip_MainInterfaceWriteStatus/48 -> C40_Ip_MainInterfaceHVJobStatus/49 : 
  Jump functions of caller  C40_Ip_MainInterfaceWrite/47:
    callsite  C40_Ip_MainInterfaceWrite/47 -> C40_Ip_FlashAccessCalloutStart/70 : 
    callsite  C40_Ip_MainInterfaceWrite/47 -> C40_Ip_MainInterfaceFillDataBuff/45 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1f
         VR  [0, 31]
       param 1: PASS THROUGH: 2, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 2: PASS THROUGH: 1, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  C40_Ip_MainInterfaceWrite/47 -> C40_Ip_ClearInterlockWrite/46 : 
    callsite  C40_Ip_MainInterfaceWrite/47 -> C40_Ip_MainInterfaceWriteJobAddress/37 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: PASS THROUGH: 3, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  C40_Ip_MainInterfaceWrite/47 -> C40_Ip_ClearAllErrorFlagsMainInterface/40 : 
    callsite  C40_Ip_MainInterfaceWrite/47 -> C40_Ip_MainInterfaceWritePreCheck/44 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: PASS THROUGH: 1, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 2: PASS THROUGH: 2, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  C40_Ip_MainInterfaceWrite/47 -> OsIf_GetCounter/78 : 
       no arg info
    callsite  C40_Ip_MainInterfaceWrite/47 -> OsIf_MicrosToTicks/77 : 
       no arg info
  Jump functions of caller  C40_Ip_ClearInterlockWrite/46:
    callsite  C40_Ip_ClearInterlockWrite/46 -> OsIf_GetElapsed/79 : 
       no arg info
    callsite  C40_Ip_ClearInterlockWrite/46 -> OsIf_GetCounter/78 : 
       no arg info
    callsite  C40_Ip_ClearInterlockWrite/46 -> OsIf_MicrosToTicks/77 : 
       no arg info
  Jump functions of caller  C40_Ip_MainInterfaceFillDataBuff/45:
  Jump functions of caller  C40_Ip_MainInterfaceWritePreCheck/44:
    callsite  C40_Ip_MainInterfaceWritePreCheck/44 -> C40_Ip_GetLock/27 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  C40_Ip_MainInterfaceWritePreCheck/44 -> C40_Ip_GetSectorNumberFromAddress/54 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  C40_Ip_MainInterfaceSectorEraseStatus/43:
    callsite  C40_Ip_MainInterfaceSectorEraseStatus/43 -> C40_Ip_MainInterfaceHVJobStatus/49 : 
  Jump functions of caller  C40_Ip_MainInterfaceSectorErase/42:
    callsite  C40_Ip_MainInterfaceSectorErase/42 -> C40_Ip_FlashAccessCalloutStart/70 : 
    callsite  C40_Ip_MainInterfaceSectorErase/42 -> C40_Ip_ClearInterlockWrite/46 : 
    callsite  C40_Ip_MainInterfaceSectorErase/42 -> C40_Ip_MainInterfaceWriteJobAddress/37 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: PASS THROUGH: 1, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  C40_Ip_MainInterfaceSectorErase/42 -> C40_Ip_GetBaseAddressOfSector/52 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  C40_Ip_MainInterfaceSectorErase/42 -> C40_Ip_ClearAllErrorFlagsMainInterface/40 : 
    callsite  C40_Ip_MainInterfaceSectorErase/42 -> C40_Ip_MainInterfaceSectorErasePreCheck/41 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  C40_Ip_MainInterfaceSectorErase/42 -> OsIf_GetCounter/78 : 
       no arg info
    callsite  C40_Ip_MainInterfaceSectorErase/42 -> OsIf_MicrosToTicks/77 : 
       no arg info
  Jump functions of caller  C40_Ip_MainInterfaceSectorErasePreCheck/41:
    callsite  C40_Ip_MainInterfaceSectorErasePreCheck/41 -> C40_Ip_GetLock/27 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  C40_Ip_ClearAllErrorFlagsMainInterface/40:
  Jump functions of caller  C40_Ip_MainInterfaceAbort/39:
    callsite  C40_Ip_MainInterfaceAbort/39 -> OsIf_GetElapsed/79 : 
       no arg info
    callsite  C40_Ip_MainInterfaceAbort/39 -> OsIf_GetCounter/78 : 
       no arg info
    callsite  C40_Ip_MainInterfaceAbort/39 -> OsIf_MicrosToTicks/77 : 
       no arg info
  Jump functions of caller  C40_Ip_InitMainInterface/38:
    callsite  C40_Ip_InitMainInterface/38 -> C40_Ip_ClearAllErrorFlagsMainInterface/40 : 
    callsite  C40_Ip_InitMainInterface/38 -> C40_Ip_MainInterfaceAbort/39 : 
  Jump functions of caller  C40_Ip_MainInterfaceWriteJobAddress/37:
    callsite  C40_Ip_MainInterfaceWriteJobAddress/37 -> OsIf_GetElapsed/79 : 
       no arg info
  Jump functions of caller  C40_Ip_MainInterfaceWriteLogicalAddress/36:
  Jump functions of caller  C40_Ip_EraseVerify/35:
    callsite  C40_Ip_EraseVerify/35 -> C40_Ip_CheckReadCompareStatus/16 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  C40_Ip_EraseVerify/35 -> C40_Ip_FlashAccessCalloutFinish/71 : 
    callsite  C40_Ip_EraseVerify/35 -> C40_Ip_CompareBlank/34 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  C40_Ip_EraseVerify/35 -> C40_Ip_FlashAccessCalloutStart/70 : 
    callsite  C40_Ip_EraseVerify/35 -> C40_Ip_ClearAllErrorFlagsMainInterface/40 : 
  Jump functions of caller  C40_Ip_CompareBlank/34:
  Jump functions of caller  C40_Ip_ProgramVerify/33:
    callsite  C40_Ip_ProgramVerify/33 -> C40_Ip_CheckReadCompareStatus/16 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  C40_Ip_ProgramVerify/33 -> C40_Ip_FlashAccessCalloutFinish/71 : 
    callsite  C40_Ip_ProgramVerify/33 -> C40_Ip_CompareData/32 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 3: UNKNOWN
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  C40_Ip_ProgramVerify/33 -> C40_Ip_FlashAccessCalloutStart/70 : 
    callsite  C40_Ip_ProgramVerify/33 -> C40_Ip_ClearAllErrorFlagsMainInterface/40 : 
  Jump functions of caller  C40_Ip_CompareData/32:
  Jump functions of caller  C40_Ip_Compare/31:
    callsite  C40_Ip_Compare/31 -> C40_Ip_EraseVerify/35 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: PASS THROUGH: 1, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  C40_Ip_Compare/31 -> C40_Ip_ProgramVerify/33 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: PASS THROUGH: 2, op nop_expr, agg_preserved
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 2: PASS THROUGH: 1, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  C40_Ip_ClearLockProtect/30:
    callsite  C40_Ip_ClearLockProtect/30 -> C40_Ip_ClearLockProtect.part.0/103 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  C40_Ip_ClearLock/29:
    callsite  C40_Ip_ClearLock/29 -> C40_Ip_ClearLockProtect/30 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  C40_Ip_ClearLock/29 -> C40_Ip_CheckLockDomainID/51 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: PASS THROUGH: 1, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  C40_Ip_ClearLock/29 -> C40_Ip_GetLock/27 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  C40_Ip_GetLockProtect/28:
    callsite  C40_Ip_GetLockProtect/28 -> C40_Ip_GetSectorID/50 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  C40_Ip_GetLock/27:
    callsite  C40_Ip_GetLock/27 -> C40_Ip_GetLock.part.0/102 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  C40_Ip_SetLockProtect/26:
    callsite  C40_Ip_SetLockProtect/26 -> C40_Ip_SetLockProtect.part.0/101 : 
  Jump functions of caller  C40_Ip_SetLock/25:
    callsite  C40_Ip_SetLock/25 -> C40_Ip_SetLockProtect/26 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  C40_Ip_SetLock/25 -> C40_Ip_CheckLockDomainID/51 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: PASS THROUGH: 1, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  C40_Ip_SetLock/25 -> C40_Ip_GetLock/27 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  C40_Ip_Read/24:
    callsite  C40_Ip_Read/24 -> C40_Ip_CheckReadCompareStatus/16 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: CONST: 1
         value: 0x1, mask: 0x0
         Unknown VR
    callsite  C40_Ip_Read/24 -> C40_Ip_FlashAccessCalloutFinish/71 : 
    callsite  C40_Ip_Read/24 -> C40_Ip_ReadData/21 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  C40_Ip_Read/24 -> C40_Ip_FlashAccessCalloutStart/70 : 
    callsite  C40_Ip_Read/24 -> C40_Ip_ClearAllErrorFlagsMainInterface/40 : 
  Jump functions of caller  C40_Ip_ReadData/21:
  Jump functions of caller  C40_Ip_SetSeedMisr/20:
    callsite  C40_Ip_SetSeedMisr/20 -> C40_Ip_SetSeedMisr.part.0/80 : 
  Jump functions of caller  C40_Ip_CheckReadCompareStatus/16:
  Jump functions of caller  C40_Ip_Abort/15:
    callsite  C40_Ip_Abort/15 -> C40_Ip_MainInterfaceAbort/39 : 
  Jump functions of caller  C40_Ip_Block4PipeSelect/14:
  Jump functions of caller  C40_Ip_DataErrorSuppression/13:
  Jump functions of caller  C40_Ip_Init/12:
    callsite  C40_Ip_Init/12 -> C40_Ip_InitMainInterface/38 : 
    callsite  C40_Ip_Init/12 -> C40_Ip_Block4PipeSelect/14 : 
    callsite  C40_Ip_Init/12 -> C40_Ip_DataErrorSuppression/13 : 

 Propagating constants:

Not considering C40_Ip_SetAsyncMode/69 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_UserMarginReadCheck/67 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_CheckUserTestStatus/61 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_ArrayIntegrityCheck/59 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_GetBlockNumberFromAddress/56 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_GetSectorNumberFromAddress/54 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_CheckLockDomainID_CheckRegister/53 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_MainInterfaceWrite/47 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_MainInterfaceSectorErase/42 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_MainInterfaceWriteLogicalAddress/36 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_Compare/31 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_ClearLockProtect/30 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_ClearLock/29 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_GetLockProtect/28 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_GetLock/27 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_SetLockProtect/26 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_SetLock/25 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_Read/24 for cloning; -fipa-cp-clone disabled.
Not considering C40_Ip_Init/12 for cloning; -fipa-cp-clone disabled.

overall_size: 1332
 - context independent values, size: 11, time_benefit: 1.000000
     Decided to specialize for all known contexts, code not going to grow.

IPA lattices after all propagation:

Lattices:
  Node: C40_Ip_GetSectorNumberFromAddress.part.0/105:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_ClearLockProtect.part.0/103:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_GetLock.part.0/102:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_SetLockProtect.part.0/101:
  Node: C40_Ip_MainInterfaceHVJobStatus.part.0/100:
  Node: C40_Ip_CheckSelecBlock.part.0/91:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_UTestCheckBusy.part.0/90:
  Node: C40_Ip_SetSeedMisr.part.0/80:
  Node: C40_Ip_FlashAccessCalloutFinish/71:
  Node: C40_Ip_FlashAccessCalloutStart/70:
  Node: C40_Ip_SetAsyncMode/69:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_GetFailedAddress/68:
  Node: C40_Ip_UserMarginReadCheck/67:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [3]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [4]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_ArrayIntegrityCheckResume/66:
  Node: C40_Ip_ArrayIntegrityResumeBroken/65:
  Node: C40_Ip_ArrayIntegrityResumeSuppened/64:
  Node: C40_Ip_ArrayIntegrityCheckSuspend/63:
  Node: C40_Ip_CheckUserTestStatusExecution/62:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_CheckUserTestStatus/61:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_CheckSelecBlock/60:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_ArrayIntegrityCheck/59:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [3]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [4]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_UTestCheckBreakpoint/58:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_UTestCheckBusy/57:
  Node: C40_Ip_GetBlockNumberFromAddress/56:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_GetCodeBlockNumber/55:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_GetSectorNumberFromAddress/54:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_CheckLockDomainID_CheckRegister/53:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_GetBaseAddressOfSector/52:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_CheckLockDomainID/51:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_GetSectorID/50:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_MainInterfaceHVJobStatus/49:
  Node: C40_Ip_MainInterfaceWriteStatus/48:
  Node: C40_Ip_MainInterfaceWrite/47:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [3]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_ClearInterlockWrite/46:
  Node: C40_Ip_MainInterfaceFillDataBuff/45:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0x1f
         uint32 [0, 31]
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_MainInterfaceWritePreCheck/44:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_MainInterfaceSectorEraseStatus/43:
  Node: C40_Ip_MainInterfaceSectorErase/42:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_MainInterfaceSectorErasePreCheck/41:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_ClearAllErrorFlagsMainInterface/40:
  Node: C40_Ip_MainInterfaceAbort/39:
  Node: C40_Ip_InitMainInterface/38:
  Node: C40_Ip_MainInterfaceWriteJobAddress/37:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_MainInterfaceWriteLogicalAddress/36:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_EraseVerify/35:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_CompareBlank/34:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         boolean * [1B, +INF]
        AGGS VARIABLE
  Node: C40_Ip_ProgramVerify/33:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_CompareData/32:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [3]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         boolean * [1B, +INF]
        AGGS VARIABLE
  Node: C40_Ip_Compare/31:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_ClearLockProtect/30:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_ClearLock/29:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_GetLockProtect/28:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_GetLock/27:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_SetLockProtect/26:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_SetLock/25:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_Read/24:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: C40_Ip_ReadData/21:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_SetSeedMisr/20:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_CheckReadCompareStatus/16:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: VARIABLE
               1 [loc_time: 3, loc_size: 11, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: C40_Ip_Abort/15:
  Node: C40_Ip_Block4PipeSelect/14:
  Node: C40_Ip_DataErrorSuppression/13:
  Node: C40_Ip_Init/12:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM

IPA decision stage:

 - Creating a specialized node of C40_Ip_CheckReadCompareStatus/16 for all known contexts.
Propagated bits info for function C40_Ip_MainInterfaceFillDataBuff/45:
 param 0: value = 0x0, mask = 0x1f

IPA constant propagation end

Reclaiming functions: C40_Ip_CheckReadCompareStatus/16
Reclaiming variables:
Clearing address taken flags:
Symbol table:

C40_Ip_CheckReadCompareStatus.constprop.0/106 (C40_Ip_CheckReadCompareStatus.constprop) @06257a80
  Type: function definition analyzed
  Visibility:
  References: C40_Ip_eReadStatus/6 (write) C40_Ip_eReadStatus/6 (write) 
  Referring: 
  Clone of C40_Ip_CheckReadCompareStatus/16
  Availability: local
  Function flags: count:1073741824 (estimated locally) local optimize_size
  Called by: C40_Ip_ProgramVerify/33 (1073741824 (estimated locally),9.35 per call) C40_Ip_EraseVerify/35 (1073741824 (estimated locally),9.35 per call) C40_Ip_Read/24 (1073741824 (estimated locally),3.18 per call) 
  Calls: 
C40_Ip_GetSectorNumberFromAddress.part.0/105 (C40_Ip_GetSectorNumberFromAddress.part.0) @063bd000
  Type: function definition analyzed
  Visibility: prevailing_def_ironly artificial
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local split_part optimize_size
  Called by: C40_Ip_GetSectorNumberFromAddress/54 (348966093 (estimated locally),0.33 per call) 
  Calls: 
C40_Ip_ClearLockProtect.part.0/103 (C40_Ip_ClearLockProtect.part.0) @063bdb60
  Type: function definition analyzed
  Visibility: prevailing_def_ironly artificial
  References: C40_Ip_u32BitPosition/4 (read) C40_Ip_u32BitPosition/4 (read) 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local split_part optimize_size
  Called by: C40_Ip_ClearLockProtect/30 (354334801 (estimated locally),0.33 per call) 
  Calls: 
C40_Ip_GetLock.part.0/102 (C40_Ip_GetLock.part.0) @061d9000
  Type: function definition analyzed
  Visibility: prevailing_def_ironly artificial
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local split_part optimize_size
  Called by: C40_Ip_GetLock/27 (354334800 (estimated locally),0.33 per call) 
  Calls: C40_Ip_GetLockProtect/28 (1073741824 (estimated locally),1.00 per call) 
C40_Ip_SetLockProtect.part.0/101 (C40_Ip_SetLockProtect.part.0) @0625c7e0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly artificial
  References: C40_Ip_u32BitPosition/4 (read) 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local split_part optimize_size
  Called by: C40_Ip_SetLockProtect/26 (182536112 (estimated locally),0.17 per call) 
  Calls: 
C40_Ip_MainInterfaceHVJobStatus.part.0/100 (C40_Ip_MainInterfaceHVJobStatus.part.0) @06225ee0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly artificial
  References: C40_Ip_u32CurrentTicks/2 (addr) C40_Ip_u32ElapsedTicks/0 (read) C40_Ip_u32ElapsedTicks/0 (write) C40_Ip_u32TimeoutTicks/1 (read) 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local split_part optimize_size
  Called by: C40_Ip_MainInterfaceHVJobStatus/49 (354334800 (estimated locally),0.33 per call) 
  Calls: OsIf_GetElapsed/79 (1073741824 (estimated locally),1.00 per call) 
C40_Ip_CheckSelecBlock.part.0/91 (C40_Ip_CheckSelecBlock.part.0) @0625cb60
  Type: function definition analyzed
  Visibility: prevailing_def_ironly artificial
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741823 (estimated locally) body local split_part optimize_size
  Called by: C40_Ip_CheckSelecBlock/60 (467721934 (estimated locally),0.44 per call) 
  Calls: 
C40_Ip_UTestCheckBusy.part.0/90 (C40_Ip_UTestCheckBusy.part.0) @061d9700
  Type: function definition analyzed
  Visibility: prevailing_def_ironly artificial
  References: 
  Referring: 
  Availability: local
  Function flags: count:69202658 (estimated locally) body local split_part optimize_size
  Called by: C40_Ip_UTestCheckBusy/57 (69202658 (estimated locally),0.25 per call) 
  Calls: 
C40_Ip_SetSeedMisr.part.0/80 (C40_Ip_SetSeedMisr.part.0) @0625cc40
  Type: function definition analyzed
  Visibility: prevailing_def_ironly artificial
  References: 
  Referring: 
  Availability: local
  Function flags: count:107374184 (estimated locally) body local split_part optimize_size
  Called by: C40_Ip_SetSeedMisr/20 (46017507 (estimated locally),0.30 per call) 
  Calls: 
OsIf_GetElapsed/79 (OsIf_GetElapsed) @05fd29a0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: C40_Ip_MainInterfaceWriteJobAddress/37 (1073741824 (estimated locally),9.35 per call) C40_Ip_MainInterfaceHVJobStatus.part.0/100 (1073741824 (estimated locally),1.00 per call) C40_Ip_ClearInterlockWrite/46 (1014686026 (estimated locally),8.83 per call) C40_Ip_MainInterfaceAbort/39 (1014686026 (estimated locally),8.83 per call) 
  Calls: 
OsIf_GetCounter/78 (OsIf_GetCounter) @05fd28c0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: C40_Ip_UserMarginReadCheck/67 (67769898 (estimated locally),0.06 per call) C40_Ip_ArrayIntegrityCheck/59 (67769898 (estimated locally),0.06 per call) C40_Ip_MainInterfaceWrite/47 (1073741823 (estimated locally),1.00 per call) C40_Ip_MainInterfaceSectorErase/42 (1073741823 (estimated locally),1.00 per call) C40_Ip_ClearInterlockWrite/46 (114863530 (estimated locally),1.00 per call) C40_Ip_MainInterfaceAbort/39 (114863530 (estimated locally),1.00 per call) 
  Calls: 
OsIf_MicrosToTicks/77 (OsIf_MicrosToTicks) @05fd27e0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: C40_Ip_UserMarginReadCheck/67 (67769898 (estimated locally),0.06 per call) C40_Ip_ArrayIntegrityCheck/59 (67769898 (estimated locally),0.06 per call) C40_Ip_MainInterfaceWrite/47 (1073741823 (estimated locally),1.00 per call) C40_Ip_MainInterfaceSectorErase/42 (1073741823 (estimated locally),1.00 per call) C40_Ip_ClearInterlockWrite/46 (114863530 (estimated locally),1.00 per call) C40_Ip_MainInterfaceAbort/39 (114863530 (estimated locally),1.00 per call) 
  Calls: 
C40_Ip_FlashAccessCalloutFinish/71 (C40_Ip_FlashAccessCalloutFinish) @05fc8b60
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: C40_Ip_pConfigPtr/8 (read) 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: C40_Ip_Read/24 (1073741824 (estimated locally),3.18 per call) C40_Ip_EraseVerify/35 (1073741824 (estimated locally),9.35 per call) C40_Ip_ProgramVerify/33 (1073741824 (estimated locally),9.35 per call) 
  Calls: 
   Indirect call(751619281 (estimated locally),0.70 per call)  Num speculative call targets: 0
C40_Ip_FlashAccessCalloutStart/70 (C40_Ip_FlashAccessCalloutStart) @05fc88c0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: C40_Ip_pConfigPtr/8 (read) 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: C40_Ip_MainInterfaceWrite/47 (71717363 (estimated locally),0.07 per call) C40_Ip_MainInterfaceSectorErase/42 (120473833 (estimated locally),0.11 per call) C40_Ip_Read/24 (1073741824 (estimated locally),3.18 per call) C40_Ip_EraseVerify/35 (1073741824 (estimated locally),9.35 per call) C40_Ip_ProgramVerify/33 (1073741824 (estimated locally),9.35 per call) 
  Calls: 
   Indirect call(751619281 (estimated locally),0.70 per call)  Num speculative call targets: 0
C40_Ip_SetAsyncMode/69 (C40_Ip_SetAsyncMode) @05fc8620
  Type: function definition analyzed
  Visibility: externally_visible public
  References: C40_Ip_bAsync/9 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 
C40_Ip_GetFailedAddress/68 (C40_Ip_GetFailedAddress) @05fc8380
  Type: function definition analyzed
  Visibility: externally_visible public
  References: C40_Ip_eOpStatus/7 (read) C40_Ip_u32LogicalAddressCheckFail/5 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741809 (estimated locally) body optimize_size
  Called by: 
  Calls: 
C40_Ip_UserMarginReadCheck/67 (C40_Ip_UserMarginReadCheck) @05fc80e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: C40_Ip_u32ElapsedTicks/0 (write) C40_Ip_u32TimeoutTicks/1 (write) C40_Ip_u32CurrentTicks/2 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: C40_Ip_SetSeedMisr/20 (8145942 (estimated locally),0.01 per call) C40_Ip_UTestCheckBreakpoint/58 (8145942 (estimated locally),0.01 per call) C40_Ip_MainInterfaceWriteJobAddress/37 (67769898 (estimated locally),0.06 per call) OsIf_GetCounter/78 (67769898 (estimated locally),0.06 per call) OsIf_MicrosToTicks/77 (67769898 (estimated locally),0.06 per call) C40_Ip_UTestCheckBusy/57 (512926472 (estimated locally),0.48 per call) C40_Ip_CheckSelecBlock/60 (1073741824 (estimated locally),1.00 per call) 
C40_Ip_ArrayIntegrityCheckResume/66 (C40_Ip_ArrayIntegrityCheckResume) @05fbb9a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: C40_Ip_ArrayIntegrityResumeBroken/65 (265921600 (estimated locally),0.25 per call) C40_Ip_ArrayIntegrityResumeSuppened/64 (141261473 (estimated locally),0.13 per call) 
C40_Ip_ArrayIntegrityResumeBroken/65 (C40_Ip_ArrayIntegrityResumeBroken) @05fbb2a0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:69202658 (estimated locally) body local optimize_size
  Called by: C40_Ip_ArrayIntegrityCheckResume/66 (265921600 (estimated locally),0.25 per call) 
  Calls: 
C40_Ip_ArrayIntegrityResumeSuppened/64 (C40_Ip_ArrayIntegrityResumeSuppened) @05fbbe00
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:69202658 (estimated locally) body local optimize_size
  Called by: C40_Ip_ArrayIntegrityCheckResume/66 (141261473 (estimated locally),0.13 per call) 
  Calls: 
C40_Ip_ArrayIntegrityCheckSuspend/63 (C40_Ip_ArrayIntegrityCheckSuspend) @05fbbb60
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:276810632 (estimated locally) body optimize_size
  Called by: 
  Calls: 
C40_Ip_CheckUserTestStatusExecution/62 (C40_Ip_CheckUserTestStatusExecution) @05fbb8c0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:160524404 (estimated locally) body local optimize_size
  Called by: C40_Ip_CheckUserTestStatus/61 (143063407 (estimated locally),0.13 per call) 
  Calls: 
C40_Ip_CheckUserTestStatus/61 (C40_Ip_CheckUserTestStatus) @05fbb620
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741823 (estimated locally) body optimize_size
  Called by: 
  Calls: C40_Ip_CheckUserTestStatusExecution/62 (143063407 (estimated locally),0.13 per call) 
C40_Ip_CheckSelecBlock/60 (C40_Ip_CheckSelecBlock) @05fbb1c0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: C40_Ip_UserMarginReadCheck/67 (1073741824 (estimated locally),1.00 per call) C40_Ip_ArrayIntegrityCheck/59 (1073741824 (estimated locally),1.00 per call) 
  Calls: C40_Ip_CheckSelecBlock.part.0/91 (467721934 (estimated locally),0.44 per call) 
C40_Ip_ArrayIntegrityCheck/59 (C40_Ip_ArrayIntegrityCheck) @05f66ee0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: C40_Ip_u32ElapsedTicks/0 (write) C40_Ip_u32TimeoutTicks/1 (write) C40_Ip_u32CurrentTicks/2 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: C40_Ip_SetSeedMisr/20 (14719622 (estimated locally),0.01 per call) C40_Ip_UTestCheckBreakpoint/58 (14719622 (estimated locally),0.01 per call) C40_Ip_MainInterfaceWriteJobAddress/37 (67769898 (estimated locally),0.06 per call) OsIf_GetCounter/78 (67769898 (estimated locally),0.06 per call) OsIf_MicrosToTicks/77 (67769898 (estimated locally),0.06 per call) C40_Ip_UTestCheckBusy/57 (512926472 (estimated locally),0.48 per call) C40_Ip_CheckSelecBlock/60 (1073741824 (estimated locally),1.00 per call) 
C40_Ip_UTestCheckBreakpoint/58 (C40_Ip_UTestCheckBreakpoint) @05f66460
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741817 (estimated locally) body local optimize_size
  Called by: C40_Ip_UserMarginReadCheck/67 (8145942 (estimated locally),0.01 per call) C40_Ip_ArrayIntegrityCheck/59 (14719622 (estimated locally),0.01 per call) 
  Calls: 
C40_Ip_UTestCheckBusy/57 (C40_Ip_UTestCheckBusy) @05f66e00
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:276810632 (estimated locally) body local optimize_size
  Called by: C40_Ip_UserMarginReadCheck/67 (512926472 (estimated locally),0.48 per call) C40_Ip_ArrayIntegrityCheck/59 (512926472 (estimated locally),0.48 per call) 
  Calls: C40_Ip_UTestCheckBusy.part.0/90 (69202658 (estimated locally),0.25 per call) 
C40_Ip_GetBlockNumberFromAddress/56 (C40_Ip_GetBlockNumberFromAddress) @05f66b60
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741823 (estimated locally) body optimize_size
  Called by: 
  Calls: C40_Ip_GetCodeBlockNumber/55 (294876346 (estimated locally),0.27 per call) 
C40_Ip_GetCodeBlockNumber/55 (C40_Ip_GetCodeBlockNumber) @05f668c0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: C40_Ip_GetBlockNumberFromAddress/56 (294876346 (estimated locally),0.27 per call) 
  Calls: 
C40_Ip_GetSectorNumberFromAddress/54 (C40_Ip_GetSectorNumberFromAddress) @05f66620
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: C40_Ip_MainInterfaceWritePreCheck/44 (1073741824 (estimated locally),1.00 per call) 
  Calls: C40_Ip_GetSectorNumberFromAddress.part.0/105 (348966093 (estimated locally),0.33 per call) 
C40_Ip_CheckLockDomainID_CheckRegister/53 (C40_Ip_CheckLockDomainID_CheckRegister) @05f66380
  Type: function definition analyzed
  Visibility: externally_visible public
  References: C40_Ip_u32SectorId/3 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: C40_Ip_CheckLockDomainID/51 (354334800 (estimated locally),0.33 per call) 
  Calls: 
C40_Ip_GetBaseAddressOfSector/52 (C40_Ip_GetBaseAddressOfSector) @05f59d20
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: C40_Ip_MainInterfaceSectorErase/42 (217325344 (estimated locally),0.20 per call) 
  Calls: 
C40_Ip_CheckLockDomainID/51 (C40_Ip_CheckLockDomainID) @05f597e0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: C40_Ip_u32SectorId/3 (read) C40_Ip_u32BitPosition/4 (read) 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: C40_Ip_ClearLock/29 (453335945 (estimated locally),0.42 per call) C40_Ip_SetLock/25 (453335945 (estimated locally),0.42 per call) 
  Calls: C40_Ip_CheckLockDomainID_CheckRegister/53 (354334800 (estimated locally),0.33 per call) 
C40_Ip_GetSectorID/50 (C40_Ip_GetSectorID) @05f592a0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: C40_Ip_u32SectorId/3 (write) C40_Ip_u32SectorId/3 (write) C40_Ip_u32SectorId/3 (write) C40_Ip_u32SectorId/3 (write) C40_Ip_u32SectorId/3 (read) 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: C40_Ip_GetLockProtect/28 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
C40_Ip_MainInterfaceHVJobStatus/49 (C40_Ip_MainInterfaceHVJobStatus) @05f59ee0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741823 (estimated locally) body local optimize_size
  Called by: C40_Ip_MainInterfaceWriteStatus/48 (1073741824 (estimated locally),1.00 per call) C40_Ip_MainInterfaceSectorEraseStatus/43 (1073741824 (estimated locally),1.00 per call) 
  Calls: C40_Ip_MainInterfaceHVJobStatus.part.0/100 (354334800 (estimated locally),0.33 per call) 
C40_Ip_MainInterfaceWriteStatus/48 (C40_Ip_MainInterfaceWriteStatus) @05f59c40
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: C40_Ip_MainInterfaceHVJobStatus/49 (1073741824 (estimated locally),1.00 per call) 
C40_Ip_MainInterfaceWrite/47 (C40_Ip_MainInterfaceWrite) @05f599a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: C40_Ip_u32LogicalAddressCheckFail/5 (write) C40_Ip_eOpStatus/7 (write) C40_Ip_u32ElapsedTicks/0 (write) C40_Ip_u32TimeoutTicks/1 (write) C40_Ip_u32CurrentTicks/2 (write) C40_Ip_bAsync/9 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741823 (estimated locally) body optimize_size
  Called by: 
  Calls: C40_Ip_FlashAccessCalloutStart/70 (71717363 (estimated locally),0.07 per call) C40_Ip_MainInterfaceFillDataBuff/45 (217325344 (estimated locally),0.20 per call) C40_Ip_ClearInterlockWrite/46 (26122506 (estimated locally),0.02 per call) C40_Ip_MainInterfaceWriteJobAddress/37 (217325344 (estimated locally),0.20 per call) C40_Ip_ClearAllErrorFlagsMainInterface/40 (217325344 (estimated locally),0.20 per call) C40_Ip_MainInterfaceWritePreCheck/44 (1073741823 (estimated locally),1.00 per call) OsIf_GetCounter/78 (1073741823 (estimated locally),1.00 per call) OsIf_MicrosToTicks/77 (1073741823 (estimated locally),1.00 per call) 
C40_Ip_ClearInterlockWrite/46 (C40_Ip_ClearInterlockWrite) @05f59700
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:114863530 (estimated locally) body local optimize_size
  Called by: C40_Ip_MainInterfaceWrite/47 (26122506 (estimated locally),0.02 per call) C40_Ip_MainInterfaceSectorErase/42 (26122506 (estimated locally),0.02 per call) 
  Calls: OsIf_GetElapsed/79 (1014686026 (estimated locally),8.83 per call) OsIf_GetCounter/78 (114863530 (estimated locally),1.00 per call) OsIf_MicrosToTicks/77 (114863530 (estimated locally),1.00 per call) 
C40_Ip_MainInterfaceFillDataBuff/45 (C40_Ip_MainInterfaceFillDataBuff) @05f59460
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:236223200 (estimated locally) body local optimize_size
  Called by: C40_Ip_MainInterfaceWrite/47 (217325344 (estimated locally),0.20 per call) 
  Calls: 
C40_Ip_MainInterfaceWritePreCheck/44 (C40_Ip_MainInterfaceWritePreCheck) @05f591c0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: C40_Ip_MainInterfaceWrite/47 (1073741823 (estimated locally),1.00 per call) 
  Calls: C40_Ip_GetLock/27 (9742865 (estimated locally),0.01 per call) C40_Ip_GetSectorNumberFromAddress/54 (1073741824 (estimated locally),1.00 per call) 
C40_Ip_MainInterfaceSectorEraseStatus/43 (C40_Ip_MainInterfaceSectorEraseStatus) @05f4ee00
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: C40_Ip_MainInterfaceHVJobStatus/49 (1073741824 (estimated locally),1.00 per call) 
C40_Ip_MainInterfaceSectorErase/42 (C40_Ip_MainInterfaceSectorErase) @05f4e8c0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: C40_Ip_u32ElapsedTicks/0 (write) C40_Ip_u32TimeoutTicks/1 (write) C40_Ip_u32CurrentTicks/2 (write) C40_Ip_bAsync/9 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741823 (estimated locally) body optimize_size
  Called by: 
  Calls: C40_Ip_FlashAccessCalloutStart/70 (120473833 (estimated locally),0.11 per call) C40_Ip_ClearInterlockWrite/46 (26122506 (estimated locally),0.02 per call) C40_Ip_MainInterfaceWriteJobAddress/37 (217325344 (estimated locally),0.20 per call) C40_Ip_GetBaseAddressOfSector/52 (217325344 (estimated locally),0.20 per call) C40_Ip_ClearAllErrorFlagsMainInterface/40 (217325344 (estimated locally),0.20 per call) C40_Ip_MainInterfaceSectorErasePreCheck/41 (1073741823 (estimated locally),1.00 per call) OsIf_GetCounter/78 (1073741823 (estimated locally),1.00 per call) OsIf_MicrosToTicks/77 (1073741823 (estimated locally),1.00 per call) 
C40_Ip_MainInterfaceSectorErasePreCheck/41 (C40_Ip_MainInterfaceSectorErasePreCheck) @05f4e0e0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: C40_Ip_MainInterfaceSectorErase/42 (1073741823 (estimated locally),1.00 per call) 
  Calls: C40_Ip_GetLock/27 (111347028 (estimated locally),0.10 per call) 
C40_Ip_ClearAllErrorFlagsMainInterface/40 (C40_Ip_ClearAllErrorFlagsMainInterface) @05f4ed20
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: C40_Ip_MainInterfaceWrite/47 (217325344 (estimated locally),0.20 per call) C40_Ip_MainInterfaceSectorErase/42 (217325344 (estimated locally),0.20 per call) C40_Ip_Read/24 (1073741824 (estimated locally),3.18 per call) C40_Ip_InitMainInterface/38 (1073741824 (estimated locally),1.00 per call) C40_Ip_EraseVerify/35 (1073741824 (estimated locally),9.35 per call) C40_Ip_ProgramVerify/33 (1073741824 (estimated locally),9.35 per call) 
  Calls: 
C40_Ip_MainInterfaceAbort/39 (C40_Ip_MainInterfaceAbort) @05f4ea80
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: C40_Ip_u32ElapsedTicks/0 (write) C40_Ip_u32TimeoutTicks/1 (write) C40_Ip_u32CurrentTicks/2 (write) C40_Ip_u32CurrentTicks/2 (addr) C40_Ip_u32ElapsedTicks/0 (read) C40_Ip_u32ElapsedTicks/0 (write) C40_Ip_u32TimeoutTicks/1 (read) 
  Referring: 
  Availability: local
  Function flags: count:114863530 (estimated locally) body local optimize_size
  Called by: C40_Ip_Abort/15 (1073741824 (estimated locally),1.00 per call) C40_Ip_InitMainInterface/38 (1073741824 (estimated locally),1.00 per call) 
  Calls: OsIf_GetElapsed/79 (1014686026 (estimated locally),8.83 per call) OsIf_GetCounter/78 (114863530 (estimated locally),1.00 per call) OsIf_MicrosToTicks/77 (114863530 (estimated locally),1.00 per call) 
C40_Ip_InitMainInterface/38 (C40_Ip_InitMainInterface) @05f4e7e0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: C40_Ip_Init/12 (1073741824 (estimated locally),1.00 per call) 
  Calls: C40_Ip_ClearAllErrorFlagsMainInterface/40 (1073741824 (estimated locally),1.00 per call) C40_Ip_MainInterfaceAbort/39 (1073741824 (estimated locally),1.00 per call) 
C40_Ip_MainInterfaceWriteJobAddress/37 (C40_Ip_MainInterfaceWriteJobAddress) @05f4e540
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: C40_Ip_u32CurrentTicks/2 (addr) C40_Ip_u32ElapsedTicks/0 (read) C40_Ip_u32ElapsedTicks/0 (write) C40_Ip_u32TimeoutTicks/1 (read) 
  Referring: 
  Availability: local
  Function flags: count:114863530 (estimated locally) body local optimize_size
  Called by: C40_Ip_UserMarginReadCheck/67 (67769898 (estimated locally),0.06 per call) C40_Ip_ArrayIntegrityCheck/59 (67769898 (estimated locally),0.06 per call) C40_Ip_MainInterfaceWrite/47 (217325344 (estimated locally),0.20 per call) C40_Ip_MainInterfaceSectorErase/42 (217325344 (estimated locally),0.20 per call) 
  Calls: OsIf_GetElapsed/79 (1073741824 (estimated locally),9.35 per call) 
C40_Ip_MainInterfaceWriteLogicalAddress/36 (C40_Ip_MainInterfaceWriteLogicalAddress) @05f4e2a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 
C40_Ip_EraseVerify/35 (C40_Ip_EraseVerify) @05f4e000
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: C40_Ip_eReadStatus/6 (write) 
  Referring: 
  Availability: local
  Function flags: count:114863530 (estimated locally) body local optimize_size
  Called by: C40_Ip_Compare/31 (161061272 (estimated locally),0.15 per call) 
  Calls: C40_Ip_CheckReadCompareStatus.constprop.0/106 (1073741824 (estimated locally),9.35 per call) C40_Ip_FlashAccessCalloutFinish/71 (1073741824 (estimated locally),9.35 per call) C40_Ip_CompareBlank/34 (1073741824 (estimated locally),9.35 per call) C40_Ip_FlashAccessCalloutStart/70 (1073741824 (estimated locally),9.35 per call) C40_Ip_ClearAllErrorFlagsMainInterface/40 (1073741824 (estimated locally),9.35 per call) 
C40_Ip_CompareBlank/34 (C40_Ip_CompareBlank) @0604da80
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741823 (estimated locally) body local optimize_size
  Called by: C40_Ip_EraseVerify/35 (1073741824 (estimated locally),9.35 per call) 
  Calls: 
C40_Ip_ProgramVerify/33 (C40_Ip_ProgramVerify) @0604d460
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: C40_Ip_eReadStatus/6 (write) 
  Referring: 
  Availability: local
  Function flags: count:114863530 (estimated locally) body local optimize_size
  Called by: C40_Ip_Compare/31 (375809640 (estimated locally),0.35 per call) 
  Calls: C40_Ip_CheckReadCompareStatus.constprop.0/106 (1073741824 (estimated locally),9.35 per call) C40_Ip_FlashAccessCalloutFinish/71 (1073741824 (estimated locally),9.35 per call) C40_Ip_CompareData/32 (1073741824 (estimated locally),9.35 per call) C40_Ip_FlashAccessCalloutStart/70 (1073741824 (estimated locally),9.35 per call) C40_Ip_ClearAllErrorFlagsMainInterface/40 (1073741824 (estimated locally),9.35 per call) 
C40_Ip_CompareData/32 (C40_Ip_CompareData) @0604dee0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741823 (estimated locally) body local optimize_size
  Called by: C40_Ip_ProgramVerify/33 (1073741824 (estimated locally),9.35 per call) 
  Calls: 
C40_Ip_Compare/31 (C40_Ip_Compare) @0604dc40
  Type: function definition analyzed
  Visibility: externally_visible public
  References: C40_Ip_eReadStatus/6 (write) C40_Ip_eReadStatus/6 (write) C40_Ip_eReadStatus/6 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: C40_Ip_EraseVerify/35 (161061272 (estimated locally),0.15 per call) C40_Ip_ProgramVerify/33 (375809640 (estimated locally),0.35 per call) 
C40_Ip_ClearLockProtect/30 (C40_Ip_ClearLockProtect) @0604d9a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: C40_Ip_u32BitPosition/4 (read) C40_Ip_u32BitPosition/4 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: C40_Ip_ClearLock/29 (54490981 (estimated locally),0.05 per call) 
  Calls: C40_Ip_ClearLockProtect.part.0/103 (354334801 (estimated locally),0.33 per call) 
C40_Ip_ClearLock/29 (C40_Ip_ClearLock) @0604d700
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: C40_Ip_ClearLockProtect/30 (54490981 (estimated locally),0.05 per call) C40_Ip_CheckLockDomainID/51 (453335945 (estimated locally),0.42 per call) C40_Ip_GetLock/27 (1073741824 (estimated locally),1.00 per call) 
C40_Ip_GetLockProtect/28 (C40_Ip_GetLockProtect) @0604d380
  Type: function definition analyzed
  Visibility: externally_visible public
  References: C40_Ip_u32SectorId/3 (write) C40_Ip_u32BitPosition/4 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: C40_Ip_GetLock.part.0/102 (1073741824 (estimated locally),1.00 per call) 
  Calls: C40_Ip_GetSectorID/50 (1073741824 (estimated locally),1.00 per call) 
C40_Ip_GetLock/27 (C40_Ip_GetLock) @0604d0e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: C40_Ip_MainInterfaceWritePreCheck/44 (9742865 (estimated locally),0.01 per call) C40_Ip_ClearLock/29 (1073741824 (estimated locally),1.00 per call) C40_Ip_SetLock/25 (1073741824 (estimated locally),1.00 per call) C40_Ip_MainInterfaceSectorErasePreCheck/41 (111347028 (estimated locally),0.10 per call) 
  Calls: C40_Ip_GetLock.part.0/102 (354334800 (estimated locally),0.33 per call) 
C40_Ip_SetLockProtect/26 (C40_Ip_SetLockProtect) @05e59b60
  Type: function definition analyzed
  Visibility: externally_visible public
  References: C40_Ip_u32BitPosition/4 (read) C40_Ip_u32BitPosition/4 (read) C40_Ip_u32BitPosition/4 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: C40_Ip_SetLock/25 (54490981 (estimated locally),0.05 per call) 
  Calls: C40_Ip_SetLockProtect.part.0/101 (182536112 (estimated locally),0.17 per call) 
C40_Ip_SetLock/25 (C40_Ip_SetLock) @05e59620
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: C40_Ip_SetLockProtect/26 (54490981 (estimated locally),0.05 per call) C40_Ip_CheckLockDomainID/51 (453335945 (estimated locally),0.42 per call) C40_Ip_GetLock/27 (1073741824 (estimated locally),1.00 per call) 
C40_Ip_Read/24 (C40_Ip_Read) @05e59e00
  Type: function definition analyzed
  Visibility: externally_visible public
  References: C40_Ip_eReadStatus/6 (write) C40_Ip_eReadStatus/6 (write) C40_Ip_eReadStatus/6 (write) C40_Ip_eReadStatus/6 (read) 
  Referring: 
  Availability: available
  Function flags: count:337833909 (estimated locally) body optimize_size
  Called by: 
  Calls: C40_Ip_CheckReadCompareStatus.constprop.0/106 (1073741824 (estimated locally),3.18 per call) C40_Ip_FlashAccessCalloutFinish/71 (1073741824 (estimated locally),3.18 per call) C40_Ip_ReadData/21 (1073741824 (estimated locally),3.18 per call) C40_Ip_FlashAccessCalloutStart/70 (1073741824 (estimated locally),3.18 per call) C40_Ip_ClearAllErrorFlagsMainInterface/40 (1073741824 (estimated locally),3.18 per call) 
C40_Ip_ReadData/21 (C40_Ip_ReadData) @05e59540
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741823 (estimated locally) body local optimize_size
  Called by: C40_Ip_Read/24 (1073741824 (estimated locally),3.18 per call) 
  Calls: 
C40_Ip_SetSeedMisr/20 (C40_Ip_SetSeedMisr) @05e592a0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:153391691 (estimated locally) body local optimize_size
  Called by: C40_Ip_UserMarginReadCheck/67 (8145942 (estimated locally),0.01 per call) C40_Ip_ArrayIntegrityCheck/59 (14719622 (estimated locally),0.01 per call) 
  Calls: C40_Ip_SetSeedMisr.part.0/80 (46017507 (estimated locally),0.30 per call) 
C40_Ip_CheckReadCompareStatus/16 (C40_Ip_CheckReadCompareStatus) @05e55ee0
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 
C40_Ip_Abort/15 (C40_Ip_Abort) @05e55c40
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: C40_Ip_MainInterfaceAbort/39 (1073741824 (estimated locally),1.00 per call) 
C40_Ip_Block4PipeSelect/14 (C40_Ip_Block4PipeSelect) @05e559a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: C40_Ip_Init/12 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
C40_Ip_DataErrorSuppression/13 (C40_Ip_DataErrorSuppression) @05e55620
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: C40_Ip_Init/12 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
C40_Ip_Init/12 (C40_Ip_Init) @05e55380
  Type: function definition analyzed
  Visibility: externally_visible public
  References: C40_Ip_pConfigPtr/8 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: C40_Ip_InitMainInterface/38 (1073741824 (estimated locally),1.00 per call) C40_Ip_Block4PipeSelect/14 (1073741824 (estimated locally),1.00 per call) C40_Ip_DataErrorSuppression/13 (1073741824 (estimated locally),1.00 per call) 
C40_Ip_pFlashBaseAddress/10 (C40_Ip_pFlashBaseAddress) @05e4f4c8
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags: initialized read-only const-value-known
C40_Ip_bAsync/9 (C40_Ip_bAsync) @05e4f480
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: C40_Ip_MainInterfaceSectorErase/42 (read) C40_Ip_MainInterfaceWrite/47 (read) C40_Ip_SetAsyncMode/69 (write) 
  Availability: available
  Varpool flags: initialized
C40_Ip_pConfigPtr/8 (C40_Ip_pConfigPtr) @05e4f3f0
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: C40_Ip_FlashAccessCalloutStart/70 (read) C40_Ip_FlashAccessCalloutFinish/71 (read) C40_Ip_Init/12 (write) 
  Availability: available
  Varpool flags:
C40_Ip_eOpStatus/7 (C40_Ip_eOpStatus) @05e4f360
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: C40_Ip_MainInterfaceWrite/47 (write) C40_Ip_GetFailedAddress/68 (read) 
  Availability: available
  Varpool flags:
C40_Ip_eReadStatus/6 (C40_Ip_eReadStatus) @05e4f2d0
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: C40_Ip_Read/24 (write) C40_Ip_CheckReadCompareStatus.constprop.0/106 (write) C40_Ip_EraseVerify/35 (write) C40_Ip_Read/24 (write) C40_Ip_ProgramVerify/33 (write) C40_Ip_Read/24 (read) C40_Ip_CheckReadCompareStatus.constprop.0/106 (write) C40_Ip_Read/24 (write) C40_Ip_Compare/31 (write) C40_Ip_Compare/31 (write) C40_Ip_Compare/31 (read) 
  Availability: available
  Varpool flags: initialized
C40_Ip_u32LogicalAddressCheckFail/5 (C40_Ip_u32LogicalAddressCheckFail) @05e4f240
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: C40_Ip_MainInterfaceWrite/47 (write) C40_Ip_GetFailedAddress/68 (read) 
  Availability: available
  Varpool flags:
C40_Ip_u32BitPosition/4 (C40_Ip_u32BitPosition) @05e4f168
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: C40_Ip_GetLockProtect/28 (write) C40_Ip_ClearLockProtect/30 (read) C40_Ip_SetLockProtect.part.0/101 (read) C40_Ip_SetLockProtect/26 (read) C40_Ip_SetLockProtect/26 (read) C40_Ip_SetLockProtect/26 (read) C40_Ip_ClearLockProtect.part.0/103 (read) C40_Ip_ClearLockProtect.part.0/103 (read) C40_Ip_ClearLockProtect/30 (read) C40_Ip_CheckLockDomainID/51 (read) 
  Availability: available
  Varpool flags:
C40_Ip_u32SectorId/3 (C40_Ip_u32SectorId) @05e4f0d8
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: C40_Ip_GetLockProtect/28 (write) C40_Ip_GetSectorID/50 (write) C40_Ip_CheckLockDomainID_CheckRegister/53 (read) C40_Ip_GetSectorID/50 (read) C40_Ip_GetSectorID/50 (write) C40_Ip_GetSectorID/50 (write) C40_Ip_GetSectorID/50 (write) C40_Ip_CheckLockDomainID/51 (read) 
  Availability: available
  Varpool flags:
C40_Ip_u32CurrentTicks/2 (C40_Ip_u32CurrentTicks) @05e46ee8
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: C40_Ip_MainInterfaceSectorErase/42 (write) C40_Ip_MainInterfaceWrite/47 (write) C40_Ip_MainInterfaceHVJobStatus.part.0/100 (addr) C40_Ip_MainInterfaceAbort/39 (addr) C40_Ip_ArrayIntegrityCheck/59 (write) C40_Ip_MainInterfaceWriteJobAddress/37 (addr) C40_Ip_MainInterfaceAbort/39 (write) C40_Ip_UserMarginReadCheck/67 (write) 
  Availability: available
  Varpool flags:
C40_Ip_u32TimeoutTicks/1 (C40_Ip_u32TimeoutTicks) @05e46ea0
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: C40_Ip_MainInterfaceSectorErase/42 (write) C40_Ip_MainInterfaceWrite/47 (write) C40_Ip_MainInterfaceHVJobStatus.part.0/100 (read) C40_Ip_MainInterfaceAbort/39 (read) C40_Ip_ArrayIntegrityCheck/59 (write) C40_Ip_MainInterfaceWriteJobAddress/37 (read) C40_Ip_MainInterfaceAbort/39 (write) C40_Ip_UserMarginReadCheck/67 (write) 
  Availability: available
  Varpool flags:
C40_Ip_u32ElapsedTicks/0 (C40_Ip_u32ElapsedTicks) @05e46e58
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: C40_Ip_ArrayIntegrityCheck/59 (write) C40_Ip_MainInterfaceWriteJobAddress/37 (write) C40_Ip_MainInterfaceSectorErase/42 (write) C40_Ip_MainInterfaceWrite/47 (write) C40_Ip_MainInterfaceHVJobStatus.part.0/100 (write) C40_Ip_MainInterfaceAbort/39 (write) C40_Ip_MainInterfaceAbort/39 (read) C40_Ip_MainInterfaceAbort/39 (write) C40_Ip_MainInterfaceHVJobStatus.part.0/100 (read) C40_Ip_MainInterfaceWriteJobAddress/37 (read) C40_Ip_UserMarginReadCheck/67 (write) 
  Availability: available
  Varpool flags:

;; Function C40_Ip_ClearAllErrorFlagsMainInterface (C40_Ip_ClearAllErrorFlagsMainInterface, funcdef_no=28, decl_uid=5955, cgraph_uid=29, symbol_order=40)

Modification phase of node C40_Ip_ClearAllErrorFlagsMainInterface/40
C40_Ip_ClearAllErrorFlagsMainInterface ()
{
  long unsigned int _1;
  long unsigned int _2;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 ={v} MEM[(struct FLASH_Type *)1076805632B].MCRS;
  _2 = _1 & 4078108672;
  MEM[(struct FLASH_Type *)1076805632B].MCRS ={v} _2;
  return;

}



;; Function C40_Ip_UTestCheckBreakpoint (C40_Ip_UTestCheckBreakpoint, funcdef_no=46, decl_uid=5925, cgraph_uid=47, symbol_order=58)

Modification phase of node C40_Ip_UTestCheckBreakpoint/58
C40_Ip_UTestCheckBreakpoint (C40_Ip_FlashBreakPointsType BreakPoints)
{
  uint32 Temp;
  long unsigned int _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;
  long unsigned int _7;
  long unsigned int _8;
  long unsigned int _9;
  long unsigned int _10;
  long unsigned int _11;
  long unsigned int _12;

  <bb 2> [local count: 1073741817]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  switch (BreakPoints_14(D)) <default: <L2> [33.33%], case 0: <L0> [33.33%], case 1: <L1> [33.33%]>

  <bb 3> [local count: 357913942]:
<L0>:
  # DEBUG BEGIN_STMT
  Temp_22 ={v} MEM[(struct FLASH_Type *)1076805632B].MCRS;
  # DEBUG Temp => Temp_22
  # DEBUG BEGIN_STMT
  Temp_23 = Temp_22 & 216858623;
  # DEBUG Temp => Temp_23
  # DEBUG BEGIN_STMT
  Temp_24 = Temp_23 | 3221225472;
  # DEBUG Temp => Temp_24
  # DEBUG BEGIN_STMT
  MEM[(struct FLASH_Type *)1076805632B].MCRS ={v} Temp_24;
  # DEBUG BEGIN_STMT
  _1 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _2 = _1 | 256;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _2;
  # DEBUG BEGIN_STMT
  _3 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _4 = _3 & 3221225471;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _4;
  # DEBUG BEGIN_STMT
  goto <bb 6>; [100.00%]

  <bb 4> [local count: 357913942]:
<L1>:
  # DEBUG BEGIN_STMT
  Temp_16 ={v} MEM[(struct FLASH_Type *)1076805632B].MCRS;
  # DEBUG Temp => Temp_16
  # DEBUG BEGIN_STMT
  Temp_17 = Temp_16 & 216858623;
  # DEBUG Temp => Temp_17
  # DEBUG BEGIN_STMT
  Temp_18 = Temp_17 | 3221225472;
  # DEBUG Temp => Temp_18
  # DEBUG BEGIN_STMT
  MEM[(struct FLASH_Type *)1076805632B].MCRS ={v} Temp_18;
  # DEBUG BEGIN_STMT
  _5 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _6 = _5 | 256;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _6;
  # DEBUG BEGIN_STMT
  _7 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _8 = _7 | 1073741824;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _8;
  # DEBUG BEGIN_STMT
  goto <bb 6>; [100.00%]

  <bb 5> [local count: 357913942]:
<L2>:
  # DEBUG BEGIN_STMT
  _9 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _10 = _9 & 4294967039;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _10;
  # DEBUG BEGIN_STMT
  _11 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _12 = _11 & 3221225471;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _12;
  # DEBUG BEGIN_STMT

  <bb 6> [local count: 1073741824]:
  return;

}



;; Function C40_Ip_FlashAccessCalloutStart (C40_Ip_FlashAccessCalloutStart, funcdef_no=58, decl_uid=5986, cgraph_uid=59, symbol_order=70)

Modification phase of node C40_Ip_FlashAccessCalloutStart/70
C40_Ip_FlashAccessCalloutStart ()
{
  const struct C40_ConfigType * C40_Ip_pConfigPtr.4_1;
  void (*<T4d5>) (void) _2;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  C40_Ip_pConfigPtr.4_1 = C40_Ip_pConfigPtr;
  _2 = C40_Ip_pConfigPtr.4_1->startFlashAccessNotifPtr;
  if (_2 != 0B)
    goto <bb 3>; [70.00%]
  else
    goto <bb 4>; [30.00%]

  <bb 3> [local count: 751619281]:
  # DEBUG BEGIN_STMT
  _2 ();

  <bb 4> [local count: 1073741824]:
  return;

}



;; Function C40_Ip_FlashAccessCalloutFinish (C40_Ip_FlashAccessCalloutFinish, funcdef_no=59, decl_uid=5988, cgraph_uid=60, symbol_order=71)

Modification phase of node C40_Ip_FlashAccessCalloutFinish/71
C40_Ip_FlashAccessCalloutFinish ()
{
  const struct C40_ConfigType * C40_Ip_pConfigPtr.11_1;
  void (*<T4d5>) (void) _2;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  C40_Ip_pConfigPtr.11_1 = C40_Ip_pConfigPtr;
  _2 = C40_Ip_pConfigPtr.11_1->finishedFlashAccessNotifPtr;
  if (_2 != 0B)
    goto <bb 3>; [70.00%]
  else
    goto <bb 4>; [30.00%]

  <bb 3> [local count: 751619281]:
  # DEBUG BEGIN_STMT
  _2 ();

  <bb 4> [local count: 1073741824]:
  return;

}



;; Function C40_Ip_MainInterfaceAbort (C40_Ip_MainInterfaceAbort, funcdef_no=27, decl_uid=5959, cgraph_uid=28, symbol_order=39)

Modification phase of node C40_Ip_MainInterfaceAbort/39
C40_Ip_MainInterfaceAbort ()
{
  C40_Ip_StatusType ReturnCode;
  long unsigned int _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int C40_Ip_u32ElapsedTicks.0_5;
  long unsigned int _6;
  long unsigned int C40_Ip_u32TimeoutTicks.2_7;
  long unsigned int _8;
  long unsigned int _9;
  long unsigned int _10;
  long unsigned int _11;
  long unsigned int _23;

  <bb 2> [local count: 114863530]:
  # DEBUG BEGIN_STMT
  # DEBUG ReturnCode => 23205
  # DEBUG BEGIN_STMT
  C40_Ip_u32ElapsedTicks = 0;
  # DEBUG BEGIN_STMT
  _1 = OsIf_MicrosToTicks (32767, 0);
  C40_Ip_u32TimeoutTicks = _1;
  # DEBUG BEGIN_STMT
  _2 = OsIf_GetCounter (0);
  C40_Ip_u32CurrentTicks = _2;
  # DEBUG BEGIN_STMT
  _3 ={v} MEM[(struct FLASH_Type *)1076805632B].MCR;
  _4 = _3 & 4294967294;
  MEM[(struct FLASH_Type *)1076805632B].MCR ={v} _4;
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  goto <bb 4>; [100.00%]

  <bb 3> [local count: 1014686026]:
  # DEBUG BEGIN_STMT
  _23 = OsIf_GetElapsed (&C40_Ip_u32CurrentTicks, 0);
  C40_Ip_u32ElapsedTicks.0_5 = C40_Ip_u32ElapsedTicks;
  _6 = C40_Ip_u32ElapsedTicks.0_5 + _23;
  C40_Ip_u32ElapsedTicks = _6;
  # DEBUG BEGIN_STMT
  C40_Ip_u32TimeoutTicks.2_7 = C40_Ip_u32TimeoutTicks;
  if (_6 >= C40_Ip_u32TimeoutTicks.2_7)
    goto <bb 5>; [5.50%]
  else
    goto <bb 6>; [94.50%]

  <bb 6> [local count: 958878296]:

  <bb 4> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _8 ={v} MEM[(struct FLASH_Type *)1076805632B].MCRS;
  _9 = _8 & 32768;
  if (_9 == 0)
    goto <bb 3>; [94.50%]
  else
    goto <bb 5>; [5.50%]

  <bb 5> [local count: 114863531]:
  # ReturnCode_12 = PHI <11220(3), 23205(4)>
  # DEBUG ReturnCode => ReturnCode_12
  # DEBUG BEGIN_STMT
  _10 ={v} MEM[(struct FLASH_Type *)1076805632B].MCR;
  _11 = _10 & 4294966991;
  MEM[(struct FLASH_Type *)1076805632B].MCR ={v} _11;
  # DEBUG BEGIN_STMT
  return ReturnCode_12;

}



;; Function C40_Ip_ClearInterlockWrite (C40_Ip_ClearInterlockWrite, funcdef_no=34, decl_uid=5969, cgraph_uid=35, symbol_order=46)

Modification phase of node C40_Ip_ClearInterlockWrite/46
C40_Ip_ClearInterlockWrite ()
{
  uint32 CurrentTicks;
  uint32 TimeoutTicks;
  uint32 ElapsedTicks;
  long unsigned int _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;
  long unsigned int _7;
  long unsigned int _19;

  <bb 2> [local count: 114863530]:
  # DEBUG BEGIN_STMT
  MEM[(struct FLASH_Type *)1076805632B].DATA[0] ={v} 0;
  # DEBUG BEGIN_STMT
  _1 ={v} MEM[(struct FLASH_Type *)1076805632B].MCR;
  _2 = _1 | 256;
  MEM[(struct FLASH_Type *)1076805632B].MCR ={v} _2;
  # DEBUG BEGIN_STMT
  # DEBUG ElapsedTicks => 0
  # DEBUG BEGIN_STMT
  TimeoutTicks_15 = OsIf_MicrosToTicks (32767, 0);
  # DEBUG TimeoutTicks => TimeoutTicks_15
  # DEBUG BEGIN_STMT
  _3 = OsIf_GetCounter (0);
  CurrentTicks = _3;
  # DEBUG BEGIN_STMT
  goto <bb 4>; [100.00%]

  <bb 3> [local count: 1014686026]:
  # DEBUG BEGIN_STMT
  _19 = OsIf_GetElapsed (&CurrentTicks, 0);
  ElapsedTicks_20 = ElapsedTicks_8 + _19;
  # DEBUG ElapsedTicks => ElapsedTicks_20
  # DEBUG BEGIN_STMT
  if (TimeoutTicks_15 <= ElapsedTicks_20)
    goto <bb 5>; [5.50%]
  else
    goto <bb 6>; [94.50%]

  <bb 6> [local count: 958878296]:

  <bb 4> [local count: 1073741824]:
  # ElapsedTicks_8 = PHI <0(2), ElapsedTicks_20(6)>
  # DEBUG ElapsedTicks => ElapsedTicks_8
  # DEBUG BEGIN_STMT
  _4 ={v} MEM[(struct FLASH_Type *)1076805632B].MCR;
  _5 = _4 & 256;
  if (_5 == 0)
    goto <bb 3>; [94.50%]
  else
    goto <bb 5>; [5.50%]

  <bb 5> [local count: 114863531]:
  # DEBUG BEGIN_STMT
  _6 ={v} MEM[(struct FLASH_Type *)1076805632B].MCR;
  _7 = _6 & 4294967039;
  MEM[(struct FLASH_Type *)1076805632B].MCR ={v} _7;
  CurrentTicks ={v} {CLOBBER};
  return;

}



;; Function C40_Ip_MainInterfaceWriteJobAddress (C40_Ip_MainInterfaceWriteJobAddress, funcdef_no=25, decl_uid=5972, cgraph_uid=26, symbol_order=37)

Modification phase of node C40_Ip_MainInterfaceWriteJobAddress/37
C40_Ip_MainInterfaceWriteJobAddress (uint32 PhysicalAddress, uint8 DomainIdValue)
{
  uint8 ActualDomainIDs;
  C40_Ip_StatusType ReturnCode;
  long unsigned int _1;
  long unsigned int _2;
  long unsigned int C40_Ip_u32ElapsedTicks.32_3;
  long unsigned int _4;
  long unsigned int C40_Ip_u32TimeoutTicks.34_5;
  long unsigned int _12;

  <bb 2> [local count: 114863530]:
  # DEBUG BEGIN_STMT
  # DEBUG ReturnCode => 23205

  <bb 3> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG Address => PhysicalAddress_9(D)
  # DEBUG INLINE_ENTRY C40_Ip_MainInterfaceWriteLogicalAddress
  # DEBUG BEGIN_STMT
  MEM[(struct PFLASH_Type *)1076264960B].PFCPGM_PEADR_L ={v} PhysicalAddress_9(D);
  # DEBUG Address => NULL
  # DEBUG BEGIN_STMT
  _1 ={v} MEM[(struct FLASH_Type *)1076805632B].MCR;
  _2 = _1 >> 16;
  ActualDomainIDs_10 = (uint8) _2;
  # DEBUG ActualDomainIDs => ActualDomainIDs_10
  # DEBUG BEGIN_STMT
  _12 = OsIf_GetElapsed (&C40_Ip_u32CurrentTicks, 0);
  C40_Ip_u32ElapsedTicks.32_3 = C40_Ip_u32ElapsedTicks;
  _4 = C40_Ip_u32ElapsedTicks.32_3 + _12;
  C40_Ip_u32ElapsedTicks = _4;
  # DEBUG BEGIN_STMT
  C40_Ip_u32TimeoutTicks.34_5 = C40_Ip_u32TimeoutTicks;
  if (_4 >= C40_Ip_u32TimeoutTicks.34_5)
    goto <bb 5>; [5.50%]
  else
    goto <bb 4>; [94.50%]

  <bb 4> [local count: 1014686026]:
  # DEBUG BEGIN_STMT
  if (ActualDomainIDs_10 != DomainIdValue_14(D))
    goto <bb 6>; [94.50%]
  else
    goto <bb 5>; [5.50%]

  <bb 6> [local count: 958878296]:
  goto <bb 3>; [100.00%]

  <bb 5> [local count: 114863531]:
  # ReturnCode_6 = PHI <11220(3), 23205(4)>
  # DEBUG ReturnCode => ReturnCode_6
  # DEBUG BEGIN_STMT
  return ReturnCode_6;

}



;; Function C40_Ip_SetSeedMisr (C40_Ip_SetSeedMisr, funcdef_no=8, decl_uid=5949, cgraph_uid=9, symbol_order=20)

Modification phase of node C40_Ip_SetSeedMisr/20
C40_Ip_SetSeedMisr (const struct C40_Ip_MisrType * MisrSeedValues)
{
  uint8 Counter;
  int _1;
  long unsigned int _3;
  long unsigned int _5;

  <bb 2> [local count: 153391691]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  if (MisrSeedValues_10(D) == 0B)
    goto <bb 3>; [30.00%]
  else
    goto <bb 8>; [70.00%]

  <bb 8> [local count: 107374184]:
  goto <bb 5>; [100.00%]

  <bb 3> [local count: 46017507]:
  # Counter_6 = PHI <0(2)>
  # DEBUG D#1 => MisrSeedValues_10(D)
  C40_Ip_SetSeedMisr.part.0 ();
  goto <bb 7>; [100.00%]

  <bb 4> [local count: 966367641]:
  # DEBUG BEGIN_STMT
  _1 = (int) Counter_7;
  _3 = MisrSeedValues_10(D)->arrMISRValue[_1];
  MEM[(struct FLASH_Type *)1076805632B].UM[_1] ={v} _3;
  # DEBUG BEGIN_STMT
  Counter_14 = Counter_7 + 1;
  # DEBUG Counter => Counter_14

  <bb 5> [local count: 1073741824]:
  # Counter_7 = PHI <Counter_14(4), 0(8)>
  # DEBUG Counter => Counter_7
  # DEBUG BEGIN_STMT
  if (Counter_7 != 9)
    goto <bb 4>; [90.00%]
  else
    goto <bb 6>; [10.00%]

  <bb 6> [local count: 107374184]:
  # DEBUG BEGIN_STMT
  _5 = MisrSeedValues_10(D)->arrMISRValue[9];
  MEM[(struct FLASH_Type *)1076805632B].UM9 ={v} _5;

  <bb 7> [local count: 153391691]:
  return;

}



;; Function C40_Ip_UTestCheckBusy (C40_Ip_UTestCheckBusy, funcdef_no=45, decl_uid=5923, cgraph_uid=46, symbol_order=57)

Modification phase of node C40_Ip_UTestCheckBusy/57
C40_Ip_UTestCheckBusy ()
{
  C40_Ip_StatusType ReturnCode;
  long unsigned int _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;

  <bb 2> [local count: 276810632]:
  # DEBUG BEGIN_STMT
  # DEBUG WaitCounter => 450
  # DEBUG BEGIN_STMT
  # DEBUG ReturnCode => 23205
  # DEBUG BEGIN_STMT
  _1 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _2 = _1 & 2;
  if (_2 != 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 3> [local count: 138405316]:
  # DEBUG BEGIN_STMT
  _3 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _4 = _3 & 512;
  if (_4 != 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 69202658]:
  ReturnCode_9 = C40_Ip_UTestCheckBusy.part.0 ();

  <bb 5> [local count: 276810633]:
  # ReturnCode_5 = PHI <23205(2), ReturnCode_9(4), 59202(3)>
  # DEBUG ReturnCode => ReturnCode_5
  # DEBUG BEGIN_STMT
  return ReturnCode_5;

}



;; Function C40_Ip_MainInterfaceHVJobStatus (C40_Ip_MainInterfaceHVJobStatus, funcdef_no=37, decl_uid=5961, cgraph_uid=38, symbol_order=49)

Modification phase of node C40_Ip_MainInterfaceHVJobStatus/49
C40_Ip_MainInterfaceHVJobStatus ()
{
  uint32 ErrorFlags;
  C40_Ip_StatusType ReturnCode;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _5;

  <bb 2> [local count: 1073741823]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _2 ={v} MEM[(struct FLASH_Type *)1076805632B].MCRS;
  _3 = _2 & 32768;
  if (_3 == 0)
    goto <bb 3>; [33.00%]
  else
    goto <bb 4>; [67.00%]

  <bb 3> [local count: 354334800]:
  ReturnCode_4 = C40_Ip_MainInterfaceHVJobStatus.part.0 ();
  goto <bb 6>; [100.00%]

  <bb 4> [local count: 719407024]:
  # DEBUG BEGIN_STMT
  _5 ={v} MEM[(struct FLASH_Type *)1076805632B].MCRS;
  ErrorFlags_8 = _5 & 212992;
  # DEBUG ErrorFlags => ErrorFlags_8
  # DEBUG BEGIN_STMT
  if (ErrorFlags_8 == 16384)
    goto <bb 6>; [34.00%]
  else
    goto <bb 5>; [66.00%]

  <bb 5> [local count: 474808633]:
  # DEBUG BEGIN_STMT
  # DEBUG ReturnCode => 10212

  <bb 6> [local count: 1073741824]:
  # ReturnCode_6 = PHI <ReturnCode_4(3), 23205(4), 10212(5)>
  # DEBUG ReturnCode => ReturnCode_6
  # DEBUG BEGIN_STMT
  return ReturnCode_6;

}



;; Function C40_Ip_CheckReadCompareStatus.constprop (C40_Ip_CheckReadCompareStatus.constprop.0, funcdef_no=73, decl_uid=7111, cgraph_uid=95, symbol_order=106)

Modification phase of node C40_Ip_CheckReadCompareStatus.constprop/106
C40_Ip_CheckReadCompareStatus.constprop (boolean CompareResult)
{
  C40_Ip_StatusType Status;
  uint32 ErrorFlags;
  uint32 ReadAddress;
  long unsigned int _1;
  long unsigned int _3;
  long unsigned int _4;

  <bb 7> [local count: 1073741824]:
  # DEBUG D#7 s=> ReadAddress
  # DEBUG ReadAddress => D#7

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG Status => 10212
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _1 ={v} MEM[(struct FLASH_Type *)1076805632B].MCRS;
  ErrorFlags_2 = _1 & 856686592;
  # DEBUG ErrorFlags => ErrorFlags_2
  # DEBUG BEGIN_STMT
  if (ErrorFlags_2 != 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 4>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  _3 ={v} MEM[(struct FLASH_Type *)1076805632B].MCRS;
  _4 = ErrorFlags_2 & _3;
  MEM[(struct FLASH_Type *)1076805632B].MCRS ={v} _4;
  # DEBUG BEGIN_STMT
  C40_Ip_eReadStatus = 10212;
  goto <bb 6>; [100.00%]

  <bb 4> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  if (CompareResult_5(D) != 0)
    goto <bb 6>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 5> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  C40_Ip_eReadStatus = 13260;

  <bb 6> [local count: 1073741824]:
  # Status_6 = PHI <10212(3), 23205(4), 10212(5)>
  # DEBUG Status => Status_6
  # DEBUG BEGIN_STMT
  return Status_6;

}



;; Function C40_Ip_DataErrorSuppression (C40_Ip_DataErrorSuppression, funcdef_no=1, decl_uid=5951, cgraph_uid=2, symbol_order=13)

Modification phase of node C40_Ip_DataErrorSuppression/13
C40_Ip_DataErrorSuppression ()
{
  long unsigned int _1;
  long unsigned int _2;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 ={v} MEM[(struct PFLASH_Type *)1076264960B].PFCR4;
  _2 = _1 & 4294967294;
  MEM[(struct PFLASH_Type *)1076264960B].PFCR4 ={v} _2;
  return;

}



;; Function C40_Ip_Block4PipeSelect (C40_Ip_Block4PipeSelect, funcdef_no=2, decl_uid=5953, cgraph_uid=3, symbol_order=14)

Modification phase of node C40_Ip_Block4PipeSelect/14
C40_Ip_Block4PipeSelect ()
{
  long unsigned int _1;
  long unsigned int _2;
  long unsigned int _3;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 ={v} MEM[(struct PFLASH_Type *)1076264960B].PFCR4;
  _2 = _1 & 4294967281;
  MEM[(struct PFLASH_Type *)1076264960B].PFCR4 ={v} _2;
  # DEBUG BEGIN_STMT
  _3 ={v} MEM[(struct PFLASH_Type *)1076264960B].PFCR4;
  MEM[(struct PFLASH_Type *)1076264960B].PFCR4 ={v} _3;
  return;

}



;; Function C40_Ip_Init (C40_Ip_Init, funcdef_no=0, decl_uid=5830, cgraph_uid=1, symbol_order=12)

Modification phase of node C40_Ip_Init/12
C40_Ip_Init (const struct C40_ConfigType * InitConfig)
{
  C40_Ip_StatusType ReturnCode;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG ReturnCode => 10212
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  C40_Ip_DataErrorSuppression ();
  # DEBUG BEGIN_STMT
  C40_Ip_Block4PipeSelect ();
  # DEBUG BEGIN_STMT
  ReturnCode_5 = C40_Ip_InitMainInterface ();
  # DEBUG ReturnCode => ReturnCode_5
  # DEBUG BEGIN_STMT
  C40_Ip_pConfigPtr = InitConfig_6(D);
  # DEBUG BEGIN_STMT
  return ReturnCode_5;

}



;; Function C40_Ip_Abort (C40_Ip_Abort, funcdef_no=3, decl_uid=5832, cgraph_uid=4, symbol_order=15)

Modification phase of node C40_Ip_Abort/15
C40_Ip_Abort ()
{
  C40_Ip_StatusType ReturnCode;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG ReturnCode => 10212
  # DEBUG BEGIN_STMT
  ReturnCode_3 = C40_Ip_MainInterfaceAbort ();
  # DEBUG ReturnCode => ReturnCode_3
  # DEBUG BEGIN_STMT
  return ReturnCode_3;

}



;; Function C40_Ip_Read (C40_Ip_Read, funcdef_no=12, decl_uid=5836, cgraph_uid=13, symbol_order=24)

Modification phase of node C40_Ip_Read/24
C40_Ip_Read (uint32 LogicalAddress, uint32 Length, uint8 * DestAddressPtr)
{
  C40_Ip_StatusType Status;
  C40_Ip_StatusType Status;
  uint32 ReadSize;
  uint32 SizeLeft;
  uint8 * DesAddressPtr;
  uint32 ReadAddress;
  C40_Ip_StatusType _25;

  <bb 2> [local count: 337833909]:
  # DEBUG BEGIN_STMT
  # DEBUG ReadAddress => LogicalAddress_7(D)
  # DEBUG BEGIN_STMT
  # DEBUG DesAddressPtr => DestAddressPtr_8(D)
  # DEBUG BEGIN_STMT
  # DEBUG SizeLeft => Length_9(D)
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG Length => Length_9(D)
  # DEBUG DestAddressPtr => DestAddressPtr_8(D)
  # DEBUG INLINE_ENTRY C40_Ip_ReadCheckInputParams
  # DEBUG BEGIN_STMT
  # DEBUG Status => 11700
  # DEBUG BEGIN_STMT
  if (DestAddressPtr_8(D) == 0B)
    goto <bb 5>; [30.00%]
  else
    goto <bb 3>; [70.00%]

  <bb 3> [local count: 236483737]:
  # DEBUG BEGIN_STMT
  if (Length_9(D) == 0)
    goto <bb 5>; [50.00%]
  else
    goto <bb 4>; [50.00%]

  <bb 4> [local count: 118241869]:
  # DEBUG BEGIN_STMT
  # DEBUG Status => 23205

  <bb 5> [local count: 337833909]:
  # Status_11 = PHI <11700(2), 11700(3), 23205(4)>
  # DEBUG Status => Status_11
  # DEBUG BEGIN_STMT
  # DEBUG Length => NULL
  # DEBUG DestAddressPtr => NULL
  # DEBUG Status => NULL
  C40_Ip_eReadStatus = Status_11;
  # DEBUG BEGIN_STMT
  if (Status_11 == 23205)
    goto <bb 6>; [34.00%]
  else
    goto <bb 11>; [66.00%]

  <bb 6> [local count: 114863530]:
  # DEBUG BEGIN_STMT
  C40_Ip_eReadStatus = 59202;

  <bb 7> [local count: 1073741824]:
  # ReadAddress_1 = PHI <LogicalAddress_7(D)(6), ReadAddress_21(12)>
  # DesAddressPtr_2 = PHI <DestAddressPtr_8(D)(6), DesAddressPtr_22(12)>
  # SizeLeft_3 = PHI <Length_9(D)(6), SizeLeft_23(12)>
  # DEBUG ReadSize => NULL
  # DEBUG SizeLeft => SizeLeft_3
  # DEBUG DesAddressPtr => DesAddressPtr_2
  # DEBUG ReadAddress => ReadAddress_1
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG ReadAddress => ReadAddress_1
  # DEBUG INLINE_ENTRY C40_Ip_ClearPreviousRead
  # DEBUG BEGIN_STMT
  # DEBUG Status => 23205
  # DEBUG BEGIN_STMT
  C40_Ip_ClearAllErrorFlagsMainInterface ();
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG ReadAddress => NULL
  # DEBUG Status => 23205
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  C40_Ip_FlashAccessCalloutStart ();
  # DEBUG BEGIN_STMT
  ReadSize_17 = C40_Ip_ReadData (ReadAddress_1, DesAddressPtr_2, SizeLeft_3);
  # DEBUG ReadSize => ReadSize_17
  # DEBUG BEGIN_STMT
  C40_Ip_FlashAccessCalloutFinish ();
  # DEBUG BEGIN_STMT
  Status_20 = C40_Ip_CheckReadCompareStatus (ReadAddress_1, 1);
  # DEBUG Status => Status_20
  # DEBUG ReadSize => ReadSize_17
  # DEBUG BEGIN_STMT
  if (Status_20 != 23205)
    goto <bb 9>; [5.50%]
  else
    goto <bb 8>; [94.50%]

  <bb 8> [local count: 1014686025]:
  # DEBUG BEGIN_STMT
  ReadAddress_21 = ReadAddress_1 + ReadSize_17;
  # DEBUG ReadAddress => ReadAddress_21
  # DEBUG BEGIN_STMT
  DesAddressPtr_22 = DesAddressPtr_2 + ReadSize_17;
  # DEBUG DesAddressPtr => DesAddressPtr_22
  # DEBUG BEGIN_STMT
  SizeLeft_23 = SizeLeft_3 - ReadSize_17;
  # DEBUG SizeLeft => SizeLeft_23
  # DEBUG BEGIN_STMT
  if (SizeLeft_23 != 0)
    goto <bb 12>; [94.50%]
  else
    goto <bb 9>; [5.50%]

  <bb 12> [local count: 958878294]:
  goto <bb 7>; [100.00%]

  <bb 9> [local count: 114863531]:
  # SizeLeft_4 = PHI <SizeLeft_3(7), SizeLeft_23(8)>
  # DEBUG SizeLeft => SizeLeft_4
  # DEBUG BEGIN_STMT
  if (SizeLeft_4 == 0)
    goto <bb 10>; [50.00%]
  else
    goto <bb 11>; [50.00%]

  <bb 10> [local count: 57431766]:
  # DEBUG BEGIN_STMT
  C40_Ip_eReadStatus = 23205;

  <bb 11> [local count: 337833910]:
  # DEBUG BEGIN_STMT
  _25 = C40_Ip_eReadStatus;
  return _25;

}



;; Function C40_Ip_SetLockProtect (C40_Ip_SetLockProtect, funcdef_no=14, decl_uid=5982, cgraph_uid=15, symbol_order=26)

Modification phase of node C40_Ip_SetLockProtect/26
C40_Ip_SetLockProtect (C40_Ip_VirtualSectorsType VirtualSector)
{
  uint32 SectorPosition;
  uint32 BlockCount;
  uint32 SectorIndex;
  long unsigned int _1;
  long unsigned int C40_Ip_u32BitPosition.19_2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int C40_Ip_u32BitPosition.21_5;
  long unsigned int _6;
  long unsigned int _8;
  long unsigned int C40_Ip_u32BitPosition.22_9;
  long unsigned int _11;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  if (VirtualSector_12(D) <= 15)
    goto <bb 3>; [50.00%]
  else
    goto <bb 4>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  _1 ={v} MEM[(struct PFLASH_Type *)1076264960B].PFCBLK_SPELOCK[2];
  C40_Ip_u32BitPosition.19_2 = C40_Ip_u32BitPosition;
  _3 = _1 | C40_Ip_u32BitPosition.19_2;
  MEM[(struct PFLASH_Type *)1076264960B].PFCBLK_SPELOCK[2] ={v} _3;
  goto <bb 9>; [100.00%]

  <bb 4> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  if (VirtualSector_12(D) == 272)
    goto <bb 5>; [34.00%]
  else
    goto <bb 6>; [66.00%]

  <bb 5> [local count: 182536112]:
  # DEBUG D#4 => VirtualSector_12(D)
  C40_Ip_SetLockProtect.part.0 ();
  goto <bb 9>; [100.00%]

  <bb 6> [local count: 354334800]:
  # DEBUG BEGIN_STMT
  SectorIndex_13 = VirtualSector_12(D) + 4294967280;
  # DEBUG SectorIndex => SectorIndex_13
  # DEBUG BEGIN_STMT
  BlockCount_14 = SectorIndex_13 >> 7;
  # DEBUG BlockCount => BlockCount_14
  # DEBUG BEGIN_STMT
  SectorPosition_15 = SectorIndex_13 & 127;
  # DEBUG SectorPosition => SectorPosition_15
  # DEBUG BEGIN_STMT
  if (SectorPosition_15 <= 95)
    goto <bb 7>; [50.00%]
  else
    goto <bb 8>; [50.00%]

  <bb 7> [local count: 177167400]:
  # DEBUG BEGIN_STMT
  _4 ={v} MEM[(struct PFLASH_Type *)1076264960B].PFCBLK_SSPELOCK[BlockCount_14];
  C40_Ip_u32BitPosition.21_5 = C40_Ip_u32BitPosition;
  _6 = _4 | C40_Ip_u32BitPosition.21_5;
  MEM[(struct PFLASH_Type *)1076264960B].PFCBLK_SSPELOCK[BlockCount_14] ={v} _6;
  goto <bb 9>; [100.00%]

  <bb 8> [local count: 177167400]:
  # DEBUG BEGIN_STMT
  _8 ={v} MEM[(struct PFLASH_Type *)1076264960B].PFCBLK_SPELOCK[BlockCount_14];
  C40_Ip_u32BitPosition.22_9 = C40_Ip_u32BitPosition;
  _11 = _8 | C40_Ip_u32BitPosition.22_9;
  MEM[(struct PFLASH_Type *)1076264960B].PFCBLK_SPELOCK[BlockCount_14] ={v} _11;

  <bb 9> [local count: 1073741824]:
  return;

}



;; Function C40_Ip_GetLockProtect (C40_Ip_GetLockProtect, funcdef_no=16, decl_uid=5980, cgraph_uid=17, symbol_order=28)

Modification phase of node C40_Ip_GetLockProtect/28
C40_Ip_GetLockProtect (C40_Ip_VirtualSectorsType VirtualSector)
{
  uint32 CheckRegister;
  uint32 SectorPosition;
  uint32 BlockCount;
  uint32 SectorIndex;
  long unsigned int _1;
  long unsigned int _2;
  uint32 _16;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _1 = C40_Ip_GetSectorID (VirtualSector_5(D));
  C40_Ip_u32SectorId = _1;
  # DEBUG BEGIN_STMT
  _2 = 1 << _1;
  C40_Ip_u32BitPosition = _2;
  # DEBUG BEGIN_STMT
  if (VirtualSector_5(D) <= 15)
    goto <bb 3>; [50.00%]
  else
    goto <bb 4>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  CheckRegister_15 ={v} MEM[(struct PFLASH_Type *)1076264960B].PFCBLK_SPELOCK[2];
  # DEBUG CheckRegister => CheckRegister_15
  goto <bb 9>; [100.00%]

  <bb 4> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  if (VirtualSector_5(D) == 272)
    goto <bb 5>; [34.00%]
  else
    goto <bb 6>; [66.00%]

  <bb 5> [local count: 182536112]:
  # DEBUG BEGIN_STMT
  CheckRegister_14 ={v} MEM[(struct PFLASH_Type *)1076264960B].PFCBLKU_SPELOCK[0];
  # DEBUG CheckRegister => CheckRegister_14
  goto <bb 9>; [100.00%]

  <bb 6> [local count: 354334800]:
  # DEBUG BEGIN_STMT
  SectorIndex_9 = VirtualSector_5(D) + 4294967280;
  # DEBUG SectorIndex => SectorIndex_9
  # DEBUG BEGIN_STMT
  BlockCount_10 = SectorIndex_9 >> 7;
  # DEBUG BlockCount => BlockCount_10
  # DEBUG BEGIN_STMT
  SectorPosition_11 = SectorIndex_9 & 127;
  # DEBUG SectorPosition => SectorPosition_11
  # DEBUG BEGIN_STMT
  if (SectorPosition_11 <= 95)
    goto <bb 7>; [50.00%]
  else
    goto <bb 8>; [50.00%]

  <bb 7> [local count: 177167400]:
  # DEBUG BEGIN_STMT
  CheckRegister_13 ={v} MEM[(struct PFLASH_Type *)1076264960B].PFCBLK_SSPELOCK[BlockCount_10];
  # DEBUG CheckRegister => CheckRegister_13
  goto <bb 9>; [100.00%]

  <bb 8> [local count: 177167400]:
  # DEBUG BEGIN_STMT
  CheckRegister_12 ={v} MEM[(struct PFLASH_Type *)1076264960B].PFCBLK_SPELOCK[BlockCount_10];
  # DEBUG CheckRegister => CheckRegister_12

  <bb 9> [local count: 1073741824]:
  # CheckRegister_3 = PHI <CheckRegister_15(3), CheckRegister_14(5), CheckRegister_13(7), CheckRegister_12(8)>
  # DEBUG CheckRegister => CheckRegister_3
  # DEBUG BEGIN_STMT
  _16 = _2 & CheckRegister_3;
  return _16;

}



;; Function C40_Ip_GetLock (C40_Ip_GetLock, funcdef_no=15, decl_uid=5845, cgraph_uid=16, symbol_order=27)

Modification phase of node C40_Ip_GetLock/27
C40_Ip_GetLock (C40_Ip_VirtualSectorsType VirtualSector)
{
  C40_Ip_StatusType ReturnCode;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  if (VirtualSector_2(D) > 272)
    goto <bb 4>; [67.00%]
  else
    goto <bb 3>; [33.00%]

  <bb 3> [local count: 354334800]:
  ReturnCode_6 = C40_Ip_GetLock.part.0 (VirtualSector_2(D));

  <bb 4> [local count: 1073741824]:
  # ReturnCode_1 = PHI <10212(2), ReturnCode_6(3)>
  # DEBUG ReturnCode => ReturnCode_1
  # DEBUG BEGIN_STMT
  return ReturnCode_1;

}



;; Function C40_Ip_ClearLockProtect (C40_Ip_ClearLockProtect, funcdef_no=18, decl_uid=5984, cgraph_uid=19, symbol_order=30)

Modification phase of node C40_Ip_ClearLockProtect/30
C40_Ip_ClearLockProtect (C40_Ip_VirtualSectorsType VirtualSector)
{
  long unsigned int _1;
  long unsigned int C40_Ip_u32BitPosition.25_2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int C40_Ip_u32BitPosition.26_6;
  long unsigned int _7;
  long unsigned int _8;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  if (VirtualSector_11(D) <= 15)
    goto <bb 3>; [50.00%]
  else
    goto <bb 4>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  _1 ={v} MEM[(struct PFLASH_Type *)1076264960B].PFCBLK_SPELOCK[2];
  C40_Ip_u32BitPosition.25_2 = C40_Ip_u32BitPosition;
  _3 = ~C40_Ip_u32BitPosition.25_2;
  _4 = _1 & _3;
  MEM[(struct PFLASH_Type *)1076264960B].PFCBLK_SPELOCK[2] ={v} _4;
  goto <bb 7>; [100.00%]

  <bb 4> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  if (VirtualSector_11(D) == 272)
    goto <bb 5>; [34.00%]
  else
    goto <bb 6>; [66.00%]

  <bb 5> [local count: 182536112]:
  # DEBUG BEGIN_STMT
  _5 ={v} MEM[(struct PFLASH_Type *)1076264960B].PFCBLKU_SPELOCK[0];
  C40_Ip_u32BitPosition.26_6 = C40_Ip_u32BitPosition;
  _7 = ~C40_Ip_u32BitPosition.26_6;
  _8 = _5 & _7;
  MEM[(struct PFLASH_Type *)1076264960B].PFCBLKU_SPELOCK[0] ={v} _8;
  goto <bb 7>; [100.00%]

  <bb 6> [local count: 354334801]:
  C40_Ip_ClearLockProtect.part.0 (VirtualSector_11(D));

  <bb 7> [local count: 1073741824]:
  return;

}



;; Function C40_Ip_Compare (C40_Ip_Compare, funcdef_no=19, decl_uid=5840, cgraph_uid=20, symbol_order=31)

Modification phase of node C40_Ip_Compare/31
C40_Ip_Compare (uint32 LogicalAddress, uint32 Length, const uint8 * SourceAddressPtr)
{
  C40_Ip_StatusType _10;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  if (Length_4(D) == 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 4>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  C40_Ip_eReadStatus = 11700;
  goto <bb 7>; [100.00%]

  <bb 4> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  C40_Ip_eReadStatus = 59202;
  # DEBUG BEGIN_STMT
  if (SourceAddressPtr_6(D) != 0B)
    goto <bb 5>; [70.00%]
  else
    goto <bb 6>; [30.00%]

  <bb 5> [local count: 375809640]:
  # DEBUG BEGIN_STMT
  C40_Ip_ProgramVerify (LogicalAddress_3(D), SourceAddressPtr_6(D), Length_4(D));
  goto <bb 7>; [100.00%]

  <bb 6> [local count: 161061272]:
  # DEBUG BEGIN_STMT
  C40_Ip_EraseVerify (LogicalAddress_3(D), Length_4(D));

  <bb 7> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _10 = C40_Ip_eReadStatus;
  return _10;

}



;; Function C40_Ip_MainInterfaceWriteLogicalAddress (C40_Ip_MainInterfaceWriteLogicalAddress, funcdef_no=24, decl_uid=5974, cgraph_uid=25, symbol_order=36)

Modification phase of node C40_Ip_MainInterfaceWriteLogicalAddress/36
C40_Ip_MainInterfaceWriteLogicalAddress (uint32 Address)
{
  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  MEM[(struct PFLASH_Type *)1076264960B].PFCPGM_PEADR_L ={v} Address_2(D);
  return;

}



;; Function C40_Ip_MainInterfaceSectorErase (C40_Ip_MainInterfaceSectorErase, funcdef_no=30, decl_uid=5855, cgraph_uid=31, symbol_order=42)

Modification phase of node C40_Ip_MainInterfaceSectorErase/42
C40_Ip_MainInterfaceSectorErase (C40_Ip_VirtualSectorsType VirtualSector, uint8 DomainIdValue)
{
  uint32 LogicalAddress;
  C40_Ip_StatusType ReturnCode;
  long unsigned int _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;
  _Bool C40_Ip_bAsync.31_7;
  long unsigned int _8;
  long unsigned int _9;

  <bb 2> [local count: 1073741823]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  C40_Ip_u32ElapsedTicks = 0;
  # DEBUG BEGIN_STMT
  _1 = OsIf_MicrosToTicks (2147483647, 0);
  C40_Ip_u32TimeoutTicks = _1;
  # DEBUG BEGIN_STMT
  _2 = OsIf_GetCounter (0);
  C40_Ip_u32CurrentTicks = _2;
  # DEBUG BEGIN_STMT
  ReturnCode_21 = C40_Ip_MainInterfaceSectorErasePreCheck (VirtualSector_19(D));
  # DEBUG ReturnCode => ReturnCode_21
  # DEBUG BEGIN_STMT
  if (ReturnCode_21 == 23205)
    goto <bb 3>; [20.24%]
  else
    goto <bb 5>; [79.76%]

  <bb 3> [local count: 217325344]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  C40_Ip_ClearAllErrorFlagsMainInterface ();
  # DEBUG BEGIN_STMT
  LogicalAddress_24 = C40_Ip_GetBaseAddressOfSector (VirtualSector_19(D));
  # DEBUG LogicalAddress => LogicalAddress_24
  # DEBUG BEGIN_STMT
  ReturnCode_27 = C40_Ip_MainInterfaceWriteJobAddress (LogicalAddress_24, DomainIdValue_25(D));
  # DEBUG ReturnCode => ReturnCode_27
  # DEBUG BEGIN_STMT
  if (ReturnCode_27 == 11220)
    goto <bb 4>; [12.02%]
  else
    goto <bb 5>; [87.98%]

  <bb 4> [local count: 26122506]:
  # DEBUG BEGIN_STMT
  C40_Ip_ClearInterlockWrite ();

  <bb 5> [local count: 1073741824]:
  # ReturnCode_10 = PHI <ReturnCode_21(2), ReturnCode_27(3), 11220(4)>
  # DEBUG ReturnCode => ReturnCode_10
  # DEBUG BEGIN_STMT
  if (ReturnCode_10 == 23205)
    goto <bb 6>; [34.00%]
  else
    goto <bb 8>; [66.00%]

  <bb 6> [local count: 365072224]:
  # DEBUG BEGIN_STMT
  MEM[(struct FLASH_Type *)1076805632B].DATA[0] ={v} 4294967295;
  # DEBUG BEGIN_STMT
  _3 ={v} MEM[(struct FLASH_Type *)1076805632B].MCR;
  _4 = _3 | 16;
  MEM[(struct FLASH_Type *)1076805632B].MCR ={v} _4;
  # DEBUG BEGIN_STMT
  _5 ={v} MEM[(struct FLASH_Type *)1076805632B].MCR;
  _6 = _5 & 4294967263;
  MEM[(struct FLASH_Type *)1076805632B].MCR ={v} _6;
  # DEBUG BEGIN_STMT
  C40_Ip_bAsync.31_7 = C40_Ip_bAsync;
  if (C40_Ip_bAsync.31_7 != 0)
    goto <bb 7>; [33.00%]
  else
    goto <bb 8>; [67.00%]

  <bb 7> [local count: 120473833]:
  # DEBUG BEGIN_STMT
  C40_Ip_FlashAccessCalloutStart ();
  # DEBUG BEGIN_STMT
  _8 ={v} MEM[(struct FLASH_Type *)1076805632B].MCR;
  _9 = _8 | 1;
  MEM[(struct FLASH_Type *)1076805632B].MCR ={v} _9;

  <bb 8> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  return ReturnCode_10;

}



;; Function C40_Ip_MainInterfaceSectorEraseStatus (C40_Ip_MainInterfaceSectorEraseStatus, funcdef_no=31, decl_uid=5857, cgraph_uid=32, symbol_order=43)

Modification phase of node C40_Ip_MainInterfaceSectorEraseStatus/43
C40_Ip_MainInterfaceSectorEraseStatus ()
{
  C40_Ip_StatusType ReturnCode;
  long unsigned int _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  ReturnCode_8 = C40_Ip_MainInterfaceHVJobStatus ();
  # DEBUG ReturnCode => ReturnCode_8
  # DEBUG BEGIN_STMT
  if (ReturnCode_8 != 59202)
    goto <bb 3>; [66.00%]
  else
    goto <bb 4>; [34.00%]

  <bb 3> [local count: 708669601]:
  # DEBUG BEGIN_STMT
  _1 ={v} MEM[(struct FLASH_Type *)1076805632B].MCR;
  _2 = _1 & 4294967294;
  MEM[(struct FLASH_Type *)1076805632B].MCR ={v} _2;
  # DEBUG BEGIN_STMT
  _3 ={v} MEM[(struct FLASH_Type *)1076805632B].MCR;
  _4 = _3 & 4294967279;
  MEM[(struct FLASH_Type *)1076805632B].MCR ={v} _4;

  <bb 4> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  return ReturnCode_8;

}



;; Function C40_Ip_MainInterfaceWriteStatus (C40_Ip_MainInterfaceWriteStatus, funcdef_no=36, decl_uid=5864, cgraph_uid=37, symbol_order=48)

Modification phase of node C40_Ip_MainInterfaceWriteStatus/48
C40_Ip_MainInterfaceWriteStatus ()
{
  C40_Ip_StatusType ReturnCode;
  long unsigned int _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  ReturnCode_8 = C40_Ip_MainInterfaceHVJobStatus ();
  # DEBUG ReturnCode => ReturnCode_8
  # DEBUG BEGIN_STMT
  if (ReturnCode_8 != 59202)
    goto <bb 3>; [66.00%]
  else
    goto <bb 4>; [34.00%]

  <bb 3> [local count: 708669601]:
  # DEBUG BEGIN_STMT
  _1 ={v} MEM[(struct FLASH_Type *)1076805632B].MCR;
  _2 = _1 & 4294967294;
  MEM[(struct FLASH_Type *)1076805632B].MCR ={v} _2;
  # DEBUG BEGIN_STMT
  _3 ={v} MEM[(struct FLASH_Type *)1076805632B].MCR;
  _4 = _3 & 4294967039;
  MEM[(struct FLASH_Type *)1076805632B].MCR ={v} _4;

  <bb 4> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  return ReturnCode_8;

}



;; Function C40_Ip_CheckLockDomainID_CheckRegister (C40_Ip_CheckLockDomainID_CheckRegister, funcdef_no=41, decl_uid=5945, cgraph_uid=42, symbol_order=53)

Modification phase of node C40_Ip_CheckLockDomainID_CheckRegister/53
C40_Ip_CheckLockDomainID_CheckRegister (C40_Ip_VirtualSectorsType VirtualSector, uint32 * CheckRegister, uint32 * TempLockMasterRegister)
{
  uint32 SectorStep;
  uint32 DomainStep;
  uint32 SectorPosition;
  uint32 BlockCount;
  uint32 SectorIndex;
  long unsigned int C40_Ip_u32SectorId.48_1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;
  long unsigned int _7;
  long unsigned int _8;
  long unsigned int _9;
  long unsigned int _10;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  C40_Ip_u32SectorId.48_1 = C40_Ip_u32SectorId;
  SectorStep_13 = C40_Ip_u32SectorId.48_1 & 4294967292;
  # DEBUG SectorStep => SectorStep_13
  # DEBUG BEGIN_STMT
  if (VirtualSector_14(D) <= 15)
    goto <bb 3>; [50.00%]
  else
    goto <bb 4>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  _2 ={v} MEM[(struct PFLASH_Type *)1076264960B].PFCBLK_SETSLOCK[2];
  *CheckRegister_18(D) = _2;
  # DEBUG BEGIN_STMT
  _3 = SectorStep_13 + 1076265984;
  *TempLockMasterRegister_21(D) = _3;
  goto <bb 9>; [100.00%]

  <bb 4> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  if (VirtualSector_14(D) == 272)
    goto <bb 5>; [34.00%]
  else
    goto <bb 6>; [66.00%]

  <bb 5> [local count: 182536112]:
  # DEBUG BEGIN_STMT
  _4 ={v} MEM[(struct PFLASH_Type *)1076264960B].PFCBLKU_SETSLOCK[0];
  *CheckRegister_18(D) = _4;
  # DEBUG BEGIN_STMT
  *TempLockMasterRegister_21(D) = 1076266112;
  goto <bb 9>; [100.00%]

  <bb 6> [local count: 354334800]:
  # DEBUG BEGIN_STMT
  SectorIndex_15 = VirtualSector_14(D) + 4294967280;
  # DEBUG SectorIndex => SectorIndex_15
  # DEBUG BEGIN_STMT
  BlockCount_16 = SectorIndex_15 >> 7;
  # DEBUG BlockCount => BlockCount_16
  # DEBUG BEGIN_STMT
  SectorPosition_17 = SectorIndex_15 & 127;
  # DEBUG SectorPosition => SectorPosition_17
  # DEBUG BEGIN_STMT
  if (SectorPosition_17 <= 95)
    goto <bb 7>; [50.00%]
  else
    goto <bb 8>; [50.00%]

  <bb 7> [local count: 177167400]:
  # DEBUG BEGIN_STMT
  _5 ={v} MEM[(struct PFLASH_Type *)1076264960B].PFCBLK_SSETSLOCK[BlockCount_16];
  *CheckRegister_18(D) = _5;
  # DEBUG BEGIN_STMT
  DomainStep_24 = BlockCount_16 << 4;
  # DEBUG DomainStep => DomainStep_24
  # DEBUG BEGIN_STMT
  _6 = SectorStep_13 + DomainStep_24;
  _7 = _6 + 1076266116;
  *TempLockMasterRegister_21(D) = _7;
  goto <bb 9>; [100.00%]

  <bb 8> [local count: 177167400]:
  # DEBUG BEGIN_STMT
  _8 ={v} MEM[(struct PFLASH_Type *)1076264960B].PFCBLK_SETSLOCK[BlockCount_16];
  *CheckRegister_18(D) = _8;
  # DEBUG BEGIN_STMT
  DomainStep_20 = BlockCount_16 << 5;
  # DEBUG DomainStep => DomainStep_20
  # DEBUG BEGIN_STMT
  _9 = SectorStep_13 + DomainStep_20;
  _10 = _9 + 1076265920;
  *TempLockMasterRegister_21(D) = _10;

  <bb 9> [local count: 1073741824]:
  return;

}



;; Function C40_Ip_CheckLockDomainID (C40_Ip_CheckLockDomainID, funcdef_no=39, decl_uid=5941, cgraph_uid=40, symbol_order=51)

Modification phase of node C40_Ip_CheckLockDomainID/51
C40_Ip_CheckLockDomainID (C40_Ip_VirtualSectorsType VirtualSector, uint8 DomainIdValue)
{
  uint32 CheckRegister;
  uint32 ShiftValue;
  uint32 TempLockMasterRegister;
  uint8 LockDomainIDValue;
  C40_Ip_StatusType ReturnCode;
  long unsigned int C40_Ip_u32SectorId.13_1;
  long unsigned int _2;
  long unsigned int CheckRegister.14_3;
  long unsigned int C40_Ip_u32BitPosition.15_4;
  long unsigned int _5;
  long unsigned int TempLockMasterRegister.16_6;
  volatile uint32 * TempLockMasterRegister.18_7;
  long unsigned int _8;
  long unsigned int _9;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG ReturnCode => 23205
  # DEBUG BEGIN_STMT
  # DEBUG LockDomainIDValue => 0
  # DEBUG BEGIN_STMT
  TempLockMasterRegister = 0;
  # DEBUG BEGIN_STMT
  # DEBUG ShiftValue => 0
  # DEBUG BEGIN_STMT
  CheckRegister = 0;
  # DEBUG BEGIN_STMT
  if (VirtualSector_16(D) != 272)
    goto <bb 3>; [66.00%]
  else
    goto <bb 4>; [34.00%]

  <bb 3> [local count: 708669601]:
  # DEBUG BEGIN_STMT
  C40_Ip_u32SectorId.13_1 = C40_Ip_u32SectorId;
  _2 = C40_Ip_u32SectorId.13_1 & 3;
  ShiftValue_17 = _2 * 8;
  # DEBUG ShiftValue => ShiftValue_17

  <bb 4> [local count: 1073741824]:
  # ShiftValue_11 = PHI <0(2), ShiftValue_17(3)>
  # DEBUG ShiftValue => ShiftValue_11
  # DEBUG BEGIN_STMT
  if (VirtualSector_16(D) <= 272)
    goto <bb 5>; [33.00%]
  else
    goto <bb 6>; [67.00%]

  <bb 5> [local count: 354334800]:
  # DEBUG BEGIN_STMT
  C40_Ip_CheckLockDomainID_CheckRegister (VirtualSector_16(D), &CheckRegister, &TempLockMasterRegister);

  <bb 6> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  CheckRegister.14_3 = CheckRegister;
  C40_Ip_u32BitPosition.15_4 = C40_Ip_u32BitPosition;
  _5 = CheckRegister.14_3 & C40_Ip_u32BitPosition.15_4;
  if (_5 != 0)
    goto <bb 7>; [50.00%]
  else
    goto <bb 10>; [50.00%]

  <bb 7> [local count: 536870913]:
  TempLockMasterRegister.16_6 = TempLockMasterRegister;
  if (TempLockMasterRegister.16_6 != 0)
    goto <bb 8>; [50.00%]
  else
    goto <bb 10>; [50.00%]

  <bb 8> [local count: 268435456]:
  # DEBUG BEGIN_STMT
  TempLockMasterRegister.18_7 = (volatile uint32 *) TempLockMasterRegister.16_6;
  _8 ={v} *TempLockMasterRegister.18_7;
  _9 = _8 >> ShiftValue_11;
  LockDomainIDValue_19 = (uint8) _9;
  # DEBUG LockDomainIDValue => LockDomainIDValue_19
  # DEBUG BEGIN_STMT
  if (LockDomainIDValue_19 != DomainIdValue_20(D))
    goto <bb 9>; [66.00%]
  else
    goto <bb 10>; [34.00%]

  <bb 9> [local count: 177167400]:
  # DEBUG BEGIN_STMT
  # DEBUG ReturnCode => 10212

  <bb 10> [local count: 1073741824]:
  # ReturnCode_10 = PHI <23205(6), 23205(7), 10212(9), 23205(8)>
  # DEBUG ReturnCode => ReturnCode_10
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  TempLockMasterRegister ={v} {CLOBBER};
  CheckRegister ={v} {CLOBBER};
  return ReturnCode_10;

}



;; Function C40_Ip_SetLock (C40_Ip_SetLock, funcdef_no=13, decl_uid=5843, cgraph_uid=14, symbol_order=25)

Modification phase of node C40_Ip_SetLock/25
C40_Ip_SetLock (C40_Ip_VirtualSectorsType VirtualSector, uint8 DomainIdValue)
{
  C40_Ip_StatusType ReturnCode;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  ReturnCode_6 = C40_Ip_GetLock (VirtualSector_4(D));
  # DEBUG ReturnCode => ReturnCode_6
  # DEBUG BEGIN_STMT
  if (ReturnCode_6 == 10212)
    goto <bb 6>; [34.00%]
  else
    goto <bb 3>; [66.00%]

  <bb 3> [local count: 708669601]:
  # DEBUG BEGIN_STMT
  if (ReturnCode_6 == 59576)
    goto <bb 6>; [36.03%]
  else
    goto <bb 4>; [63.97%]

  <bb 4> [local count: 453335945]:
  # DEBUG BEGIN_STMT
  ReturnCode_9 = C40_Ip_CheckLockDomainID (VirtualSector_4(D), DomainIdValue_7(D));
  # DEBUG ReturnCode => ReturnCode_9
  # DEBUG BEGIN_STMT
  if (ReturnCode_9 == 23205)
    goto <bb 5>; [12.02%]
  else
    goto <bb 6>; [87.98%]

  <bb 5> [local count: 54490981]:
  # DEBUG BEGIN_STMT
  C40_Ip_SetLockProtect (VirtualSector_4(D));

  <bb 6> [local count: 1073741824]:
  # ReturnCode_1 = PHI <ReturnCode_6(2), 23205(3), ReturnCode_9(4), 23205(5)>
  # DEBUG ReturnCode => ReturnCode_1
  # DEBUG BEGIN_STMT
  return ReturnCode_1;

}



;; Function C40_Ip_ClearLock (C40_Ip_ClearLock, funcdef_no=17, decl_uid=5848, cgraph_uid=18, symbol_order=29)

Modification phase of node C40_Ip_ClearLock/29
C40_Ip_ClearLock (C40_Ip_VirtualSectorsType VirtualSector, uint8 DomainIdValue)
{
  C40_Ip_StatusType ReturnCode;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  ReturnCode_6 = C40_Ip_GetLock (VirtualSector_4(D));
  # DEBUG ReturnCode => ReturnCode_6
  # DEBUG BEGIN_STMT
  if (ReturnCode_6 == 10212)
    goto <bb 6>; [34.00%]
  else
    goto <bb 3>; [66.00%]

  <bb 3> [local count: 708669601]:
  # DEBUG BEGIN_STMT
  if (ReturnCode_6 == 64034)
    goto <bb 6>; [36.03%]
  else
    goto <bb 4>; [63.97%]

  <bb 4> [local count: 453335945]:
  # DEBUG BEGIN_STMT
  ReturnCode_9 = C40_Ip_CheckLockDomainID (VirtualSector_4(D), DomainIdValue_7(D));
  # DEBUG ReturnCode => ReturnCode_9
  # DEBUG BEGIN_STMT
  if (ReturnCode_9 == 23205)
    goto <bb 5>; [12.02%]
  else
    goto <bb 6>; [87.98%]

  <bb 5> [local count: 54490981]:
  # DEBUG BEGIN_STMT
  C40_Ip_ClearLockProtect (VirtualSector_4(D));

  <bb 6> [local count: 1073741824]:
  # ReturnCode_1 = PHI <ReturnCode_6(2), 23205(3), ReturnCode_9(4), 23205(5)>
  # DEBUG ReturnCode => ReturnCode_1
  # DEBUG BEGIN_STMT
  return ReturnCode_1;

}



;; Function C40_Ip_GetSectorNumberFromAddress (C40_Ip_GetSectorNumberFromAddress, funcdef_no=42, decl_uid=5850, cgraph_uid=43, symbol_order=54)

Modification phase of node C40_Ip_GetSectorNumberFromAddress/54
C40_Ip_GetSectorNumberFromAddress (uint32 TargetAddress)
{
  C40_Ip_VirtualSectorsType VirtualSectors;
  long unsigned int _1;
  long unsigned int _2;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _1 = TargetAddress_6(D) + 3841982464;
  if (_1 <= 8191)
    goto <bb 6>; [35.00%]
  else
    goto <bb 3>; [65.00%]

  <bb 3> [local count: 697932185]:
  # DEBUG BEGIN_STMT
  _2 = TargetAddress_6(D) + 4026531840;
  if (_2 <= 131071)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 4> [local count: 348966092]:
  # DEBUG BEGIN_STMT
  VirtualSectors_7 = _2 >> 13;
  # DEBUG VirtualSectors => VirtualSectors_7
  goto <bb 6>; [100.00%]

  <bb 5> [local count: 348966093]:
  VirtualSectors_3 = C40_Ip_GetSectorNumberFromAddress.part.0 (TargetAddress_6(D));

  <bb 6> [local count: 1073741824]:
  # VirtualSectors_4 = PHI <272(2), VirtualSectors_7(4), VirtualSectors_3(5)>
  # DEBUG VirtualSectors => VirtualSectors_4
  # DEBUG BEGIN_STMT
  return VirtualSectors_4;

}



;; Function C40_Ip_MainInterfaceWrite (C40_Ip_MainInterfaceWrite, funcdef_no=35, decl_uid=5862, cgraph_uid=36, symbol_order=47)

Modification phase of node C40_Ip_MainInterfaceWrite/47
C40_Ip_MainInterfaceWrite (uint32 LogicalAddress, uint32 Length, const uint8 * SourceAddressPtr, uint8 DomainIdValue)
{
  uint32 LocationWriteDataRegs;
  C40_Ip_StatusType ReturnCode;
  long unsigned int _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  _Bool C40_Ip_bAsync.38_6;
  long unsigned int _7;
  long unsigned int _8;

  <bb 2> [local count: 1073741823]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  C40_Ip_u32LogicalAddressCheckFail = LogicalAddress_13(D);
  # DEBUG BEGIN_STMT
  C40_Ip_eOpStatus = 17;
  # DEBUG BEGIN_STMT
  C40_Ip_u32ElapsedTicks = 0;
  # DEBUG BEGIN_STMT
  _1 = OsIf_MicrosToTicks (2147483647, 0);
  C40_Ip_u32TimeoutTicks = _1;
  # DEBUG BEGIN_STMT
  _2 = OsIf_GetCounter (0);
  C40_Ip_u32CurrentTicks = _2;
  # DEBUG BEGIN_STMT
  ReturnCode_24 = C40_Ip_MainInterfaceWritePreCheck (LogicalAddress_13(D), Length_21(D), SourceAddressPtr_22(D));
  # DEBUG ReturnCode => ReturnCode_24
  # DEBUG BEGIN_STMT
  if (ReturnCode_24 == 23205)
    goto <bb 3>; [20.24%]
  else
    goto <bb 5>; [79.76%]

  <bb 3> [local count: 217325344]:
  # DEBUG BEGIN_STMT
  C40_Ip_ClearAllErrorFlagsMainInterface ();
  # DEBUG BEGIN_STMT
  ReturnCode_28 = C40_Ip_MainInterfaceWriteJobAddress (LogicalAddress_13(D), DomainIdValue_26(D));
  # DEBUG ReturnCode => ReturnCode_28
  # DEBUG BEGIN_STMT
  if (ReturnCode_28 == 11220)
    goto <bb 4>; [12.02%]
  else
    goto <bb 5>; [87.98%]

  <bb 4> [local count: 26122506]:
  # DEBUG BEGIN_STMT
  C40_Ip_ClearInterlockWrite ();

  <bb 5> [local count: 1073741824]:
  # ReturnCode_9 = PHI <ReturnCode_24(2), ReturnCode_28(3), 11220(4)>
  # DEBUG ReturnCode => ReturnCode_9
  # DEBUG BEGIN_STMT
  if (ReturnCode_9 == 23205)
    goto <bb 6>; [20.24%]
  else
    goto <bb 8>; [79.76%]

  <bb 6> [local count: 217325344]:
  # DEBUG BEGIN_STMT
  _3 = LogicalAddress_13(D) >> 2;
  LocationWriteDataRegs_30 = _3 & 31;
  # DEBUG LocationWriteDataRegs => LocationWriteDataRegs_30
  # DEBUG BEGIN_STMT
  C40_Ip_MainInterfaceFillDataBuff (LocationWriteDataRegs_30, SourceAddressPtr_22(D), Length_21(D));
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _4 ={v} MEM[(struct FLASH_Type *)1076805632B].MCR;
  _5 = _4 | 256;
  MEM[(struct FLASH_Type *)1076805632B].MCR ={v} _5;
  # DEBUG BEGIN_STMT
  C40_Ip_bAsync.38_6 = C40_Ip_bAsync;
  if (C40_Ip_bAsync.38_6 != 0)
    goto <bb 7>; [33.00%]
  else
    goto <bb 8>; [67.00%]

  <bb 7> [local count: 71717363]:
  # DEBUG BEGIN_STMT
  C40_Ip_FlashAccessCalloutStart ();
  # DEBUG BEGIN_STMT
  _7 ={v} MEM[(struct FLASH_Type *)1076805632B].MCR;
  _8 = _7 | 1;
  MEM[(struct FLASH_Type *)1076805632B].MCR ={v} _8;

  <bb 8> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  return ReturnCode_9;

}



;; Function C40_Ip_GetBlockNumberFromAddress (C40_Ip_GetBlockNumberFromAddress, funcdef_no=44, decl_uid=5852, cgraph_uid=45, symbol_order=56)

Modification phase of node C40_Ip_GetBlockNumberFromAddress/56
C40_Ip_GetBlockNumberFromAddress (uint32 TargetAddress)
{
  C40_Ip_FlashBlocksNumberType BlockNumber;
  long unsigned int _1;
  long unsigned int _2;
  long unsigned int _3;

  <bb 2> [local count: 1073741823]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _1 = TargetAddress_5(D) + 3841982464;
  if (_1 <= 8191)
    goto <bb 6>; [35.00%]
  else
    goto <bb 3>; [65.00%]

  <bb 3> [local count: 697932184]:
  # DEBUG BEGIN_STMT
  _2 = TargetAddress_5(D) + 4026531840;
  if (_2 <= 131071)
    goto <bb 6>; [35.00%]
  else
    goto <bb 4>; [65.00%]

  <bb 4> [local count: 453655918]:
  # DEBUG BEGIN_STMT
  _3 = TargetAddress_5(D) + 4290772992;
  if (_3 <= 2097151)
    goto <bb 5>; [65.00%]
  else
    goto <bb 6>; [35.00%]

  <bb 5> [local count: 294876346]:
  # DEBUG BEGIN_STMT
  BlockNumber_7 = C40_Ip_GetCodeBlockNumber (TargetAddress_5(D));
  # DEBUG BlockNumber => BlockNumber_7

  <bb 6> [local count: 1073741824]:
  # BlockNumber_4 = PHI <5(2), 4(3), BlockNumber_7(5), 255(4)>
  # DEBUG BlockNumber => BlockNumber_4
  # DEBUG BEGIN_STMT
  return BlockNumber_4;

}



;; Function C40_Ip_ArrayIntegrityCheck (C40_Ip_ArrayIntegrityCheck, funcdef_no=47, decl_uid=5873, cgraph_uid=48, symbol_order=59)

Modification phase of node C40_Ip_ArrayIntegrityCheck/59
C40_Ip_ArrayIntegrityCheck (uint32 SelectBlock, C40_Ip_ArrayIntegritySequenceType AddressSequence, C40_Ip_FlashBreakPointsType BreakPoints, const struct C40_Ip_MisrType * MisrSeedValues, uint8 DomainIdValue)
{
  uint32 WaitCounter;
  C40_Ip_StatusType ReturnCode;
  _Bool _1;
  long unsigned int _2;
  signed int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;
  long unsigned int _7;
  long unsigned int _8;
  long unsigned int _9;
  long unsigned int _10;
  long unsigned int _11;
  long unsigned int _12;
  long unsigned int _13;
  long unsigned int _14;
  long unsigned int _15;
  long unsigned int _16;
  long unsigned int _17;
  long unsigned int _18;
  long unsigned int _19;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG WaitCounter => 450
  # DEBUG BEGIN_STMT
  _1 = C40_Ip_CheckSelecBlock (SelectBlock_25(D));
  if (_1 != 0)
    goto <bb 3>; [47.77%]
  else
    goto <bb 15>; [52.23%]

  <bb 3> [local count: 512926472]:
  # DEBUG BEGIN_STMT
  ReturnCode_27 = C40_Ip_UTestCheckBusy ();
  # DEBUG ReturnCode => ReturnCode_27
  # DEBUG BEGIN_STMT
  if (ReturnCode_27 == 23205)
    goto <bb 4>; [34.00%]
  else
    goto <bb 15>; [66.00%]

  <bb 4> [local count: 174395002]:
  # DEBUG BEGIN_STMT
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} 4193884569;
  # DEBUG BEGIN_STMT
  _2 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _3 = (signed int) _2;
  if (_3 >= 0)
    goto <bb 15>; [61.14%]
  else
    goto <bb 5>; [38.86%]

  <bb 5> [local count: 67769898]:
  # DEBUG BEGIN_STMT
  C40_Ip_u32ElapsedTicks = 0;
  # DEBUG BEGIN_STMT
  _4 = OsIf_MicrosToTicks (2147483647, 0);
  C40_Ip_u32TimeoutTicks = _4;
  # DEBUG BEGIN_STMT
  _5 = OsIf_GetCounter (0);
  C40_Ip_u32CurrentTicks = _5;
  # DEBUG BEGIN_STMT
  ReturnCode_36 = C40_Ip_MainInterfaceWriteJobAddress (SelectBlock_25(D), DomainIdValue_34(D));
  # DEBUG ReturnCode => ReturnCode_36
  # DEBUG BEGIN_STMT
  if (ReturnCode_36 == 23205)
    goto <bb 6>; [21.72%]
  else
    goto <bb 10>; [78.28%]

  <bb 6> [local count: 14719622]:
  # DEBUG BEGIN_STMT
  MEM[(struct FLASH_Type *)1076805632B].DATA[0] ={v} 4294967295;
  # DEBUG BEGIN_STMT
  if (AddressSequence_43(D) == 1)
    goto <bb 7>; [34.00%]
  else
    goto <bb 8>; [66.00%]

  <bb 7> [local count: 5004672]:
  # DEBUG BEGIN_STMT
  _6 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _7 = _6 | 4;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _7;
  goto <bb 9>; [100.00%]

  <bb 8> [local count: 9714950]:
  # DEBUG BEGIN_STMT
  _8 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _9 = _8 & 4294967291;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _9;

  <bb 9> [local count: 14719622]:
  # DEBUG BEGIN_STMT
  C40_Ip_UTestCheckBreakpoint (BreakPoints_46(D));
  # DEBUG BEGIN_STMT
  C40_Ip_SetSeedMisr (MisrSeedValues_48(D));
  # DEBUG BEGIN_STMT
  _10 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _11 = _10 | 2;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _11;
  goto <bb 15>; [100.00%]

  <bb 10> [local count: 53050276]:
  # DEBUG BEGIN_STMT
  MEM[(struct FLASH_Type *)1076805632B].DATA[0] ={v} 4294967295;
  # DEBUG BEGIN_STMT
  _12 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _13 = _12 | 2;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _13;
  # DEBUG BEGIN_STMT
  _14 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _15 = _14 & 4294967293;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _15;
  # DEBUG BEGIN_STMT
  goto <bb 12>; [100.00%]

  <bb 11> [local count: 770072730]:
  # DEBUG BEGIN_STMT
  WaitCounter_40 = WaitCounter_21 + 4294967295;
  # DEBUG WaitCounter => WaitCounter_40

  <bb 12> [local count: 823123006]:
  # WaitCounter_21 = PHI <450(10), WaitCounter_40(11)>
  # DEBUG WaitCounter => WaitCounter_21
  # DEBUG BEGIN_STMT
  _16 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _17 = _16 & 1;
  if (_17 == 0)
    goto <bb 13>; [94.50%]
  else
    goto <bb 14>; [5.50%]

  <bb 13> [local count: 777851241]:
  if (WaitCounter_21 != 0)
    goto <bb 11>; [99.00%]
  else
    goto <bb 14>; [1.00%]

  <bb 14> [local count: 53050276]:
  # DEBUG BEGIN_STMT
  _18 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _19 = _18 & 2147483647;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _19;

  <bb 15> [local count: 1073741824]:
  # ReturnCode_20 = PHI <ReturnCode_27(3), 10212(4), 23205(9), ReturnCode_36(14), 11700(2)>
  # DEBUG ReturnCode => ReturnCode_20
  # DEBUG BEGIN_STMT
  return ReturnCode_20;

}



;; Function C40_Ip_CheckUserTestStatus (C40_Ip_CheckUserTestStatus, funcdef_no=49, decl_uid=5867, cgraph_uid=50, symbol_order=61)

Modification phase of node C40_Ip_CheckUserTestStatus/61
C40_Ip_CheckUserTestStatus (const struct C40_Ip_MisrType * MisrExpectedValues, C40_Ip_UtestStateType * TestResult)
{
  C40_Ip_StatusType ReturnCode;
  long unsigned int _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741823]:
  # DEBUG BEGIN_STMT
  # DEBUG ReturnCode => 23205
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  if (MisrExpectedValues_9(D) == 0B)
    goto <bb 9>; [18.75%]
  else
    goto <bb 3>; [81.25%]

  <bb 3> [local count: 872415231]:
  if (TestResult_10(D) == 0B)
    goto <bb 9>; [18.75%]
  else
    goto <bb 4>; [81.25%]

  <bb 4> [local count: 708837376]:
  # DEBUG BEGIN_STMT
  *TestResult_10(D) = 0;
  # DEBUG BEGIN_STMT
  _1 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _2 = _1 & 2;
  if (_2 != 0)
    goto <bb 5>; [65.00%]
  else
    goto <bb 9>; [35.00%]

  <bb 5> [local count: 460744293]:
  # DEBUG BEGIN_STMT
  _3 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _4 = _3 & 1;
  if (_4 != 0)
    goto <bb 6>; [65.00%]
  else
    goto <bb 9>; [35.00%]

  <bb 6> [local count: 299483790]:
  # DEBUG BEGIN_STMT
  _5 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _6 = _5 & 64;
  if (_6 != 0)
    goto <bb 7>; [52.23%]
  else
    goto <bb 8>; [47.77%]

  <bb 7> [local count: 156420383]:
  # DEBUG BEGIN_STMT
  *TestResult_10(D) = 23;
  goto <bb 9>; [100.00%]

  <bb 8> [local count: 143063407]:
  # DEBUG BEGIN_STMT
  ReturnCode_14 = C40_Ip_CheckUserTestStatusExecution (MisrExpectedValues_9(D), TestResult_10(D));
  # DEBUG ReturnCode => ReturnCode_14

  <bb 9> [local count: 1073741824]:
  # ReturnCode_7 = PHI <11700(3), 59202(5), 11220(4), ReturnCode_14(8), 23205(7), 11700(2)>
  # DEBUG ReturnCode => ReturnCode_7
  # DEBUG BEGIN_STMT
  return ReturnCode_7;

}



;; Function C40_Ip_ArrayIntegrityCheckSuspend (C40_Ip_ArrayIntegrityCheckSuspend, funcdef_no=51, decl_uid=5875, cgraph_uid=52, symbol_order=63)

Modification phase of node C40_Ip_ArrayIntegrityCheckSuspend/63
C40_Ip_ArrayIntegrityCheckSuspend ()
{
  uint32 WaitCounter;
  C40_Ip_StatusType ReturnCode;
  long unsigned int _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;
  long unsigned int _7;
  long unsigned int _8;
  long unsigned int _9;
  long unsigned int _10;
  long unsigned int _11;
  long unsigned int _12;

  <bb 2> [local count: 276810632]:
  # DEBUG BEGIN_STMT
  # DEBUG ReturnCode => 23205
  # DEBUG BEGIN_STMT
  # DEBUG WaitCounter => 450
  # DEBUG BEGIN_STMT
  _1 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _2 = _1 & 2;
  if (_2 != 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 11>; [50.00%]

  <bb 3> [local count: 138405316]:
  _3 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _4 = _3 & 65;
  if (_4 == 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 11>; [50.00%]

  <bb 4> [local count: 69202658]:
  # DEBUG BEGIN_STMT
  _5 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _6 = _5 | 64;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _6;
  # DEBUG BEGIN_STMT
  goto <bb 6>; [100.00%]

  <bb 5> [local count: 1004539167]:
  # DEBUG BEGIN_STMT
  WaitCounter_18 = WaitCounter_14 + 4294967295;
  # DEBUG WaitCounter => WaitCounter_18

  <bb 6> [local count: 1073741824]:
  # WaitCounter_14 = PHI <450(4), WaitCounter_18(5)>
  # DEBUG WaitCounter => WaitCounter_14
  # DEBUG BEGIN_STMT
  _7 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _8 = _7 & 1;
  if (_8 == 0)
    goto <bb 7>; [94.50%]
  else
    goto <bb 8>; [5.50%]

  <bb 7> [local count: 1014686026]:
  if (WaitCounter_14 != 0)
    goto <bb 5>; [99.00%]
  else
    goto <bb 8>; [1.00%]

  <bb 8> [local count: 69202658]:
  # DEBUG BEGIN_STMT
  _9 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _10 = _9 & 64;
  if (_10 == 0)
    goto <bb 10>; [50.00%]
  else
    goto <bb 9>; [50.00%]

  <bb 9> [local count: 34601329]:
  _11 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _12 = _11 & 1;
  if (_12 == 0)
    goto <bb 10>; [50.00%]
  else
    goto <bb 11>; [50.00%]

  <bb 10> [local count: 51901994]:
  # DEBUG BEGIN_STMT
  # DEBUG ReturnCode => 10212

  <bb 11> [local count: 276810633]:
  # ReturnCode_13 = PHI <10212(10), 10212(3), 23205(9), 10212(2)>
  # DEBUG ReturnCode => ReturnCode_13
  # DEBUG BEGIN_STMT
  return ReturnCode_13;

}



;; Function C40_Ip_ArrayIntegrityCheckResume (C40_Ip_ArrayIntegrityCheckResume, funcdef_no=54, decl_uid=5877, cgraph_uid=55, symbol_order=66)

Modification phase of node C40_Ip_ArrayIntegrityCheckResume/66
C40_Ip_ArrayIntegrityCheckResume ()
{
  C40_Ip_StatusType ReturnCode;
  long unsigned int _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG ReturnCode => 23205
  # DEBUG BEGIN_STMT
  _1 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _2 = _1 & 2;
  if (_2 != 0)
    goto <bb 3>; [65.00%]
  else
    goto <bb 7>; [35.00%]

  <bb 3> [local count: 697932185]:
  # DEBUG BEGIN_STMT
  _3 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _4 = _3 & 65;
  if (_4 == 65)
    goto <bb 4>; [20.24%]
  else
    goto <bb 5>; [79.76%]

  <bb 4> [local count: 141261473]:
  # DEBUG BEGIN_STMT
  ReturnCode_13 = C40_Ip_ArrayIntegrityResumeSuppened ();
  # DEBUG ReturnCode => ReturnCode_13
  goto <bb 7>; [100.00%]

  <bb 5> [local count: 556670712]:
  # DEBUG BEGIN_STMT
  _5 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _6 = _5 & 512;
  if (_6 != 0)
    goto <bb 6>; [47.77%]
  else
    goto <bb 7>; [52.23%]

  <bb 6> [local count: 265921600]:
  # DEBUG BEGIN_STMT
  ReturnCode_11 = C40_Ip_ArrayIntegrityResumeBroken ();
  # DEBUG ReturnCode => ReturnCode_11

  <bb 7> [local count: 1073741824]:
  # ReturnCode_7 = PHI <23205(5), 10212(2), ReturnCode_13(4), ReturnCode_11(6)>
  # DEBUG ReturnCode => ReturnCode_7
  # DEBUG BEGIN_STMT
  return ReturnCode_7;

}



;; Function C40_Ip_UserMarginReadCheck (C40_Ip_UserMarginReadCheck, funcdef_no=55, decl_uid=5883, cgraph_uid=56, symbol_order=67)

Modification phase of node C40_Ip_UserMarginReadCheck/67
C40_Ip_UserMarginReadCheck (uint32 SelectBlock, C40_Ip_FlashBreakPointsType BreakPoints, C40_Ip_MarginOptionType MarginLevel, const struct C40_Ip_MisrType * MisrSeedValues, uint8 DomainIdValue)
{
  uint32 WaitCounter;
  C40_Ip_StatusType ReturnCode;
  _Bool _1;
  long unsigned int _2;
  signed int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;
  long unsigned int _7;
  long unsigned int _8;
  long unsigned int _9;
  long unsigned int _10;
  long unsigned int _11;
  long unsigned int _12;
  long unsigned int _13;
  long unsigned int _14;
  long unsigned int _15;
  long unsigned int _16;
  long unsigned int _17;
  long unsigned int _18;
  long unsigned int _19;
  long unsigned int _20;
  long unsigned int _21;
  long unsigned int _22;
  long unsigned int _23;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG ReturnCode => 23205
  # DEBUG BEGIN_STMT
  # DEBUG WaitCounter => 450
  # DEBUG BEGIN_STMT
  _1 = C40_Ip_CheckSelecBlock (SelectBlock_29(D));
  if (_1 != 0)
    goto <bb 3>; [47.77%]
  else
    goto <bb 15>; [52.23%]

  <bb 3> [local count: 512926472]:
  # DEBUG BEGIN_STMT
  ReturnCode_31 = C40_Ip_UTestCheckBusy ();
  # DEBUG ReturnCode => ReturnCode_31
  # DEBUG BEGIN_STMT
  if (ReturnCode_31 == 23205)
    goto <bb 4>; [34.00%]
  else
    goto <bb 15>; [66.00%]

  <bb 4> [local count: 174395002]:
  # DEBUG BEGIN_STMT
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} 4193884569;
  # DEBUG BEGIN_STMT
  _2 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _3 = (signed int) _2;
  if (_3 >= 0)
    goto <bb 15>; [61.14%]
  else
    goto <bb 5>; [38.86%]

  <bb 5> [local count: 67769898]:
  # DEBUG BEGIN_STMT
  C40_Ip_u32ElapsedTicks = 0;
  # DEBUG BEGIN_STMT
  _4 = OsIf_MicrosToTicks (2147483647, 0);
  C40_Ip_u32TimeoutTicks = _4;
  # DEBUG BEGIN_STMT
  _5 = OsIf_GetCounter (0);
  C40_Ip_u32CurrentTicks = _5;
  # DEBUG BEGIN_STMT
  ReturnCode_40 = C40_Ip_MainInterfaceWriteJobAddress (SelectBlock_29(D), DomainIdValue_38(D));
  # DEBUG ReturnCode => ReturnCode_40
  # DEBUG BEGIN_STMT
  if (ReturnCode_40 == 23205)
    goto <bb 6>; [12.02%]
  else
    goto <bb 10>; [87.98%]

  <bb 6> [local count: 8145942]:
  # DEBUG BEGIN_STMT
  MEM[(struct FLASH_Type *)1076805632B].DATA[0] ={v} 4294967295;
  # DEBUG BEGIN_STMT
  _6 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _7 = _6 | 4;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _7;
  # DEBUG BEGIN_STMT
  C40_Ip_UTestCheckBreakpoint (BreakPoints_48(D));
  # DEBUG BEGIN_STMT
  _8 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _9 = _8 | 32;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _9;
  # DEBUG BEGIN_STMT
  if (MarginLevel_51(D) == 1)
    goto <bb 7>; [34.00%]
  else
    goto <bb 8>; [66.00%]

  <bb 7> [local count: 2769620]:
  # DEBUG BEGIN_STMT
  _10 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _11 = _10 | 16;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _11;
  goto <bb 9>; [100.00%]

  <bb 8> [local count: 5376322]:
  # DEBUG BEGIN_STMT
  _12 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _13 = _12 & 4294967279;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _13;

  <bb 9> [local count: 8145942]:
  # DEBUG BEGIN_STMT
  C40_Ip_SetSeedMisr (MisrSeedValues_54(D));
  # DEBUG BEGIN_STMT
  _14 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _15 = _14 | 2;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _15;
  goto <bb 15>; [100.00%]

  <bb 10> [local count: 59623956]:
  # DEBUG BEGIN_STMT
  MEM[(struct FLASH_Type *)1076805632B].DATA[0] ={v} 4294967295;
  # DEBUG BEGIN_STMT
  _16 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _17 = _16 | 2;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _17;
  # DEBUG BEGIN_STMT
  _18 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _19 = _18 & 4294967293;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _19;
  # DEBUG BEGIN_STMT
  goto <bb 12>; [100.00%]

  <bb 11> [local count: 865495645]:
  # DEBUG BEGIN_STMT
  WaitCounter_44 = WaitCounter_25 + 4294967295;
  # DEBUG WaitCounter => WaitCounter_44

  <bb 12> [local count: 925119601]:
  # WaitCounter_25 = PHI <450(10), WaitCounter_44(11)>
  # DEBUG WaitCounter => WaitCounter_25
  # DEBUG BEGIN_STMT
  _20 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _21 = _20 & 1;
  if (_21 == 0)
    goto <bb 13>; [94.50%]
  else
    goto <bb 14>; [5.50%]

  <bb 13> [local count: 874238023]:
  if (WaitCounter_25 != 0)
    goto <bb 11>; [99.00%]
  else
    goto <bb 14>; [1.00%]

  <bb 14> [local count: 59623956]:
  # DEBUG BEGIN_STMT
  _22 ={v} MEM[(struct FLASH_Type *)1076805632B].UT0;
  _23 = _22 & 2147483647;
  MEM[(struct FLASH_Type *)1076805632B].UT0 ={v} _23;

  <bb 15> [local count: 1073741824]:
  # ReturnCode_24 = PHI <ReturnCode_31(3), 10212(4), 23205(9), ReturnCode_40(14), 11700(2)>
  # DEBUG ReturnCode => ReturnCode_24
  # DEBUG BEGIN_STMT
  return ReturnCode_24;

}



;; Function C40_Ip_GetFailedAddress (C40_Ip_GetFailedAddress, funcdef_no=56, decl_uid=5885, cgraph_uid=57, symbol_order=68)

Modification phase of node C40_Ip_GetFailedAddress/68
C40_Ip_GetFailedAddress ()
{
  uint32 TempADR;
  uint32 Temp;
  uint32 AddrOffset;
  uint32 CheckRegionBlockError;
  uint32 Addr;
  long unsigned int _1;
  <unnamed type> C40_Ip_eOpStatus.54_2;
  long unsigned int C40_Ip_u32LogicalAddressCheckFail.55_3;
  long unsigned int _4;

  <bb 2> [local count: 1073741809]:
  # DEBUG BEGIN_STMT
  # DEBUG Addr => 4294967295
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  TempADR_8 ={v} MEM[(struct FLASH_Type *)1076805632B].ADR;
  # DEBUG TempADR => TempADR_8
  # DEBUG BEGIN_STMT
  _1 = TempADR_8 >> 1;
  AddrOffset_9 = _1 & 262143;
  # DEBUG AddrOffset => AddrOffset_9
  # DEBUG BEGIN_STMT
  C40_Ip_eOpStatus.54_2 = C40_Ip_eOpStatus;
  if (C40_Ip_eOpStatus.54_2 == 17)
    goto <bb 3>; [34.00%]
  else
    goto <bb 4>; [66.00%]

  <bb 3> [local count: 365072219]:
  # DEBUG BEGIN_STMT
  C40_Ip_u32LogicalAddressCheckFail.55_3 = C40_Ip_u32LogicalAddressCheckFail;
  Temp_11 = C40_Ip_u32LogicalAddressCheckFail.55_3 & 127;
  # DEBUG Temp => Temp_11
  # DEBUG BEGIN_STMT
  _4 = AddrOffset_9 << 3;
  AddrOffset_12 = _4 + Temp_11;
  # DEBUG AddrOffset => AddrOffset_12
  goto <bb 5>; [100.00%]

  <bb 4> [local count: 708669590]:
  # DEBUG BEGIN_STMT
  AddrOffset_10 = AddrOffset_9 << 3;
  # DEBUG AddrOffset => AddrOffset_10

  <bb 5> [local count: 1073741809]:
  # AddrOffset_6 = PHI <AddrOffset_12(3), AddrOffset_10(4)>
  # DEBUG AddrOffset => AddrOffset_6
  # DEBUG BEGIN_STMT
  CheckRegionBlockError_13 = TempADR_8 & 20447232;
  # DEBUG CheckRegionBlockError => CheckRegionBlockError_13
  # DEBUG BEGIN_STMT
  switch (CheckRegionBlockError_13) <default: <L10> [20.00%], case 524288: <L3> [20.00%], case 1048576: <L4> [20.00%], case 2097152: <L5> [20.00%], case 16777216: <L6> [20.00%]>

  <bb 6> [local count: 214748365]:
<L3>:
  # DEBUG BEGIN_STMT
  Addr_17 = AddrOffset_6 + 4194304;
  # DEBUG Addr => Addr_17
  # DEBUG BEGIN_STMT
  goto <bb 10>; [100.00%]

  <bb 7> [local count: 214748365]:
<L4>:
  # DEBUG BEGIN_STMT
  Addr_16 = AddrOffset_6 + 5242880;
  # DEBUG Addr => Addr_16
  # DEBUG BEGIN_STMT
  goto <bb 10>; [100.00%]

  <bb 8> [local count: 214748365]:
<L5>:
  # DEBUG BEGIN_STMT
  Addr_15 = AddrOffset_6 + 268435456;
  # DEBUG Addr => Addr_15
  # DEBUG BEGIN_STMT
  goto <bb 10>; [100.00%]

  <bb 9> [local count: 214748365]:
<L6>:
  # DEBUG BEGIN_STMT
  Addr_14 = AddrOffset_6 + 452984832;
  # DEBUG Addr => Addr_14
  # DEBUG BEGIN_STMT

  <bb 10> [local count: 1073741824]:
  # Addr_5 = PHI <Addr_17(6), Addr_16(7), Addr_15(8), Addr_14(9), 4294967295(5)>
<L10>:
  # DEBUG Addr => Addr_5
  # DEBUG BEGIN_STMT
  return Addr_5;

}



;; Function C40_Ip_SetAsyncMode (C40_Ip_SetAsyncMode, funcdef_no=57, decl_uid=5887, cgraph_uid=58, symbol_order=69)

Modification phase of node C40_Ip_SetAsyncMode/69
C40_Ip_SetAsyncMode (const boolean Async)
{
  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  C40_Ip_bAsync = Async_2(D);
  return;

}


