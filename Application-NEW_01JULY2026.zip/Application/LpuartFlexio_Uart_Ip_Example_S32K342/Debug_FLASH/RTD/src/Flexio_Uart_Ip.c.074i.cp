
IPA constant propagation start:
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_41(D), 4, TimerDecrement_36, 2);
  Starting walk at: Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_41(D), 4, TimerDecrement_36, 2);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:DevAssert (_13);
  Function call may change dynamic type:DevAssert (_5);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:DevAssert (_26);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_41(D), 1, 2);
  Starting walk at: Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_41(D), 1, 2);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_41(D), 4, TimerDecrement_36, 2);
  Function call may change dynamic type:DevAssert (_13);
  Function call may change dynamic type:DevAssert (_5);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:DevAssert (_26);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerCondition (1077035008B, Channel_41(D), 4, 2);
  Starting walk at: Flexio_Uart_Ip_SetTimerCondition (1077035008B, Channel_41(D), 4, 2);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_41(D), 1, 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_41(D), 4, TimerDecrement_36, 2);
  Function call may change dynamic type:DevAssert (_13);
  Function call may change dynamic type:DevAssert (_5);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:DevAssert (_26);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_41(D), 0, TimerDecrement_36, 0);
  Starting walk at: Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_41(D), 0, TimerDecrement_36, 0);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:DevAssert (_13);
  Function call may change dynamic type:DevAssert (_5);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:DevAssert (_26);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_41(D), 1, 2);
  Starting walk at: Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_41(D), 1, 2);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_41(D), 0, TimerDecrement_36, 0);
  Function call may change dynamic type:DevAssert (_13);
  Function call may change dynamic type:DevAssert (_5);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:DevAssert (_26);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerCondition (1077035008B, Channel_41(D), 2, 2);
  Starting walk at: Flexio_Uart_Ip_SetTimerCondition (1077035008B, Channel_41(D), 2, 2);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_41(D), 1, 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_41(D), 0, TimerDecrement_36, 0);
  Function call may change dynamic type:DevAssert (_13);
  Function call may change dynamic type:DevAssert (_5);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:DevAssert (_26);
Determining dynamic type for call: Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_52(D), 0);
  Starting walk at: Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_52(D), 0);
  instance pointer: &StartTime  Outer instance pointer: StartTime offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetupReceiveData (Channel_32(D));
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_07 ();
  Function call may change dynamic type:DevAssert (_10);
  Function call may change dynamic type:DevAssert (_7);
  Function call may change dynamic type:DevAssert (_5);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
Determining dynamic type for call: Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_52(D), 0);
  Starting walk at: Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_52(D), 0);
  instance pointer: &TimeoutTicks  Outer instance pointer: TimeoutTicks offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetupReceiveData (Channel_32(D));
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_07 ();
  Function call may change dynamic type:DevAssert (_10);
  Function call may change dynamic type:DevAssert (_7);
  Function call may change dynamic type:DevAssert (_5);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
Determining dynamic type for call: _19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.16_18, 0);
  Starting walk at: _19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.16_18, 0);
  instance pointer: &StartTime  Outer instance pointer: StartTime offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_52(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetupReceiveData (Channel_32(D));
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_07 ();
  Function call may change dynamic type:DevAssert (_10);
  Function call may change dynamic type:DevAssert (_7);
  Function call may change dynamic type:DevAssert (_5);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:Flexio_Uart_Ip_ReadData (Channel_32(D));
  Function call may change dynamic type:Flexio_Uart_Ip_CheckShifterErrorStatus (Channel_32(D));
  Function call may change dynamic type:_12 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_32(D));
  Function call may change dynamic type:_19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.16_18, 0);
  Function call may change dynamic type:_15 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.15_14, 0);
Determining dynamic type for call: _19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.16_18, 0);
  Starting walk at: _19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.16_18, 0);
  instance pointer: &ElapsedTicks  Outer instance pointer: ElapsedTicks offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_52(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetupReceiveData (Channel_32(D));
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_07 ();
  Function call may change dynamic type:DevAssert (_10);
  Function call may change dynamic type:DevAssert (_7);
  Function call may change dynamic type:DevAssert (_5);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:Flexio_Uart_Ip_ReadData (Channel_32(D));
  Function call may change dynamic type:Flexio_Uart_Ip_CheckShifterErrorStatus (Channel_32(D));
  Function call may change dynamic type:_12 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_32(D));
  Function call may change dynamic type:_19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.16_18, 0);
  Function call may change dynamic type:_15 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.15_14, 0);
Determining dynamic type for call: _15 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.15_14, 0);
  Starting walk at: _15 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.15_14, 0);
  instance pointer: &StartTime  Outer instance pointer: StartTime offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:_12 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_32(D));
  Function call may change dynamic type:_19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.16_18, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_52(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetupReceiveData (Channel_32(D));
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_07 ();
  Function call may change dynamic type:DevAssert (_10);
  Function call may change dynamic type:DevAssert (_7);
  Function call may change dynamic type:DevAssert (_5);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:Flexio_Uart_Ip_ReadData (Channel_32(D));
  Function call may change dynamic type:Flexio_Uart_Ip_CheckShifterErrorStatus (Channel_32(D));
  Function call may change dynamic type:_12 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_32(D));
  Function call may change dynamic type:_15 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.15_14, 0);
Determining dynamic type for call: _15 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.15_14, 0);
  Starting walk at: _15 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.15_14, 0);
  instance pointer: &ElapsedTicks  Outer instance pointer: ElapsedTicks offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:_12 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_32(D));
  Function call may change dynamic type:_19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.16_18, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_52(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetupReceiveData (Channel_32(D));
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_07 ();
  Function call may change dynamic type:DevAssert (_10);
  Function call may change dynamic type:DevAssert (_7);
  Function call may change dynamic type:DevAssert (_5);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:Flexio_Uart_Ip_ReadData (Channel_32(D));
  Function call may change dynamic type:Flexio_Uart_Ip_CheckShifterErrorStatus (Channel_32(D));
  Function call may change dynamic type:_12 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_32(D));
  Function call may change dynamic type:_15 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.15_14, 0);
Determining dynamic type for call: _23 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.17_22, 0);
  Starting walk at: _23 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.17_22, 0);
  instance pointer: &StartTime  Outer instance pointer: StartTime offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_CheckShifterErrorStatus (Channel_32(D));
  Function call may change dynamic type:_12 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_32(D));
  Function call may change dynamic type:_19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.16_18, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_52(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetupReceiveData (Channel_32(D));
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_07 ();
  Function call may change dynamic type:DevAssert (_10);
  Function call may change dynamic type:DevAssert (_7);
  Function call may change dynamic type:DevAssert (_5);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:Flexio_Uart_Ip_ReadData (Channel_32(D));
  Function call may change dynamic type:_15 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.15_14, 0);
Determining dynamic type for call: _23 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.17_22, 0);
  Starting walk at: _23 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.17_22, 0);
  instance pointer: &ElapsedTicks  Outer instance pointer: ElapsedTicks offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_CheckShifterErrorStatus (Channel_32(D));
  Function call may change dynamic type:_12 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_32(D));
  Function call may change dynamic type:_19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.16_18, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_52(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetupReceiveData (Channel_32(D));
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_07 ();
  Function call may change dynamic type:DevAssert (_10);
  Function call may change dynamic type:DevAssert (_7);
  Function call may change dynamic type:DevAssert (_5);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:Flexio_Uart_Ip_ReadData (Channel_32(D));
  Function call may change dynamic type:_15 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.15_14, 0);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_33(D), 1);
  Starting walk at: Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_33(D), 1);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterInterrupt (Channel_33(D), 0);
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:DevAssert (_11);
  Function call may change dynamic type:DevAssert (_8);
  Function call may change dynamic type:DevAssert (_6);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
Determining dynamic type for call: Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_55(D), 0);
  Starting walk at: Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_55(D), 0);
  instance pointer: &StartTime  Outer instance pointer: StartTime offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_33(D), 1);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterInterrupt (Channel_33(D), 0);
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:DevAssert (_11);
  Function call may change dynamic type:DevAssert (_8);
  Function call may change dynamic type:DevAssert (_6);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
Determining dynamic type for call: Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_55(D), 0);
  Starting walk at: Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_55(D), 0);
  instance pointer: &TimeoutTicks  Outer instance pointer: TimeoutTicks offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_33(D), 1);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterInterrupt (Channel_33(D), 0);
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:DevAssert (_11);
  Function call may change dynamic type:DevAssert (_8);
  Function call may change dynamic type:DevAssert (_6);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
Determining dynamic type for call: _19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.11_18, 0);
  Starting walk at: _19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.11_18, 0);
  instance pointer: &StartTime  Outer instance pointer: StartTime offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_55(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_33(D), 1);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterInterrupt (Channel_33(D), 0);
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:DevAssert (_11);
  Function call may change dynamic type:DevAssert (_8);
  Function call may change dynamic type:DevAssert (_6);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:_16 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.10_15, 0);
  Function call may change dynamic type:_13 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_33(D));
  Function call may change dynamic type:Flexio_Uart_Ip_WriteData (Channel_33(D));
  Function call may change dynamic type:_19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.11_18, 0);
Determining dynamic type for call: _19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.11_18, 0);
  Starting walk at: _19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.11_18, 0);
  instance pointer: &ElapsedTicks  Outer instance pointer: ElapsedTicks offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_55(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_33(D), 1);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterInterrupt (Channel_33(D), 0);
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:DevAssert (_11);
  Function call may change dynamic type:DevAssert (_8);
  Function call may change dynamic type:DevAssert (_6);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:_16 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.10_15, 0);
  Function call may change dynamic type:_13 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_33(D));
  Function call may change dynamic type:Flexio_Uart_Ip_WriteData (Channel_33(D));
  Function call may change dynamic type:_19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.11_18, 0);
Determining dynamic type for call: _16 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.10_15, 0);
  Starting walk at: _16 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.10_15, 0);
  instance pointer: &StartTime  Outer instance pointer: StartTime offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:_13 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_33(D));
  Function call may change dynamic type:Flexio_Uart_Ip_WriteData (Channel_33(D));
  Function call may change dynamic type:_19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.11_18, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_55(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_33(D), 1);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterInterrupt (Channel_33(D), 0);
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:DevAssert (_11);
  Function call may change dynamic type:DevAssert (_8);
  Function call may change dynamic type:DevAssert (_6);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:_16 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.10_15, 0);
  Function call may change dynamic type:_13 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_33(D));
Determining dynamic type for call: _16 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.10_15, 0);
  Starting walk at: _16 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.10_15, 0);
  instance pointer: &ElapsedTicks  Outer instance pointer: ElapsedTicks offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:_13 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_33(D));
  Function call may change dynamic type:Flexio_Uart_Ip_WriteData (Channel_33(D));
  Function call may change dynamic type:_19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.11_18, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_55(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_33(D), 1);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterInterrupt (Channel_33(D), 0);
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:DevAssert (_11);
  Function call may change dynamic type:DevAssert (_8);
  Function call may change dynamic type:DevAssert (_6);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:_16 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.10_15, 0);
  Function call may change dynamic type:_13 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_33(D));
Determining dynamic type for call: _22 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.12_21, 0);
  Starting walk at: _22 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.12_21, 0);
  instance pointer: &StartTime  Outer instance pointer: StartTime offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_55(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_33(D), 1);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterInterrupt (Channel_33(D), 0);
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:DevAssert (_11);
  Function call may change dynamic type:DevAssert (_8);
  Function call may change dynamic type:DevAssert (_6);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:_16 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.10_15, 0);
  Function call may change dynamic type:_13 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_33(D));
  Function call may change dynamic type:Flexio_Uart_Ip_WriteData (Channel_33(D));
  Function call may change dynamic type:_19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.11_18, 0);
Determining dynamic type for call: _22 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.12_21, 0);
  Starting walk at: _22 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.12_21, 0);
  instance pointer: &ElapsedTicks  Outer instance pointer: ElapsedTicks offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_55(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_33(D), 1);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterInterrupt (Channel_33(D), 0);
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_05 ();
  Function call may change dynamic type:DevAssert (_11);
  Function call may change dynamic type:DevAssert (_8);
  Function call may change dynamic type:DevAssert (_6);
  Function call may change dynamic type:DevAssert (_3);
  Function call may change dynamic type:DevAssert (_2);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:_16 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.10_15, 0);
  Function call may change dynamic type:_13 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_33(D));
  Function call may change dynamic type:Flexio_Uart_Ip_WriteData (Channel_33(D));
  Function call may change dynamic type:_19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.11_18, 0);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_18(D), 1);
  Starting walk at: Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_18(D), 1);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:SchM_Exit_Uart_UART_EXCLUSIVE_AREA_04 ();
  Function call may change dynamic type:SchM_Enter_Uart_UART_EXCLUSIVE_AREA_04 ();
  Function call may change dynamic type:DevAssert (_11);
  Function call may change dynamic type:DevAssert (_8);
  Function call may change dynamic type:DevAssert (_6);
  Function call may change dynamic type:DevAssert (_5);
  Function call may change dynamic type:DevAssert (_4);
  Function call may change dynamic type:DevAssert (_1);
Determining dynamic type for call: Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Starting walk at: Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  instance pointer: &StartTime  Outer instance pointer: StartTime offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:DevAssert (_4);
  Function call may change dynamic type:DevAssert (_1);
Determining dynamic type for call: Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Starting walk at: Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  instance pointer: &TimeoutTicks  Outer instance pointer: TimeoutTicks offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:DevAssert (_4);
  Function call may change dynamic type:DevAssert (_1);
Determining dynamic type for call: _5 = Flexio_Uart_Ip_GetStatus (Channel_14(D), 0B);
  Starting walk at: _5 = Flexio_Uart_Ip_GetStatus (Channel_14(D), 0B);
  instance pointer: 0B  Outer instance pointer: 0B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Function call may change dynamic type:DevAssert (_4);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:_7 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.4_6, 0);
  Function call may change dynamic type:_5 = Flexio_Uart_Ip_GetStatus (Channel_14(D), 0B);
Determining dynamic type for call: _7 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.4_6, 0);
  Starting walk at: _7 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.4_6, 0);
  instance pointer: &StartTime  Outer instance pointer: StartTime offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:_5 = Flexio_Uart_Ip_GetStatus (Channel_14(D), 0B);
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Function call may change dynamic type:DevAssert (_4);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:_7 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.4_6, 0);
  Function call may change dynamic type:_5 = Flexio_Uart_Ip_GetStatus (Channel_14(D), 0B);
Determining dynamic type for call: _7 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.4_6, 0);
  Starting walk at: _7 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.4_6, 0);
  instance pointer: &ElapsedTicks  Outer instance pointer: ElapsedTicks offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:_5 = Flexio_Uart_Ip_GetStatus (Channel_14(D), 0B);
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Function call may change dynamic type:DevAssert (_4);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:_7 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.4_6, 0);
  Function call may change dynamic type:_5 = Flexio_Uart_Ip_GetStatus (Channel_14(D), 0B);
Determining dynamic type for call: _9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.5_8, 0);
  Starting walk at: _9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.5_8, 0);
  instance pointer: &StartTime  Outer instance pointer: StartTime offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:_5 = Flexio_Uart_Ip_GetStatus (Channel_14(D), 0B);
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Function call may change dynamic type:DevAssert (_4);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:_7 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.4_6, 0);
Determining dynamic type for call: _9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.5_8, 0);
  Starting walk at: _9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.5_8, 0);
  instance pointer: &ElapsedTicks  Outer instance pointer: ElapsedTicks offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:_5 = Flexio_Uart_Ip_GetStatus (Channel_14(D), 0B);
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Function call may change dynamic type:DevAssert (_4);
  Function call may change dynamic type:DevAssert (_1);
  Function call may change dynamic type:_7 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.4_6, 0);
Determining dynamic type for call: Flexio_Uart_Ip_SetShifterMode (1077035008B, Channel_2(D), 1);
  Starting walk at: Flexio_Uart_Ip_SetShifterMode (1077035008B, Channel_2(D), 1);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Mcl_Ip_ClearShifterStatus (1077035008B, Channel_2(D));
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_2(D), 1);
  Starting walk at: Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_2(D), 1);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterMode (1077035008B, Channel_2(D), 1);
  Function call may change dynamic type:Flexio_Mcl_Ip_ClearShifterStatus (1077035008B, Channel_2(D));
Determining dynamic type for call: _9 (Channel_18(D), 0, _10);
  Starting walk at: _9 (Channel_18(D), 0, _10);
  instance pointer: _10  Outer instance pointer: _10 offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_ReadData (Channel_18(D));
Determining dynamic type for call: _4 (Channel_18(D), 3, _5);
  Starting walk at: _4 (Channel_18(D), 3, _5);
  instance pointer: _5  Outer instance pointer: _5 offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: _13 (Channel_18(D), 2, _14);
  Starting walk at: _13 (Channel_18(D), 2, _14);
  instance pointer: _14  Outer instance pointer: _14 offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_StopTransfer (Channel_18(D));
  Function call may change dynamic type:Flexio_Mcl_Ip_ClearShifterStatus (1077035008B, Channel_18(D));
  Function call may change dynamic type:Flexio_Uart_Ip_ReadData (Channel_18(D));
  Function call may change dynamic type:Flexio_Mcl_Ip_ClearShifterErrorStatus (1077035008B, Channel_18(D));
  Function call may change dynamic type:_4 (Channel_18(D), 3, _5);
  Function call may change dynamic type:Flexio_Mcl_Ip_ClearShifterStatus (1077035008B, Channel_18(D));
  Function call may change dynamic type:_9 (Channel_18(D), 0, _10);
Determining dynamic type for call: _3 (Channel_11(D), 1, _4);
  Starting walk at: _3 (Channel_11(D), 1, _4);
  instance pointer: _4  Outer instance pointer: _4 offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: Flexio_Uart_Ip_SetShifterStartBit (1077035008B, Channel_16(D), 3);
  Starting walk at: Flexio_Uart_Ip_SetShifterStartBit (1077035008B, Channel_16(D), 3);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:_10 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_16(D));
Determining dynamic type for call: _8 (Channel_16(D), 2, _9);
  Starting walk at: _8 (Channel_16(D), 2, _9);
  instance pointer: _9  Outer instance pointer: _9 offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_StopTransfer (Channel_16(D));
  Function call may change dynamic type:Flexio_Mcl_Ip_ClearShifterStatus (1077035008B, Channel_16(D));
Determining dynamic type for call: Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Starting walk at: Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  instance pointer: &StartTime  Outer instance pointer: StartTime offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_EndTransfer (Channel_20(D));
Determining dynamic type for call: Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Starting walk at: Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  instance pointer: &TimeoutTicks  Outer instance pointer: TimeoutTicks offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_EndTransfer (Channel_20(D));
Determining dynamic type for call: _9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.1_8, 0);
  Starting walk at: _9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.1_8, 0);
  instance pointer: &StartTime  Outer instance pointer: StartTime offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:_7 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_EndTransfer (Channel_20(D));
  Function call may change dynamic type:_9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.1_8, 0);
  Function call may change dynamic type:_7 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
Determining dynamic type for call: _9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.1_8, 0);
  Starting walk at: _9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.1_8, 0);
  instance pointer: &ElapsedTicks  Outer instance pointer: ElapsedTicks offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:_7 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_EndTransfer (Channel_20(D));
  Function call may change dynamic type:_9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.1_8, 0);
  Function call may change dynamic type:_7 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
Determining dynamic type for call: _6 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.0_5, 0);
  Starting walk at: _6 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.0_5, 0);
  instance pointer: &StartTime  Outer instance pointer: StartTime offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:_4 = Flexio_Mcl_Ip_GetTimerStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_EndTransfer (Channel_20(D));
  Function call may change dynamic type:_6 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.0_5, 0);
  Function call may change dynamic type:_4 = Flexio_Mcl_Ip_GetTimerStatus (1077035008B, Channel_20(D));
Determining dynamic type for call: _6 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.0_5, 0);
  Starting walk at: _6 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.0_5, 0);
  instance pointer: &ElapsedTicks  Outer instance pointer: ElapsedTicks offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:_4 = Flexio_Mcl_Ip_GetTimerStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_EndTransfer (Channel_20(D));
  Function call may change dynamic type:_6 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.0_5, 0);
  Function call may change dynamic type:_4 = Flexio_Mcl_Ip_GetTimerStatus (1077035008B, Channel_20(D));
Determining dynamic type for call: _12 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.2_11, 0);
  Starting walk at: _12 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.2_11, 0);
  instance pointer: &StartTime  Outer instance pointer: StartTime offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:_6 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.0_5, 0);
  Function call may change dynamic type:_4 = Flexio_Mcl_Ip_GetTimerStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_EndTransfer (Channel_20(D));
  Function call may change dynamic type:_10 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:_7 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:_9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.1_8, 0);
Determining dynamic type for call: _12 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.2_11, 0);
  Starting walk at: _12 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.2_11, 0);
  instance pointer: &ElapsedTicks  Outer instance pointer: ElapsedTicks offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:_6 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.0_5, 0);
  Function call may change dynamic type:_4 = Flexio_Mcl_Ip_GetTimerStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_EndTransfer (Channel_20(D));
  Function call may change dynamic type:_10 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:_7 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:_9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.1_8, 0);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_20(D), 0);
  Starting walk at: Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_20(D), 0);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_EndTransfer (Channel_20(D));
  Function call may change dynamic type:_12 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.2_11, 0);
  Function call may change dynamic type:_6 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.0_5, 0);
  Function call may change dynamic type:_4 = Flexio_Mcl_Ip_GetTimerStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Function call may change dynamic type:_10 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:_7 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:_9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.1_8, 0);
Determining dynamic type for call: Flexio_Uart_Ip_SetShifterMode (1077035008B, Channel_20(D), 0);
  Starting walk at: Flexio_Uart_Ip_SetShifterMode (1077035008B, Channel_20(D), 0);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_20(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_EndTransfer (Channel_20(D));
  Function call may change dynamic type:_12 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.2_11, 0);
  Function call may change dynamic type:_6 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.0_5, 0);
  Function call may change dynamic type:_4 = Flexio_Mcl_Ip_GetTimerStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Function call may change dynamic type:_10 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:_7 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:_9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.1_8, 0);
Determining dynamic type for call: Flexio_Uart_Ip_SetShifterStartBit (1077035008B, Channel_20(D), 2);
  Starting walk at: Flexio_Uart_Ip_SetShifterStartBit (1077035008B, Channel_20(D), 2);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Mcl_Ip_ClearShifterErrorStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterMode (1077035008B, Channel_20(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_20(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_EndTransfer (Channel_20(D));
  Function call may change dynamic type:_12 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.2_11, 0);
  Function call may change dynamic type:_6 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.0_5, 0);
  Function call may change dynamic type:_4 = Flexio_Mcl_Ip_GetTimerStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Function call may change dynamic type:_10 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:_7 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:_9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.1_8, 0);
Determining dynamic type for call: Flexio_Uart_Ip_SetShifterMode (1077035008B, Channel_20(D), 2);
  Starting walk at: Flexio_Uart_Ip_SetShifterMode (1077035008B, Channel_20(D), 2);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterStartBit (1077035008B, Channel_20(D), 2);
  Function call may change dynamic type:Flexio_Mcl_Ip_ClearShifterErrorStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterMode (1077035008B, Channel_20(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_20(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_EndTransfer (Channel_20(D));
  Function call may change dynamic type:_12 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.2_11, 0);
  Function call may change dynamic type:_6 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.0_5, 0);
  Function call may change dynamic type:_4 = Flexio_Mcl_Ip_GetTimerStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  Function call may change dynamic type:_10 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:_7 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
  Function call may change dynamic type:_9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.1_8, 0);
Determining dynamic type for call: Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_9(D), 0, Channel_9(D), 1);
  Starting walk at: Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_9(D), 0, Channel_9(D), 1);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: Flexio_Uart_Ip_SetPinShifterControl (1077035008B, Channel_9(D), DataPin_11(D), 0, 0);
  Starting walk at: Flexio_Uart_Ip_SetPinShifterControl (1077035008B, Channel_9(D), DataPin_11(D), 0, 0);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_9(D), 0, Channel_9(D), 1);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_9(D), 4, TimerDec_14(D), 2);
  Starting walk at: Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_9(D), 4, TimerDec_14(D), 2);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetPinShifterControl (1077035008B, Channel_9(D), DataPin_11(D), 0, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_9(D), 0, Channel_9(D), 1);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_9(D), 1, 2);
  Starting walk at: Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_9(D), 1, 2);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_9(D), 4, TimerDec_14(D), 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetPinShifterControl (1077035008B, Channel_9(D), DataPin_11(D), 0, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_9(D), 0, Channel_9(D), 1);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerCondition (1077035008B, Channel_9(D), 4, 2);
  Starting walk at: Flexio_Uart_Ip_SetTimerCondition (1077035008B, Channel_9(D), 4, 2);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_9(D), 1, 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_9(D), 4, TimerDec_14(D), 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetPinShifterControl (1077035008B, Channel_9(D), DataPin_11(D), 0, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_9(D), 0, Channel_9(D), 1);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerControl (1077035008B, Channel_9(D), 0);
  Starting walk at: Flexio_Uart_Ip_SetTimerControl (1077035008B, Channel_9(D), 0);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerCondition (1077035008B, Channel_9(D), 4, 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_9(D), 1, 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_9(D), 4, TimerDec_14(D), 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetPinShifterControl (1077035008B, Channel_9(D), DataPin_11(D), 0, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_9(D), 0, Channel_9(D), 1);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerTrigger (1077035008B, Channel_9(D), 0, 0, 0);
  Starting walk at: Flexio_Uart_Ip_SetTimerTrigger (1077035008B, Channel_9(D), 0, 0, 0);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerControl (1077035008B, Channel_9(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerCondition (1077035008B, Channel_9(D), 4, 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_9(D), 1, 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_9(D), 4, TimerDec_14(D), 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetPinShifterControl (1077035008B, Channel_9(D), DataPin_11(D), 0, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_9(D), 0, Channel_9(D), 1);
Determining dynamic type for call: Flexio_Uart_Ip_SetPinTimerControl (1077035008B, Channel_9(D), DataPin_11(D), 1, 0);
  Starting walk at: Flexio_Uart_Ip_SetPinTimerControl (1077035008B, Channel_9(D), DataPin_11(D), 1, 0);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerTrigger (1077035008B, Channel_9(D), 0, 0, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerControl (1077035008B, Channel_9(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerCondition (1077035008B, Channel_9(D), 4, 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_9(D), 1, 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_9(D), 4, TimerDec_14(D), 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetPinShifterControl (1077035008B, Channel_9(D), DataPin_11(D), 0, 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_9(D), 0, Channel_9(D), 1);
Determining dynamic type for call: Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_11(D), 2, Channel_11(D), 0);
  Starting walk at: Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_11(D), 2, Channel_11(D), 0);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: Flexio_Uart_Ip_SetPinShifterControl (1077035008B, Channel_11(D), DataPin_13(D), 0, 3);
  Starting walk at: Flexio_Uart_Ip_SetPinShifterControl (1077035008B, Channel_11(D), DataPin_13(D), 0, 3);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_11(D), 2, Channel_11(D), 0);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_11(D), 0, TimerDec_16(D), 0);
  Starting walk at: Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_11(D), 0, TimerDec_16(D), 0);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetPinShifterControl (1077035008B, Channel_11(D), DataPin_13(D), 0, 3);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_11(D), 2, Channel_11(D), 0);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_11(D), 1, 2);
  Starting walk at: Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_11(D), 1, 2);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_11(D), 0, TimerDec_16(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetPinShifterControl (1077035008B, Channel_11(D), DataPin_13(D), 0, 3);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_11(D), 2, Channel_11(D), 0);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerCondition (1077035008B, Channel_11(D), 2, 2);
  Starting walk at: Flexio_Uart_Ip_SetTimerCondition (1077035008B, Channel_11(D), 2, 2);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_11(D), 1, 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_11(D), 0, TimerDec_16(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetPinShifterControl (1077035008B, Channel_11(D), DataPin_13(D), 0, 3);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_11(D), 2, Channel_11(D), 0);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerControl (1077035008B, Channel_11(D), 0);
  Starting walk at: Flexio_Uart_Ip_SetTimerControl (1077035008B, Channel_11(D), 0);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerCondition (1077035008B, Channel_11(D), 2, 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_11(D), 1, 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_11(D), 0, TimerDec_16(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetPinShifterControl (1077035008B, Channel_11(D), DataPin_13(D), 0, 3);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_11(D), 2, Channel_11(D), 0);
Determining dynamic type for call: Flexio_Uart_Ip_SetTimerTrigger (1077035008B, Channel_11(D), _7, 1, 1);
  Starting walk at: Flexio_Uart_Ip_SetTimerTrigger (1077035008B, Channel_11(D), _7, 1, 1);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerControl (1077035008B, Channel_11(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerCondition (1077035008B, Channel_11(D), 2, 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_11(D), 1, 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_11(D), 0, TimerDec_16(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetPinShifterControl (1077035008B, Channel_11(D), DataPin_13(D), 0, 3);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_11(D), 2, Channel_11(D), 0);
Determining dynamic type for call: Flexio_Uart_Ip_SetPinTimerControl (1077035008B, Channel_11(D), 0, 0, 0);
  Starting walk at: Flexio_Uart_Ip_SetPinTimerControl (1077035008B, Channel_11(D), 0, 0, 0);
  instance pointer: 1077035008B  Outer instance pointer: 1077035008B offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerTrigger (1077035008B, Channel_11(D), _7, 1, 1);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerControl (1077035008B, Channel_11(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerCondition (1077035008B, Channel_11(D), 2, 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_11(D), 1, 2);
  Function call may change dynamic type:Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_11(D), 0, TimerDec_16(D), 0);
  Function call may change dynamic type:Flexio_Uart_Ip_SetPinShifterControl (1077035008B, Channel_11(D), DataPin_13(D), 0, 3);
  Function call may change dynamic type:Flexio_Uart_Ip_SetShifterControl (1077035008B, Channel_11(D), 2, Channel_11(D), 0);

IPA structures before propagation:

Jump functions:
  Jump functions of caller  Flexio_Mcl_Ip_GetShifterErrorStatus/71:
  Jump functions of caller  SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07/70:
  Jump functions of caller  SchM_Enter_Uart_UART_EXCLUSIVE_AREA_07/69:
  Jump functions of caller  SchM_Exit_Uart_UART_EXCLUSIVE_AREA_06/68:
  Jump functions of caller  SchM_Enter_Uart_UART_EXCLUSIVE_AREA_06/67:
  Jump functions of caller  SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05/66:
  Jump functions of caller  SchM_Enter_Uart_UART_EXCLUSIVE_AREA_05/65:
  Jump functions of caller  SchM_Exit_Uart_UART_EXCLUSIVE_AREA_04/64:
  Jump functions of caller  SchM_Enter_Uart_UART_EXCLUSIVE_AREA_04/63:
  Jump functions of caller  Flexio_Mcl_Ip_SetSoftwareReset/62:
  Jump functions of caller  OsIf_GetElapsed/61:
  Jump functions of caller  OsIf_MicrosToTicks/60:
  Jump functions of caller  OsIf_GetCounter/59:
  Jump functions of caller  Flexio_Mcl_Ip_SetShifterErrorInterrupt/58:
  Jump functions of caller  Flexio_Mcl_Ip_SetShifterInterrupt/57:
  Jump functions of caller  Flexio_Mcl_Ip_SetTimerInterrupt/56:
  Jump functions of caller  Flexio_Mcl_Ip_GetTimerStatus/55:
  Jump functions of caller  Flexio_Mcl_Ip_GetShifterStatus/54:
  Jump functions of caller  Flexio_Mcl_Ip_ClearShifterErrorStatus/53:
  Jump functions of caller  Flexio_Mcl_Ip_ClearShifterStatus/52:
  Jump functions of caller  Flexio_Mcl_Ip_ClearTimerStatus/51:
  Jump functions of caller  Flexio_Uart_Ip_SetRxBuffer/50:
    callsite  Flexio_Uart_Ip_SetRxBuffer/50 -> DevAssert/20 : 
       param 0: PASS THROUGH: 2, op ne_expr 0
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SetRxBuffer/50 -> DevAssert/20 : 
       param 0: PASS THROUGH: 1, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SetRxBuffer/50 -> DevAssert/20 : 
       param 0: PASS THROUGH: 0, op le_expr 7
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_SetTxBuffer/49:
    callsite  Flexio_Uart_Ip_SetTxBuffer/49 -> DevAssert/20 : 
       param 0: PASS THROUGH: 2, op ne_expr 0
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SetTxBuffer/49 -> DevAssert/20 : 
       param 0: PASS THROUGH: 1, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SetTxBuffer/49 -> DevAssert/20 : 
       param 0: PASS THROUGH: 0, op le_expr 7
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_SetBaudRate/48:
    callsite  Flexio_Uart_Ip_SetBaudRate/48 -> Flexio_Uart_Ip_SetTimerCondition/6 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 4
         value: 0x4, mask: 0x0
         Unknown VR
       param 3: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_SetBaudRate/48 -> Flexio_Uart_Ip_SetTimerStartStopBitConfig/5 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 1
         value: 0x1, mask: 0x0
         Unknown VR
       param 3: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_SetBaudRate/48 -> Flexio_Uart_Ip_SetTimerConfig/4 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 4
         value: 0x4, mask: 0x0
         Unknown VR
       param 3: UNKNOWN
         value: 0x0, mask: 0x5
         VR  [0, 5]
       param 4: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_SetBaudRate/48 -> Flexio_Uart_Ip_SetTimerCondition/6 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
       param 3: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_SetBaudRate/48 -> Flexio_Uart_Ip_SetTimerStartStopBitConfig/5 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 1
         value: 0x1, mask: 0x0
         Unknown VR
       param 3: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_SetBaudRate/48 -> Flexio_Uart_Ip_SetTimerConfig/4 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
       param 3: UNKNOWN
         value: 0x0, mask: 0x5
         VR  [0, 5]
       param 4: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_SetBaudRate/48 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SetBaudRate/48 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SetBaudRate/48 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SetBaudRate/48 -> DevAssert/20 : 
       param 0: PASS THROUGH: 2, op ne_expr 0
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SetBaudRate/48 -> DevAssert/20 : 
       param 0: PASS THROUGH: 0, op le_expr 7
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_AbortTransferData/47:
    callsite  Flexio_Uart_Ip_AbortTransferData/47 -> Flexio_Uart_Ip_StopTransfer/29 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  Flexio_Uart_Ip_AbortTransferData/47 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_AbortTransferData/47 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_AbortTransferData/47 -> DevAssert/20 : 
       param 0: PASS THROUGH: 0, op le_expr 7
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_SyncReceive/46:
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> Flexio_Mcl_Ip_ClearTimerStatus/51 : 
       no arg info
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> Flexio_Uart_Ip_CheckTimeout/19 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> Flexio_Uart_Ip_CheckTimeout/19 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> Flexio_Uart_Ip_ReadData/33 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> Flexio_Uart_Ip_CheckShifterErrorStatus/35 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> Flexio_Uart_Ip_CheckTimeout/19 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> Flexio_Mcl_Ip_GetShifterStatus/54 : 
       no arg info
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> Flexio_Uart_Ip_StartTimeout/18 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 2: PASS THROUGH: 3, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> Flexio_Uart_Ip_SetupReceiveData/37 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07/70 : 
       no arg info
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07/70 : 
       no arg info
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> SchM_Enter_Uart_UART_EXCLUSIVE_AREA_07/69 : 
       no arg info
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> DevAssert/20 : 
       param 0: PASS THROUGH: 2, op ne_expr 0
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> DevAssert/20 : 
       param 0: PASS THROUGH: 1, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncReceive/46 -> DevAssert/20 : 
       param 0: PASS THROUGH: 0, op le_expr 7
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_AsyncReceive/45:
    callsite  Flexio_Uart_Ip_AsyncReceive/45 -> Flexio_Uart_Ip_SetShifterInterrupt/36 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 1: CONST: 1
         value: 0x1, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_AsyncReceive/45 -> Flexio_Uart_Ip_EnableReceiver/38 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  Flexio_Uart_Ip_AsyncReceive/45 -> SchM_Exit_Uart_UART_EXCLUSIVE_AREA_06/68 : 
       no arg info
    callsite  Flexio_Uart_Ip_AsyncReceive/45 -> SchM_Exit_Uart_UART_EXCLUSIVE_AREA_06/68 : 
       no arg info
    callsite  Flexio_Uart_Ip_AsyncReceive/45 -> SchM_Enter_Uart_UART_EXCLUSIVE_AREA_06/67 : 
       no arg info
    callsite  Flexio_Uart_Ip_AsyncReceive/45 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_AsyncReceive/45 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_AsyncReceive/45 -> DevAssert/20 : 
       param 0: PASS THROUGH: 2, op ne_expr 0
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_AsyncReceive/45 -> DevAssert/20 : 
       param 0: PASS THROUGH: 1, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_AsyncReceive/45 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_AsyncReceive/45 -> DevAssert/20 : 
       param 0: PASS THROUGH: 0, op le_expr 7
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_SyncSend/44:
    callsite  Flexio_Uart_Ip_SyncSend/44 -> Flexio_Mcl_Ip_ClearTimerStatus/51 : 
       no arg info
    callsite  Flexio_Uart_Ip_SyncSend/44 -> Flexio_Uart_Ip_CheckTimeout/19 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncSend/44 -> Flexio_Uart_Ip_CheckTimeout/19 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncSend/44 -> Flexio_Uart_Ip_CheckTimeout/19 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncSend/44 -> Flexio_Mcl_Ip_GetShifterStatus/54 : 
       no arg info
    callsite  Flexio_Uart_Ip_SyncSend/44 -> Flexio_Uart_Ip_WriteData/30 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncSend/44 -> Flexio_Uart_Ip_StartTimeout/18 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 2: PASS THROUGH: 3, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncSend/44 -> Flexio_Uart_Ip_SetTimerMode/10 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 1
         value: 0x1, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncSend/44 -> Flexio_Uart_Ip_SetShifterInterrupt/36 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 1: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncSend/44 -> SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05/66 : 
       no arg info
    callsite  Flexio_Uart_Ip_SyncSend/44 -> SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05/66 : 
       no arg info
    callsite  Flexio_Uart_Ip_SyncSend/44 -> SchM_Enter_Uart_UART_EXCLUSIVE_AREA_05/65 : 
       no arg info
    callsite  Flexio_Uart_Ip_SyncSend/44 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncSend/44 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncSend/44 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncSend/44 -> DevAssert/20 : 
       param 0: PASS THROUGH: 2, op ne_expr 0
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncSend/44 -> DevAssert/20 : 
       param 0: PASS THROUGH: 1, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_SyncSend/44 -> DevAssert/20 : 
       param 0: PASS THROUGH: 0, op le_expr 7
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_GetStatus/43:
    callsite  Flexio_Uart_Ip_GetStatus/43 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_GetStatus/43 -> DevAssert/20 : 
       param 0: PASS THROUGH: 0, op le_expr 7
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_AsyncSend/42:
    callsite  Flexio_Uart_Ip_AsyncSend/42 -> Flexio_Uart_Ip_SetShifterInterrupt/36 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 1: CONST: 1
         value: 0x1, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_AsyncSend/42 -> Flexio_Uart_Ip_SetTimerMode/10 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 1
         value: 0x1, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_AsyncSend/42 -> SchM_Exit_Uart_UART_EXCLUSIVE_AREA_04/64 : 
       no arg info
    callsite  Flexio_Uart_Ip_AsyncSend/42 -> SchM_Exit_Uart_UART_EXCLUSIVE_AREA_04/64 : 
       no arg info
    callsite  Flexio_Uart_Ip_AsyncSend/42 -> SchM_Enter_Uart_UART_EXCLUSIVE_AREA_04/63 : 
       no arg info
    callsite  Flexio_Uart_Ip_AsyncSend/42 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_AsyncSend/42 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_AsyncSend/42 -> DevAssert/20 : 
       param 0: PASS THROUGH: 2, op ne_expr 0
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_AsyncSend/42 -> DevAssert/20 : 
       param 0: PASS THROUGH: 1, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_AsyncSend/42 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_AsyncSend/42 -> DevAssert/20 : 
       param 0: PASS THROUGH: 0, op le_expr 7
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_Deinit/41:
    callsite  Flexio_Uart_Ip_Deinit/41 -> Flexio_Mcl_Ip_SetSoftwareReset/62 : 
       no arg info
    callsite  Flexio_Uart_Ip_Deinit/41 -> Flexio_Mcl_Ip_SetSoftwareReset/62 : 
       no arg info
    callsite  Flexio_Uart_Ip_Deinit/41 -> Flexio_Uart_Ip_SetShifterInterrupt/36 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 1: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_Deinit/41 -> Flexio_Uart_Ip_CheckTimeout/19 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_Deinit/41 -> Flexio_Uart_Ip_CheckTimeout/19 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_Deinit/41 -> Flexio_Uart_Ip_GetStatus/43 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 1: CONST: 0B
         value: 0x0, mask: 0xfffffff8
         Unknown VR
    callsite  Flexio_Uart_Ip_Deinit/41 -> Flexio_Uart_Ip_StartTimeout/18 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 2: CONST: 10000000
         value: 0x989680, mask: 0x0
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_Deinit/41 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_Deinit/41 -> DevAssert/20 : 
       param 0: PASS THROUGH: 0, op le_expr 7
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_GetBaudRate/40:
    callsite  Flexio_Uart_Ip_GetBaudRate/40 -> DevAssert/20 : 
       param 0: PASS THROUGH: 1, op ne_expr 0B
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_GetBaudRate/40 -> DevAssert/20 : 
       param 0: PASS THROUGH: 0, op le_expr 7
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_Init/39:
    callsite  Flexio_Uart_Ip_Init/39 -> Flexio_Uart_Ip_ConfigureRx/27 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 1: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 2: UNKNOWN
         value: 0x0, mask: 0xff
         Unknown VR
       param 3: UNKNOWN
         value: 0x0, mask: 0xff
         Unknown VR
       param 4: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  Flexio_Uart_Ip_Init/39 -> Flexio_Uart_Ip_ConfigureTx/26 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 1: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 2: UNKNOWN
         value: 0x0, mask: 0xff
         Unknown VR
       param 3: UNKNOWN
         value: 0x0, mask: 0xff
         Unknown VR
       param 4: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  Flexio_Uart_Ip_Init/39 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_Init/39 -> DevAssert/20 : 
       param 0: PASS THROUGH: 0, op le_expr 7
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_Init/39 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_EnableReceiver/38:
    callsite  Flexio_Uart_Ip_EnableReceiver/38 -> Flexio_Uart_Ip_SetTimerMode/10 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 1
         value: 0x1, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_EnableReceiver/38 -> Flexio_Uart_Ip_SetShifterMode/11 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 1
         value: 0x1, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_EnableReceiver/38 -> Flexio_Mcl_Ip_ClearShifterStatus/52 : 
       no arg info
  Jump functions of caller  Flexio_Uart_Ip_SetupReceiveData/37:
    callsite  Flexio_Uart_Ip_SetupReceiveData/37 -> Flexio_Uart_Ip_EnableReceiver/38 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  Flexio_Uart_Ip_SetupReceiveData/37 -> Flexio_Uart_Ip_SetShifterInterrupt/36 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 1: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_SetShifterInterrupt/36:
    callsite  Flexio_Uart_Ip_SetShifterInterrupt/36 -> Flexio_Mcl_Ip_SetShifterErrorInterrupt/58 : 
       no arg info
    callsite  Flexio_Uart_Ip_SetShifterInterrupt/36 -> Flexio_Mcl_Ip_SetShifterInterrupt/57 : 
       no arg info
  Jump functions of caller  Flexio_Uart_Ip_CheckShifterErrorStatus/35:
    callsite  Flexio_Uart_Ip_CheckShifterErrorStatus/35 -> Flexio_Mcl_Ip_ClearShifterErrorStatus/53 : 
       no arg info
    callsite  Flexio_Uart_Ip_CheckShifterErrorStatus/35 -> Flexio_Mcl_Ip_GetShifterErrorStatus/71 : 
       no arg info
  Jump functions of caller  Flexio_Uart_Ip_CheckRxOperation/34:
    callsite  Flexio_Uart_Ip_CheckRxOperation/34 -> Flexio_Uart_Ip_StopTransfer/29 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  Flexio_Uart_Ip_CheckRxOperation/34 -> Flexio_Mcl_Ip_ClearShifterStatus/52 : 
       no arg info
    callsite  Flexio_Uart_Ip_CheckRxOperation/34 -> Flexio_Uart_Ip_ReadData/33 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  Flexio_Uart_Ip_CheckRxOperation/34 -> Flexio_Mcl_Ip_ClearShifterStatus/52 : 
       no arg info
    callsite  Flexio_Uart_Ip_CheckRxOperation/34 -> Flexio_Mcl_Ip_ClearShifterErrorStatus/53 : 
       no arg info
    indirect simple callsite, calling param -1, offset 0, for stmt _13 (Channel_18(D), 2, _14);
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 1: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    indirect simple callsite, calling param -1, offset 0, for stmt _9 (Channel_18(D), 0, _10);
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 1: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    indirect simple callsite, calling param -1, offset 0, for stmt _4 (Channel_18(D), 3, _5);
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 1: CONST: 3
         value: 0x3, mask: 0x0
         Unknown VR
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_ReadData/33:
    callsite  Flexio_Uart_Ip_ReadData/33 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
    callsite  Flexio_Uart_Ip_ReadData/33 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_CheckCompleteTransferData/32:
    callsite  Flexio_Uart_Ip_CheckCompleteTransferData/32 -> Flexio_Mcl_Ip_SetTimerInterrupt/56 : 
       no arg info
    callsite  Flexio_Uart_Ip_CheckCompleteTransferData/32 -> Flexio_Mcl_Ip_SetShifterInterrupt/57 : 
       no arg info
    callsite  Flexio_Uart_Ip_CheckCompleteTransferData/32 -> Flexio_Mcl_Ip_ClearTimerStatus/51 : 
       no arg info
    indirect simple callsite, calling param -1, offset 0, for stmt _3 (Channel_11(D), 1, _4);
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 1: CONST: 1
         value: 0x1, mask: 0x0
         Unknown VR
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_CheckTxOperation/31:
    callsite  Flexio_Uart_Ip_CheckTxOperation/31 -> Flexio_Uart_Ip_CheckCompleteTransferData/32 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  Flexio_Uart_Ip_CheckTxOperation/31 -> Flexio_Uart_Ip_WriteData/30 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  Flexio_Uart_Ip_CheckTxOperation/31 -> Flexio_Mcl_Ip_ClearShifterStatus/52 : 
       no arg info
    callsite  Flexio_Uart_Ip_CheckTxOperation/31 -> Flexio_Uart_Ip_SetShifterStartBit/12 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 3
         value: 0x3, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_CheckTxOperation/31 -> Flexio_Mcl_Ip_GetShifterStatus/54 : 
       no arg info
    callsite  Flexio_Uart_Ip_CheckTxOperation/31 -> Flexio_Uart_Ip_StopTransfer/29 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  Flexio_Uart_Ip_CheckTxOperation/31 -> Flexio_Mcl_Ip_ClearShifterStatus/52 : 
       no arg info
    callsite  Flexio_Uart_Ip_CheckTxOperation/31 -> Flexio_Mcl_Ip_ClearTimerStatus/51 : 
       no arg info
    indirect simple callsite, calling param -1, offset 0, for stmt _8 (Channel_16(D), 2, _9);
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 1: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_WriteData/30:
    callsite  Flexio_Uart_Ip_WriteData/30 -> DevAssert/20 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x1
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_StopTransfer/29:
    callsite  Flexio_Uart_Ip_StopTransfer/29 -> Flexio_Uart_Ip_SetShifterMode/11 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_StopTransfer/29 -> Flexio_Uart_Ip_SetShifterStartBit/12 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_StopTransfer/29 -> Flexio_Mcl_Ip_ClearShifterErrorStatus/53 : 
       no arg info
    callsite  Flexio_Uart_Ip_StopTransfer/29 -> Flexio_Uart_Ip_SetShifterMode/11 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_StopTransfer/29 -> Flexio_Uart_Ip_SetTimerMode/10 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_StopTransfer/29 -> Flexio_Uart_Ip_CheckTimeout/19 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_StopTransfer/29 -> Flexio_Mcl_Ip_GetShifterStatus/54 : 
       no arg info
    callsite  Flexio_Uart_Ip_StopTransfer/29 -> Flexio_Uart_Ip_CheckTimeout/19 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_StopTransfer/29 -> Flexio_Mcl_Ip_GetShifterStatus/54 : 
       no arg info
    callsite  Flexio_Uart_Ip_StopTransfer/29 -> Flexio_Uart_Ip_CheckTimeout/19 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 2: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_StopTransfer/29 -> Flexio_Mcl_Ip_GetTimerStatus/55 : 
       no arg info
    callsite  Flexio_Uart_Ip_StopTransfer/29 -> Flexio_Uart_Ip_StartTimeout/18 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
       param 2: CONST: 10000000
         value: 0x989680, mask: 0x0
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_StopTransfer/29 -> Flexio_Uart_Ip_EndTransfer/28 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_EndTransfer/28:
    callsite  Flexio_Uart_Ip_EndTransfer/28 -> Flexio_Mcl_Ip_SetTimerInterrupt/56 : 
       no arg info
    callsite  Flexio_Uart_Ip_EndTransfer/28 -> Flexio_Uart_Ip_SetShifterInterrupt/36 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 1: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_ConfigureRx/27:
    callsite  Flexio_Uart_Ip_ConfigureRx/27 -> Flexio_Uart_Ip_SetPinTimerControl/9 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: PASS THROUGH: 3, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 3: CONST: 1
         value: 0x1, mask: 0x0
         Unknown VR
       param 4: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_ConfigureRx/27 -> Flexio_Uart_Ip_SetTimerTrigger/8 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
       param 4: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_ConfigureRx/27 -> Flexio_Uart_Ip_SetTimerControl/7 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_ConfigureRx/27 -> Flexio_Uart_Ip_SetTimerCondition/6 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 4
         value: 0x4, mask: 0x0
         Unknown VR
       param 3: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_ConfigureRx/27 -> Flexio_Uart_Ip_SetTimerStartStopBitConfig/5 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 1
         value: 0x1, mask: 0x0
         Unknown VR
       param 3: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_ConfigureRx/27 -> Flexio_Uart_Ip_SetTimerConfig/4 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 4
         value: 0x4, mask: 0x0
         Unknown VR
       param 3: PASS THROUGH: 4, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 4: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_ConfigureRx/27 -> Flexio_Uart_Ip_SetPinShifterControl/2 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: PASS THROUGH: 3, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
       param 4: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_ConfigureRx/27 -> Flexio_Uart_Ip_SetShifterControl/1 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
       param 3: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 4: CONST: 1
         value: 0x1, mask: 0x0
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_ConfigureTx/26:
    callsite  Flexio_Uart_Ip_ConfigureTx/26 -> Flexio_Uart_Ip_SetPinTimerControl/9 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
       param 4: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_ConfigureTx/26 -> Flexio_Uart_Ip_SetTimerTrigger/8 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: UNKNOWN
         value: 0x0, mask: 0xfd
         Unknown VR
       param 3: CONST: 1
         value: 0x1, mask: 0x0
         Unknown VR
       param 4: CONST: 1
         value: 0x1, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_ConfigureTx/26 -> Flexio_Uart_Ip_SetTimerControl/7 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_ConfigureTx/26 -> Flexio_Uart_Ip_SetTimerCondition/6 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
       param 3: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_ConfigureTx/26 -> Flexio_Uart_Ip_SetTimerStartStopBitConfig/5 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 1
         value: 0x1, mask: 0x0
         Unknown VR
       param 3: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_ConfigureTx/26 -> Flexio_Uart_Ip_SetTimerConfig/4 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
       param 3: PASS THROUGH: 4, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 4: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_ConfigureTx/26 -> Flexio_Uart_Ip_SetPinShifterControl/2 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: PASS THROUGH: 3, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 3: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
       param 4: CONST: 3
         value: 0x3, mask: 0x0
         Unknown VR
    callsite  Flexio_Uart_Ip_ConfigureTx/26 -> Flexio_Uart_Ip_SetShifterControl/1 : 
       param 0: CONST: 1077035008B
         value: 0x0, mask: 0xfffffff8
         VR  [1, -1]
       param 1: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: CONST: 2
         value: 0x2, mask: 0x0
         Unknown VR
       param 3: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 4: CONST: 0
         value: 0x0, mask: 0x0
         Unknown VR
  Jump functions of caller  Flexio_Uart_Ip_IrqHandler/25:
    callsite  Flexio_Uart_Ip_IrqHandler/25 -> Flexio_Uart_Ip_CheckRxOperation/34 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 1: PASS THROUGH: 1, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: PASS THROUGH: 2, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  Flexio_Uart_Ip_IrqHandler/25 -> Flexio_Uart_Ip_CheckTxOperation/31 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 1: PASS THROUGH: 1, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
       param 2: PASS THROUGH: 3, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  Flexio_Uart_Ip_IrqHandler/25 -> Flexio_Mcl_Ip_ClearShifterErrorStatus/53 : 
       no arg info
    callsite  Flexio_Uart_Ip_IrqHandler/25 -> Flexio_Mcl_Ip_ClearShifterStatus/52 : 
       no arg info
    callsite  Flexio_Uart_Ip_IrqHandler/25 -> Flexio_Mcl_Ip_ClearTimerStatus/51 : 
       no arg info
  Jump functions of caller  DevAssert/20:
  Jump functions of caller  Flexio_Uart_Ip_CheckTimeout/19:
    callsite  Flexio_Uart_Ip_CheckTimeout/19 -> OsIf_GetElapsed/61 : 
       no arg info
  Jump functions of caller  Flexio_Uart_Ip_StartTimeout/18:
    callsite  Flexio_Uart_Ip_StartTimeout/18 -> OsIf_MicrosToTicks/60 : 
       no arg info
    callsite  Flexio_Uart_Ip_StartTimeout/18 -> OsIf_GetCounter/59 : 
       no arg info
  Jump functions of caller  Flexio_Uart_Ip_SetShifterStartBit/12:
  Jump functions of caller  Flexio_Uart_Ip_SetShifterMode/11:
  Jump functions of caller  Flexio_Uart_Ip_SetTimerMode/10:
  Jump functions of caller  Flexio_Uart_Ip_SetPinTimerControl/9:
  Jump functions of caller  Flexio_Uart_Ip_SetTimerTrigger/8:
  Jump functions of caller  Flexio_Uart_Ip_SetTimerControl/7:
  Jump functions of caller  Flexio_Uart_Ip_SetTimerCondition/6:
  Jump functions of caller  Flexio_Uart_Ip_SetTimerStartStopBitConfig/5:
  Jump functions of caller  Flexio_Uart_Ip_SetTimerConfig/4:
  Jump functions of caller  Flexio_Uart_Ip_SetPinShifterControl/2:
  Jump functions of caller  Flexio_Uart_Ip_SetShifterControl/1:

 Propagating constants:

Not considering Flexio_Uart_Ip_SetRxBuffer/50 for cloning; -fipa-cp-clone disabled.
Not considering Flexio_Uart_Ip_SetTxBuffer/49 for cloning; -fipa-cp-clone disabled.
Not considering Flexio_Uart_Ip_SetBaudRate/48 for cloning; -fipa-cp-clone disabled.
Not considering Flexio_Uart_Ip_AbortTransferData/47 for cloning; -fipa-cp-clone disabled.
Not considering Flexio_Uart_Ip_SyncReceive/46 for cloning; -fipa-cp-clone disabled.
Not considering Flexio_Uart_Ip_AsyncReceive/45 for cloning; -fipa-cp-clone disabled.
Not considering Flexio_Uart_Ip_SyncSend/44 for cloning; -fipa-cp-clone disabled.
Not considering Flexio_Uart_Ip_GetStatus/43 for cloning; -fipa-cp-clone disabled.
Not considering Flexio_Uart_Ip_AsyncSend/42 for cloning; -fipa-cp-clone disabled.
Not considering Flexio_Uart_Ip_Deinit/41 for cloning; -fipa-cp-clone disabled.
Not considering Flexio_Uart_Ip_GetBaudRate/40 for cloning; -fipa-cp-clone disabled.
Not considering Flexio_Uart_Ip_Init/39 for cloning; -fipa-cp-clone disabled.
Not considering Flexio_Uart_Ip_IrqHandler/25 for cloning; -fipa-cp-clone disabled.

overall_size: 1368
 - context independent values, size: 0, time_benefit: 1.000000
     Decided to specialize for all known contexts, code not going to grow.
 - context independent values, size: 8, time_benefit: 1.000000
     Decided to specialize for all known contexts, code not going to grow.
 - context independent values, size: 8, time_benefit: 1.000000
     Decided to specialize for all known contexts, code not going to grow.
 - context independent values, size: 7, time_benefit: 1.000000
     Decided to specialize for all known contexts, code not going to grow.
 - context independent values, size: 21, time_benefit: 4.000000
     Decided to specialize for all known contexts, code not going to grow.
 - context independent values, size: 25, time_benefit: 1.000000
     Decided to specialize for all known contexts, code not going to grow.
 - context independent values, size: 4, time_benefit: 1.000000
     Decided to specialize for all known contexts, code not going to grow.
 - context independent values, size: 9, time_benefit: 4.000000
     Decided to specialize for all known contexts, code not going to grow.
 - context independent values, size: 3, time_benefit: 7.000000
     Decided to specialize for all known contexts, code not going to grow.
 - context independent values, size: 23, time_benefit: 1.000000
     Decided to specialize for all known contexts, code not going to grow.
 - context independent values, size: 21, time_benefit: 4.000000
     Decided to specialize for all known contexts, code not going to grow.
 - context independent values, size: 24, time_benefit: 1.000000
     Decided to specialize for all known contexts, code not going to grow.

IPA lattices after all propagation:

Lattices:
  Node: Flexio_Uart_Ip_SetRxBuffer/50:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Flexio_Uart_Ip_SetTxBuffer/49:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Flexio_Uart_Ip_SetBaudRate/48:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Flexio_Uart_Ip_AbortTransferData/47:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Flexio_Uart_Ip_SyncReceive/46:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [3]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Flexio_Uart_Ip_AsyncReceive/45:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Flexio_Uart_Ip_SyncSend/44:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [3]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Flexio_Uart_Ip_GetStatus/43:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Flexio_Uart_Ip_AsyncSend/42:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Flexio_Uart_Ip_Deinit/41:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Flexio_Uart_Ip_GetBaudRate/40:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Flexio_Uart_Ip_Init/39:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: Flexio_Uart_Ip_EnableReceiver/38:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_SetupReceiveData/37:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_SetShifterInterrupt/36:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: 1 [loc_time: 1, loc_size: 12, prop_time: 0, prop_size: 0]
               0 [loc_time: 1, loc_size: 12, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         _Bool VARYING
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_CheckShifterErrorStatus/35:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_CheckRxOperation/34:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_ReadData/33:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_CheckCompleteTransferData/32:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_CheckTxOperation/31:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_WriteData/30:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_StopTransfer/29:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_EndTransfer/28:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_ConfigureRx/27:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [3]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [4]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_ConfigureTx/26:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [3]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [4]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_IrqHandler/25:
    param [0]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [1]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [2]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
    param [3]: BOTTOM
         ctxs: BOTTOM
         Bits unusable (BOTTOM)
         int VARYING
        AGGS BOTTOM
  Node: DevAssert/20:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_CheckTimeout/19:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0xfffffffc
         uint32 * [1B, +INF]
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0xfffffffc
         uint32 * [1B, +INF]
        AGGS VARIABLE
    param [2]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [3]: 0 [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0x0
         OsIf_CounterType [0, 0]
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_StartTimeout/18:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0xfffffffc
         uint32 * [1B, +INF]
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0xfffffffc
         uint32 * [1B, +INF]
        AGGS VARIABLE
    param [2]: VARIABLE
               10000000 [loc_time: 2, loc_size: 12, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [3]: 0 [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0x0
         OsIf_CounterType [0, 0]
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_SetShifterStartBit/12:
    param [0]: 1077035008B [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0xfffffff8
         struct FLEXIO_Type * [1077035008B, 1077035008B]
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: 3 [loc_time: 3, loc_size: 9, prop_time: 0, prop_size: 0]
               2 [loc_time: 3, loc_size: 9, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x3, mask = 0x1
         Flexio_Mcl_Ip_ShifterStartType [2, 3]
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_SetShifterMode/11:
    param [0]: 1077035008B [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0xfffffff8
         struct FLEXIO_Type * [1077035008B, 1077035008B]
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: 1 [loc_time: 3, loc_size: 9, prop_time: 0, prop_size: 0]
               2 [loc_time: 3, loc_size: 9, prop_time: 0, prop_size: 0]
               0 [loc_time: 3, loc_size: 9, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x1, mask = 0x3
         Flexio_Mcl_Ip_ShifterModeType [0, 2]
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_SetPinTimerControl/9:
    param [0]: 1077035008B [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0xfffffff8
         struct FLEXIO_Type * [1077035008B, 1077035008B]
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: VARIABLE
               0 [loc_time: 7, loc_size: 23, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [3]: 1 [loc_time: 7, loc_size: 23, prop_time: 0, prop_size: 0]
               0 [loc_time: 7, loc_size: 23, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x1, mask = 0x1
         Flexio_Mcl_Ip_PinPolarityType [0, 1]
        AGGS VARIABLE
    param [4]: 0 [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0x0
         Flexio_Mcl_Ip_PinConfigType [0, 0]
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_SetTimerTrigger/8:
    param [0]: 1077035008B [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0xfffffff8
         struct FLEXIO_Type * [1077035008B, 1077035008B]
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: VARIABLE
               0 [loc_time: 4, loc_size: 25, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0xfd
         int VARYING
        AGGS VARIABLE
    param [3]: 0 [loc_time: 4, loc_size: 25, prop_time: 0, prop_size: 0]
               1 [loc_time: 4, loc_size: 25, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0x1
         Flexio_Mcl_Ip_TriggerPolarityType [0, 1]
        AGGS VARIABLE
    param [4]: 0 [loc_time: 4, loc_size: 25, prop_time: 0, prop_size: 0]
               1 [loc_time: 4, loc_size: 25, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0x1
         Flexio_Mcl_Ip_TriggerSourceType [0, 1]
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_SetTimerControl/7:
    param [0]: 1077035008B [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0xfffffff8
         struct FLEXIO_Type * [1077035008B, 1077035008B]
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: 1 [loc_time: 3, loc_size: 9, prop_time: 0, prop_size: 0]
               0 [loc_time: 3, loc_size: 9, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x1, mask = 0x1
         Flexio_Mcl_Ip_TimerModeType [0, 1]
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_SetTimerCondition/6:
    param [0]: 1077035008B [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0xfffffff8
         struct FLEXIO_Type * [1077035008B, 1077035008B]
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: 4 [loc_time: 7, loc_size: 15, prop_time: 0, prop_size: 0]
               2 [loc_time: 7, loc_size: 15, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x4, mask = 0x6
         Flexio_Mcl_Ip_TimerEnableType [2, 4]
        AGGS VARIABLE
    param [3]: 2 [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x2, mask = 0x0
         Flexio_Mcl_Ip_TimerDisableType [2, 2]
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_SetTimerStartStopBitConfig/5:
    param [0]: 1077035008B [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0xfffffff8
         struct FLEXIO_Type * [1077035008B, 1077035008B]
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: 1 [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x1, mask = 0x0
         Flexio_Mcl_Ip_TimerStartType [1, 1]
        AGGS VARIABLE
    param [3]: 2 [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x2, mask = 0x0
         Flexio_Mcl_Ip_TimerStopType [2, 2]
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_SetTimerConfig/4:
    param [0]: 1077035008B [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0xfffffff8
         struct FLEXIO_Type * [1077035008B, 1077035008B]
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: 4 [loc_time: 4, loc_size: 25, prop_time: 0, prop_size: 0]
               0 [loc_time: 4, loc_size: 25, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x4, mask = 0x4
         Flexio_Mcl_Ip_TimerResetType [0, 4]
        AGGS VARIABLE
    param [3]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [4]: 2 [loc_time: 4, loc_size: 25, prop_time: 0, prop_size: 0]
               0 [loc_time: 4, loc_size: 25, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x2, mask = 0x2
         Flexio_Mcl_Ip_TimerOutputType [0, 2]
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_SetPinShifterControl/2:
    param [0]: 1077035008B [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0xfffffff8
         struct FLEXIO_Type * [1077035008B, 1077035008B]
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [3]: 0 [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0x0
         Flexio_Mcl_Ip_PinPolarityType [0, 0]
        AGGS VARIABLE
    param [4]: 0 [loc_time: 7, loc_size: 23, prop_time: 0, prop_size: 0]
               3 [loc_time: 7, loc_size: 23, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0x3
         Flexio_Mcl_Ip_PinConfigType [0, 3]
        AGGS VARIABLE
  Node: Flexio_Uart_Ip_SetShifterControl/1:
    param [0]: 1077035008B [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0xfffffff8
         struct FLEXIO_Type * [1077035008B, 1077035008B]
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [2]: 0 [loc_time: 3, loc_size: 25, prop_time: 0, prop_size: 0]
               2 [loc_time: 3, loc_size: 25, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0x2
         Flexio_Mcl_Ip_ShifterModeType [0, 2]
        AGGS VARIABLE
    param [3]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [4]: 1 [loc_time: 4, loc_size: 24, prop_time: 0, prop_size: 0]
               0 [loc_time: 4, loc_size: 24, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits: value = 0x1, mask = 0x1
         Flexio_Mcl_Ip_TimerPolarityType [0, 1]
        AGGS VARIABLE

IPA decision stage:

 - Creating a specialized node of Flexio_Uart_Ip_CheckTimeout/19 for all known contexts.
    replacing param #3 OsifCounter with const 0
 - Creating a specialized node of Flexio_Uart_Ip_StartTimeout/18 for all known contexts.
    replacing param #3 OsifCounter with const 0
 - Creating a specialized node of Flexio_Uart_Ip_SetShifterStartBit/12 for all known contexts.
    replacing param #0 Base with const 1077035008B
 - Creating a specialized node of Flexio_Uart_Ip_SetShifterMode/11 for all known contexts.
    replacing param #0 Base with const 1077035008B
 - Creating a specialized node of Flexio_Uart_Ip_SetPinTimerControl/9 for all known contexts.
    replacing param #0 Base with const 1077035008B
    replacing param #4 PinConfig with const 0
 - Creating a specialized node of Flexio_Uart_Ip_SetTimerTrigger/8 for all known contexts.
    replacing param #0 Base with const 1077035008B
 - Creating a specialized node of Flexio_Uart_Ip_SetTimerControl/7 for all known contexts.
    replacing param #0 Base with const 1077035008B
 - Creating a specialized node of Flexio_Uart_Ip_SetTimerCondition/6 for all known contexts.
    replacing param #0 Base with const 1077035008B
    replacing param #3 Disable with const 2
 - Creating a specialized node of Flexio_Uart_Ip_SetTimerStartStopBitConfig/5 for all known contexts.
    replacing param #0 Base with const 1077035008B
    replacing param #2 Start with const 1
    replacing param #3 Stop with const 2
 - Creating a specialized node of Flexio_Uart_Ip_SetTimerConfig/4 for all known contexts.
    replacing param #0 Base with const 1077035008B
 - Creating a specialized node of Flexio_Uart_Ip_SetPinShifterControl/2 for all known contexts.
    replacing param #0 Base with const 1077035008B
    replacing param #3 PinPolarity with const 0
 - Creating a specialized node of Flexio_Uart_Ip_SetShifterControl/1 for all known contexts.
    replacing param #0 Base with const 1077035008B
Propagated bits info for function Flexio_Uart_Ip_SetShifterControl.constprop/89:
 param 0: value = 0x0, mask = 0xfffffff8
 param 2: value = 0x0, mask = 0x2
 param 4: value = 0x1, mask = 0x1
Propagated bits info for function Flexio_Uart_Ip_SetPinShifterControl.constprop/88:
 param 0: value = 0x0, mask = 0xfffffff8
 param 3: value = 0x0, mask = 0x0
 param 4: value = 0x0, mask = 0x3
Propagated bits info for function Flexio_Uart_Ip_SetTimerConfig.constprop/87:
 param 0: value = 0x0, mask = 0xfffffff8
 param 2: value = 0x4, mask = 0x4
 param 4: value = 0x2, mask = 0x2
Propagated bits info for function Flexio_Uart_Ip_SetTimerStartStopBitConfig.constprop/86:
 param 0: value = 0x0, mask = 0xfffffff8
 param 2: value = 0x1, mask = 0x0
 param 3: value = 0x2, mask = 0x0
Propagated bits info for function Flexio_Uart_Ip_SetTimerCondition.constprop/85:
 param 0: value = 0x0, mask = 0xfffffff8
 param 2: value = 0x4, mask = 0x6
 param 3: value = 0x2, mask = 0x0
Propagated bits info for function Flexio_Uart_Ip_SetTimerControl.constprop/84:
 param 0: value = 0x0, mask = 0xfffffff8
 param 2: value = 0x1, mask = 0x1
Propagated bits info for function Flexio_Uart_Ip_SetTimerTrigger.constprop/83:
 param 0: value = 0x0, mask = 0xfffffff8
 param 2: value = 0x0, mask = 0xfd
 param 3: value = 0x0, mask = 0x1
 param 4: value = 0x0, mask = 0x1
Propagated bits info for function Flexio_Uart_Ip_SetPinTimerControl.constprop/82:
 param 0: value = 0x0, mask = 0xfffffff8
 param 3: value = 0x1, mask = 0x1
 param 4: value = 0x0, mask = 0x0
Propagated bits info for function Flexio_Uart_Ip_SetShifterMode.constprop/81:
 param 0: value = 0x0, mask = 0xfffffff8
 param 2: value = 0x1, mask = 0x3
Propagated bits info for function Flexio_Uart_Ip_SetShifterStartBit.constprop/80:
 param 0: value = 0x0, mask = 0xfffffff8
 param 2: value = 0x3, mask = 0x1
Propagated bits info for function Flexio_Uart_Ip_StartTimeout.constprop/79:
 param 0: value = 0x0, mask = 0xfffffffc
 param 1: value = 0x0, mask = 0xfffffffc
 param 3: value = 0x0, mask = 0x0
Propagated bits info for function Flexio_Uart_Ip_CheckTimeout.constprop/78:
 param 0: value = 0x0, mask = 0xfffffffc
 param 1: value = 0x0, mask = 0xfffffffc
 param 3: value = 0x0, mask = 0x0
Propagated bits info for function Flexio_Uart_Ip_CheckTimeout/19:
 param 0: value = 0x0, mask = 0xfffffffc
 param 1: value = 0x0, mask = 0xfffffffc
 param 3: value = 0x0, mask = 0x0
Propagated bits info for function Flexio_Uart_Ip_StartTimeout/18:
 param 0: value = 0x0, mask = 0xfffffffc
 param 1: value = 0x0, mask = 0xfffffffc
 param 3: value = 0x0, mask = 0x0
Propagated bits info for function Flexio_Uart_Ip_SetShifterStartBit/12:
 param 0: value = 0x0, mask = 0xfffffff8
 param 2: value = 0x3, mask = 0x1
Propagated bits info for function Flexio_Uart_Ip_SetShifterMode/11:
 param 0: value = 0x0, mask = 0xfffffff8
 param 2: value = 0x1, mask = 0x3
Propagated bits info for function Flexio_Uart_Ip_SetPinTimerControl/9:
 param 0: value = 0x0, mask = 0xfffffff8
 param 3: value = 0x1, mask = 0x1
 param 4: value = 0x0, mask = 0x0
Propagated bits info for function Flexio_Uart_Ip_SetTimerTrigger/8:
 param 0: value = 0x0, mask = 0xfffffff8
 param 2: value = 0x0, mask = 0xfd
 param 3: value = 0x0, mask = 0x1
 param 4: value = 0x0, mask = 0x1
Propagated bits info for function Flexio_Uart_Ip_SetTimerControl/7:
 param 0: value = 0x0, mask = 0xfffffff8
 param 2: value = 0x1, mask = 0x1
Propagated bits info for function Flexio_Uart_Ip_SetTimerCondition/6:
 param 0: value = 0x0, mask = 0xfffffff8
 param 2: value = 0x4, mask = 0x6
 param 3: value = 0x2, mask = 0x0
Propagated bits info for function Flexio_Uart_Ip_SetTimerStartStopBitConfig/5:
 param 0: value = 0x0, mask = 0xfffffff8
 param 2: value = 0x1, mask = 0x0
 param 3: value = 0x2, mask = 0x0
Propagated bits info for function Flexio_Uart_Ip_SetTimerConfig/4:
 param 0: value = 0x0, mask = 0xfffffff8
 param 2: value = 0x4, mask = 0x4
 param 4: value = 0x2, mask = 0x2
Propagated bits info for function Flexio_Uart_Ip_SetPinShifterControl/2:
 param 0: value = 0x0, mask = 0xfffffff8
 param 3: value = 0x0, mask = 0x0
 param 4: value = 0x0, mask = 0x3
Propagated bits info for function Flexio_Uart_Ip_SetShifterControl/1:
 param 0: value = 0x0, mask = 0xfffffff8
 param 2: value = 0x0, mask = 0x2
 param 4: value = 0x1, mask = 0x1

IPA constant propagation end

Reclaiming functions: Flexio_Uart_Ip_CheckTimeout/19 Flexio_Uart_Ip_StartTimeout/18 Flexio_Uart_Ip_SetShifterStartBit/12 Flexio_Uart_Ip_SetShifterMode/11 Flexio_Uart_Ip_SetTimerMode/10 Flexio_Uart_Ip_SetPinTimerControl/9 Flexio_Uart_Ip_SetTimerTrigger/8 Flexio_Uart_Ip_SetTimerControl/7 Flexio_Uart_Ip_SetTimerCondition/6 Flexio_Uart_Ip_SetTimerStartStopBitConfig/5 Flexio_Uart_Ip_SetTimerConfig/4 Flexio_Uart_Ip_SetPinShifterControl/2 Flexio_Uart_Ip_SetShifterControl/1
Reclaiming variables:
Clearing address taken flags:
Symbol table:

Flexio_Uart_Ip_SetShifterControl.constprop.0/89 (Flexio_Uart_Ip_SetShifterControl.constprop) @063b6540
  Type: function definition analyzed
  Visibility:
  References: 
  Referring: 
  Clone of Flexio_Uart_Ip_SetShifterControl/1
  Availability: local
  Function flags: count:1073741824 (estimated locally) local optimize_size
  Called by: Flexio_Uart_Ip_ConfigureTx/26 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_ConfigureRx/27 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Uart_Ip_SetPinShifterControl.constprop.0/88 (Flexio_Uart_Ip_SetPinShifterControl.constprop) @063b62a0
  Type: function definition analyzed
  Visibility:
  References: 
  Referring: 
  Clone of Flexio_Uart_Ip_SetPinShifterControl/2
  Availability: local
  Function flags: count:1073741824 (estimated locally) local optimize_size
  Called by: Flexio_Uart_Ip_ConfigureTx/26 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_ConfigureRx/27 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Uart_Ip_SetTimerConfig.constprop.0/87 (Flexio_Uart_Ip_SetTimerConfig.constprop) @063b6000
  Type: function definition analyzed
  Visibility:
  References: 
  Referring: 
  Clone of Flexio_Uart_Ip_SetTimerConfig/4
  Availability: local
  Function flags: count:1073741824 (estimated locally) local optimize_size
  Called by: Flexio_Uart_Ip_ConfigureTx/26 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_ConfigureRx/27 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetBaudRate/48 (237296945 (estimated locally),0.22 per call) Flexio_Uart_Ip_SetBaudRate/48 (460635239 (estimated locally),0.43 per call) 
  Calls: 
Flexio_Uart_Ip_SetTimerStartStopBitConfig.constprop.0/86 (Flexio_Uart_Ip_SetTimerStartStopBitConfig.constprop) @063b0d20
  Type: function definition analyzed
  Visibility:
  References: 
  Referring: 
  Clone of Flexio_Uart_Ip_SetTimerStartStopBitConfig/5
  Availability: local
  Function flags: count:1073741824 (estimated locally) local optimize_size
  Called by: Flexio_Uart_Ip_ConfigureTx/26 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_ConfigureRx/27 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetBaudRate/48 (237296945 (estimated locally),0.22 per call) Flexio_Uart_Ip_SetBaudRate/48 (460635239 (estimated locally),0.43 per call) 
  Calls: 
Flexio_Uart_Ip_SetTimerCondition.constprop.0/85 (Flexio_Uart_Ip_SetTimerCondition.constprop) @063b0a80
  Type: function definition analyzed
  Visibility:
  References: 
  Referring: 
  Clone of Flexio_Uart_Ip_SetTimerCondition/6
  Availability: local
  Function flags: count:1073741824 (estimated locally) local optimize_size
  Called by: Flexio_Uart_Ip_ConfigureTx/26 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_ConfigureRx/27 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetBaudRate/48 (237296945 (estimated locally),0.22 per call) Flexio_Uart_Ip_SetBaudRate/48 (460635239 (estimated locally),0.43 per call) 
  Calls: 
Flexio_Uart_Ip_SetTimerControl.constprop.0/84 (Flexio_Uart_Ip_SetTimerControl.constprop) @063b07e0
  Type: function definition analyzed
  Visibility:
  References: 
  Referring: 
  Clone of Flexio_Uart_Ip_SetTimerControl/7
  Availability: local
  Function flags: count:1073741824 (estimated locally) local icf_merged optimize_size
  Called by: Flexio_Uart_Ip_EnableReceiver/38 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_StopTransfer/29 (859859951 (estimated locally),1.00 per call) Flexio_Uart_Ip_AsyncSend/42 (697932184 (estimated locally),0.65 per call) Flexio_Uart_Ip_SyncSend/44 (8893213 (estimated locally),0.65 per call) Flexio_Uart_Ip_ConfigureTx/26 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_ConfigureRx/27 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Uart_Ip_SetTimerTrigger.constprop.0/83 (Flexio_Uart_Ip_SetTimerTrigger.constprop) @063b0540
  Type: function definition analyzed
  Visibility:
  References: 
  Referring: 
  Clone of Flexio_Uart_Ip_SetTimerTrigger/8
  Availability: local
  Function flags: count:1073741824 (estimated locally) local optimize_size
  Called by: Flexio_Uart_Ip_ConfigureTx/26 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_ConfigureRx/27 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Uart_Ip_SetPinTimerControl.constprop.0/82 (Flexio_Uart_Ip_SetPinTimerControl.constprop) @063b02a0
  Type: function definition analyzed
  Visibility:
  References: 
  Referring: 
  Clone of Flexio_Uart_Ip_SetPinTimerControl/9
  Availability: local
  Function flags: count:1073741824 (estimated locally) local optimize_size
  Called by: Flexio_Uart_Ip_ConfigureTx/26 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_ConfigureRx/27 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Uart_Ip_SetShifterMode.constprop.0/81 (Flexio_Uart_Ip_SetShifterMode.constprop) @063b0000
  Type: function definition analyzed
  Visibility:
  References: 
  Referring: 
  Clone of Flexio_Uart_Ip_SetShifterMode/11
  Availability: local
  Function flags: count:1073741824 (estimated locally) local optimize_size
  Called by: Flexio_Uart_Ip_EnableReceiver/38 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_StopTransfer/29 (859859951 (estimated locally),1.00 per call) Flexio_Uart_Ip_StopTransfer/29 (174035653 (estimated locally),0.20 per call) 
  Calls: 
Flexio_Uart_Ip_SetShifterStartBit.constprop.0/80 (Flexio_Uart_Ip_SetShifterStartBit.constprop) @06390e00
  Type: function definition analyzed
  Visibility:
  References: 
  Referring: 
  Clone of Flexio_Uart_Ip_SetShifterStartBit/12
  Availability: local
  Function flags: count:1073741824 (estimated locally) local optimize_size
  Called by: Flexio_Uart_Ip_StopTransfer/29 (174035653 (estimated locally),0.20 per call) Flexio_Uart_Ip_CheckTxOperation/31 (29675540 (estimated locally),0.03 per call) 
  Calls: 
Flexio_Uart_Ip_StartTimeout.constprop.0/79 (Flexio_Uart_Ip_StartTimeout.constprop) @06390c40
  Type: function definition analyzed
  Visibility:
  References: 
  Referring: 
  Clone of Flexio_Uart_Ip_StartTimeout/18
  Availability: local
  Function flags: count:1073741824 (estimated locally) local optimize_size
  Called by: Flexio_Uart_Ip_StopTransfer/29 (174035653 (estimated locally),0.20 per call) Flexio_Uart_Ip_Deinit/41 (114863530 (estimated locally),1.00 per call) Flexio_Uart_Ip_SyncSend/44 (8893213 (estimated locally),0.65 per call) Flexio_Uart_Ip_SyncReceive/46 (13097219 (estimated locally),0.65 per call) 
  Calls: OsIf_GetCounter/59 (1073741824 (estimated locally),1.00 per call) OsIf_MicrosToTicks/60 (1073741824 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_CheckTimeout.constprop.0/78 (Flexio_Uart_Ip_CheckTimeout.constprop) @063909a0
  Type: function definition analyzed
  Visibility:
  References: 
  Referring: 
  Clone of Flexio_Uart_Ip_CheckTimeout/19
  Availability: local
  Function flags: count:1073741824 (estimated locally) local optimize_size
  Called by: Flexio_Uart_Ip_StopTransfer/29 (522717052 (estimated locally),0.61 per call) Flexio_Uart_Ip_StopTransfer/29 (1014686025 (estimated locally),1.18 per call) Flexio_Uart_Ip_StopTransfer/29 (174035654 (estimated locally),0.20 per call) Flexio_Uart_Ip_Deinit/41 (1014686026 (estimated locally),8.83 per call) Flexio_Uart_Ip_Deinit/41 (114863531 (estimated locally),1.00 per call) Flexio_Uart_Ip_SyncSend/44 (1014686025 (estimated locally),74.16 per call) Flexio_Uart_Ip_SyncSend/44 (119227247 (estimated locally),8.71 per call) Flexio_Uart_Ip_SyncSend/44 (8893214 (estimated locally),0.65 per call) Flexio_Uart_Ip_SyncReceive/46 (1014686025 (estimated locally),50.36 per call) Flexio_Uart_Ip_SyncReceive/46 (119227247 (estimated locally),5.92 per call) Flexio_Uart_Ip_SyncReceive/46 (2650877 (estimated locally),0.13 per call) 
  Calls: OsIf_GetElapsed/61 (1073741824 (estimated locally),1.00 per call) 
Flexio_Mcl_Ip_GetShifterErrorStatus/71 (Flexio_Mcl_Ip_GetShifterErrorStatus) @06208620
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_CheckShifterErrorStatus/35 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07/70 (SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07) @06208380
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_SyncReceive/46 (13097219 (estimated locally),0.65 per call) Flexio_Uart_Ip_SyncReceive/46 (7052348 (estimated locally),0.35 per call) 
  Calls: 
SchM_Enter_Uart_UART_EXCLUSIVE_AREA_07/69 (SchM_Enter_Uart_UART_EXCLUSIVE_AREA_07) @062082a0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_SyncReceive/46 (20149567 (estimated locally),1.00 per call) 
  Calls: 
SchM_Exit_Uart_UART_EXCLUSIVE_AREA_06/68 (SchM_Exit_Uart_UART_EXCLUSIVE_AREA_06) @05f67ee0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_AsyncReceive/45 (697932184 (estimated locally),0.65 per call) Flexio_Uart_Ip_AsyncReceive/45 (375809640 (estimated locally),0.35 per call) 
  Calls: 
SchM_Enter_Uart_UART_EXCLUSIVE_AREA_06/67 (SchM_Enter_Uart_UART_EXCLUSIVE_AREA_06) @05f67e00
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_AsyncReceive/45 (1073741823 (estimated locally),1.00 per call) 
  Calls: 
SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05/66 (SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05) @05f67c40
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_SyncSend/44 (8893213 (estimated locally),0.65 per call) Flexio_Uart_Ip_SyncSend/44 (4788653 (estimated locally),0.35 per call) 
  Calls: 
SchM_Enter_Uart_UART_EXCLUSIVE_AREA_05/65 (SchM_Enter_Uart_UART_EXCLUSIVE_AREA_05) @05f67b60
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_SyncSend/44 (13681867 (estimated locally),1.00 per call) 
  Calls: 
SchM_Exit_Uart_UART_EXCLUSIVE_AREA_04/64 (SchM_Exit_Uart_UART_EXCLUSIVE_AREA_04) @05f677e0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_AsyncSend/42 (697932184 (estimated locally),0.65 per call) Flexio_Uart_Ip_AsyncSend/42 (375809640 (estimated locally),0.35 per call) 
  Calls: 
SchM_Enter_Uart_UART_EXCLUSIVE_AREA_04/63 (SchM_Enter_Uart_UART_EXCLUSIVE_AREA_04) @05f67700
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_AsyncSend/42 (1073741823 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Mcl_Ip_SetSoftwareReset/62 (Flexio_Mcl_Ip_SetSoftwareReset) @05f67540
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_Deinit/41 (37904965 (estimated locally),0.33 per call) Flexio_Uart_Ip_Deinit/41 (37904965 (estimated locally),0.33 per call) 
  Calls: 
OsIf_GetElapsed/61 (OsIf_GetElapsed) @05fc5c40
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_CheckTimeout.constprop.0/78 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
OsIf_MicrosToTicks/60 (OsIf_MicrosToTicks) @05fc59a0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_StartTimeout.constprop.0/79 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
OsIf_GetCounter/59 (OsIf_GetCounter) @05fc58c0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_StartTimeout.constprop.0/79 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Mcl_Ip_SetShifterErrorInterrupt/58 (Flexio_Mcl_Ip_SetShifterErrorInterrupt) @05fc5700
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_SetShifterInterrupt/36 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Mcl_Ip_SetShifterInterrupt/57 (Flexio_Mcl_Ip_SetShifterInterrupt) @05fc5620
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_SetShifterInterrupt/36 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_CheckCompleteTransferData/32 (116930483 (estimated locally),0.11 per call) 
  Calls: 
Flexio_Mcl_Ip_SetTimerInterrupt/56 (Flexio_Mcl_Ip_SetTimerInterrupt) @05fc5460
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_EndTransfer/28 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_CheckCompleteTransferData/32 (116930483 (estimated locally),0.11 per call) 
  Calls: 
Flexio_Mcl_Ip_GetTimerStatus/55 (Flexio_Mcl_Ip_GetTimerStatus) @05fc52a0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_StopTransfer/29 (553139738 (estimated locally),0.64 per call) 
  Calls: 
Flexio_Mcl_Ip_GetShifterStatus/54 (Flexio_Mcl_Ip_GetShifterStatus) @05fc5000
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_SyncReceive/46 (1073741824 (estimated locally),53.29 per call) Flexio_Uart_Ip_SyncSend/44 (1073741824 (estimated locally),78.48 per call) Flexio_Uart_Ip_CheckTxOperation/31 (89925878 (estimated locally),0.08 per call) Flexio_Uart_Ip_StopTransfer/29 (114863531 (estimated locally),0.13 per call) Flexio_Uart_Ip_StopTransfer/29 (1073741824 (estimated locally),1.25 per call) 
  Calls: 
Flexio_Mcl_Ip_ClearShifterErrorStatus/53 (Flexio_Mcl_Ip_ClearShifterErrorStatus) @061f9380
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_IrqHandler/25 (187153200 (estimated locally),0.17 per call) Flexio_Uart_Ip_CheckShifterErrorStatus/35 (354334800 (estimated locally),0.33 per call) Flexio_Uart_Ip_CheckRxOperation/34 (177167399 (estimated locally),0.16 per call) Flexio_Uart_Ip_StopTransfer/29 (859859951 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Mcl_Ip_ClearShifterStatus/52 (Flexio_Mcl_Ip_ClearShifterStatus) @061f90e0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_IrqHandler/25 (187153200 (estimated locally),0.17 per call) Flexio_Uart_Ip_CheckRxOperation/34 (177167400 (estimated locally),0.16 per call) Flexio_Uart_Ip_CheckRxOperation/34 (134217728 (estimated locally),0.13 per call) Flexio_Uart_Ip_CheckTxOperation/31 (67108864 (estimated locally),0.06 per call) Flexio_Uart_Ip_CheckTxOperation/31 (89925878 (estimated locally),0.08 per call) Flexio_Uart_Ip_EnableReceiver/38 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Mcl_Ip_ClearTimerStatus/51 (Flexio_Mcl_Ip_ClearTimerStatus) @061f9ee0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Uart_Ip_SyncReceive/46 (13097220 (estimated locally),0.65 per call) Flexio_Uart_Ip_SyncSend/44 (8893214 (estimated locally),0.65 per call) Flexio_Uart_Ip_IrqHandler/25 (187153200 (estimated locally),0.17 per call) Flexio_Uart_Ip_CheckTxOperation/31 (88583700 (estimated locally),0.08 per call) Flexio_Uart_Ip_CheckCompleteTransferData/32 (354334800 (estimated locally),0.33 per call) 
  Calls: 
Flexio_Uart_Ip_SetRxBuffer/50 (Flexio_Uart_Ip_SetRxBuffer) @061f9a80
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: DevAssert/20 (1073741824 (estimated locally),1.00 per call) DevAssert/20 (1073741824 (estimated locally),1.00 per call) DevAssert/20 (1073741824 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_SetTxBuffer/49 (Flexio_Uart_Ip_SetTxBuffer) @061f97e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: DevAssert/20 (1073741824 (estimated locally),1.00 per call) DevAssert/20 (1073741824 (estimated locally),1.00 per call) DevAssert/20 (1073741824 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_SetBaudRate/48 (Flexio_Uart_Ip_SetBaudRate) @061f9540
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) Flexio_Uart_Ip_apUserConfig/23 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741823 (estimated locally) body optimize_size
  Called by: 
  Calls: Flexio_Uart_Ip_SetTimerCondition.constprop.0/85 (460635239 (estimated locally),0.43 per call) Flexio_Uart_Ip_SetTimerStartStopBitConfig.constprop.0/86 (460635239 (estimated locally),0.43 per call) Flexio_Uart_Ip_SetTimerConfig.constprop.0/87 (460635239 (estimated locally),0.43 per call) Flexio_Uart_Ip_SetTimerCondition.constprop.0/85 (237296945 (estimated locally),0.22 per call) Flexio_Uart_Ip_SetTimerStartStopBitConfig.constprop.0/86 (237296945 (estimated locally),0.22 per call) Flexio_Uart_Ip_SetTimerConfig.constprop.0/87 (237296945 (estimated locally),0.22 per call) DevAssert/20 (154312805 (estimated locally),0.14 per call) DevAssert/20 (230317619 (estimated locally),0.21 per call) DevAssert/20 (1073741823 (estimated locally),1.00 per call) DevAssert/20 (1073741823 (estimated locally),1.00 per call) DevAssert/20 (1073741823 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_AbortTransferData/47 (Flexio_Uart_Ip_AbortTransferData) @061f92a0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) Flexio_Uart_Ip_apUserConfig/23 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Flexio_Uart_Ip_StopTransfer/29 (177167400 (estimated locally),0.16 per call) DevAssert/20 (1073741824 (estimated locally),1.00 per call) DevAssert/20 (1073741824 (estimated locally),1.00 per call) DevAssert/20 (1073741824 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_SyncReceive/46 (Flexio_Uart_Ip_SyncReceive) @061f9000
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) Flexio_Uart_Ip_apUserConfig/23 (read) 
  Referring: 
  Availability: available
  Function flags: count:20149567 (estimated locally) body optimize_size
  Called by: 
  Calls: Flexio_Mcl_Ip_ClearTimerStatus/51 (13097220 (estimated locally),0.65 per call) Flexio_Uart_Ip_CheckTimeout.constprop.0/78 (2650877 (estimated locally),0.13 per call) Flexio_Uart_Ip_CheckTimeout.constprop.0/78 (119227247 (estimated locally),5.92 per call) Flexio_Uart_Ip_ReadData/33 (110659526 (estimated locally),5.49 per call) Flexio_Uart_Ip_CheckShifterErrorStatus/35 (114863531 (estimated locally),5.70 per call) Flexio_Uart_Ip_CheckTimeout.constprop.0/78 (1014686025 (estimated locally),50.36 per call) Flexio_Mcl_Ip_GetShifterStatus/54 (1073741824 (estimated locally),53.29 per call) Flexio_Uart_Ip_StartTimeout.constprop.0/79 (13097219 (estimated locally),0.65 per call) Flexio_Uart_Ip_SetupReceiveData/37 (13097219 (estimated locally),0.65 per call) SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07/70 (13097219 (estimated locally),0.65 per call) SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07/70 (7052348 (estimated locally),0.35 per call) SchM_Enter_Uart_UART_EXCLUSIVE_AREA_07/69 (20149567 (estimated locally),1.00 per call) DevAssert/20 (20149567 (estimated locally),1.00 per call) DevAssert/20 (20149567 (estimated locally),1.00 per call) DevAssert/20 (20149567 (estimated locally),1.00 per call) DevAssert/20 (20149567 (estimated locally),1.00 per call) DevAssert/20 (20149567 (estimated locally),1.00 per call) DevAssert/20 (20149567 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_AsyncReceive/45 (Flexio_Uart_Ip_AsyncReceive) @061e5620
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) Flexio_Uart_Ip_apUserConfig/23 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741823 (estimated locally) body optimize_size
  Called by: 
  Calls: Flexio_Uart_Ip_SetShifterInterrupt/36 (230317619 (estimated locally),0.21 per call) Flexio_Uart_Ip_EnableReceiver/38 (697932184 (estimated locally),0.65 per call) SchM_Exit_Uart_UART_EXCLUSIVE_AREA_06/68 (697932184 (estimated locally),0.65 per call) SchM_Exit_Uart_UART_EXCLUSIVE_AREA_06/68 (375809640 (estimated locally),0.35 per call) SchM_Enter_Uart_UART_EXCLUSIVE_AREA_06/67 (1073741823 (estimated locally),1.00 per call) DevAssert/20 (1073741823 (estimated locally),1.00 per call) DevAssert/20 (1073741823 (estimated locally),1.00 per call) DevAssert/20 (1073741823 (estimated locally),1.00 per call) DevAssert/20 (1073741823 (estimated locally),1.00 per call) DevAssert/20 (1073741823 (estimated locally),1.00 per call) DevAssert/20 (1073741823 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_SyncSend/44 (Flexio_Uart_Ip_SyncSend) @061e5ee0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) Flexio_Uart_Ip_apUserConfig/23 (read) 
  Referring: 
  Availability: available
  Function flags: count:13681867 (estimated locally) body optimize_size
  Called by: 
  Calls: Flexio_Mcl_Ip_ClearTimerStatus/51 (8893214 (estimated locally),0.65 per call) Flexio_Uart_Ip_CheckTimeout.constprop.0/78 (8893214 (estimated locally),0.65 per call) Flexio_Uart_Ip_CheckTimeout.constprop.0/78 (119227247 (estimated locally),8.71 per call) Flexio_Uart_Ip_CheckTimeout.constprop.0/78 (1014686025 (estimated locally),74.16 per call) Flexio_Mcl_Ip_GetShifterStatus/54 (1073741824 (estimated locally),78.48 per call) Flexio_Uart_Ip_WriteData/30 (114863530 (estimated locally),8.40 per call) Flexio_Uart_Ip_StartTimeout.constprop.0/79 (8893213 (estimated locally),0.65 per call) Flexio_Uart_Ip_SetTimerControl.constprop.0/84 (8893213 (estimated locally),0.65 per call) Flexio_Uart_Ip_SetShifterInterrupt/36 (8893213 (estimated locally),0.65 per call) SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05/66 (8893213 (estimated locally),0.65 per call) SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05/66 (4788653 (estimated locally),0.35 per call) SchM_Enter_Uart_UART_EXCLUSIVE_AREA_05/65 (13681867 (estimated locally),1.00 per call) DevAssert/20 (13681867 (estimated locally),1.00 per call) DevAssert/20 (13681867 (estimated locally),1.00 per call) DevAssert/20 (13681867 (estimated locally),1.00 per call) DevAssert/20 (13681867 (estimated locally),1.00 per call) DevAssert/20 (13681867 (estimated locally),1.00 per call) DevAssert/20 (13681867 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_GetStatus/43 (Flexio_Uart_Ip_GetStatus) @061e5b60
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) Flexio_Uart_Ip_apUserConfig/23 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: Flexio_Uart_Ip_Deinit/41 (1073741824 (estimated locally),9.35 per call) 
  Calls: DevAssert/20 (1073741824 (estimated locally),1.00 per call) DevAssert/20 (1073741824 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_AsyncSend/42 (Flexio_Uart_Ip_AsyncSend) @061e58c0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) Flexio_Uart_Ip_apUserConfig/23 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741823 (estimated locally) body optimize_size
  Called by: 
  Calls: Flexio_Uart_Ip_SetShifterInterrupt/36 (230317619 (estimated locally),0.21 per call) Flexio_Uart_Ip_SetTimerControl.constprop.0/84 (697932184 (estimated locally),0.65 per call) SchM_Exit_Uart_UART_EXCLUSIVE_AREA_04/64 (697932184 (estimated locally),0.65 per call) SchM_Exit_Uart_UART_EXCLUSIVE_AREA_04/64 (375809640 (estimated locally),0.35 per call) SchM_Enter_Uart_UART_EXCLUSIVE_AREA_04/63 (1073741823 (estimated locally),1.00 per call) DevAssert/20 (1073741823 (estimated locally),1.00 per call) DevAssert/20 (1073741823 (estimated locally),1.00 per call) DevAssert/20 (1073741823 (estimated locally),1.00 per call) DevAssert/20 (1073741823 (estimated locally),1.00 per call) DevAssert/20 (1073741823 (estimated locally),1.00 per call) DevAssert/20 (1073741823 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_Deinit/41 (Flexio_Uart_Ip_Deinit) @061e5540
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) Flexio_Uart_Ip_apStateStructuresArray/24 (write) 
  Referring: 
  Availability: available
  Function flags: count:114863530 (estimated locally) body optimize_size
  Called by: 
  Calls: Flexio_Mcl_Ip_SetSoftwareReset/62 (37904965 (estimated locally),0.33 per call) Flexio_Mcl_Ip_SetSoftwareReset/62 (37904965 (estimated locally),0.33 per call) Flexio_Uart_Ip_SetShifterInterrupt/36 (37904965 (estimated locally),0.33 per call) Flexio_Uart_Ip_CheckTimeout.constprop.0/78 (114863531 (estimated locally),1.00 per call) Flexio_Uart_Ip_CheckTimeout.constprop.0/78 (1014686026 (estimated locally),8.83 per call) Flexio_Uart_Ip_GetStatus/43 (1073741824 (estimated locally),9.35 per call) Flexio_Uart_Ip_StartTimeout.constprop.0/79 (114863530 (estimated locally),1.00 per call) DevAssert/20 (114863530 (estimated locally),1.00 per call) DevAssert/20 (114863530 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_GetBaudRate/40 (Flexio_Uart_Ip_GetBaudRate) @061e51c0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: DevAssert/20 (1073741824 (estimated locally),1.00 per call) DevAssert/20 (1073741824 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_Init/39 (Flexio_Uart_Ip_Init) @061b7e00
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) Flexio_Uart_Ip_apStateStructuresArray/24 (write) Flexio_Uart_Ip_apUserConfig/23 (write) 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Flexio_Uart_Ip_ConfigureRx/27 (708669601 (estimated locally),0.66 per call) Flexio_Uart_Ip_ConfigureTx/26 (365072224 (estimated locally),0.34 per call) DevAssert/20 (1073741824 (estimated locally),1.00 per call) DevAssert/20 (1073741824 (estimated locally),1.00 per call) DevAssert/20 (1073741824 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_EnableReceiver/38 (Flexio_Uart_Ip_EnableReceiver) @061b7620
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: Flexio_Uart_Ip_AsyncReceive/45 (697932184 (estimated locally),0.65 per call) Flexio_Uart_Ip_SetupReceiveData/37 (1073741824 (estimated locally),1.00 per call) 
  Calls: Flexio_Uart_Ip_SetTimerControl.constprop.0/84 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetShifterMode.constprop.0/81 (1073741824 (estimated locally),1.00 per call) Flexio_Mcl_Ip_ClearShifterStatus/52 (1073741824 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_SetupReceiveData/37 (Flexio_Uart_Ip_SetupReceiveData) @061b7000
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: Flexio_Uart_Ip_SyncReceive/46 (13097219 (estimated locally),0.65 per call) 
  Calls: Flexio_Uart_Ip_EnableReceiver/38 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetShifterInterrupt/36 (1073741824 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_SetShifterInterrupt/36 (Flexio_Uart_Ip_SetShifterInterrupt) @061b7d20
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: Flexio_Uart_Ip_AsyncReceive/45 (230317619 (estimated locally),0.21 per call) Flexio_Uart_Ip_SyncSend/44 (8893213 (estimated locally),0.65 per call) Flexio_Uart_Ip_Deinit/41 (37904965 (estimated locally),0.33 per call) Flexio_Uart_Ip_AsyncSend/42 (230317619 (estimated locally),0.21 per call) Flexio_Uart_Ip_SetupReceiveData/37 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_EndTransfer/28 (1073741824 (estimated locally),1.00 per call) 
  Calls: Flexio_Mcl_Ip_SetShifterErrorInterrupt/58 (1073741824 (estimated locally),1.00 per call) Flexio_Mcl_Ip_SetShifterInterrupt/57 (1073741824 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_CheckShifterErrorStatus/35 (Flexio_Uart_Ip_CheckShifterErrorStatus) @061b7a80
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: Flexio_Uart_Ip_SyncReceive/46 (114863531 (estimated locally),5.70 per call) 
  Calls: Flexio_Mcl_Ip_ClearShifterErrorStatus/53 (354334800 (estimated locally),0.33 per call) Flexio_Mcl_Ip_GetShifterErrorStatus/71 (1073741824 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_CheckRxOperation/34 (Flexio_Uart_Ip_CheckRxOperation) @061b77e0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) Flexio_Uart_Ip_apUserConfig/23 (read) 
  Referring: 
  Availability: local
  Function flags: count:1073741821 (estimated locally) body local optimize_size
  Called by: Flexio_Uart_Ip_IrqHandler/25 (585148489 (estimated locally),0.54 per call) 
  Calls: Flexio_Uart_Ip_StopTransfer/29 (177167400 (estimated locally),0.16 per call) Flexio_Mcl_Ip_ClearShifterStatus/52 (177167400 (estimated locally),0.16 per call) Flexio_Uart_Ip_ReadData/33 (134217728 (estimated locally),0.13 per call) Flexio_Mcl_Ip_ClearShifterStatus/52 (134217728 (estimated locally),0.13 per call) Flexio_Mcl_Ip_ClearShifterErrorStatus/53 (177167399 (estimated locally),0.16 per call) 
   Indirect call(42165842 (estimated locally),0.04 per call)  Num speculative call targets: 0
   Indirect call(46976205 (estimated locally),0.04 per call)  Num speculative call targets: 0
   Indirect call(251792459 (estimated locally),0.23 per call)  Num speculative call targets: 0
Flexio_Uart_Ip_ReadData/33 (Flexio_Uart_Ip_ReadData) @061b7540
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) Flexio_Uart_Ip_apUserConfig/23 (read) 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: Flexio_Uart_Ip_SyncReceive/46 (110659526 (estimated locally),5.49 per call) Flexio_Uart_Ip_CheckRxOperation/34 (134217728 (estimated locally),0.13 per call) 
  Calls: DevAssert/20 (1073741824 (estimated locally),1.00 per call) DevAssert/20 (1073741824 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_CheckCompleteTransferData/32 (Flexio_Uart_Ip_CheckCompleteTransferData) @061b71c0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) Flexio_Uart_Ip_apUserConfig/23 (read) 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: Flexio_Uart_Ip_CheckTxOperation/31 (67108864 (estimated locally),0.06 per call) 
  Calls: Flexio_Mcl_Ip_SetTimerInterrupt/56 (116930483 (estimated locally),0.11 per call) Flexio_Mcl_Ip_SetShifterInterrupt/57 (116930483 (estimated locally),0.11 per call) Flexio_Mcl_Ip_ClearTimerStatus/51 (354334800 (estimated locally),0.33 per call) 
   Indirect call(375809640 (estimated locally),0.35 per call)  Num speculative call targets: 0
Flexio_Uart_Ip_CheckTxOperation/31 (Flexio_Uart_Ip_CheckTxOperation) @05e2ed20
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) Flexio_Uart_Ip_apUserConfig/23 (read) 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: Flexio_Uart_Ip_IrqHandler/25 (301440135 (estimated locally),0.28 per call) 
  Calls: Flexio_Uart_Ip_CheckCompleteTransferData/32 (67108864 (estimated locally),0.06 per call) Flexio_Uart_Ip_WriteData/30 (67108864 (estimated locally),0.06 per call) Flexio_Mcl_Ip_ClearShifterStatus/52 (67108864 (estimated locally),0.06 per call) Flexio_Uart_Ip_SetShifterStartBit.constprop.0/80 (29675540 (estimated locally),0.03 per call) Flexio_Mcl_Ip_GetShifterStatus/54 (89925878 (estimated locally),0.08 per call) Flexio_Uart_Ip_StopTransfer/29 (89925878 (estimated locally),0.08 per call) Flexio_Mcl_Ip_ClearShifterStatus/52 (89925878 (estimated locally),0.08 per call) Flexio_Mcl_Ip_ClearTimerStatus/51 (88583700 (estimated locally),0.08 per call) 
   Indirect call(62948115 (estimated locally),0.06 per call)  Num speculative call targets: 0
Flexio_Uart_Ip_WriteData/30 (Flexio_Uart_Ip_WriteData) @05e2e7e0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: Flexio_Uart_Ip_apUserConfig/23 (read) Flexio_Uart_Ip_apStateStructuresArray/24 (read) 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: Flexio_Uart_Ip_SyncSend/44 (114863530 (estimated locally),8.40 per call) Flexio_Uart_Ip_CheckTxOperation/31 (67108864 (estimated locally),0.06 per call) 
  Calls: DevAssert/20 (1073741824 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_StopTransfer/29 (Flexio_Uart_Ip_StopTransfer) @05e2eee0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: Flexio_Uart_Ip_apUserConfig/23 (read) Flexio_Uart_Ip_apStateStructuresArray/24 (read) 
  Referring: 
  Availability: local
  Function flags: count:859859949 (estimated locally) body local optimize_size
  Called by: Flexio_Uart_Ip_AbortTransferData/47 (177167400 (estimated locally),0.16 per call) Flexio_Uart_Ip_CheckRxOperation/34 (177167400 (estimated locally),0.16 per call) Flexio_Uart_Ip_CheckTxOperation/31 (89925878 (estimated locally),0.08 per call) 
  Calls: Flexio_Uart_Ip_SetShifterMode.constprop.0/81 (174035653 (estimated locally),0.20 per call) Flexio_Uart_Ip_SetShifterStartBit.constprop.0/80 (174035653 (estimated locally),0.20 per call) Flexio_Mcl_Ip_ClearShifterErrorStatus/53 (859859951 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetShifterMode.constprop.0/81 (859859951 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetTimerControl.constprop.0/84 (859859951 (estimated locally),1.00 per call) Flexio_Uart_Ip_CheckTimeout.constprop.0/78 (174035654 (estimated locally),0.20 per call) Flexio_Mcl_Ip_GetShifterStatus/54 (114863531 (estimated locally),0.13 per call) Flexio_Uart_Ip_CheckTimeout.constprop.0/78 (1014686025 (estimated locally),1.18 per call) Flexio_Mcl_Ip_GetShifterStatus/54 (1073741824 (estimated locally),1.25 per call) Flexio_Uart_Ip_CheckTimeout.constprop.0/78 (522717052 (estimated locally),0.61 per call) Flexio_Mcl_Ip_GetTimerStatus/55 (553139738 (estimated locally),0.64 per call) Flexio_Uart_Ip_StartTimeout.constprop.0/79 (174035653 (estimated locally),0.20 per call) Flexio_Uart_Ip_EndTransfer/28 (859859949 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_EndTransfer/28 (Flexio_Uart_Ip_EndTransfer) @05e2ec40
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: Flexio_Uart_Ip_apStateStructuresArray/24 (read) 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: Flexio_Uart_Ip_StopTransfer/29 (859859949 (estimated locally),1.00 per call) 
  Calls: Flexio_Mcl_Ip_SetTimerInterrupt/56 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetShifterInterrupt/36 (1073741824 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_ConfigureRx/27 (Flexio_Uart_Ip_ConfigureRx) @05e2e9a0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: Flexio_Uart_Ip_Init/39 (708669601 (estimated locally),0.66 per call) 
  Calls: Flexio_Uart_Ip_SetPinTimerControl.constprop.0/82 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetTimerTrigger.constprop.0/83 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetTimerControl.constprop.0/84 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetTimerCondition.constprop.0/85 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetTimerStartStopBitConfig.constprop.0/86 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetTimerConfig.constprop.0/87 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetPinShifterControl.constprop.0/88 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetShifterControl.constprop.0/89 (1073741824 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_ConfigureTx/26 (Flexio_Uart_Ip_ConfigureTx) @05e2e700
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: Flexio_Uart_Ip_Init/39 (365072224 (estimated locally),0.34 per call) 
  Calls: Flexio_Uart_Ip_SetPinTimerControl.constprop.0/82 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetTimerTrigger.constprop.0/83 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetTimerControl.constprop.0/84 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetTimerCondition.constprop.0/85 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetTimerStartStopBitConfig.constprop.0/86 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetTimerConfig.constprop.0/87 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetPinShifterControl.constprop.0/88 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetShifterControl.constprop.0/89 (1073741824 (estimated locally),1.00 per call) 
Flexio_Uart_Ip_IrqHandler/25 (Flexio_Uart_Ip_IrqHandler) @05e2e460
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Flexio_Uart_Ip_apUserConfig/23 (read) 
  Referring: 
  Availability: available
  Function flags: count:1073741823 (estimated locally) body optimize_size
  Called by: 
  Calls: Flexio_Uart_Ip_CheckRxOperation/34 (585148489 (estimated locally),0.54 per call) Flexio_Uart_Ip_CheckTxOperation/31 (301440135 (estimated locally),0.28 per call) Flexio_Mcl_Ip_ClearShifterErrorStatus/53 (187153200 (estimated locally),0.17 per call) Flexio_Mcl_Ip_ClearShifterStatus/52 (187153200 (estimated locally),0.17 per call) Flexio_Mcl_Ip_ClearTimerStatus/51 (187153200 (estimated locally),0.17 per call) 
Flexio_Uart_Ip_apStateStructuresArray/24 (Flexio_Uart_Ip_apStateStructuresArray) @05e29120
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: Flexio_Uart_Ip_EndTransfer/28 (read) Flexio_Uart_Ip_CheckCompleteTransferData/32 (read) Flexio_Uart_Ip_ReadData/33 (read) Flexio_Uart_Ip_SetBaudRate/48 (read) Flexio_Uart_Ip_WriteData/30 (read) Flexio_Uart_Ip_StopTransfer/29 (read) Flexio_Uart_Ip_SetTxBuffer/49 (read) Flexio_Uart_Ip_AbortTransferData/47 (read) Flexio_Uart_Ip_CheckRxOperation/34 (read) Flexio_Uart_Ip_CheckShifterErrorStatus/35 (read) Flexio_Uart_Ip_Init/39 (read) Flexio_Uart_Ip_AsyncSend/42 (read) Flexio_Uart_Ip_Init/39 (write) Flexio_Uart_Ip_GetBaudRate/40 (read) Flexio_Uart_Ip_GetStatus/43 (read) Flexio_Uart_Ip_Deinit/41 (write) Flexio_Uart_Ip_SyncSend/44 (read) Flexio_Uart_Ip_CheckTxOperation/31 (read) Flexio_Uart_Ip_AsyncReceive/45 (read) Flexio_Uart_Ip_SyncReceive/46 (read) Flexio_Uart_Ip_Deinit/41 (read) Flexio_Uart_Ip_SetRxBuffer/50 (read) 
  Availability: available
  Varpool flags:
Flexio_Uart_Ip_apUserConfig/23 (Flexio_Uart_Ip_apUserConfig) @05e29090
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: Flexio_Uart_Ip_CheckTxOperation/31 (read) Flexio_Uart_Ip_CheckCompleteTransferData/32 (read) Flexio_Uart_Ip_ReadData/33 (read) Flexio_Uart_Ip_SyncReceive/46 (read) Flexio_Uart_Ip_WriteData/30 (read) Flexio_Uart_Ip_StopTransfer/29 (read) Flexio_Uart_Ip_AbortTransferData/47 (read) Flexio_Uart_Ip_CheckRxOperation/34 (read) Flexio_Uart_Ip_IrqHandler/25 (read) Flexio_Uart_Ip_Init/39 (write) Flexio_Uart_Ip_AsyncSend/42 (read) Flexio_Uart_Ip_GetStatus/43 (read) Flexio_Uart_Ip_SyncSend/44 (read) Flexio_Uart_Ip_AsyncReceive/45 (read) Flexio_Uart_Ip_SetBaudRate/48 (read) 
  Availability: available
  Varpool flags:
Flexio_Uart_Ip_apStateStructure/21 (Flexio_Uart_Ip_apStateStructure) @05e52f30
  Type: variable definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Varpool flags:
DevAssert/20 (DevAssert) @05e54700
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:21262216 (estimated locally) body local optimize_size
  Called by: Flexio_Uart_Ip_SetRxBuffer/50 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetRxBuffer/50 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetRxBuffer/50 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetTxBuffer/49 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetTxBuffer/49 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetTxBuffer/49 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetBaudRate/48 (154312805 (estimated locally),0.14 per call) Flexio_Uart_Ip_SetBaudRate/48 (230317619 (estimated locally),0.21 per call) Flexio_Uart_Ip_SetBaudRate/48 (1073741823 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetBaudRate/48 (1073741823 (estimated locally),1.00 per call) Flexio_Uart_Ip_SetBaudRate/48 (1073741823 (estimated locally),1.00 per call) Flexio_Uart_Ip_AbortTransferData/47 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_AbortTransferData/47 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_AbortTransferData/47 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_SyncReceive/46 (20149567 (estimated locally),1.00 per call) Flexio_Uart_Ip_SyncReceive/46 (20149567 (estimated locally),1.00 per call) Flexio_Uart_Ip_SyncReceive/46 (20149567 (estimated locally),1.00 per call) Flexio_Uart_Ip_SyncReceive/46 (20149567 (estimated locally),1.00 per call) Flexio_Uart_Ip_SyncReceive/46 (20149567 (estimated locally),1.00 per call) Flexio_Uart_Ip_SyncReceive/46 (20149567 (estimated locally),1.00 per call) Flexio_Uart_Ip_AsyncReceive/45 (1073741823 (estimated locally),1.00 per call) Flexio_Uart_Ip_AsyncReceive/45 (1073741823 (estimated locally),1.00 per call) Flexio_Uart_Ip_AsyncReceive/45 (1073741823 (estimated locally),1.00 per call) Flexio_Uart_Ip_AsyncReceive/45 (1073741823 (estimated locally),1.00 per call) Flexio_Uart_Ip_AsyncReceive/45 (1073741823 (estimated locally),1.00 per call) Flexio_Uart_Ip_AsyncReceive/45 (1073741823 (estimated locally),1.00 per call) Flexio_Uart_Ip_SyncSend/44 (13681867 (estimated locally),1.00 per call) Flexio_Uart_Ip_SyncSend/44 (13681867 (estimated locally),1.00 per call) Flexio_Uart_Ip_SyncSend/44 (13681867 (estimated locally),1.00 per call) Flexio_Uart_Ip_SyncSend/44 (13681867 (estimated locally),1.00 per call) Flexio_Uart_Ip_SyncSend/44 (13681867 (estimated locally),1.00 per call) Flexio_Uart_Ip_SyncSend/44 (13681867 (estimated locally),1.00 per call) Flexio_Uart_Ip_Deinit/41 (114863530 (estimated locally),1.00 per call) Flexio_Uart_Ip_Deinit/41 (114863530 (estimated locally),1.00 per call) Flexio_Uart_Ip_GetStatus/43 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_GetStatus/43 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_AsyncSend/42 (1073741823 (estimated locally),1.00 per call) Flexio_Uart_Ip_AsyncSend/42 (1073741823 (estimated locally),1.00 per call) Flexio_Uart_Ip_AsyncSend/42 (1073741823 (estimated locally),1.00 per call) Flexio_Uart_Ip_AsyncSend/42 (1073741823 (estimated locally),1.00 per call) Flexio_Uart_Ip_AsyncSend/42 (1073741823 (estimated locally),1.00 per call) Flexio_Uart_Ip_AsyncSend/42 (1073741823 (estimated locally),1.00 per call) Flexio_Uart_Ip_GetBaudRate/40 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_GetBaudRate/40 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_Init/39 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_Init/39 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_Init/39 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_ReadData/33 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_ReadData/33 (1073741824 (estimated locally),1.00 per call) Flexio_Uart_Ip_WriteData/30 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Uart_Ip_CheckTimeout/19 (Flexio_Uart_Ip_CheckTimeout) @05e24460
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 
Flexio_Uart_Ip_StartTimeout/18 (Flexio_Uart_Ip_StartTimeout) @05e241c0
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 
Flexio_Uart_Ip_SetShifterStartBit/12 (Flexio_Uart_Ip_SetShifterStartBit) @05e1f1c0
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 
Flexio_Uart_Ip_SetShifterMode/11 (Flexio_Uart_Ip_SetShifterMode) @05e19e00
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 
Flexio_Uart_Ip_SetPinTimerControl/9 (Flexio_Uart_Ip_SetPinTimerControl) @05e19700
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 
Flexio_Uart_Ip_SetTimerTrigger/8 (Flexio_Uart_Ip_SetTimerTrigger) @05e191c0
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 
Flexio_Uart_Ip_SetTimerControl/7 (Flexio_Uart_Ip_SetTimerControl) @05db8c40
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:1073741824 (estimated locally) body icf_merged optimize_size
  Called by: 
  Calls: 
Flexio_Uart_Ip_SetTimerCondition/6 (Flexio_Uart_Ip_SetTimerCondition) @05db88c0
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 
Flexio_Uart_Ip_SetTimerStartStopBitConfig/5 (Flexio_Uart_Ip_SetTimerStartStopBitConfig) @05db8460
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 
Flexio_Uart_Ip_SetTimerConfig/4 (Flexio_Uart_Ip_SetTimerConfig) @05db8000
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 
Flexio_Uart_Ip_SetPinShifterControl/2 (Flexio_Uart_Ip_SetPinShifterControl) @05db47e0
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 
Flexio_Uart_Ip_SetShifterControl/1 (Flexio_Uart_Ip_SetShifterControl) @05db42a0
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: 

;; Function DevAssert (DevAssert, funcdef_no=20, decl_uid=6219, cgraph_uid=21, symbol_order=20)

Modification phase of node DevAssert/20
DevAssert (volatile boolean x)
{
  _Bool x.3_1;

  <bb 2> [local count: 21262216]:
  # DEBUG BEGIN_STMT
  x.3_1 ={v} x;
  if (x.3_1 != 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 5> [local count: 10631108]:

  <bb 3> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  __asm__ __volatile__("BKPT #0");
  # DEBUG BEGIN_STMT

  <bb 6> [local count: 1073741824]:
  goto <bb 3>; [100.00%]

  <bb 4> [local count: 10631108]:
  # DEBUG BEGIN_STMT
  return;

}



;; Function Flexio_Uart_Ip_WriteData (Flexio_Uart_Ip_WriteData, funcdef_no=26, decl_uid=6255, cgraph_uid=27, symbol_order=30)

Modification phase of node Flexio_Uart_Ip_WriteData/30
Flexio_Uart_Ip_WriteData (const uint8 Channel)
{
  uint32 Data32b;
  struct Flexio_Uart_Ip_StateStructureType * UartState;
  const struct Flexio_Uart_Ip_UserConfigType * UartUserCfg;
  int _1;
  const uint8 * _2;
  _Bool _3;
  <unnamed type> _4;
  const uint8 * _5;
  unsigned char _6;
  const uint8 * _7;
  long unsigned int _8;
  long unsigned int _9;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG Data32b => 0
  # DEBUG BEGIN_STMT
  _1 = (int) Channel_12(D);
  UartUserCfg_14 = Flexio_Uart_Ip_apUserConfig[_1];
  # DEBUG UartUserCfg => UartUserCfg_14
  # DEBUG BEGIN_STMT
  UartState_15 = Flexio_Uart_Ip_apStateStructuresArray[_1];
  # DEBUG UartState => UartState_15
  # DEBUG BEGIN_STMT
  _2 = UartState_15->TxData;
  _3 = _2 != 0B;
  DevAssert (_3);
  # DEBUG BEGIN_STMT
  # DEBUG Base => 1077035008B
  # DEBUG BEGIN_STMT
  _4 = UartUserCfg_14->BitCount;
  if (_4 == 8)
    goto <bb 3>; [34.00%]
  else
    goto <bb 4>; [66.00%]

  <bb 3> [local count: 365072224]:
  # DEBUG BEGIN_STMT
  _5 = UartState_15->TxData;
  _6 ={v} *_5;
  Data32b_17 = (uint32) _6;
  # DEBUG Data32b => Data32b_17
  # DEBUG BEGIN_STMT
  _7 = _5 + 1;
  UartState_15->TxData = _7;
  # DEBUG BEGIN_STMT
  _8 ={v} UartState_15->RemainingBytes;
  _9 = _8 + 4294967295;
  UartState_15->RemainingBytes ={v} _9;

  <bb 4> [local count: 1073741824]:
  # Data32b_10 = PHI <0(2), Data32b_17(3)>
  # DEBUG Data32b => Data32b_10
  # DEBUG BEGIN_STMT
  # DEBUG Base => 1077035008B
  # DEBUG Shifter => Channel_12(D)
  # DEBUG Value => Data32b_10
  # DEBUG INLINE_ENTRY Flexio_Uart_Ip_WriteShifterBuffer
  # DEBUG BEGIN_STMT
  MEM[(struct FLEXIO_Type *)1077035008B].SHIFTBUF[_1] ={v} Data32b_10;
  # DEBUG Base => NULL
  # DEBUG Shifter => NULL
  # DEBUG Value => NULL
  return;

}



;; Function Flexio_Uart_Ip_ReadData (Flexio_Uart_Ip_ReadData, funcdef_no=29, decl_uid=6245, cgraph_uid=30, symbol_order=33)

Modification phase of node Flexio_Uart_Ip_ReadData/33
Flexio_Uart_Ip_ReadData (const uint8 Channel)
{
  uint32 Data;
  const struct Flexio_Uart_Ip_UserConfigType * UartUserCfg;
  struct Flexio_Uart_Ip_StateStructureType * UartState;
  uint32 Data32b;
  int _1;
  long unsigned int _2;
  _Bool _3;
  volatile uint8 * _4;
  _Bool _5;
  <unnamed type> _6;
  long unsigned int _7;
  volatile uint8 * _8;
  unsigned char _9;
  volatile uint8 * _10;
  volatile uint8 * _11;
  long unsigned int _12;
  long unsigned int _13;
  long unsigned int _25;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _1 = (int) Channel_15(D);
  UartState_17 = Flexio_Uart_Ip_apStateStructuresArray[_1];
  # DEBUG UartState => UartState_17
  # DEBUG BEGIN_STMT
  UartUserCfg_18 = Flexio_Uart_Ip_apUserConfig[_1];
  # DEBUG UartUserCfg => UartUserCfg_18
  # DEBUG BEGIN_STMT
  _2 ={v} UartState_17->RemainingBytes;
  _3 = _2 != 0;
  DevAssert (_3);
  # DEBUG BEGIN_STMT
  _4 = UartState_17->RxData;
  _5 = _4 != 0B;
  DevAssert (_5);
  # DEBUG BEGIN_STMT
  # DEBUG Base => 1077035008B
  # DEBUG BEGIN_STMT
  # DEBUG Base => 1077035008B
  # DEBUG Shifter => Channel_15(D)
  # DEBUG INLINE_ENTRY Flexio_Uart_Ip_ReadShifterBuffer
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _25 ={v} MEM[(const struct FLEXIO_Type *)1077035008B].SHIFTBUF[_1];
  Data_26 = _25 & 4278190080;
  # DEBUG Data => Data_26
  # DEBUG BEGIN_STMT
  # DEBUG Base => NULL
  # DEBUG Shifter => NULL
  # DEBUG Data => NULL
  # DEBUG Data32b => Data_26
  # DEBUG BEGIN_STMT
  _6 = UartUserCfg_18->BitCount;
  _7 = 32 - _6;
  Data32b_21 = Data_26 >> _7;
  # DEBUG Data32b => Data32b_21
  # DEBUG BEGIN_STMT
  if (_6 == 8)
    goto <bb 3>; [34.00%]
  else
    goto <bb 4>; [66.00%]

  <bb 3> [local count: 365072224]:
  # DEBUG BEGIN_STMT
  _8 = UartState_17->RxData;
  _9 = (unsigned char) Data32b_21;
  *_8 ={v} _9;
  # DEBUG BEGIN_STMT
  _10 = UartState_17->RxData;
  _11 = _10 + 1;
  UartState_17->RxData = _11;
  # DEBUG BEGIN_STMT
  _12 ={v} UartState_17->RemainingBytes;
  _13 = _12 + 4294967295;
  UartState_17->RemainingBytes ={v} _13;

  <bb 4> [local count: 1073741824]:
  return;

}



;; Function Flexio_Uart_Ip_SetShifterInterrupt (Flexio_Uart_Ip_SetShifterInterrupt, funcdef_no=32, decl_uid=6264, cgraph_uid=33, symbol_order=36)

Modification phase of node Flexio_Uart_Ip_SetShifterInterrupt/36
Flexio_Uart_Ip_SetShifterInterrupt (const uint8 Channel, boolean Enable)
{
  int _1;
  unsigned int _2;
  unsigned char _3;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG Base => 1077035008B
  # DEBUG BEGIN_STMT
  _1 = (int) Channel_4(D);
  _2 = 1 << _1;
  _3 = (unsigned char) _2;
  Flexio_Mcl_Ip_SetShifterInterrupt (1077035008B, _3, Enable_6(D));
  # DEBUG BEGIN_STMT
  Flexio_Mcl_Ip_SetShifterErrorInterrupt (1077035008B, _3, Enable_6(D));
  return;

}



;; Function Flexio_Uart_Ip_SetTimerCondition.constprop (Flexio_Uart_Ip_SetTimerCondition.constprop.0, funcdef_no=51, decl_uid=6858, cgraph_uid=82, symbol_order=85)

Modification phase of node Flexio_Uart_Ip_SetTimerCondition.constprop/85
Adjusting mask for param 2 to 0x6
Setting value range of param 2 (now 1) [2, 4]
Flexio_Uart_Ip_SetTimerCondition.constprop (uint8 Timer, Flexio_Mcl_Ip_TimerEnableType Enable)
{
  struct FLEXIO_Type * Base;
  Flexio_Mcl_Ip_TimerDisableType Disable;
  int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _6;
  long unsigned int _7;
  long unsigned int _8;
  long unsigned int _9;
  long unsigned int _10;
  long unsigned int _11;
  long unsigned int _12;
  long unsigned int _13;

  <bb 3> [local count: 1073741824]:
  # DEBUG Disable => 2
  # DEBUG Base => 1077035008B

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _2 = (int) Timer_1(D);
  _3 ={v} MEM[(struct FLEXIO_Type *)1077035008B].TIMCFG[_2];
  _4 = _3 & 4294965503;
  _6 = Enable_5(D) << 8;
  _7 = _6 & 1792;
  _8 = _4 | _7;
  MEM[(struct FLEXIO_Type *)1077035008B].TIMCFG[_2] ={v} _8;
  # DEBUG BEGIN_STMT
  _9 ={v} MEM[(struct FLEXIO_Type *)1077035008B].TIMCFG[_2];
  _10 = _9 & 4294938623;
  _11 = 8192;
  _12 = _11 & 28672;
  _13 = _10 | _12;
  MEM[(struct FLEXIO_Type *)1077035008B].TIMCFG[_2] ={v} _13;
  return;

}



;; Function Flexio_Uart_Ip_SetTimerStartStopBitConfig.constprop (Flexio_Uart_Ip_SetTimerStartStopBitConfig.constprop.0, funcdef_no=50, decl_uid=6859, cgraph_uid=83, symbol_order=86)

Modification phase of node Flexio_Uart_Ip_SetTimerStartStopBitConfig.constprop/86
Flexio_Uart_Ip_SetTimerStartStopBitConfig.constprop (uint8 Timer)
{
  struct FLEXIO_Type * Base;
  Flexio_Mcl_Ip_TimerStartType Start;
  Flexio_Mcl_Ip_TimerStopType Stop;
  int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;
  long unsigned int _7;
  long unsigned int _8;
  long unsigned int _9;
  long unsigned int _10;
  long unsigned int _11;
  long unsigned int _12;

  <bb 3> [local count: 1073741824]:
  # DEBUG Stop => 2
  # DEBUG Start => 1
  # DEBUG Base => 1077035008B

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _2 = (int) Timer_1(D);
  _3 ={v} MEM[(struct FLEXIO_Type *)1077035008B].TIMCFG[_2];
  _4 = _3 & 4294967293;
  _5 = 2;
  _6 = _5 & 2;
  _7 = _4 | _6;
  MEM[(struct FLEXIO_Type *)1077035008B].TIMCFG[_2] ={v} _7;
  # DEBUG BEGIN_STMT
  _8 ={v} MEM[(struct FLEXIO_Type *)1077035008B].TIMCFG[_2];
  _9 = _8 & 4294967247;
  _10 = 32;
  _11 = _10 & 48;
  _12 = _9 | _11;
  MEM[(struct FLEXIO_Type *)1077035008B].TIMCFG[_2] ={v} _12;
  return;

}



;; Function Flexio_Uart_Ip_SetTimerConfig.constprop (Flexio_Uart_Ip_SetTimerConfig.constprop.0, funcdef_no=49, decl_uid=6860, cgraph_uid=84, symbol_order=87)

Modification phase of node Flexio_Uart_Ip_SetTimerConfig.constprop/87
Adjusting mask for param 2 to 0x4
Adjusting mask for param 4 to 0x2
Setting value range of param 2 (now 1) [0, 4]
Setting value range of param 4 (now 3) [0, 2]
Flexio_Uart_Ip_SetTimerConfig.constprop (uint8 Timer, Flexio_Mcl_Ip_TimerResetType Reset, Flexio_Uart_Ip_TimerDecrementType Decrement, Flexio_Mcl_Ip_TimerOutputType Output)
{
  struct FLEXIO_Type * Base;
  int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _6;
  long unsigned int _7;
  long unsigned int _8;
  long unsigned int _9;
  long unsigned int _10;
  long unsigned int _12;
  long unsigned int _13;
  long unsigned int _14;
  long unsigned int _15;
  long unsigned int _16;
  long unsigned int _18;
  long unsigned int _19;
  long unsigned int _20;

  <bb 3> [local count: 1073741824]:
  # DEBUG Base => 1077035008B

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _2 = (int) Timer_1(D);
  _3 ={v} MEM[(struct FLEXIO_Type *)1077035008B].TIMCFG[_2];
  _4 = _3 & 4294508543;
  _6 = Reset_5(D) << 16;
  _7 = _6 & 458752;
  _8 = _4 | _7;
  MEM[(struct FLEXIO_Type *)1077035008B].TIMCFG[_2] ={v} _8;
  # DEBUG BEGIN_STMT
  _9 ={v} MEM[(struct FLEXIO_Type *)1077035008B].TIMCFG[_2];
  _10 = _9 & 4287627263;
  _12 = Decrement_11(D) << 20;
  _13 = _12 & 7340032;
  _14 = _10 | _13;
  MEM[(struct FLEXIO_Type *)1077035008B].TIMCFG[_2] ={v} _14;
  # DEBUG BEGIN_STMT
  _15 ={v} MEM[(struct FLEXIO_Type *)1077035008B].TIMCFG[_2];
  _16 = _15 & 4244635647;
  _18 = Output_17(D) << 24;
  _19 = _18 & 50331648;
  _20 = _16 | _19;
  MEM[(struct FLEXIO_Type *)1077035008B].TIMCFG[_2] ={v} _20;
  return;

}



;; Function Flexio_Uart_Ip_EnableReceiver (Flexio_Uart_Ip_EnableReceiver, funcdef_no=34, decl_uid=6251, cgraph_uid=35, symbol_order=38)

Modification phase of node Flexio_Uart_Ip_EnableReceiver/38
Flexio_Uart_Ip_EnableReceiver (const uint8 Channel)
{
  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG Base => 1077035008B
  # DEBUG BEGIN_STMT
  Flexio_Mcl_Ip_ClearShifterStatus (1077035008B, Channel_2(D));
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetShifterMode (1077035008B, Channel_2(D), 1);
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_2(D), 1);
  return;

}



;; Function Flexio_Uart_Ip_StopTransfer (Flexio_Uart_Ip_StopTransfer, funcdef_no=25, decl_uid=6239, cgraph_uid=26, symbol_order=29)

Modification phase of node Flexio_Uart_Ip_StopTransfer/29
Flexio_Uart_Ip_StopTransfer (const uint8 Channel)
{
  uint32 ElapsedTicks;
  uint32 TimeoutTicks;
  uint32 StartTime;
  struct Flexio_Uart_Ip_StateStructureType * UartState;
  const struct Flexio_Uart_Ip_UserConfigType * UartUserCfg;
  int _1;
  <unnamed type> _2;
  <unnamed type> _3;
  _Bool _4;
  long unsigned int TimeoutTicks.0_5;
  _Bool _6;
  _Bool _7;
  long unsigned int TimeoutTicks.1_8;
  _Bool _9;
  _Bool _10;
  long unsigned int TimeoutTicks.2_11;
  _Bool _12;
  <unnamed type> _13;
  long unsigned int _42;

  <bb 2> [local count: 859859949]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _1 = (int) Channel_20(D);
  UartUserCfg_22 = Flexio_Uart_Ip_apUserConfig[_1];
  # DEBUG UartUserCfg => UartUserCfg_22
  # DEBUG BEGIN_STMT
  # DEBUG Base => 1077035008B
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  ElapsedTicks = 0;
  # DEBUG BEGIN_STMT
  UartState_24 = Flexio_Uart_Ip_apStateStructuresArray[_1];
  # DEBUG UartState => UartState_24
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_EndTransfer (Channel_20(D));
  # DEBUG BEGIN_STMT
  _2 ={v} UartState_24->Status;
  if (_2 == 516)
    goto <bb 3>; [20.24%]
  else
    goto <bb 12>; [79.76%]

  <bb 3> [local count: 174035653]:
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  # DEBUG BEGIN_STMT
  _3 = UartUserCfg_22->Direction;
  if (_3 == 1)
    goto <bb 15>; [34.00%]
  else
    goto <bb 16>; [66.00%]

  <bb 15> [local count: 59172123]:

  <bb 4> [local count: 553139738]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _4 = Flexio_Mcl_Ip_GetTimerStatus (1077035008B, Channel_20(D));
  if (_4 != 0)
    goto <bb 10>; [5.50%]
  else
    goto <bb 5>; [94.50%]

  <bb 5> [local count: 522717052]:
  TimeoutTicks.0_5 = TimeoutTicks;
  _6 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.0_5, 0);
  if (_6 != 0)
    goto <bb 10>; [5.50%]
  else
    goto <bb 17>; [94.50%]

  <bb 17> [local count: 493967614]:
  goto <bb 4>; [100.00%]

  <bb 16> [local count: 114863530]:

  <bb 6> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _7 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
  if (_7 != 0)
    goto <bb 8>; [5.50%]
  else
    goto <bb 7>; [94.50%]

  <bb 7> [local count: 1014686025]:
  TimeoutTicks.1_8 = TimeoutTicks;
  _9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.1_8, 0);
  if (_9 != 0)
    goto <bb 8>; [5.50%]
  else
    goto <bb 18>; [94.50%]

  <bb 18> [local count: 958878294]:
  goto <bb 6>; [100.00%]

  <bb 8> [local count: 114863531]:
  # DEBUG BEGIN_STMT
  _10 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_20(D));
  if (_10 != 0)
    goto <bb 9>; [50.00%]
  else
    goto <bb 10>; [50.00%]

  <bb 9> [local count: 57431766]:
  # DEBUG BEGIN_STMT
  # DEBUG Base => 1077035008B
  # DEBUG Shifter => Channel_20(D)
  # DEBUG INLINE_ENTRY Flexio_Uart_Ip_ReadShifterBuffer
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _42 ={v} MEM[(const struct FLEXIO_Type *)1077035008B].SHIFTBUF[_1];
  # DEBUG Data => _42 & 4278190080
  # DEBUG BEGIN_STMT

  <bb 10> [local count: 174035654]:
  # DEBUG Base => NULL
  # DEBUG Shifter => NULL
  # DEBUG Data => NULL
  # DEBUG BEGIN_STMT
  TimeoutTicks.2_11 = TimeoutTicks;
  _12 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.2_11, 0);
  if (_12 != 0)
    goto <bb 11>; [50.00%]
  else
    goto <bb 12>; [50.00%]

  <bb 11> [local count: 87017827]:
  # DEBUG BEGIN_STMT
  UartState_24->Status ={v} 518;

  <bb 12> [local count: 859859951]:
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_20(D), 0);
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetShifterMode (1077035008B, Channel_20(D), 0);
  # DEBUG BEGIN_STMT
  Flexio_Mcl_Ip_ClearShifterErrorStatus (1077035008B, Channel_20(D));
  # DEBUG BEGIN_STMT
  _13 = UartUserCfg_22->Direction;
  if (_13 == 1)
    goto <bb 13>; [20.24%]
  else
    goto <bb 14>; [79.76%]

  <bb 13> [local count: 174035653]:
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetShifterStartBit (1077035008B, Channel_20(D), 2);
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetShifterMode (1077035008B, Channel_20(D), 2);

  <bb 14> [local count: 859859952]:
  StartTime ={v} {CLOBBER};
  TimeoutTicks ={v} {CLOBBER};
  ElapsedTicks ={v} {CLOBBER};
  return;

}



;; Function Flexio_Uart_Ip_IrqHandler (Flexio_Uart_Ip_IrqHandler, funcdef_no=21, decl_uid=6132, cgraph_uid=22, symbol_order=25)

Modification phase of node Flexio_Uart_Ip_IrqHandler/25
Flexio_Uart_Ip_IrqHandler (uint8 Channel, uint8 ShifterMaskFlag, uint8 ShifterErrorMaskFlag, uint8 TimerMaskFlag)
{
  const struct Flexio_Uart_Ip_UserConfigType * UartUserCfg;
  int _1;
  <unnamed type> _2;

  <bb 2> [local count: 1073741823]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _1 = (int) Channel_4(D);
  UartUserCfg_6 = Flexio_Uart_Ip_apUserConfig[_1];
  # DEBUG UartUserCfg => UartUserCfg_6
  # DEBUG BEGIN_STMT
  # DEBUG Base => 1077035008B
  # DEBUG BEGIN_STMT
  if (UartUserCfg_6 == 0B)
    goto <bb 3>; [17.43%]
  else
    goto <bb 4>; [82.57%]

  <bb 3> [local count: 187153200]:
  # DEBUG BEGIN_STMT
  Flexio_Mcl_Ip_ClearTimerStatus (1077035008B, Channel_4(D));
  # DEBUG BEGIN_STMT
  Flexio_Mcl_Ip_ClearShifterStatus (1077035008B, Channel_4(D));
  # DEBUG BEGIN_STMT
  Flexio_Mcl_Ip_ClearShifterErrorStatus (1077035008B, Channel_4(D));
  goto <bb 7>; [100.00%]

  <bb 4> [local count: 886588623]:
  # DEBUG BEGIN_STMT
  _2 = UartUserCfg_6->Direction;
  if (_2 == 1)
    goto <bb 5>; [34.00%]
  else
    goto <bb 6>; [66.00%]

  <bb 5> [local count: 301440135]:
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_CheckTxOperation (Channel_4(D), ShifterMaskFlag_7(D), TimerMaskFlag_10(D));
  goto <bb 7>; [100.00%]

  <bb 6> [local count: 585148489]:
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_CheckRxOperation (Channel_4(D), ShifterMaskFlag_7(D), ShifterErrorMaskFlag_8(D));

  <bb 7> [local count: 1073741824]:
  return;

}



;; Function Flexio_Uart_Ip_Init (Flexio_Uart_Ip_Init, funcdef_no=35, decl_uid=6137, cgraph_uid=36, symbol_order=39)

Modification phase of node Flexio_Uart_Ip_Init/39
Flexio_Uart_Ip_Init (const uint8 Channel, const struct Flexio_Uart_Ip_UserConfigType * UserConfig)
{
  struct Flexio_Uart_Ip_StateStructureType * UartStatePtr;
  int _1;
  struct Flexio_Uart_Ip_StateStructureType * _2;
  _Bool _3;
  _Bool _4;
  long unsigned int _5;
  long unsigned int _6;
  _Bool _7;
  struct Flexio_Uart_Ip_StateStructureType * _8;
  long unsigned int _9;
  <unnamed type> _10;
  <unnamed type> _11;
  unsigned char _12;
  unsigned char _13;
  <unnamed type> _14;
  <unnamed type> _15;
  unsigned char _16;
  unsigned char _17;
  <unnamed type> _18;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  UartStatePtr_22 = UserConfig_21(D)->StateStruct;
  # DEBUG UartStatePtr => UartStatePtr_22
  # DEBUG BEGIN_STMT
  _1 = (int) Channel_23(D);
  _2 = Flexio_Uart_Ip_apStateStructuresArray[_1];
  _3 = _2 == 0B;
  DevAssert (_3);
  # DEBUG BEGIN_STMT
  _4 = Channel_23(D) <= 7;
  DevAssert (_4);
  # DEBUG BEGIN_STMT
  _5 = (long unsigned int) Channel_23(D);
  _6 = UserConfig_21(D)->Channel;
  _7 = _5 == _6;
  DevAssert (_7);
  # DEBUG BEGIN_STMT
  _8 = UserConfig_21(D)->StateStruct;
  Flexio_Uart_Ip_apStateStructuresArray[_1] = _8;
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_apUserConfig[_1] = UserConfig_21(D);
  # DEBUG BEGIN_STMT
  UartStatePtr_22->RxData = 0B;
  # DEBUG BEGIN_STMT
  UartStatePtr_22->TxData = 0B;
  # DEBUG BEGIN_STMT
  UartStatePtr_22->RemainingBytes ={v} 0;
  # DEBUG BEGIN_STMT
  _9 = UserConfig_21(D)->BaudRate;
  UartStatePtr_22->BaudRate = _9;
  # DEBUG BEGIN_STMT
  UartStatePtr_22->Status ={v} 0;
  # DEBUG BEGIN_STMT
  UartStatePtr_22->DriverIdle ={v} 0;
  # DEBUG BEGIN_STMT
  _10 = UserConfig_21(D)->Direction;
  if (_10 == 1)
    goto <bb 3>; [34.00%]
  else
    goto <bb 4>; [66.00%]

  <bb 3> [local count: 365072224]:
  # DEBUG BEGIN_STMT
  _11 = UserConfig_21(D)->BitCount;
  _12 = UserConfig_21(D)->Divider;
  _13 = UserConfig_21(D)->DataPin;
  _14 = UserConfig_21(D)->TimerDec;
  Flexio_Uart_Ip_ConfigureTx (Channel_23(D), _11, _12, _13, _14);
  goto <bb 5>; [100.00%]

  <bb 4> [local count: 708669601]:
  # DEBUG BEGIN_STMT
  _15 = UserConfig_21(D)->BitCount;
  _16 = UserConfig_21(D)->Divider;
  _17 = UserConfig_21(D)->DataPin;
  _18 = UserConfig_21(D)->TimerDec;
  Flexio_Uart_Ip_ConfigureRx (Channel_23(D), _15, _16, _17, _18);

  <bb 5> [local count: 1073741824]:
  return;

}



;; Function Flexio_Uart_Ip_GetBaudRate (Flexio_Uart_Ip_GetBaudRate, funcdef_no=36, decl_uid=6142, cgraph_uid=37, symbol_order=40)

Modification phase of node Flexio_Uart_Ip_GetBaudRate/40
Flexio_Uart_Ip_GetBaudRate (const uint8 Channel, uint32 * BaudRate)
{
  const struct Flexio_Uart_Ip_StateStructureType * UartState;
  _Bool _1;
  _Bool _2;
  int _3;
  long unsigned int _4;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Channel_5(D) <= 7;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _2 = BaudRate_8(D) != 0B;
  DevAssert (_2);
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _3 = (int) Channel_5(D);
  UartState_10 = Flexio_Uart_Ip_apStateStructuresArray[_3];
  # DEBUG UartState => UartState_10
  # DEBUG BEGIN_STMT
  _4 = UartState_10->BaudRate;
  *BaudRate_8(D) = _4;
  return;

}



;; Function Flexio_Uart_Ip_AsyncSend (Flexio_Uart_Ip_AsyncSend, funcdef_no=38, decl_uid=6150, cgraph_uid=39, symbol_order=42)

Modification phase of node Flexio_Uart_Ip_AsyncSend/42
Flexio_Uart_Ip_AsyncSend (const uint8 Channel, const uint8 * TxBuff, const uint32 TxSize)
{
  Flexio_Uart_Ip_StatusType RetStatus;
  const struct Flexio_Uart_Ip_UserConfigType * UartUserCfg;
  struct Flexio_Uart_Ip_StateStructureType * UartState;
  _Bool _1;
  int _2;
  long unsigned int _3;
  _Bool _4;
  _Bool _5;
  _Bool _6;
  <unnamed type> _7;
  _Bool _8;
  <unnamed type> _9;
  long unsigned int _10;
  _Bool _11;
  _Bool _12;
  <unnamed type> _13;
  int iftmp.6_15;
  unsigned char iftmp.7_16;
  int _40;

  <bb 2> [local count: 1073741823]:
  # DEBUG BEGIN_STMT
  _1 = Channel_18(D) <= 7;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _2 = (int) Channel_18(D);
  UartState_21 = Flexio_Uart_Ip_apStateStructuresArray[_2];
  # DEBUG UartState => UartState_21
  # DEBUG BEGIN_STMT
  UartUserCfg_22 = Flexio_Uart_Ip_apUserConfig[_2];
  # DEBUG UartUserCfg => UartUserCfg_22
  # DEBUG BEGIN_STMT
  # DEBUG RetStatus => 1
  # DEBUG BEGIN_STMT
  _4 = UartState_21 != 0B;
  DevAssert (_4);
  # DEBUG BEGIN_STMT
  _5 = TxBuff_24(D) != 0B;
  DevAssert (_5);
  # DEBUG BEGIN_STMT
  _6 = TxSize_26(D) != 0;
  DevAssert (_6);
  # DEBUG BEGIN_STMT
  _7 = UartUserCfg_22->Direction;
  _8 = _7 == 1;
  DevAssert (_8);
  # DEBUG BEGIN_STMT
  _9 = UartUserCfg_22->BitCount;
  if (_9 <= 8)
    goto <bb 4>; [50.00%]
  else
    goto <bb 3>; [50.00%]

  <bb 3> [local count: 536870911]:
  _10 = TxSize_26(D) & 1;
  _3 = 1 - _10;
  _40 = (int) _3;

  <bb 4> [local count: 1073741823]:
  # iftmp.6_15 = PHI <_40(3), 1(2)>
  _11 = (_Bool) iftmp.6_15;
  DevAssert (_11);
  # DEBUG BEGIN_STMT
  SchM_Enter_Uart_UART_EXCLUSIVE_AREA_04 ();
  # DEBUG BEGIN_STMT
  _12 ={v} UartState_21->DriverIdle;
  if (_12 != 0)
    goto <bb 5>; [35.00%]
  else
    goto <bb 6>; [65.00%]

  <bb 5> [local count: 375809640]:
  # DEBUG BEGIN_STMT
  SchM_Exit_Uart_UART_EXCLUSIVE_AREA_04 ();
  # DEBUG BEGIN_STMT
  # DEBUG RetStatus => 2
  goto <bb 10>; [100.00%]

  <bb 6> [local count: 697932184]:
  # DEBUG BEGIN_STMT
  UartState_21->DriverIdle ={v} 1;
  # DEBUG BEGIN_STMT
  SchM_Exit_Uart_UART_EXCLUSIVE_AREA_04 ();
  # DEBUG BEGIN_STMT
  # DEBUG Base => 1077035008B
  # DEBUG BEGIN_STMT
  UartState_21->TxData = TxBuff_24(D);
  # DEBUG BEGIN_STMT
  UartState_21->RemainingBytes ={v} TxSize_26(D);
  # DEBUG BEGIN_STMT
  UartState_21->Status ={v} 2;
  # DEBUG BEGIN_STMT
  if (TxSize_26(D) == 1)
    goto <bb 8>; [34.00%]
  else
    goto <bb 7>; [66.00%]

  <bb 7> [local count: 460635238]:

  <bb 8> [local count: 697932184]:
  # iftmp.7_16 = PHI <1(6), 2(7)>
  UartState_21->TxFlush = iftmp.7_16;
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_18(D), 1);
  # DEBUG BEGIN_STMT
  _13 = UartUserCfg_22->DriverType;
  if (_13 == 0)
    goto <bb 9>; [33.00%]
  else
    goto <bb 10>; [67.00%]

  <bb 9> [local count: 230317619]:
<L9>:
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetShifterInterrupt (Channel_18(D), 1);
  # DEBUG BEGIN_STMT
  # DEBUG RetStatus => 0
  # DEBUG BEGIN_STMT

  <bb 10> [local count: 1073741824]:
  # RetStatus_14 = PHI <2(5), 0(9), 1(8)>
  # DEBUG RetStatus => RetStatus_14
  # DEBUG BEGIN_STMT
  return RetStatus_14;

}



;; Function Flexio_Uart_Ip_GetStatus (Flexio_Uart_Ip_GetStatus, funcdef_no=39, decl_uid=6167, cgraph_uid=40, symbol_order=43)

Modification phase of node Flexio_Uart_Ip_GetStatus/43
Flexio_Uart_Ip_GetStatus (const uint8 Channel, uint32 * BytesRemaining)
{
  const struct Flexio_Uart_Ip_UserConfigType * UartUserCfg;
  const struct Flexio_Uart_Ip_StateStructureType * UartState;
  _Bool _1;
  int _2;
  _Bool _3;
  _Bool _4;
  <unnamed type> _5;
  long unsigned int _6;
  Flexio_Uart_Ip_StatusType _17;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Channel_8(D) <= 7;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _2 = (int) Channel_8(D);
  UartState_11 = Flexio_Uart_Ip_apStateStructuresArray[_2];
  # DEBUG UartState => UartState_11
  # DEBUG BEGIN_STMT
  UartUserCfg_12 = Flexio_Uart_Ip_apUserConfig[_2];
  # DEBUG UartUserCfg => UartUserCfg_12
  # DEBUG BEGIN_STMT
  _3 = UartState_11 != 0B;
  DevAssert (_3);
  # DEBUG BEGIN_STMT
  if (BytesRemaining_14(D) != 0B)
    goto <bb 3>; [70.00%]
  else
    goto <bb 7>; [30.00%]

  <bb 3> [local count: 751619281]:
  # DEBUG BEGIN_STMT
  _4 ={v} UartState_11->DriverIdle;
  if (_4 != 0)
    goto <bb 4>; [50.00%]
  else
    goto <bb 6>; [50.00%]

  <bb 4> [local count: 375809640]:
  # DEBUG BEGIN_STMT
  _5 = UartUserCfg_12->DriverType;
  if (_5 == 0)
    goto <bb 5>; [50.00%]
  else
    goto <bb 7>; [50.00%]

  <bb 5> [local count: 187904820]:
  # DEBUG BEGIN_STMT
  _6 ={v} UartState_11->RemainingBytes;
  *BytesRemaining_14(D) = _6;
  goto <bb 7>; [100.00%]

  <bb 6> [local count: 375809640]:
  # DEBUG BEGIN_STMT
  *BytesRemaining_14(D) = 0;

  <bb 7> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _17 ={v} UartState_11->Status;
  return _17;

}



;; Function Flexio_Uart_Ip_Deinit (Flexio_Uart_Ip_Deinit, funcdef_no=37, decl_uid=6139, cgraph_uid=38, symbol_order=41)

Modification phase of node Flexio_Uart_Ip_Deinit/41
Flexio_Uart_Ip_Deinit (const uint8 Channel)
{
  Flexio_Uart_Ip_StatusType RetVal;
  uint32 ElapsedTicks;
  uint32 TimeoutTicks;
  uint32 StartTime;
  _Bool _1;
  int _2;
  struct Flexio_Uart_Ip_StateStructureType * _3;
  _Bool _4;
  <unnamed type> _5;
  long unsigned int TimeoutTicks.4_6;
  _Bool _7;
  long unsigned int TimeoutTicks.5_8;
  _Bool _9;

  <bb 2> [local count: 114863530]:
  # DEBUG BEGIN_STMT
  _1 = Channel_14(D) <= 7;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  ElapsedTicks = 0;
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG Base => 1077035008B
  # DEBUG BEGIN_STMT
  _2 = (int) Channel_14(D);
  _3 = Flexio_Uart_Ip_apStateStructuresArray[_2];
  _4 = _3 != 0B;
  DevAssert (_4);
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, 10000000, 0);
  # DEBUG BEGIN_STMT

  <bb 3> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _5 = Flexio_Uart_Ip_GetStatus (Channel_14(D), 0B);
  if (_5 == 2)
    goto <bb 4>; [94.50%]
  else
    goto <bb 5>; [5.50%]

  <bb 4> [local count: 1014686026]:
  TimeoutTicks.4_6 = TimeoutTicks;
  _7 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.4_6, 0);
  if (_7 != 0)
    goto <bb 5>; [5.50%]
  else
    goto <bb 8>; [94.50%]

  <bb 8> [local count: 958878296]:
  goto <bb 3>; [100.00%]

  <bb 5> [local count: 114863531]:
  # DEBUG BEGIN_STMT
  TimeoutTicks.5_8 = TimeoutTicks;
  _9 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.5_8, 0);
  if (_9 != 0)
    goto <bb 7>; [67.00%]
  else
    goto <bb 6>; [33.00%]

  <bb 6> [local count: 37904965]:
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_apStateStructuresArray[_2] = 0B;
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetShifterInterrupt (Channel_14(D), 0);
  # DEBUG BEGIN_STMT
  Flexio_Mcl_Ip_SetSoftwareReset (1077035008B, 1);
  # DEBUG BEGIN_STMT
  Flexio_Mcl_Ip_SetSoftwareReset (1077035008B, 0);
  # DEBUG BEGIN_STMT
  # DEBUG RetVal => 0

  <bb 7> [local count: 114863531]:
  # RetVal_10 = PHI <1(5), 0(6)>
  # DEBUG RetVal => RetVal_10
  # DEBUG BEGIN_STMT
  StartTime ={v} {CLOBBER};
  TimeoutTicks ={v} {CLOBBER};
  ElapsedTicks ={v} {CLOBBER};
  return RetVal_10;

}



;; Function Flexio_Uart_Ip_SyncSend (Flexio_Uart_Ip_SyncSend, funcdef_no=40, decl_uid=6155, cgraph_uid=41, symbol_order=44)

Modification phase of node Flexio_Uart_Ip_SyncSend/44
Flexio_Uart_Ip_SyncSend (const uint8 Channel, const uint8 * TxBuff, const uint32 TxSize, const uint32 Timeout)
{
  Flexio_Uart_Ip_StatusType RetStatus;
  const struct Flexio_Uart_Ip_UserConfigType * UartUserCfg;
  struct Flexio_Uart_Ip_StateStructureType * UartState;
  uint32 ElapsedTicks;
  uint32 TimeoutTicks;
  uint32 StartTime;
  _Bool _1;
  _Bool _2;
  _Bool _3;
  int _4;
  _Bool _6;
  <unnamed type> _7;
  _Bool _8;
  <unnamed type> _9;
  long unsigned int _10;
  _Bool _11;
  _Bool _12;
  _Bool _13;
  int _14;
  long unsigned int TimeoutTicks.10_15;
  _Bool _16;
  long unsigned int _17;
  long unsigned int TimeoutTicks.11_18;
  _Bool _19;
  long unsigned int _20;
  long unsigned int TimeoutTicks.12_21;
  _Bool _22;
  <unnamed type> _23;
  int iftmp.8_25;
  unsigned char iftmp.9_26;

  <bb 2> [local count: 13681867]:
  # DEBUG BEGIN_STMT
  _1 = Channel_33(D) <= 7;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _2 = TxBuff_36(D) != 0B;
  DevAssert (_2);
  # DEBUG BEGIN_STMT
  _3 = TxSize_38(D) != 0;
  DevAssert (_3);
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  ElapsedTicks = 0;
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _4 = (int) Channel_33(D);
  UartState_41 = Flexio_Uart_Ip_apStateStructuresArray[_4];
  # DEBUG UartState => UartState_41
  # DEBUG BEGIN_STMT
  UartUserCfg_42 = Flexio_Uart_Ip_apUserConfig[_4];
  # DEBUG UartUserCfg => UartUserCfg_42
  # DEBUG BEGIN_STMT
  # DEBUG Base => 1077035008B
  # DEBUG BEGIN_STMT
  _6 = UartState_41 != 0B;
  DevAssert (_6);
  # DEBUG BEGIN_STMT
  _7 = UartUserCfg_42->Direction;
  _8 = _7 == 1;
  DevAssert (_8);
  # DEBUG BEGIN_STMT
  _9 = UartUserCfg_42->BitCount;
  if (_9 <= 8)
    goto <bb 4>; [50.00%]
  else
    goto <bb 3>; [50.00%]

  <bb 3> [local count: 6840933]:
  _10 = TxSize_38(D) & 1;
  _20 = 1 - _10;
  _14 = (int) _20;

  <bb 4> [local count: 13681867]:
  # iftmp.8_25 = PHI <_14(3), 1(2)>
  _11 = (_Bool) iftmp.8_25;
  DevAssert (_11);
  # DEBUG BEGIN_STMT
  SchM_Enter_Uart_UART_EXCLUSIVE_AREA_05 ();
  # DEBUG BEGIN_STMT
  _12 ={v} UartState_41->DriverIdle;
  if (_12 != 0)
    goto <bb 5>; [35.00%]
  else
    goto <bb 6>; [65.00%]

  <bb 5> [local count: 4788653]:
  # DEBUG BEGIN_STMT
  SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05 ();
  # DEBUG BEGIN_STMT
  # DEBUG RetStatus => 2
  goto <bb 20>; [100.00%]

  <bb 6> [local count: 8893213]:
  # DEBUG BEGIN_STMT
  UartState_41->DriverIdle ={v} 1;
  # DEBUG BEGIN_STMT
  SchM_Exit_Uart_UART_EXCLUSIVE_AREA_05 ();
  # DEBUG BEGIN_STMT
  UartState_41->TxData = TxBuff_36(D);
  # DEBUG BEGIN_STMT
  UartState_41->RemainingBytes ={v} TxSize_38(D);
  # DEBUG BEGIN_STMT
  UartState_41->Status ={v} 2;
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetShifterInterrupt (Channel_33(D), 0);
  # DEBUG BEGIN_STMT
  if (TxSize_38(D) == 1)
    goto <bb 8>; [34.00%]
  else
    goto <bb 7>; [66.00%]

  <bb 7> [local count: 5869521]:

  <bb 8> [local count: 8893213]:
  # iftmp.9_26 = PHI <1(6), 2(7)>
  UartState_41->TxFlush = iftmp.9_26;
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetTimerMode (1077035008B, Channel_33(D), 1);
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_55(D), 0);
  # DEBUG BEGIN_STMT
  goto <bb 12>; [100.00%]

  <bb 9> [local count: 114863530]:
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_WriteData (Channel_33(D));
  # DEBUG BEGIN_STMT

  <bb 10> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _13 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_33(D));
  if (_13 != 0)
    goto <bb 22>; [5.50%]
  else
    goto <bb 11>; [94.50%]

  <bb 22> [local count: 59055800]:
  goto <bb 13>; [100.00%]

  <bb 11> [local count: 1014686025]:
  TimeoutTicks.10_15 = TimeoutTicks;
  _16 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.10_15, 0);
  if (_16 != 0)
    goto <bb 21>; [5.50%]
  else
    goto <bb 23>; [94.50%]

  <bb 23> [local count: 958878295]:
  goto <bb 10>; [100.00%]

  <bb 21> [local count: 55807731]:

  <bb 12> [local count: 64700944]:

  <bb 13> [local count: 123756744]:
  # DEBUG BEGIN_STMT
  _17 ={v} UartState_41->RemainingBytes;
  if (_17 != 0)
    goto <bb 14>; [96.34%]
  else
    goto <bb 15>; [3.66%]

  <bb 14> [local count: 119227247]:
  TimeoutTicks.11_18 = TimeoutTicks;
  _19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.11_18, 0);
  if (_19 != 0)
    goto <bb 15>; [3.66%]
  else
    goto <bb 9>; [96.34%]

  <bb 15> [local count: 8893214]:
  # DEBUG BEGIN_STMT
  TimeoutTicks.12_21 = TimeoutTicks;
  _22 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.12_21, 0);
  if (_22 != 0)
    goto <bb 16>; [50.00%]
  else
    goto <bb 17>; [50.00%]

  <bb 16> [local count: 4446607]:
  # DEBUG BEGIN_STMT
  UartState_41->Status ={v} 518;

  <bb 17> [local count: 8893214]:
  # DEBUG BEGIN_STMT
  _23 ={v} UartState_41->Status;
  if (_23 == 2)
    goto <bb 18>; [34.00%]
  else
    goto <bb 19>; [66.00%]

  <bb 18> [local count: 3023693]:
  # DEBUG BEGIN_STMT
  UartState_41->Status ={v} 0;

  <bb 19> [local count: 8893214]:
  # DEBUG BEGIN_STMT
  Flexio_Mcl_Ip_ClearTimerStatus (1077035008B, Channel_33(D));
  # DEBUG BEGIN_STMT
  UartState_41->DriverIdle ={v} 0;
  # DEBUG BEGIN_STMT
  RetStatus_66 ={v} UartState_41->Status;
  # DEBUG RetStatus => RetStatus_66

  <bb 20> [local count: 13681868]:
  # RetStatus_24 = PHI <2(5), RetStatus_66(19)>
  # DEBUG RetStatus => RetStatus_24
  # DEBUG BEGIN_STMT
  StartTime ={v} {CLOBBER};
  TimeoutTicks ={v} {CLOBBER};
  ElapsedTicks ={v} {CLOBBER};
  return RetStatus_24;

}



;; Function Flexio_Uart_Ip_AsyncReceive (Flexio_Uart_Ip_AsyncReceive, funcdef_no=41, decl_uid=6159, cgraph_uid=42, symbol_order=45)

Modification phase of node Flexio_Uart_Ip_AsyncReceive/45
Flexio_Uart_Ip_AsyncReceive (const uint8 Channel, uint8 * RxBuff, const uint32 RxSize)
{
  Flexio_Uart_Ip_StatusType RetStatus;
  const struct Flexio_Uart_Ip_UserConfigType * UartUserCfg;
  struct Flexio_Uart_Ip_StateStructureType * UartState;
  _Bool _1;
  int _2;
  long unsigned int _3;
  _Bool _4;
  _Bool _5;
  _Bool _6;
  <unnamed type> _7;
  _Bool _8;
  <unnamed type> _9;
  long unsigned int _10;
  _Bool _11;
  _Bool _12;
  <unnamed type> _13;
  int iftmp.13_15;
  int _38;

  <bb 2> [local count: 1073741823]:
  # DEBUG BEGIN_STMT
  _1 = Channel_17(D) <= 7;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _2 = (int) Channel_17(D);
  UartState_20 = Flexio_Uart_Ip_apStateStructuresArray[_2];
  # DEBUG UartState => UartState_20
  # DEBUG BEGIN_STMT
  UartUserCfg_21 = Flexio_Uart_Ip_apUserConfig[_2];
  # DEBUG UartUserCfg => UartUserCfg_21
  # DEBUG BEGIN_STMT
  # DEBUG RetStatus => 1
  # DEBUG BEGIN_STMT
  _4 = UartState_20 != 0B;
  DevAssert (_4);
  # DEBUG BEGIN_STMT
  _5 = RxBuff_23(D) != 0B;
  DevAssert (_5);
  # DEBUG BEGIN_STMT
  _6 = RxSize_25(D) != 0;
  DevAssert (_6);
  # DEBUG BEGIN_STMT
  _7 = UartUserCfg_21->Direction;
  _8 = _7 == 0;
  DevAssert (_8);
  # DEBUG BEGIN_STMT
  _9 = UartUserCfg_21->BitCount;
  if (_9 <= 8)
    goto <bb 4>; [50.00%]
  else
    goto <bb 3>; [50.00%]

  <bb 3> [local count: 536870911]:
  _10 = RxSize_25(D) & 1;
  _3 = 1 - _10;
  _38 = (int) _3;

  <bb 4> [local count: 1073741823]:
  # iftmp.13_15 = PHI <_38(3), 1(2)>
  _11 = (_Bool) iftmp.13_15;
  DevAssert (_11);
  # DEBUG BEGIN_STMT
  SchM_Enter_Uart_UART_EXCLUSIVE_AREA_06 ();
  # DEBUG BEGIN_STMT
  _12 ={v} UartState_20->DriverIdle;
  if (_12 != 0)
    goto <bb 5>; [35.00%]
  else
    goto <bb 6>; [65.00%]

  <bb 5> [local count: 375809640]:
  # DEBUG BEGIN_STMT
  SchM_Exit_Uart_UART_EXCLUSIVE_AREA_06 ();
  # DEBUG BEGIN_STMT
  # DEBUG RetStatus => 2
  goto <bb 8>; [100.00%]

  <bb 6> [local count: 697932184]:
  # DEBUG BEGIN_STMT
  UartState_20->DriverIdle ={v} 1;
  # DEBUG BEGIN_STMT
  SchM_Exit_Uart_UART_EXCLUSIVE_AREA_06 ();
  # DEBUG BEGIN_STMT
  UartState_20->RxData = RxBuff_23(D);
  # DEBUG BEGIN_STMT
  UartState_20->RemainingBytes ={v} RxSize_25(D);
  # DEBUG BEGIN_STMT
  UartState_20->Status ={v} 2;
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_EnableReceiver (Channel_17(D));
  # DEBUG BEGIN_STMT
  _13 = UartUserCfg_21->DriverType;
  if (_13 == 0)
    goto <bb 7>; [33.00%]
  else
    goto <bb 8>; [67.00%]

  <bb 7> [local count: 230317619]:
<L6>:
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetShifterInterrupt (Channel_17(D), 1);
  # DEBUG BEGIN_STMT
  # DEBUG RetStatus => 0
  # DEBUG BEGIN_STMT

  <bb 8> [local count: 1073741824]:
  # RetStatus_14 = PHI <2(5), 0(7), 1(6)>
  # DEBUG RetStatus => RetStatus_14
  # DEBUG BEGIN_STMT
  return RetStatus_14;

}



;; Function Flexio_Uart_Ip_SyncReceive (Flexio_Uart_Ip_SyncReceive, funcdef_no=42, decl_uid=6164, cgraph_uid=43, symbol_order=46)

Modification phase of node Flexio_Uart_Ip_SyncReceive/46
Flexio_Uart_Ip_SyncReceive (const uint8 Channel, uint8 * RxBuff, const uint32 RxSize, const uint32 Timeout)
{
  Flexio_Uart_Ip_StatusType RetStatus;
  uint32 ElapsedTicks;
  uint32 TimeoutTicks;
  uint32 StartTime;
  const struct Flexio_Uart_Ip_UserConfigType * UartUserCfg;
  struct Flexio_Uart_Ip_StateStructureType * UartState;
  _Bool _1;
  _Bool _2;
  _Bool _3;
  int _4;
  _Bool _5;
  <unnamed type> _6;
  _Bool _7;
  <unnamed type> _8;
  long unsigned int _9;
  _Bool _10;
  _Bool _11;
  _Bool _12;
  int _13;
  long unsigned int TimeoutTicks.15_14;
  _Bool _15;
  <unnamed type> _16;
  long unsigned int _17;
  long unsigned int TimeoutTicks.16_18;
  _Bool _19;
  long unsigned int _20;
  <unnamed type> _21;
  long unsigned int TimeoutTicks.17_22;
  _Bool _23;
  int iftmp.14_25;

  <bb 2> [local count: 20149567]:
  # DEBUG BEGIN_STMT
  _1 = Channel_32(D) <= 7;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _2 = RxBuff_35(D) != 0B;
  DevAssert (_2);
  # DEBUG BEGIN_STMT
  _3 = RxSize_37(D) != 0;
  DevAssert (_3);
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  ElapsedTicks = 0;
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG Base => 1077035008B
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _4 = (int) Channel_32(D);
  UartState_40 = Flexio_Uart_Ip_apStateStructuresArray[_4];
  # DEBUG UartState => UartState_40
  # DEBUG BEGIN_STMT
  UartUserCfg_41 = Flexio_Uart_Ip_apUserConfig[_4];
  # DEBUG UartUserCfg => UartUserCfg_41
  # DEBUG BEGIN_STMT
  _5 = UartState_40 != 0B;
  DevAssert (_5);
  # DEBUG BEGIN_STMT
  _6 = UartUserCfg_41->Direction;
  _7 = _6 == 0;
  DevAssert (_7);
  # DEBUG BEGIN_STMT
  _8 = UartUserCfg_41->BitCount;
  if (_8 <= 8)
    goto <bb 4>; [50.00%]
  else
    goto <bb 3>; [50.00%]

  <bb 3> [local count: 10074784]:
  _9 = RxSize_37(D) & 1;
  _20 = 1 - _9;
  _13 = (int) _20;

  <bb 4> [local count: 20149567]:
  # iftmp.14_25 = PHI <_13(3), 1(2)>
  _10 = (_Bool) iftmp.14_25;
  DevAssert (_10);
  # DEBUG BEGIN_STMT
  SchM_Enter_Uart_UART_EXCLUSIVE_AREA_07 ();
  # DEBUG BEGIN_STMT
  _11 ={v} UartState_40->DriverIdle;
  if (_11 != 0)
    goto <bb 5>; [35.00%]
  else
    goto <bb 6>; [65.00%]

  <bb 5> [local count: 7052348]:
  # DEBUG BEGIN_STMT
  SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07 ();
  # DEBUG BEGIN_STMT
  # DEBUG RetStatus => 2
  goto <bb 18>; [100.00%]

  <bb 6> [local count: 13097219]:
  # DEBUG BEGIN_STMT
  UartState_40->DriverIdle ={v} 1;
  # DEBUG BEGIN_STMT
  SchM_Exit_Uart_UART_EXCLUSIVE_AREA_07 ();
  # DEBUG BEGIN_STMT
  UartState_40->RxData = RxBuff_35(D);
  # DEBUG BEGIN_STMT
  UartState_40->RemainingBytes ={v} RxSize_37(D);
  # DEBUG BEGIN_STMT
  UartState_40->Status ={v} 2;
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetupReceiveData (Channel_32(D));
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_StartTimeout (&StartTime, &TimeoutTicks, Timeout_52(D), 0);
  # DEBUG BEGIN_STMT
  goto <bb 11>; [100.00%]

  <bb 19> [local count: 114863530]:

  <bb 7> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _12 = Flexio_Mcl_Ip_GetShifterStatus (1077035008B, Channel_32(D));
  if (_12 != 0)
    goto <bb 9>; [5.50%]
  else
    goto <bb 8>; [94.50%]

  <bb 8> [local count: 1014686025]:
  TimeoutTicks.15_14 = TimeoutTicks;
  _15 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.15_14, 0);
  if (_15 != 0)
    goto <bb 9>; [5.50%]
  else
    goto <bb 20>; [94.50%]

  <bb 20> [local count: 958878295]:
  goto <bb 7>; [100.00%]

  <bb 9> [local count: 114863531]:
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_CheckShifterErrorStatus (Channel_32(D));
  # DEBUG BEGIN_STMT
  _16 ={v} UartState_40->Status;
  if (_16 == 514)
    goto <bb 13>; [3.66%]
  else
    goto <bb 10>; [96.34%]

  <bb 10> [local count: 110659526]:
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_ReadData (Channel_32(D));

  <bb 11> [local count: 123756744]:
  # DEBUG BEGIN_STMT
  _17 ={v} UartState_40->RemainingBytes;
  if (_17 != 0)
    goto <bb 12>; [96.34%]
  else
    goto <bb 13>; [3.66%]

  <bb 12> [local count: 119227247]:
  TimeoutTicks.16_18 = TimeoutTicks;
  _19 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.16_18, 0);
  if (_19 != 0)
    goto <bb 13>; [3.66%]
  else
    goto <bb 19>; [96.34%]

  <bb 13> [local count: 13097220]:
  # DEBUG BEGIN_STMT
  _21 ={v} UartState_40->Status;
  if (_21 == 2)
    goto <bb 14>; [20.24%]
  else
    goto <bb 17>; [79.76%]

  <bb 14> [local count: 2650877]:
  # DEBUG BEGIN_STMT
  TimeoutTicks.17_22 = TimeoutTicks;
  _23 = Flexio_Uart_Ip_CheckTimeout (&StartTime, &ElapsedTicks, TimeoutTicks.17_22, 0);
  if (_23 != 0)
    goto <bb 15>; [50.00%]
  else
    goto <bb 16>; [50.00%]

  <bb 15> [local count: 1325439]:
  # DEBUG BEGIN_STMT
  UartState_40->Status ={v} 518;
  goto <bb 17>; [100.00%]

  <bb 16> [local count: 1325439]:
  # DEBUG BEGIN_STMT
  UartState_40->Status ={v} 0;

  <bb 17> [local count: 13097220]:
  # DEBUG BEGIN_STMT
  Flexio_Mcl_Ip_ClearTimerStatus (1077035008B, Channel_32(D));
  # DEBUG BEGIN_STMT
  UartState_40->DriverIdle ={v} 0;
  # DEBUG BEGIN_STMT
  RetStatus_64 ={v} UartState_40->Status;
  # DEBUG RetStatus => RetStatus_64

  <bb 18> [local count: 20149568]:
  # RetStatus_24 = PHI <2(5), RetStatus_64(17)>
  # DEBUG RetStatus => RetStatus_24
  # DEBUG BEGIN_STMT
  StartTime ={v} {CLOBBER};
  TimeoutTicks ={v} {CLOBBER};
  ElapsedTicks ={v} {CLOBBER};
  return RetStatus_24;

}



;; Function Flexio_Uart_Ip_AbortTransferData (Flexio_Uart_Ip_AbortTransferData, funcdef_no=43, decl_uid=6173, cgraph_uid=44, symbol_order=47)

Modification phase of node Flexio_Uart_Ip_AbortTransferData/47
Flexio_Uart_Ip_AbortTransferData (const uint8 Channel)
{
  Flexio_Uart_Ip_StatusType RetStatus;
  const struct Flexio_Uart_Ip_UserConfigType * UartUserCfg;
  struct Flexio_Uart_Ip_StateStructureType * UartState;
  _Bool _1;
  int _2;
  _Bool _3;
  _Bool _4;
  _Bool _5;
  <unnamed type> _6;
  <unnamed type> _7;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Channel_11(D) <= 7;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG RetStatus => 0
  # DEBUG BEGIN_STMT
  _2 = (int) Channel_11(D);
  UartState_14 = Flexio_Uart_Ip_apStateStructuresArray[_2];
  # DEBUG UartState => UartState_14
  # DEBUG BEGIN_STMT
  UartUserCfg_15 = Flexio_Uart_Ip_apUserConfig[_2];
  # DEBUG UartUserCfg => UartUserCfg_15
  # DEBUG BEGIN_STMT
  _3 = UartState_14 != 0B;
  DevAssert (_3);
  # DEBUG BEGIN_STMT
  _4 = UartUserCfg_15 != 0B;
  DevAssert (_4);
  # DEBUG BEGIN_STMT
  _5 ={v} UartState_14->DriverIdle;
  if (_5 != 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 7>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  UartState_14->Status ={v} 516;
  # DEBUG BEGIN_STMT
  _6 = UartUserCfg_15->DriverType;
  if (_6 == 0)
    goto <bb 4>; [33.00%]
  else
    goto <bb 5>; [67.00%]

  <bb 4> [local count: 177167400]:
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_StopTransfer (Channel_11(D));

  <bb 5> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  _7 ={v} UartState_14->Status;
  if (_7 == 518)
    goto <bb 6>; [34.00%]
  else
    goto <bb 7>; [66.00%]

  <bb 6> [local count: 182536112]:
  # DEBUG BEGIN_STMT
  # DEBUG RetStatus => 1

  <bb 7> [local count: 1073741824]:
  # RetStatus_8 = PHI <0(2), 0(5), 1(6)>
  # DEBUG RetStatus => RetStatus_8
  # DEBUG BEGIN_STMT
  return RetStatus_8;

}



;; Function Flexio_Uart_Ip_SetBaudRate (Flexio_Uart_Ip_SetBaudRate, funcdef_no=44, decl_uid=6146, cgraph_uid=45, symbol_order=48)

Modification phase of node Flexio_Uart_Ip_SetBaudRate/48
Flexio_Uart_Ip_SetBaudRate (const uint8 Channel, const Flexio_Uart_Ip_BaudrateType DesiredBaudrate, const uint32 ClockFrequency)
{
  uint16 BitCountValue;
  sint32 Divider;
  Flexio_Uart_Ip_StatusType Status;
  Flexio_Uart_Ip_TimerDecrementType TimerDecrement;
  const struct Flexio_Uart_Ip_UserConfigType * UartUserCfg;
  struct Flexio_Uart_Ip_StateStructureType * UartState;
  _Bool _1;
  _Bool _2;
  int _3;
  <unnamed type> _4;
  _Bool _5;
  _Bool _6;
  <unnamed type> _7;
  long int ClockFrequency.18_8;
  long int DesiredBaudrate.19_9;
  long int _10;
  long int _11;
  unsigned int Divider.20_12;
  _Bool _13;
  long unsigned int _14;
  long unsigned int _15;
  long int ClockFrequency.22_16;
  long int DesiredBaudrate.23_17;
  long int _18;
  long int _19;
  unsigned int Divider.24_20;
  long unsigned int _21;
  long unsigned int _22;
  long int _23;
  long int _24;
  unsigned int Divider.28_25;
  _Bool _26;
  long unsigned int _27;
  long unsigned int _28;
  short unsigned int _29;
  short unsigned int _30;
  short unsigned int _31;
  unsigned char _32;
  short unsigned int _33;
  short unsigned int _34;
  <unnamed type> _35;
  long unsigned int _48;
  long unsigned int _53;
  long unsigned int _57;
  long unsigned int _68;

  <bb 2> [local count: 1073741823]:
  # DEBUG BEGIN_STMT
  _1 = Channel_41(D) <= 7;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _2 = ClockFrequency_44(D) != 0;
  DevAssert (_2);
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _3 = (int) Channel_41(D);
  UartState_46 = Flexio_Uart_Ip_apStateStructuresArray[_3];
  # DEBUG UartState => UartState_46
  # DEBUG BEGIN_STMT
  UartUserCfg_47 = Flexio_Uart_Ip_apUserConfig[_3];
  # DEBUG UartUserCfg => UartUserCfg_47
  # DEBUG BEGIN_STMT
  # DEBUG Base => 1077035008B
  # DEBUG BEGIN_STMT
  _4 = UartUserCfg_47->BitCount;
  BitCountValue_49 = (uint16) _4;
  # DEBUG BitCountValue => BitCountValue_49
  # DEBUG BEGIN_STMT
  _5 = UartState_46 != 0B;
  DevAssert (_5);
  # DEBUG BEGIN_STMT
  _6 ={v} UartState_46->DriverIdle;
  if (_6 != 0)
    goto <bb 12>; [35.00%]
  else
    goto <bb 3>; [65.00%]

  <bb 3> [local count: 697932184]:
  # DEBUG BEGIN_STMT
  _7 = UartUserCfg_47->TimerDec;
  if (_7 == 0)
    goto <bb 4>; [33.00%]
  else
    goto <bb 5>; [67.00%]

  <bb 4> [local count: 230317619]:
  # DEBUG BEGIN_STMT
  # DEBUG TimerDecrement => 0
  # DEBUG BEGIN_STMT
  ClockFrequency.18_8 = (long int) ClockFrequency_44(D);
  DesiredBaudrate.19_9 = (long int) DesiredBaudrate_51(D);
  _10 = DesiredBaudrate.19_9 * 2;
  _11 = ClockFrequency.18_8 / _10;
  Divider_59 = _11 + -1;
  # DEBUG Divider => Divider_59
  # DEBUG BEGIN_STMT
  Divider.20_12 = (unsigned int) Divider_59;
  _13 = Divider.20_12 <= 255;
  DevAssert (_13);
  # DEBUG BEGIN_STMT
  _57 = (long unsigned int) _11;
  _14 = _57 * 2;
  _15 = ClockFrequency_44(D) / _14;
  UartState_46->BaudRate = _15;
  goto <bb 8>; [100.00%]

  <bb 5> [local count: 467614564]:
  # DEBUG BEGIN_STMT
  ClockFrequency.22_16 = (long int) ClockFrequency_44(D);
  DesiredBaudrate.23_17 = (long int) DesiredBaudrate_51(D);
  _18 = DesiredBaudrate.23_17 * 32;
  _19 = ClockFrequency.22_16 / _18;
  Divider_52 = _19 + -1;
  # DEBUG Divider => Divider_52
  # DEBUG BEGIN_STMT
  Divider.24_20 = (unsigned int) Divider_52;
  if (Divider.24_20 <= 255)
    goto <bb 6>; [67.00%]
  else
    goto <bb 7>; [33.00%]

  <bb 6> [local count: 313301759]:
  # DEBUG BEGIN_STMT
  # DEBUG TimerDecrement => 4
  # DEBUG BEGIN_STMT
  _53 = (long unsigned int) _19;
  _21 = _53 * 32;
  _22 = ClockFrequency_44(D) / _21;
  UartState_46->BaudRate = _22;
  goto <bb 8>; [100.00%]

  <bb 7> [local count: 154312805]:
  # DEBUG BEGIN_STMT
  # DEBUG TimerDecrement => 5
  # DEBUG BEGIN_STMT
  _23 = DesiredBaudrate.23_17 * 512;
  _24 = ClockFrequency.22_16 / _23;
  Divider_54 = _24 + -1;
  # DEBUG Divider => Divider_54
  # DEBUG BEGIN_STMT
  Divider.28_25 = (unsigned int) Divider_54;
  _26 = Divider.28_25 <= 255;
  DevAssert (_26);
  # DEBUG BEGIN_STMT
  _48 = (long unsigned int) _24;
  _27 = _48 * 512;
  _28 = ClockFrequency_44(D) / _27;
  UartState_46->BaudRate = _28;

  <bb 8> [local count: 697932185]:
  # TimerDecrement_36 = PHI <0(4), 4(6), 5(7)>
  # Divider_38 = PHI <Divider_59(4), Divider_52(6), Divider_54(7)>
  # DEBUG Divider => Divider_38
  # DEBUG TimerDecrement => TimerDecrement_36
  # DEBUG BEGIN_STMT
  _29 = BitCountValue_49 << 1;
  _30 = _29 + 65535;
  _31 = _30 << 8;
  _32 = (unsigned char) Divider_38;
  _33 = (short unsigned int) _32;
  _34 = _31 + _33;
  # DEBUG Base => 1077035008B
  # DEBUG Timer => Channel_41(D)
  # DEBUG Value => _34
  # DEBUG INLINE_ENTRY Flexio_Uart_Ip_SetTimerCompare
  # DEBUG BEGIN_STMT
  _68 = (long unsigned int) _34;
  MEM[(struct FLEXIO_Type *)1077035008B].TIMCMP[_3] ={v} _68;
  # DEBUG Base => NULL
  # DEBUG Timer => NULL
  # DEBUG Value => NULL
  # DEBUG BEGIN_STMT
  _35 = UartUserCfg_47->Direction;
  if (_35 == 1)
    goto <bb 9>; [34.00%]
  else
    goto <bb 10>; [66.00%]

  <bb 9> [local count: 237296945]:
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_41(D), 0, TimerDecrement_36, 0);
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_41(D), 1, 2);
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetTimerCondition (1077035008B, Channel_41(D), 2, 2);
  goto <bb 12>; [100.00%]

  <bb 10> [local count: 460635239]:
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetTimerConfig (1077035008B, Channel_41(D), 4, TimerDecrement_36, 2);
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetTimerStartStopBitConfig (1077035008B, Channel_41(D), 1, 2);
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_SetTimerCondition (1077035008B, Channel_41(D), 4, 2);

  <bb 12> [local count: 1073741824]:
  # Status_37 = PHI <2(2), 0(10), 0(9)>
  # DEBUG Status => Status_37
  # DEBUG BEGIN_STMT
  return Status_37;

}



;; Function Flexio_Uart_Ip_SetTxBuffer (Flexio_Uart_Ip_SetTxBuffer, funcdef_no=45, decl_uid=6177, cgraph_uid=46, symbol_order=49)

Modification phase of node Flexio_Uart_Ip_SetTxBuffer/49
Flexio_Uart_Ip_SetTxBuffer (const uint8 Channel, const uint8 * TxData, const uint32 TxSize)
{
  struct Flexio_Uart_Ip_StateStructureType * UartState;
  _Bool _1;
  _Bool _2;
  _Bool _3;
  int _4;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Channel_5(D) <= 7;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _2 = TxData_8(D) != 0B;
  DevAssert (_2);
  # DEBUG BEGIN_STMT
  _3 = TxSize_10(D) != 0;
  DevAssert (_3);
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _4 = (int) Channel_5(D);
  UartState_12 = Flexio_Uart_Ip_apStateStructuresArray[_4];
  # DEBUG UartState => UartState_12
  # DEBUG BEGIN_STMT
  UartState_12->TxData = TxData_8(D);
  # DEBUG BEGIN_STMT
  UartState_12->RemainingBytes ={v} TxSize_10(D);
  return;

}



;; Function Flexio_Uart_Ip_SetRxBuffer (Flexio_Uart_Ip_SetRxBuffer, funcdef_no=46, decl_uid=6181, cgraph_uid=47, symbol_order=50)

Modification phase of node Flexio_Uart_Ip_SetRxBuffer/50
Flexio_Uart_Ip_SetRxBuffer (const uint8 Channel, uint8 * RxData, const uint32 RxSize)
{
  struct Flexio_Uart_Ip_StateStructureType * UartState;
  _Bool _1;
  _Bool _2;
  _Bool _3;
  int _4;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = Channel_5(D) <= 7;
  DevAssert (_1);
  # DEBUG BEGIN_STMT
  _2 = RxData_8(D) != 0B;
  DevAssert (_2);
  # DEBUG BEGIN_STMT
  _3 = RxSize_10(D) != 0;
  DevAssert (_3);
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _4 = (int) Channel_5(D);
  UartState_12 = Flexio_Uart_Ip_apStateStructuresArray[_4];
  # DEBUG UartState => UartState_12
  # DEBUG BEGIN_STMT
  UartState_12->RxData = RxData_8(D);
  # DEBUG BEGIN_STMT
  UartState_12->RemainingBytes ={v} RxSize_10(D);
  return;

}


