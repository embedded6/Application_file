Creating summary for MCL_FLEXIO_ISR/1:


Creating summary for Flexio_Mcl_Ip_CommonIrq/0:



========== IPA-SRA IPA stage ==========

Summary for node MCL_FLEXIO_ISR/1:
  No parameter information. 

  Summary for edge MCL_FLEXIO_ISR/1->Flexio_Mcl_Ip_CommonIrq/0:
    return value ignored

Summary for node Flexio_Mcl_Ip_CommonIrq/0:
  No parameter information. 

  Summary for edge Flexio_Mcl_Ip_CommonIrq/0->Flexio_Uart_Ip_IrqHandler/10:
    return value ignored
  Summary for edge Flexio_Mcl_Ip_CommonIrq/0->Flexio_Uart_Ip_IrqHandler/10:
    return value ignored
  Summary for edge Flexio_Mcl_Ip_CommonIrq/0->Flexio_Mcl_Ip_GetAllTimerInterrupt/8:
  Summary for edge Flexio_Mcl_Ip_CommonIrq/0->Flexio_Mcl_Ip_GetAllTimerStatus/7:
  Summary for edge Flexio_Mcl_Ip_CommonIrq/0->Flexio_Mcl_Ip_GetAllShifterErrorStatus/6:
  Summary for edge Flexio_Mcl_Ip_CommonIrq/0->Flexio_Mcl_Ip_GetAllShifterErrorInterrupt/5:
  Summary for edge Flexio_Mcl_Ip_CommonIrq/0->Flexio_Mcl_Ip_GetAllShifterInterrupt/4:
  Summary for edge Flexio_Mcl_Ip_CommonIrq/0->Flexio_Mcl_Ip_GetAllShifterStatus/3:


Function MCL_FLEXIO_ISR/1 disqualified because it cannot be made local.

========== IPA-SRA decisions ==========

========== IPA SRA IPA analysis done ==========


Reclaiming functions:
Reclaiming variables:
Clearing address taken flags:
Symbol table:

Flexio_Uart_Ip_IrqHandler/10 (Flexio_Uart_Ip_IrqHandler) @05fc7380
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Mcl_Ip_CommonIrq/0 (446945034 (estimated locally),0.42 per call) Flexio_Mcl_Ip_CommonIrq/0 (446945034 (estimated locally),0.42 per call) 
  Calls: 
Flexio_Ip_baIpIsInitialized/9 (Flexio_Ip_baIpIsInitialized) @05e6ee58
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: Flexio_Mcl_Ip_CommonIrq/0 (read) 
  Availability: not_available
  Varpool flags:
Flexio_Mcl_Ip_GetAllTimerInterrupt/8 (Flexio_Mcl_Ip_GetAllTimerInterrupt) @05fc72a0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Mcl_Ip_CommonIrq/0 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Mcl_Ip_GetAllTimerStatus/7 (Flexio_Mcl_Ip_GetAllTimerStatus) @05fc71c0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Mcl_Ip_CommonIrq/0 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Mcl_Ip_GetAllShifterErrorStatus/6 (Flexio_Mcl_Ip_GetAllShifterErrorStatus) @05fc70e0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Mcl_Ip_CommonIrq/0 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Mcl_Ip_GetAllShifterErrorInterrupt/5 (Flexio_Mcl_Ip_GetAllShifterErrorInterrupt) @05fc7000
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Mcl_Ip_CommonIrq/0 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Mcl_Ip_GetAllShifterInterrupt/4 (Flexio_Mcl_Ip_GetAllShifterInterrupt) @05e61a80
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Mcl_Ip_CommonIrq/0 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Mcl_Ip_GetAllShifterStatus/3 (Flexio_Mcl_Ip_GetAllShifterStatus) @05e617e0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Mcl_Ip_CommonIrq/0 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Ip_paxBase/2 (Flexio_Ip_paxBase) @05e6ec60
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: Flexio_Mcl_Ip_CommonIrq/0 (read) 
  Availability: not_available
  Varpool flags: read-only
MCL_FLEXIO_ISR/1 (MCL_FLEXIO_ISR) @05e61c40
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Flexio_Mcl_Ip_CommonIrq/0 (1073741824 (estimated locally),1.00 per call) 
Flexio_Mcl_Ip_CommonIrq/0 (Flexio_Mcl_Ip_CommonIrq) @05e619a0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: Flexio_Ip_paxBase/2 (read) Flexio_Ip_baIpIsInitialized/9 (read) 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: MCL_FLEXIO_ISR/1 (1073741824 (estimated locally),1.00 per call) 
  Calls: Flexio_Uart_Ip_IrqHandler/10 (446945034 (estimated locally),0.42 per call) Flexio_Uart_Ip_IrqHandler/10 (446945034 (estimated locally),0.42 per call) Flexio_Mcl_Ip_GetAllTimerInterrupt/8 (1073741824 (estimated locally),1.00 per call) Flexio_Mcl_Ip_GetAllTimerStatus/7 (1073741824 (estimated locally),1.00 per call) Flexio_Mcl_Ip_GetAllShifterErrorStatus/6 (1073741824 (estimated locally),1.00 per call) Flexio_Mcl_Ip_GetAllShifterErrorInterrupt/5 (1073741824 (estimated locally),1.00 per call) Flexio_Mcl_Ip_GetAllShifterInterrupt/4 (1073741824 (estimated locally),1.00 per call) Flexio_Mcl_Ip_GetAllShifterStatus/3 (1073741824 (estimated locally),1.00 per call) 
MCL_FLEXIO_ISR ()
{
  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  Flexio_Mcl_Ip_CommonIrq ();
  # DEBUG BEGIN_STMT
  return;

}


Flexio_Mcl_Ip_CommonIrq ()
{
  uint8 u8TimerEnabledIrq;
  uint8 u8TimerMaskFlag;
  uint8 u8ShifterErrMaskFlag;
  uint8 u8ShifterErrEnabledIrq;
  uint8 u8ShifterEnabledIrq;
  uint8 u8ShifterMaskFlag;
  struct FLEXIO_Type * BaseAddr;
  long unsigned int _1;
  long unsigned int _2;
  long unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;
  _Bool _7;
  long unsigned int _8;
  unsigned char _9;
  long unsigned int _10;
  long unsigned int _11;
  long unsigned int _12;
  unsigned char _13;
  long unsigned int _14;
  long unsigned int _15;
  unsigned char _16;
  long unsigned int _39;
  long unsigned int _40;
  unsigned char _41;
  unsigned char _42;
  unsigned char _43;
  unsigned char _44;
  unsigned char _45;
  unsigned char _46;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  BaseAddr_20 = Flexio_Ip_paxBase[0];
  # DEBUG BaseAddr => BaseAddr_20
  # DEBUG BEGIN_STMT
  _1 = Flexio_Mcl_Ip_GetAllShifterStatus (BaseAddr_20);
  u8ShifterMaskFlag_22 = (uint8) _1;
  # DEBUG u8ShifterMaskFlag => u8ShifterMaskFlag_22
  # DEBUG BEGIN_STMT
  _2 = Flexio_Mcl_Ip_GetAllShifterInterrupt (BaseAddr_20);
  u8ShifterEnabledIrq_24 = (uint8) _2;
  # DEBUG u8ShifterEnabledIrq => u8ShifterEnabledIrq_24
  # DEBUG BEGIN_STMT
  _3 = Flexio_Mcl_Ip_GetAllShifterErrorInterrupt (BaseAddr_20);
  u8ShifterErrEnabledIrq_26 = (uint8) _3;
  # DEBUG u8ShifterErrEnabledIrq => u8ShifterErrEnabledIrq_26
  # DEBUG BEGIN_STMT
  _4 = Flexio_Mcl_Ip_GetAllShifterErrorStatus (BaseAddr_20);
  u8ShifterErrMaskFlag_28 = (uint8) _4;
  # DEBUG u8ShifterErrMaskFlag => u8ShifterErrMaskFlag_28
  # DEBUG BEGIN_STMT
  _5 = Flexio_Mcl_Ip_GetAllTimerStatus (BaseAddr_20);
  u8TimerMaskFlag_30 = (uint8) _5;
  # DEBUG u8TimerMaskFlag => u8TimerMaskFlag_30
  # DEBUG BEGIN_STMT
  _6 = Flexio_Mcl_Ip_GetAllTimerInterrupt (BaseAddr_20);
  u8TimerEnabledIrq_32 = (uint8) _6;
  # DEBUG u8TimerEnabledIrq => u8TimerEnabledIrq_32
  # DEBUG BEGIN_STMT
  _7 = Flexio_Ip_baIpIsInitialized[0];
  if (_7 != 0)
    goto <bb 3>; [50.00%]
  else
    goto <bb 11>; [50.00%]

  <bb 3> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  _8 ={v} BaseAddr_20->SHIFTERR;
  _9 = u8ShifterErrEnabledIrq_26 & u8ShifterErrMaskFlag_28;
  _10 = (long unsigned int) _9;
  _11 = _8 | _10;
  BaseAddr_20->SHIFTERR ={v} _11;
  # DEBUG BEGIN_STMT
  _12 ={v} BaseAddr_20->TIMSTAT;
  _13 = u8TimerMaskFlag_30 & u8TimerEnabledIrq_32;
  _14 = (long unsigned int) _13;
  _15 = _12 | _14;
  BaseAddr_20->TIMSTAT ={v} _15;
  # DEBUG BEGIN_STMT
  _16 = u8ShifterMaskFlag_22 & u8ShifterEnabledIrq_24;
  _41 = _16 & 1;
  if (_41 != 0)
    goto <bb 6>; [33.00%]
  else
    goto <bb 4>; [67.00%]

  <bb 4> [local count: 359703512]:
  _42 = _9 & 1;
  if (_42 != 0)
    goto <bb 6>; [50.00%]
  else
    goto <bb 5>; [50.00%]

  <bb 5> [local count: 179851756]:
  _43 = _13 & 1;
  if (_43 != 0)
    goto <bb 6>; [50.00%]
  else
    goto <bb 7>; [50.00%]

  <bb 6> [local count: 446945034]:
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_IrqHandler (0, u8ShifterMaskFlag_22, u8ShifterErrMaskFlag_28, u8TimerMaskFlag_30);

  <bb 7> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  _44 = _16 & 2;
  if (_44 != 0)
    goto <bb 10>; [33.00%]
  else
    goto <bb 8>; [67.00%]

  <bb 8> [local count: 359703512]:
  _45 = _9 & 2;
  if (_45 != 0)
    goto <bb 10>; [50.00%]
  else
    goto <bb 9>; [50.00%]

  <bb 9> [local count: 179851756]:
  _46 = _13 & 2;
  if (_46 != 0)
    goto <bb 10>; [50.00%]
  else
    goto <bb 12>; [50.00%]

  <bb 10> [local count: 446945034]:
  # DEBUG BEGIN_STMT
  Flexio_Uart_Ip_IrqHandler (1, u8ShifterMaskFlag_22, u8ShifterErrMaskFlag_28, u8TimerMaskFlag_30);
  goto <bb 12>; [100.00%]

  <bb 11> [local count: 536870913]:
  # DEBUG BEGIN_STMT
  _39 = _4 & 255;
  BaseAddr_20->SHIFTERR ={v} _39;
  # DEBUG BEGIN_STMT
  _40 = _5 & 255;
  BaseAddr_20->TIMSTAT ={v} _40;

  <bb 12> [local count: 1073741824]:
  return;

}


