
IPA constant propagation start:

IPA structures before propagation:

Jump functions:
  Jump functions of caller  Flexio_Uart_Ip_IrqHandler/10:
  Jump functions of caller  Flexio_Mcl_Ip_GetAllTimerInterrupt/8:
  Jump functions of caller  Flexio_Mcl_Ip_GetAllTimerStatus/7:
  Jump functions of caller  Flexio_Mcl_Ip_GetAllShifterErrorStatus/6:
  Jump functions of caller  Flexio_Mcl_Ip_GetAllShifterErrorInterrupt/5:
  Jump functions of caller  Flexio_Mcl_Ip_GetAllShifterInterrupt/4:
  Jump functions of caller  Flexio_Mcl_Ip_GetAllShifterStatus/3:
  Jump functions of caller  MCL_FLEXIO_ISR/1:
    callsite  MCL_FLEXIO_ISR/1 -> Flexio_Mcl_Ip_CommonIrq/0 : 
  Jump functions of caller  Flexio_Mcl_Ip_CommonIrq/0:
    callsite  Flexio_Mcl_Ip_CommonIrq/0 -> Flexio_Uart_Ip_IrqHandler/10 : 
       no arg info
    callsite  Flexio_Mcl_Ip_CommonIrq/0 -> Flexio_Uart_Ip_IrqHandler/10 : 
       no arg info
    callsite  Flexio_Mcl_Ip_CommonIrq/0 -> Flexio_Mcl_Ip_GetAllTimerInterrupt/8 : 
       no arg info
    callsite  Flexio_Mcl_Ip_CommonIrq/0 -> Flexio_Mcl_Ip_GetAllTimerStatus/7 : 
       no arg info
    callsite  Flexio_Mcl_Ip_CommonIrq/0 -> Flexio_Mcl_Ip_GetAllShifterErrorStatus/6 : 
       no arg info
    callsite  Flexio_Mcl_Ip_CommonIrq/0 -> Flexio_Mcl_Ip_GetAllShifterErrorInterrupt/5 : 
       no arg info
    callsite  Flexio_Mcl_Ip_CommonIrq/0 -> Flexio_Mcl_Ip_GetAllShifterInterrupt/4 : 
       no arg info
    callsite  Flexio_Mcl_Ip_CommonIrq/0 -> Flexio_Mcl_Ip_GetAllShifterStatus/3 : 
       no arg info

 Propagating constants:


overall_size: 70

IPA lattices after all propagation:

Lattices:
  Node: MCL_FLEXIO_ISR/1:
  Node: Flexio_Mcl_Ip_CommonIrq/0:

IPA decision stage:


IPA constant propagation end

Reclaiming functions:
Reclaiming variables:
Clearing address taken flags:
Symbol table:

Flexio_Uart_Ip_IrqHandler/10 (Flexio_Uart_Ip_IrqHandler) @05fc7380
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Mcl_Ip_CommonIrq/0 (446945034 (estimated locally),0.42 per call) Flexio_Mcl_Ip_CommonIrq/0 (446945034 (estimated locally),0.42 per call) 
  Calls: 
Flexio_Ip_baIpIsInitialized/9 (Flexio_Ip_baIpIsInitialized) @05e6ee58
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: Flexio_Mcl_Ip_CommonIrq/0 (read) 
  Availability: not_available
  Varpool flags:
Flexio_Mcl_Ip_GetAllTimerInterrupt/8 (Flexio_Mcl_Ip_GetAllTimerInterrupt) @05fc72a0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Mcl_Ip_CommonIrq/0 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Mcl_Ip_GetAllTimerStatus/7 (Flexio_Mcl_Ip_GetAllTimerStatus) @05fc71c0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Mcl_Ip_CommonIrq/0 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Mcl_Ip_GetAllShifterErrorStatus/6 (Flexio_Mcl_Ip_GetAllShifterErrorStatus) @05fc70e0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Mcl_Ip_CommonIrq/0 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Mcl_Ip_GetAllShifterErrorInterrupt/5 (Flexio_Mcl_Ip_GetAllShifterErrorInterrupt) @05fc7000
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Mcl_Ip_CommonIrq/0 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Mcl_Ip_GetAllShifterInterrupt/4 (Flexio_Mcl_Ip_GetAllShifterInterrupt) @05e61a80
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Mcl_Ip_CommonIrq/0 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Mcl_Ip_GetAllShifterStatus/3 (Flexio_Mcl_Ip_GetAllShifterStatus) @05e617e0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flexio_Mcl_Ip_CommonIrq/0 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
Flexio_Ip_paxBase/2 (Flexio_Ip_paxBase) @05e6ec60
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: Flexio_Mcl_Ip_CommonIrq/0 (read) 
  Availability: not_available
  Varpool flags: read-only
MCL_FLEXIO_ISR/1 (MCL_FLEXIO_ISR) @05e61c40
  Type: function definition analyzed
  Visibility: externally_visible public
  References: 
  Referring: 
  Availability: available
  Function flags: count:1073741824 (estimated locally) body optimize_size
  Called by: 
  Calls: Flexio_Mcl_Ip_CommonIrq/0 (1073741824 (estimated locally),1.00 per call) 
Flexio_Mcl_Ip_CommonIrq/0 (Flexio_Mcl_Ip_CommonIrq) @05e619a0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: Flexio_Ip_paxBase/2 (read) Flexio_Ip_baIpIsInitialized/9 (read) 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: MCL_FLEXIO_ISR/1 (1073741824 (estimated locally),1.00 per call) 
  Calls: Flexio_Uart_Ip_IrqHandler/10 (446945034 (estimated locally),0.42 per call) Flexio_Uart_Ip_IrqHandler/10 (446945034 (estimated locally),0.42 per call) Flexio_Mcl_Ip_GetAllTimerInterrupt/8 (1073741824 (estimated locally),1.00 per call) Flexio_Mcl_Ip_GetAllTimerStatus/7 (1073741824 (estimated locally),1.00 per call) Flexio_Mcl_Ip_GetAllShifterErrorStatus/6 (1073741824 (estimated locally),1.00 per call) Flexio_Mcl_Ip_GetAllShifterErrorInterrupt/5 (1073741824 (estimated locally),1.00 per call) Flexio_Mcl_Ip_GetAllShifterInterrupt/4 (1073741824 (estimated locally),1.00 per call) Flexio_Mcl_Ip_GetAllShifterStatus/3 (1073741824 (estimated locally),1.00 per call) 

;; Function MCL_FLEXIO_ISR (MCL_FLEXIO_ISR, funcdef_no=1, decl_uid=5925, cgraph_uid=2, symbol_order=1)

Modification phase of node MCL_FLEXIO_ISR/1
MCL_FLEXIO_ISR ()
{
  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  Flexio_Mcl_Ip_CommonIrq ();
  # DEBUG BEGIN_STMT
  return;

}


