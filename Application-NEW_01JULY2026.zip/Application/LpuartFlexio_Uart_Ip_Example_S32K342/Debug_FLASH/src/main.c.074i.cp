
IPA constant propagation start:
Determining dynamic type for call: UART_Print (&b);
  Starting walk at: UART_Print (&b);
  instance pointer: &b  Outer instance pointer: b offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("==============================================\r\n");
  Starting walk at: UART_Print ("==============================================\r\n");
  instance pointer: "==============================================\r\n"  Outer instance pointer: "==============================================\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  S32K342  UART -> Flash  File Store\r\n");
  Starting walk at: UART_Print ("  S32K342  UART -> Flash  File Store\r\n");
  instance pointer: "  S32K342  UART -> Flash  File Store\r\n"  Outer instance pointer: "  S32K342  UART -> Flash  File Store\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  Target     : PFlash (Code Flash)\r\n");
  Starting walk at: UART_Print ("  Target     : PFlash (Code Flash)\r\n");
  instance pointer: "  Target     : PFlash (Code Flash)\r\n"  Outer instance pointer: "  Target     : PFlash (Code Flash)\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  Flash base : 0x004E0000\r\n");
  Starting walk at: UART_Print ("  Flash base : 0x004E0000\r\n");
  instance pointer: "  Flash base : 0x004E0000\r\n"  Outer instance pointer: "  Flash base : 0x004E0000\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  Sector     : 128 KB each\r\n");
  Starting walk at: UART_Print ("  Sector     : 128 KB each\r\n");
  instance pointer: "  Sector     : 128 KB each\r\n"  Outer instance pointer: "  Sector     : 128 KB each\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  Buffer     : DTCM RAM (128 KB)\r\n");
  Starting walk at: UART_Print ("  Buffer     : DTCM RAM (128 KB)\r\n");
  instance pointer: "  Buffer     : DTCM RAM (128 KB)\r\n"  Outer instance pointer: "  Buffer     : DTCM RAM (128 KB)\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  Max file   : ");
  Starting walk at: UART_Print ("  Max file   : ");
  instance pointer: "  Max file   : "  Outer instance pointer: "  Max file   : " offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (" bytes\r\n");
  Starting walk at: UART_Print (" bytes\r\n");
  instance pointer: " bytes\r\n"  Outer instance pointer: " bytes\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("==============================================\r\n");
  Starting walk at: UART_Print ("==============================================\r\n");
  instance pointer: "==============================================\r\n"  Outer instance pointer: "==============================================\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("HOW TO INCREASE MAX FILE SIZE:\r\n");
  Starting walk at: UART_Print ("HOW TO INCREASE MAX FILE SIZE:\r\n");
  instance pointer: "HOW TO INCREASE MAX FILE SIZE:\r\n"  Outer instance pointer: "HOW TO INCREASE MAX FILE SIZE:\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  Change RX_BUF_SIZE in main.c\r\n");
  Starting walk at: UART_Print ("  Change RX_BUF_SIZE in main.c\r\n");
  instance pointer: "  Change RX_BUF_SIZE in main.c\r\n"  Outer instance pointer: "  Change RX_BUF_SIZE in main.c\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  Max safe value = 120000 (DTCM is 128 KB)\r\n");
  Starting walk at: UART_Print ("  Max safe value = 120000 (DTCM is 128 KB)\r\n");
  instance pointer: "  Max safe value = 120000 (DTCM is 128 KB)\r\n"  Outer instance pointer: "  Max safe value = 120000 (DTCM is 128 KB)\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n----------------------------------------------\r\n");
  Starting walk at: UART_Print ("\r\n----------------------------------------------\r\n");
  instance pointer: "\r\n----------------------------------------------\r\n"  Outer instance pointer: "\r\n----------------------------------------------\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("Type 8 hex chars = file size (no Enter):\r\n");
  Starting walk at: UART_Print ("Type 8 hex chars = file size (no Enter):\r\n");
  instance pointer: "Type 8 hex chars = file size (no Enter):\r\n"  Outer instance pointer: "Type 8 hex chars = file size (no Enter):\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  38000 bytes  ->  00009470\r\n");
  Starting walk at: UART_Print ("  38000 bytes  ->  00009470\r\n");
  instance pointer: "  38000 bytes  ->  00009470\r\n"  Outer instance pointer: "  38000 bytes  ->  00009470\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  65000 bytes  ->  0000FDE8\r\n");
  Starting walk at: UART_Print ("  65000 bytes  ->  0000FDE8\r\n");
  instance pointer: "  65000 bytes  ->  0000FDE8\r\n"  Outer instance pointer: "  65000 bytes  ->  0000FDE8\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  100000 bytes ->  000186A0\r\n");
  Starting walk at: UART_Print ("  100000 bytes ->  000186A0\r\n");
  instance pointer: "  100000 bytes ->  000186A0\r\n"  Outer instance pointer: "  100000 bytes ->  000186A0\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  Reset/erase  ->  00000000\r\n");
  Starting walk at: UART_Print ("  Reset/erase  ->  00000000\r\n");
  instance pointer: "  Reset/erase  ->  00000000\r\n"  Outer instance pointer: "  Reset/erase  ->  00000000\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("----------------------------------------------\r\n");
  Starting walk at: UART_Print ("----------------------------------------------\r\n");
  instance pointer: "----------------------------------------------\r\n"  Outer instance pointer: "----------------------------------------------\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: _1 = ReadHeader (&fileLen);
  Starting walk at: _1 = ReadHeader (&fileLen);
  instance pointer: &fileLen  Outer instance pointer: fileLen offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:UART_Print ("----------------------------------------------\r\n");
  Function call may change dynamic type:UART_Print ("  Reset/erase  ->  00000000\r\n");
  Function call may change dynamic type:UART_Print ("  100000 bytes ->  000186A0\r\n");
  Function call may change dynamic type:UART_Print ("  65000 bytes  ->  0000FDE8\r\n");
  Function call may change dynamic type:UART_Print ("  38000 bytes  ->  00009470\r\n");
  Function call may change dynamic type:UART_Print ("Type 8 hex chars = file size (no Enter):\r\n");
  Function call may change dynamic type:UART_Print ("\r\n----------------------------------------------\r\n");
Determining dynamic type for call: UART_Print ("File size : ");
  Starting walk at: UART_Print ("File size : ");
  instance pointer: "File size : "  Outer instance pointer: "File size : " offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (" bytes  (0x");
  Starting walk at: UART_Print (" bytes  (0x");
  instance pointer: " bytes  (0x"  Outer instance pointer: " bytes  (0x" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (")\r\n");
  Starting walk at: UART_Print (")\r\n");
  instance pointer: ")\r\n"  Outer instance pointer: ")\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("Flash target : 0x");
  Starting walk at: UART_Print ("Flash target : 0x");
  instance pointer: "Flash target : 0x"  Outer instance pointer: "Flash target : 0x" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (">>> ERASE DONE.  NOW: File -> Send File -> tick Binary -> Send <<<\r\n");
  Starting walk at: UART_Print (">>> ERASE DONE.  NOW: File -> Send File -> tick Binary -> Send <<<\r\n");
  instance pointer: ">>> ERASE DONE.  NOW: File -> Send File -> tick Binary -> Send <<<\r\n"  Outer instance pointer: ">>> ERASE DONE.  NOW: File -> Send File -> tick Binary -> Send <<<\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("Waiting for ");
  Starting walk at: UART_Print ("Waiting for ");
  instance pointer: "Waiting for "  Outer instance pointer: "Waiting for " offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (" bytes...\r\n");
  Starting walk at: UART_Print (" bytes...\r\n");
  instance pointer: " bytes...\r\n"  Outer instance pointer: " bytes...\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: _10 = UART_ReadExact (&RxBuf, fileLen.11_9);
  Starting walk at: _10 = UART_ReadExact (&RxBuf, fileLen.11_9);
  instance pointer: &RxBuf  Outer instance pointer: RxBuf offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:UART_Print (" bytes...\r\n");
  Function call may change dynamic type:UART_PrintUInt (fileLen.10_8);
  Function call may change dynamic type:UART_Print ("Waiting for ");
  Function call may change dynamic type:UART_Print (">>> ERASE DONE.  NOW: File -> Send File -> tick Binary -> Send <<<\r\n");
  Function call may change dynamic type:UART_Print ("\r\n");
  Function call may change dynamic type:_7 = Flash_EraseForFile (fileLen.9_6);
  Function call may change dynamic type:UART_Print ("\r\n");
  Function call may change dynamic type:UART_PrintHex32 (5111808);
  Function call may change dynamic type:UART_Print ("Flash target : 0x");
  Function call may change dynamic type:UART_Print (")\r\n");
  Function call may change dynamic type:UART_PrintHex32 (fileLen.7_4);
  Function call may change dynamic type:UART_Print (" bytes  (0x");
  Function call may change dynamic type:UART_PrintUInt (fileLen.6_3);
  Function call may change dynamic type:UART_Print ("File size : ");
  Function call may change dynamic type:_1 = ReadHeader (&fileLen);
  Function call may change dynamic type:UART_Print ("----------------------------------------------\r\n");
  Function call may change dynamic type:UART_Print ("  Reset/erase  ->  00000000\r\n");
  Function call may change dynamic type:UART_Print ("  100000 bytes ->  000186A0\r\n");
  Function call may change dynamic type:UART_Print ("  65000 bytes  ->  0000FDE8\r\n");
  Function call may change dynamic type:UART_Print ("  38000 bytes  ->  00009470\r\n");
  Function call may change dynamic type:UART_Print ("Type 8 hex chars = file size (no Enter):\r\n");
  Function call may change dynamic type:UART_Print ("\r\n----------------------------------------------\r\n");
Determining dynamic type for call: UART_Print ("Receive OK -- ");
  Starting walk at: UART_Print ("Receive OK -- ");
  instance pointer: "Receive OK -- "  Outer instance pointer: "Receive OK -- " offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (" bytes in DTCM RAM.\r\n");
  Starting walk at: UART_Print (" bytes in DTCM RAM.\r\n");
  instance pointer: " bytes in DTCM RAM.\r\n"  Outer instance pointer: " bytes in DTCM RAM.\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: fileCrc_50 = CRC32_Compute (&RxBuf, fileLen.13_12);
  Starting walk at: fileCrc_50 = CRC32_Compute (&RxBuf, fileLen.13_12);
  instance pointer: &RxBuf  Outer instance pointer: RxBuf offset: 0 (bits) vtbl reference: 
  Function call may change dynamic type:UART_Print (" bytes in DTCM RAM.\r\n");
  Function call may change dynamic type:UART_PrintUInt (fileLen.12_11);
  Function call may change dynamic type:UART_Print ("Receive OK -- ");
  Function call may change dynamic type:_10 = UART_ReadExact (&RxBuf, fileLen.11_9);
  Function call may change dynamic type:UART_Print (" bytes...\r\n");
  Function call may change dynamic type:UART_PrintUInt (fileLen.10_8);
  Function call may change dynamic type:UART_Print ("Waiting for ");
  Function call may change dynamic type:UART_Print (">>> ERASE DONE.  NOW: File -> Send File -> tick Binary -> Send <<<\r\n");
  Function call may change dynamic type:UART_Print ("\r\n");
  Function call may change dynamic type:_7 = Flash_EraseForFile (fileLen.9_6);
  Function call may change dynamic type:UART_Print ("\r\n");
  Function call may change dynamic type:UART_PrintHex32 (5111808);
  Function call may change dynamic type:UART_Print ("Flash target : 0x");
  Function call may change dynamic type:UART_Print (")\r\n");
  Function call may change dynamic type:UART_PrintHex32 (fileLen.7_4);
  Function call may change dynamic type:UART_Print (" bytes  (0x");
  Function call may change dynamic type:UART_PrintUInt (fileLen.6_3);
  Function call may change dynamic type:UART_Print ("File size : ");
  Function call may change dynamic type:_1 = ReadHeader (&fileLen);
  Function call may change dynamic type:UART_Print ("----------------------------------------------\r\n");
  Function call may change dynamic type:UART_Print ("  Reset/erase  ->  00000000\r\n");
  Function call may change dynamic type:UART_Print ("  100000 bytes ->  000186A0\r\n");
  Function call may change dynamic type:UART_Print ("  65000 bytes  ->  0000FDE8\r\n");
  Function call may change dynamic type:UART_Print ("  38000 bytes  ->  00009470\r\n");
  Function call may change dynamic type:UART_Print ("Type 8 hex chars = file size (no Enter):\r\n");
  Function call may change dynamic type:UART_Print ("\r\n----------------------------------------------\r\n");
Determining dynamic type for call: UART_Print ("CRC32 received : 0x");
  Starting walk at: UART_Print ("CRC32 received : 0x");
  instance pointer: "CRC32 received : 0x"  Outer instance pointer: "CRC32 received : 0x" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("Writing to flash 0x");
  Starting walk at: UART_Print ("Writing to flash 0x");
  instance pointer: "Writing to flash 0x"  Outer instance pointer: "Writing to flash 0x" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("...\r\n");
  Starting walk at: UART_Print ("...\r\n");
  instance pointer: "...\r\n"  Outer instance pointer: "...\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("Flash write done.\r\n");
  Starting walk at: UART_Print ("Flash write done.\r\n");
  instance pointer: "Flash write done.\r\n"  Outer instance pointer: "Flash write done.\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("Verifying...\r\n");
  Starting walk at: UART_Print ("Verifying...\r\n");
  instance pointer: "Verifying...\r\n"  Outer instance pointer: "Verifying...\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (">>> FLASH STORE SUCCESS <<<\r\n");
  Starting walk at: UART_Print (">>> FLASH STORE SUCCESS <<<\r\n");
  instance pointer: ">>> FLASH STORE SUCCESS <<<\r\n"  Outer instance pointer: ">>> FLASH STORE SUCCESS <<<\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  ");
  Starting walk at: UART_Print ("  ");
  instance pointer: "  "  Outer instance pointer: "  " offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (" bytes stored at 0x");
  Starting walk at: UART_Print (" bytes stored at 0x");
  instance pointer: " bytes stored at 0x"  Outer instance pointer: " bytes stored at 0x" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (" -- 0x");
  Starting walk at: UART_Print (" -- 0x");
  instance pointer: " -- 0x"  Outer instance pointer: " -- 0x" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (">>> FLASH VERIFY FAILED <<<\r\n");
  Starting walk at: UART_Print (">>> FLASH VERIFY FAILED <<<\r\n");
  instance pointer: ">>> FLASH VERIFY FAILED <<<\r\n"  Outer instance pointer: ">>> FLASH VERIFY FAILED <<<\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (">>> FLASH WRITE FAILED <<<\r\n");
  Starting walk at: UART_Print (">>> FLASH WRITE FAILED <<<\r\n");
  instance pointer: ">>> FLASH WRITE FAILED <<<\r\n"  Outer instance pointer: ">>> FLASH WRITE FAILED <<<\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (">>> RECEIVE FAILED <<<\r\n");
  Starting walk at: UART_Print (">>> RECEIVE FAILED <<<\r\n");
  instance pointer: ">>> RECEIVE FAILED <<<\r\n"  Outer instance pointer: ">>> RECEIVE FAILED <<<\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("ERROR: file too large. Max = ");
  Starting walk at: UART_Print ("ERROR: file too large. Max = ");
  instance pointer: "ERROR: file too large. Max = "  Outer instance pointer: "ERROR: file too large. Max = " offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (" bytes.\r\n");
  Starting walk at: UART_Print (" bytes.\r\n");
  instance pointer: " bytes.\r\n"  Outer instance pointer: " bytes.\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("Increase RX_BUF_SIZE in main.c (max ~120000)\r\n");
  Starting walk at: UART_Print ("Increase RX_BUF_SIZE in main.c (max ~120000)\r\n");
  instance pointer: "Increase RX_BUF_SIZE in main.c (max ~120000)\r\n"  Outer instance pointer: "Increase RX_BUF_SIZE in main.c (max ~120000)\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("Reset: erasing sectors...\r\n");
  Starting walk at: UART_Print ("Reset: erasing sectors...\r\n");
  instance pointer: "Reset: erasing sectors...\r\n"  Outer instance pointer: "Reset: erasing sectors...\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("Erase done. Ready for new file.\r\n");
  Starting walk at: UART_Print ("Erase done. Ready for new file.\r\n");
  instance pointer: "Erase done. Ready for new file.\r\n"  Outer instance pointer: "Erase done. Ready for new file.\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  CRC32 received : 0x");
  Starting walk at: UART_Print ("  CRC32 received : 0x");
  instance pointer: "  CRC32 received : 0x"  Outer instance pointer: "  CRC32 received : 0x" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  CRC32 in flash : 0x");
  Starting walk at: UART_Print ("  CRC32 in flash : 0x");
  instance pointer: "  CRC32 in flash : 0x"  Outer instance pointer: "  CRC32 in flash : 0x" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("ERROR: CRC MISMATCH\r\n");
  Starting walk at: UART_Print ("ERROR: CRC MISMATCH\r\n");
  instance pointer: "ERROR: CRC MISMATCH\r\n"  Outer instance pointer: "ERROR: CRC MISMATCH\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("ERROR: readback failed offset=0x");
  Starting walk at: UART_Print ("ERROR: readback failed offset=0x");
  instance pointer: "ERROR: readback failed offset=0x"  Outer instance pointer: "ERROR: readback failed offset=0x" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("ERROR: write failed offset=0x");
  Starting walk at: UART_Print ("ERROR: write failed offset=0x");
  instance pointer: "ERROR: write failed offset=0x"  Outer instance pointer: "ERROR: write failed offset=0x" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("ERROR: write start failed offset=0x");
  Starting walk at: UART_Print ("ERROR: write start failed offset=0x");
  instance pointer: "ERROR: write start failed offset=0x"  Outer instance pointer: "ERROR: write start failed offset=0x" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("Erasing ");
  Starting walk at: UART_Print ("Erasing ");
  instance pointer: "Erasing "  Outer instance pointer: "Erasing " offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (" PFlash sector(s) x 128 KB each...\r\n");
  Starting walk at: UART_Print (" PFlash sector(s) x 128 KB each...\r\n");
  instance pointer: " PFlash sector(s) x 128 KB each...\r\n"  Outer instance pointer: " PFlash sector(s) x 128 KB each...\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("Erase complete.\r\n");
  Starting walk at: UART_Print ("Erase complete.\r\n");
  instance pointer: "Erase complete.\r\n"  Outer instance pointer: "Erase complete.\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  Sector ");
  Starting walk at: UART_Print ("  Sector ");
  instance pointer: "  Sector "  Outer instance pointer: "  Sector " offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (" OK\r\n");
  Starting walk at: UART_Print (" OK\r\n");
  instance pointer: " OK\r\n"  Outer instance pointer: " OK\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  Starting erase sector=");
  Starting walk at: UART_Print ("  Starting erase sector=");
  instance pointer: "  Starting erase sector="  Outer instance pointer: "  Starting erase sector=" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("...\r\n");
  Starting walk at: UART_Print ("...\r\n");
  instance pointer: "...\r\n"  Outer instance pointer: "...\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  Erase started, polling status...\r\n");
  Starting walk at: UART_Print ("  Erase started, polling status...\r\n");
  instance pointer: "  Erase started, polling status...\r\n"  Outer instance pointer: "  Erase started, polling status...\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  Erase status OK\r\n");
  Starting walk at: UART_Print ("  Erase status OK\r\n");
  instance pointer: "  Erase status OK\r\n"  Outer instance pointer: "  Erase status OK\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("ERROR: erase failed sector=");
  Starting walk at: UART_Print ("ERROR: erase failed sector=");
  instance pointer: "ERROR: erase failed sector="  Outer instance pointer: "ERROR: erase failed sector=" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (" status=");
  Starting walk at: UART_Print (" status=");
  instance pointer: " status="  Outer instance pointer: " status=" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("ERROR: erase TIMEOUT sector=");
  Starting walk at: UART_Print ("ERROR: erase TIMEOUT sector=");
  instance pointer: "ERROR: erase TIMEOUT sector="  Outer instance pointer: "ERROR: erase TIMEOUT sector=" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (" last_status=");
  Starting walk at: UART_Print (" last_status=");
  instance pointer: " last_status="  Outer instance pointer: " last_status=" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("ERROR: erase start failed sector=");
  Starting walk at: UART_Print ("ERROR: erase start failed sector=");
  instance pointer: "ERROR: erase start failed sector="  Outer instance pointer: "ERROR: erase start failed sector=" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (" status=");
  Starting walk at: UART_Print (" status=");
  instance pointer: " status="  Outer instance pointer: " status=" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  Checking lock for sector=");
  Starting walk at: UART_Print ("  Checking lock for sector=");
  instance pointer: "  Checking lock for sector="  Outer instance pointer: "  Checking lock for sector=" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (" (index=");
  Starting walk at: UART_Print (" (index=");
  instance pointer: " (index="  Outer instance pointer: " (index=" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (")...\r\n");
  Starting walk at: UART_Print (")...\r\n");
  instance pointer: ")...\r\n"  Outer instance pointer: ")...\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  Sector already unlocked\r\n");
  Starting walk at: UART_Print ("  Sector already unlocked\r\n");
  instance pointer: "  Sector already unlocked\r\n"  Outer instance pointer: "  Sector already unlocked\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  Sector locked, clearing...\r\n");
  Starting walk at: UART_Print ("  Sector locked, clearing...\r\n");
  instance pointer: "  Sector locked, clearing...\r\n"  Outer instance pointer: "  Sector locked, clearing...\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("  Sector unlocked OK\r\n");
  Starting walk at: UART_Print ("  Sector unlocked OK\r\n");
  instance pointer: "  Sector unlocked OK\r\n"  Outer instance pointer: "  Sector unlocked OK\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("ERROR: unlock failed sector=");
  Starting walk at: UART_Print ("ERROR: unlock failed sector=");
  instance pointer: "ERROR: unlock failed sector="  Outer instance pointer: "ERROR: unlock failed sector=" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("\r\n");
  Starting walk at: UART_Print ("\r\n");
  instance pointer: "\r\n"  Outer instance pointer: "\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: _1 = UART_ReadExact (&hdr, 8);
  Starting walk at: _1 = UART_ReadExact (&hdr, 8);
  instance pointer: &hdr  Outer instance pointer: hdr offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("ERROR: non-hex character in header\r\n");
  Starting walk at: UART_Print ("ERROR: non-hex character in header\r\n");
  instance pointer: "ERROR: non-hex character in header\r\n"  Outer instance pointer: "ERROR: non-hex character in header\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("ERROR: RX timeout\r\n");
  Starting walk at: UART_Print ("ERROR: RX timeout\r\n");
  instance pointer: "ERROR: RX timeout\r\n"  Outer instance pointer: "ERROR: RX timeout\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("ERROR: RX start failed\r\n");
  Starting walk at: UART_Print ("ERROR: RX start failed\r\n");
  instance pointer: "ERROR: RX start failed\r\n"  Outer instance pointer: "ERROR: RX start failed\r\n" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print (&h);
  Starting walk at: UART_Print (&h);
  instance pointer: &h  Outer instance pointer: h offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_Print ("0");
  Starting walk at: UART_Print ("0");
  instance pointer: "0"  Outer instance pointer: "0" offset: 0 (bits) vtbl reference: 
Determining dynamic type for call: UART_WriteRaw (msg_3(D), _1);
  Starting walk at: UART_WriteRaw (msg_3(D), _1);
  instance pointer: msg_3(D)  Outer instance pointer: msg_3(D) offset: 0 (bits) vtbl reference: 

IPA structures before propagation:

Jump functions:
  Jump functions of caller  UART_PrintUInt.part.0/74:
    callsite  UART_PrintUInt.part.0/74 -> UART_Print/32 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
  Jump functions of caller  HexNibble.part.0/73:
  Jump functions of caller  C40_Ip_Read/72:
  Jump functions of caller  C40_Ip_MainInterfaceWriteStatus/71:
  Jump functions of caller  C40_Ip_MainInterfaceWrite/70:
  Jump functions of caller  memcpy/69:
  Jump functions of caller  memset/68:
  Jump functions of caller  Lpuart_Uart_Ip_AbortReceivingData/67:
  Jump functions of caller  Lpuart_Uart_Ip_GetReceiveStatus/66:
  Jump functions of caller  Lpuart_Uart_Ip_AsyncReceive/65:
  Jump functions of caller  C40_Ip_MainInterfaceSectorEraseStatus/64:
  Jump functions of caller  C40_Ip_MainInterfaceSectorErase/63:
  Jump functions of caller  C40_Ip_ClearLock/62:
  Jump functions of caller  C40_Ip_GetLock/61:
  Jump functions of caller  Lpuart_Uart_Ip_GetTransmitStatus/60:
  Jump functions of caller  Lpuart_Uart_Ip_AsyncSend/59:
  Jump functions of caller  strlen/58:
  Jump functions of caller  C40_Ip_Init/56:
  Jump functions of caller  Lpuart_Uart_Ip_Init/54:
  Jump functions of caller  IntCtrl_Ip_ConfigIrqRouting/52:
  Jump functions of caller  IntCtrl_Ip_Init/50:
  Jump functions of caller  Siul2_Port_Ip_Init/48:
  Jump functions of caller  Clock_Ip_Init/46:
  Jump functions of caller  main/45:
    callsite  main/45 -> DoTransfer/44 : 
    callsite  main/45 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/45 -> UART_Print/32 : 
       param 0: CONST: "  Max safe value = 120000 (DTCM is 128 KB)\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/45 -> UART_Print/32 : 
       param 0: CONST: "  Change RX_BUF_SIZE in main.c\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/45 -> UART_Print/32 : 
       param 0: CONST: "HOW TO INCREASE MAX FILE SIZE:\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/45 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/45 -> UART_Print/32 : 
       param 0: CONST: "==============================================\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/45 -> UART_Print/32 : 
       param 0: CONST: " bytes\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/45 -> UART_PrintUInt.part.0/74 : 
       param 0: CONST: 100000
         value: 0x186a0, mask: 0x0
         Unknown VR
    callsite  main/45 -> UART_Print/32 : 
       param 0: CONST: "  Max file   : "
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/45 -> UART_Print/32 : 
       param 0: CONST: "  Buffer     : DTCM RAM (128 KB)\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/45 -> UART_Print/32 : 
       param 0: CONST: "  Sector     : 128 KB each\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/45 -> UART_Print/32 : 
       param 0: CONST: "  Flash base : 0x004E0000\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/45 -> UART_Print/32 : 
       param 0: CONST: "  Target     : PFlash (Code Flash)\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/45 -> UART_Print/32 : 
       param 0: CONST: "  S32K342  UART -> Flash  File Store\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/45 -> UART_Print/32 : 
       param 0: CONST: "==============================================\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/45 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  main/45 -> C40_Ip_Init/56 : 
       no arg info
    callsite  main/45 -> Lpuart_Uart_Ip_Init/54 : 
       no arg info
    callsite  main/45 -> IntCtrl_Ip_ConfigIrqRouting/52 : 
       no arg info
    callsite  main/45 -> IntCtrl_Ip_Init/50 : 
       no arg info
    callsite  main/45 -> Siul2_Port_Ip_Init/48 : 
       no arg info
    callsite  main/45 -> Clock_Ip_Init/46 : 
       no arg info
  Jump functions of caller  DoTransfer/44:
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_PrintHex32/34 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: " -- 0x"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_PrintHex32/34 : 
       param 0: CONST: 5111808
         value: 0x4e0000, mask: 0x0
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: " bytes stored at 0x"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_PrintUInt/33 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "  "
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: ">>> FLASH STORE SUCCESS <<<\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: ">>> FLASH VERIFY FAILED <<<\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> Flash_VerifyCRC/43 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "Verifying...\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "Flash write done.\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: ">>> FLASH WRITE FAILED <<<\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> Flash_WriteFromBuffer/42 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "...\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_PrintHex32/34 : 
       param 0: CONST: 5111808
         value: 0x4e0000, mask: 0x0
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "Writing to flash 0x"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_PrintHex32/34 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "CRC32 received : 0x"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> CRC32_Compute/38 : 
       param 0: CONST: &RxBuf
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: " bytes in DTCM RAM.\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_PrintUInt/33 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "Receive OK -- "
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: ">>> RECEIVE FAILED <<<\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_ReadExact/35 : 
       param 0: CONST: &RxBuf
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
       param 1: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: " bytes...\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_PrintUInt/33 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "Waiting for "
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: ">>> ERASE DONE.  NOW: File -> Send File -> tick Binary -> Send <<<\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> Flash_EraseForFile/41 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_PrintHex32/34 : 
       param 0: CONST: 5111808
         value: 0x4e0000, mask: 0x0
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "Flash target : 0x"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "Increase RX_BUF_SIZE in main.c (max ~120000)\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: " bytes.\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_PrintUInt.part.0/74 : 
       param 0: CONST: 100000
         value: 0x186a0, mask: 0x0
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "ERROR: file too large. Max = "
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: ")\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_PrintHex32/34 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: " bytes  (0x"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_PrintUInt/33 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "File size : "
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "Erase done. Ready for new file.\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> Flash_EraseForFile/41 : 
       param 0: CONST: 100000
         value: 0x186a0, mask: 0x0
         Unknown VR
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "Reset: erasing sectors...\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> ReadHeader/37 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffffc
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "----------------------------------------------\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "  Reset/erase  ->  00000000\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "  100000 bytes ->  000186A0\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "  65000 bytes  ->  0000FDE8\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "  38000 bytes  ->  00009470\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "Type 8 hex chars = file size (no Enter):\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  DoTransfer/44 -> UART_Print/32 : 
       param 0: CONST: "\r\n----------------------------------------------\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
  Jump functions of caller  Flash_VerifyCRC/43:
    callsite  Flash_VerifyCRC/43 -> UART_Print/32 : 
       param 0: CONST: "ERROR: CRC MISMATCH\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_VerifyCRC/43 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_VerifyCRC/43 -> UART_PrintHex32/34 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  Flash_VerifyCRC/43 -> UART_Print/32 : 
       param 0: CONST: "  CRC32 in flash : 0x"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_VerifyCRC/43 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_VerifyCRC/43 -> UART_PrintHex32/34 : 
       param 0: PASS THROUGH: 1, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  Flash_VerifyCRC/43 -> UART_Print/32 : 
       param 0: CONST: "  CRC32 received : 0x"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_VerifyCRC/43 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_VerifyCRC/43 -> UART_PrintHex32/34 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffff0
         Unknown VR
    callsite  Flash_VerifyCRC/43 -> UART_Print/32 : 
       param 0: CONST: "ERROR: readback failed offset=0x"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_VerifyCRC/43 -> C40_Ip_Read/72 : 
       no arg info
  Jump functions of caller  Flash_WriteFromBuffer/42:
    callsite  Flash_WriteFromBuffer/42 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_WriteFromBuffer/42 -> UART_PrintHex32/34 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffff0
         Unknown VR
    callsite  Flash_WriteFromBuffer/42 -> UART_Print/32 : 
       param 0: CONST: "ERROR: write failed offset=0x"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_WriteFromBuffer/42 -> C40_Ip_MainInterfaceWriteStatus/71 : 
       no arg info
    callsite  Flash_WriteFromBuffer/42 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_WriteFromBuffer/42 -> UART_PrintHex32/34 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xfffffff0
         Unknown VR
    callsite  Flash_WriteFromBuffer/42 -> UART_Print/32 : 
       param 0: CONST: "ERROR: write start failed offset=0x"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_WriteFromBuffer/42 -> C40_Ip_MainInterfaceWrite/70 : 
       no arg info
    callsite  Flash_WriteFromBuffer/42 -> memcpy/69 : 
       no arg info
    callsite  Flash_WriteFromBuffer/42 -> memset/68 : 
       no arg info
  Jump functions of caller  Flash_EraseForFile/41:
    callsite  Flash_EraseForFile/41 -> UART_Print/32 : 
       param 0: CONST: "Erase complete.\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_EraseForFile/41 -> UART_Print/32 : 
       param 0: CONST: " OK\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_EraseForFile/41 -> UART_PrintUInt/33 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x7fff
         VR  [0, 32767]
    callsite  Flash_EraseForFile/41 -> UART_Print/32 : 
       param 0: CONST: "  Sector "
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_EraseForFile/41 -> Flash_EraseSector/40 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x7fff
         VR  [0, 32767]
    callsite  Flash_EraseForFile/41 -> Flash_UnlockSector/39 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x7fff
         VR  [0, 32767]
    callsite  Flash_EraseForFile/41 -> UART_Print/32 : 
       param 0: CONST: " PFlash sector(s) x 128 KB each...\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_EraseForFile/41 -> UART_PrintUInt/33 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0x7fff
         VR  [0, 32767]
    callsite  Flash_EraseForFile/41 -> UART_Print/32 : 
       param 0: CONST: "Erasing "
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
  Jump functions of caller  Flash_EraseSector/40:
    callsite  Flash_EraseSector/40 -> UART_Print/32 : 
       param 0: CONST: "  Erase status OK\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_EraseSector/40 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_EraseSector/40 -> UART_PrintUInt/33 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  Flash_EraseSector/40 -> UART_Print/32 : 
       param 0: CONST: " status="
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_EraseSector/40 -> UART_PrintUInt/33 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  Flash_EraseSector/40 -> UART_Print/32 : 
       param 0: CONST: "ERROR: erase failed sector="
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_EraseSector/40 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_EraseSector/40 -> UART_PrintUInt/33 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  Flash_EraseSector/40 -> UART_Print/32 : 
       param 0: CONST: " last_status="
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_EraseSector/40 -> UART_PrintUInt/33 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  Flash_EraseSector/40 -> UART_Print/32 : 
       param 0: CONST: "ERROR: erase TIMEOUT sector="
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_EraseSector/40 -> C40_Ip_MainInterfaceSectorEraseStatus/64 : 
       no arg info
    callsite  Flash_EraseSector/40 -> UART_Print/32 : 
       param 0: CONST: "  Erase started, polling status...\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_EraseSector/40 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_EraseSector/40 -> UART_PrintUInt/33 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  Flash_EraseSector/40 -> UART_Print/32 : 
       param 0: CONST: " status="
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_EraseSector/40 -> UART_PrintUInt/33 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  Flash_EraseSector/40 -> UART_Print/32 : 
       param 0: CONST: "ERROR: erase start failed sector="
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_EraseSector/40 -> C40_Ip_MainInterfaceSectorErase/63 : 
       no arg info
    callsite  Flash_EraseSector/40 -> UART_Print/32 : 
       param 0: CONST: "...\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_EraseSector/40 -> UART_PrintUInt/33 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  Flash_EraseSector/40 -> UART_Print/32 : 
       param 0: CONST: "  Starting erase sector="
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
  Jump functions of caller  Flash_UnlockSector/39:
    callsite  Flash_UnlockSector/39 -> UART_Print/32 : 
       param 0: CONST: "  Sector already unlocked\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_UnlockSector/39 -> UART_Print/32 : 
       param 0: CONST: "  Sector unlocked OK\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_UnlockSector/39 -> UART_Print/32 : 
       param 0: CONST: "\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_UnlockSector/39 -> UART_PrintUInt/33 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  Flash_UnlockSector/39 -> UART_Print/32 : 
       param 0: CONST: "ERROR: unlock failed sector="
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_UnlockSector/39 -> C40_Ip_GetLock/61 : 
       no arg info
    callsite  Flash_UnlockSector/39 -> C40_Ip_ClearLock/62 : 
       no arg info
    callsite  Flash_UnlockSector/39 -> UART_Print/32 : 
       param 0: CONST: "  Sector locked, clearing...\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_UnlockSector/39 -> C40_Ip_GetLock/61 : 
       no arg info
    callsite  Flash_UnlockSector/39 -> UART_Print/32 : 
       param 0: CONST: ")...\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_UnlockSector/39 -> UART_PrintUInt/33 : 
       param 0: PASS THROUGH: 0, op plus_expr 23
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  Flash_UnlockSector/39 -> UART_Print/32 : 
       param 0: CONST: " (index="
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  Flash_UnlockSector/39 -> UART_PrintUInt/33 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  Flash_UnlockSector/39 -> UART_Print/32 : 
       param 0: CONST: "  Checking lock for sector="
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
  Jump functions of caller  CRC32_Compute/38:
  Jump functions of caller  ReadHeader/37:
    callsite  ReadHeader/37 -> UART_Print/32 : 
       param 0: CONST: "ERROR: non-hex character in header\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  ReadHeader/37 -> HexNibble/36 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  ReadHeader/37 -> HexNibble/36 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xff
         Unknown VR
    callsite  ReadHeader/37 -> UART_ReadExact/35 : 
       param 0: UNKNOWN
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
       param 1: CONST: 8
         value: 0x8, mask: 0x0
         Unknown VR
  Jump functions of caller  HexNibble/36:
    callsite  HexNibble/36 -> HexNibble.part.0/73 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xff
         Unknown VR
  Jump functions of caller  UART_ReadExact/35:
    callsite  UART_ReadExact/35 -> UART_Print/32 : 
       param 0: CONST: "ERROR: RX timeout\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  UART_ReadExact/35 -> Lpuart_Uart_Ip_AbortReceivingData/67 : 
       no arg info
    callsite  UART_ReadExact/35 -> Lpuart_Uart_Ip_GetReceiveStatus/66 : 
       no arg info
    callsite  UART_ReadExact/35 -> UART_Print/32 : 
       param 0: CONST: "ERROR: RX start failed\r\n"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
    callsite  UART_ReadExact/35 -> Lpuart_Uart_Ip_AsyncReceive/65 : 
       no arg info
  Jump functions of caller  UART_PrintHex32/34:
    callsite  UART_PrintHex32/34 -> UART_Print/32 : 
       param 0: UNKNOWN
         Aggregate passed by reference:
           offset: 64, type: char, CONST: 0
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
  Jump functions of caller  UART_PrintUInt/33:
    callsite  UART_PrintUInt/33 -> UART_PrintUInt.part.0/74 : 
       param 0: PASS THROUGH: 0, op nop_expr
         value: 0x0, mask: 0xffffffff
         Unknown VR
    callsite  UART_PrintUInt/33 -> UART_Print/32 : 
       param 0: CONST: "0"
         value: 0x0, mask: 0xffffffff
         VR  [1, -1]
  Jump functions of caller  UART_Print/32:
    callsite  UART_Print/32 -> UART_WriteRaw/31 : 
       param 0: PASS THROUGH: 0, op nop_expr, agg_preserved
         value: 0x0, mask: 0xffffffff
         Unknown VR
       param 1: UNKNOWN
         value: 0x0, mask: 0x7fffffff
         VR  [0, 2147483645]
    callsite  UART_Print/32 -> strlen/58 : 
       no arg info
  Jump functions of caller  UART_WriteRaw/31:
    callsite  UART_WriteRaw/31 -> Lpuart_Uart_Ip_GetTransmitStatus/60 : 
       no arg info
    callsite  UART_WriteRaw/31 -> Lpuart_Uart_Ip_AsyncSend/59 : 
       no arg info

 Propagating constants:


overall_size: 631
 - context independent values, size: 18, time_benefit: 1.000000
     Decided to specialize for all known contexts, code not going to grow.

IPA lattices after all propagation:

Lattices:
  Node: UART_PrintUInt.part.0/74:
    param [0]: VARIABLE
               100000 [loc_time: 1, loc_size: 29, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: HexNibble.part.0/73:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: main/45:
  Node: DoTransfer/44:
  Node: Flash_VerifyCRC/43:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Flash_WriteFromBuffer/42:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Flash_EraseForFile/41:
    param [0]: VARIABLE
               100000 [loc_time: 69, loc_size: 30, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: Flash_EraseSector/40:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0x7fff
         uint32 [0, 32767]
        AGGS VARIABLE
  Node: Flash_UnlockSector/39:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0x7fff
         uint32 [0, 32767]
        AGGS VARIABLE
  Node: CRC32_Compute/38:
    param [0]: &RxBuf [loc_time: 0, loc_size: 0, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         const uint8 * [1B, +INF]
        AGGS VARIABLE
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: ReadHeader/37:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0xfffffffc
         uint32 * [1B, +INF]
        AGGS VARIABLE
  Node: HexNibble/36:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: UART_ReadExact/35:
    param [0]: VARIABLE
               &RxBuf [loc_time: 1, loc_size: 35, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         uint8 * [1B, +INF]
        AGGS VARIABLE
    param [1]: VARIABLE
               8 [loc_time: 3, loc_size: 33, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: UART_PrintHex32/34:
    param [0]: VARIABLE
               5111808 [loc_time: 1, loc_size: 16, prop_time: 0, prop_size: 0]
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: UART_PrintUInt/33:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         int VARYING
        AGGS VARIABLE
  Node: UART_Print/32:
    param [0]: BOTTOM
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         const char * [1B, +INF]
        AGGS VARIABLE
        ref offset 64: 0 [loc_time: 0, loc_size: 9, prop_time: 0, prop_size: 0]
  Node: UART_WriteRaw/31:
    param [0]: VARIABLE
         ctxs: VARIABLE
         Bits unusable (BOTTOM)
         const uint8 * [1B, +INF]
        AGGS VARIABLE
        ref offset 64: 0 [loc_time: 0, loc_size: 24, prop_time: 0, prop_size: 0]
    param [1]: VARIABLE
         ctxs: VARIABLE
         Bits: value = 0x0, mask = 0x7fffffff
         uint32 [0, 2147483645]
        AGGS VARIABLE

IPA decision stage:

 - Creating a specialized node of CRC32_Compute/38 for all known contexts.
    replacing param #0 data with const &RxBuf
Propagated bits info for function Flash_EraseSector/40:
 param 0: value = 0x0, mask = 0x7fff
Propagated bits info for function Flash_UnlockSector/39:
 param 0: value = 0x0, mask = 0x7fff
Propagated bits info for function ReadHeader/37:
 param 0: value = 0x0, mask = 0xfffffffc
Propagated bits info for function UART_WriteRaw/31:
 param 1: value = 0x0, mask = 0x7fffffff

IPA constant propagation end

Reclaiming functions: CRC32_Compute/38
Reclaiming variables:
Clearing address taken flags:
Symbol table:

CRC32_Compute.constprop.0/78 (CRC32_Compute.constprop) @067ae620
  Type: function definition analyzed
  Visibility:
  References: RxBuf/28 (addr) 
  Referring: 
  Clone of CRC32_Compute/38
  Availability: local
  Function flags: count:14744044 (estimated locally) local optimize_size
  Called by: DoTransfer/44 (99587951 (estimated locally),0.09 per call) 
  Calls: 
UART_PrintUInt.part.0/74 (UART_PrintUInt.part.0) @066b4b60
  Type: function definition analyzed
  Visibility: prevailing_def_ironly artificial
  References: 
  Referring: 
  Availability: local
  Function flags: count:118111600 (estimated locally) body local split_part optimize_size
  Called by: main/45 (2697764 (estimated locally),0.20 per call) DoTransfer/44 (159025459 (estimated locally),0.15 per call) UART_PrintUInt/33 (118111600 (estimated locally),0.80 per call) 
  Calls: UART_Print/32 (118111600 (estimated locally),1.00 per call) 
HexNibble.part.0/73 (HexNibble.part.0) @0666dee0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly artificial
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local split_part optimize_size
  Called by: HexNibble/36 (467721933 (estimated locally),0.44 per call) 
  Calls: 
C40_Ip_Read/72 (C40_Ip_Read) @06657380
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_VerifyCRC/43 (15602163 (estimated locally),8.83 per call) 
  Calls: 
C40_Ip_MainInterfaceWriteStatus/71 (C40_Ip_MainInterfaceWriteStatus) @066571c0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_WriteFromBuffer/42 (1073741824 (estimated locally),79.73 per call) 
  Calls: 
C40_Ip_MainInterfaceWrite/70 (C40_Ip_MainInterfaceWrite) @066570e0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_WriteFromBuffer/42 (122598713 (estimated locally),9.10 per call) 
  Calls: 
memcpy/69 (memcpy) @06657000
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_WriteFromBuffer/42 (122598713 (estimated locally),9.10 per call) 
  Calls: 
memset/68 (memset) @0661aee0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_WriteFromBuffer/42 (122598713 (estimated locally),9.10 per call) 
  Calls: 
Lpuart_Uart_Ip_AbortReceivingData/67 (Lpuart_Uart_Ip_AbortReceivingData) @0661ac40
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: UART_ReadExact/35 (14006618 (estimated locally),0.08 per call) 
  Calls: 
Lpuart_Uart_Ip_GetReceiveStatus/66 (Lpuart_Uart_Ip_GetReceiveStatus) @0661ab60
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: UART_ReadExact/35 (1073741824 (estimated locally),6.05 per call) 
  Calls: 
Lpuart_Uart_Ip_AsyncReceive/65 (Lpuart_Uart_Ip_AsyncReceive) @0661aa80
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: UART_ReadExact/35 (86763613 (estimated locally),0.49 per call) 
  Calls: 
C40_Ip_MainInterfaceSectorEraseStatus/64 (C40_Ip_MainInterfaceSectorEraseStatus) @0661a8c0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_EraseSector/40 (1073741824 (estimated locally),7.76 per call) 
  Calls: 
C40_Ip_MainInterfaceSectorErase/63 (C40_Ip_MainInterfaceSectorErase) @0661a7e0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_EraseSector/40 (138405316 (estimated locally),1.00 per call) 
  Calls: 
C40_Ip_ClearLock/62 (C40_Ip_ClearLock) @0661a620
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_UnlockSector/39 (365072224 (estimated locally),0.34 per call) 
  Calls: 
C40_Ip_GetLock/61 (C40_Ip_GetLock) @0661a540
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_UnlockSector/39 (365072224 (estimated locally),0.34 per call) Flash_UnlockSector/39 (1073741823 (estimated locally),1.00 per call) 
  Calls: 
Lpuart_Uart_Ip_GetTransmitStatus/60 (Lpuart_Uart_Ip_GetTransmitStatus) @0661a000
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: UART_WriteRaw/31 (1073741824 (estimated locally),10.24 per call) 
  Calls: 
Lpuart_Uart_Ip_AsyncSend/59 (Lpuart_Uart_Ip_AsyncSend) @0660dee0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: UART_WriteRaw/31 (104852513 (estimated locally),1.00 per call) 
  Calls: 
strlen/58 (strlen) @0660dd20
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: UART_Print/32 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
C40ConfigSet_BOARD_InitPeripherals_InitCfg/57 (C40ConfigSet_BOARD_InitPeripherals_InitCfg) @066121f8
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/45 (addr) 
  Availability: not_available
  Varpool flags: read-only
C40_Ip_Init/56 (C40_Ip_Init) @0660da80
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/45 (13328872 (estimated locally),1.00 per call) 
  Calls: 
Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS/55 (Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS) @06612168
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/45 (addr) 
  Availability: not_available
  Varpool flags: read-only
Lpuart_Uart_Ip_Init/54 (Lpuart_Uart_Ip_Init) @0660d8c0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/45 (13328872 (estimated locally),1.00 per call) 
  Calls: 
intRouteConfig/53 (intRouteConfig) @066120d8
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/45 (addr) 
  Availability: not_available
  Varpool flags: read-only
IntCtrl_Ip_ConfigIrqRouting/52 (IntCtrl_Ip_ConfigIrqRouting) @0660d7e0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/45 (13328872 (estimated locally),1.00 per call) 
  Calls: 
IntCtrlConfig_0/51 (IntCtrlConfig_0) @06612048
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/45 (addr) 
  Availability: not_available
  Varpool flags: read-only
IntCtrl_Ip_Init/50 (IntCtrl_Ip_Init) @0660d700
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/45 (13328872 (estimated locally),1.00 per call) 
  Calls: 
g_pin_mux_InitConfigArr0/49 (g_pin_mux_InitConfigArr0) @065fef78
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/45 (addr) 
  Availability: not_available
  Varpool flags: read-only
Siul2_Port_Ip_Init/48 (Siul2_Port_Ip_Init) @0660d620
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/45 (13328872 (estimated locally),1.00 per call) 
  Calls: 
Clock_Ip_aClockConfig/47 (Clock_Ip_aClockConfig) @065feee8
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/45 (addr) 
  Availability: not_available
  Varpool flags: read-only
Clock_Ip_Init/46 (Clock_Ip_Init) @0660d540
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/45 (13328872 (estimated locally),1.00 per call) 
  Calls: 
main/45 (main) @0660d0e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Clock_Ip_aClockConfig/47 (addr) g_pin_mux_InitConfigArr0/49 (addr) IntCtrlConfig_0/51 (addr) intRouteConfig/53 (addr) Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS/55 (addr) C40ConfigSet_BOARD_InitPeripherals_InitCfg/57 (addr) 
  Referring: 
  Availability: available
  Function flags: count:13328872 (estimated locally) body only_called_at_startup executed_once optimize_size
  Called by: 
  Calls: DoTransfer/44 (272474102 (estimated locally),20.44 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_PrintUInt.part.0/74 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) C40_Ip_Init/56 (13328872 (estimated locally),1.00 per call) Lpuart_Uart_Ip_Init/54 (13328872 (estimated locally),1.00 per call) IntCtrl_Ip_ConfigIrqRouting/52 (13328872 (estimated locally),1.00 per call) IntCtrl_Ip_Init/50 (13328872 (estimated locally),1.00 per call) Siul2_Port_Ip_Init/48 (13328872 (estimated locally),1.00 per call) Clock_Ip_Init/46 (13328872 (estimated locally),1.00 per call) 
DoTransfer/44 (DoTransfer) @065f6e00
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: RxBuf/28 (addr) RxBuf/28 (addr) 
  Referring: 
  Availability: local
  Function flags: count:1073741823 (estimated locally) body local optimize_size
  Called by: main/45 (272474102 (estimated locally),20.44 per call) 
  Calls: UART_Print/32 (43380511 (estimated locally),0.04 per call) UART_PrintHex32/34 (43380511 (estimated locally),0.04 per call) UART_Print/32 (43380511 (estimated locally),0.04 per call) UART_PrintHex32/34 (43380511 (estimated locally),0.04 per call) UART_Print/32 (43380511 (estimated locally),0.04 per call) UART_PrintUInt/33 (43380511 (estimated locally),0.04 per call) UART_Print/32 (43380511 (estimated locally),0.04 per call) UART_Print/32 (43380511 (estimated locally),0.04 per call) UART_Print/32 (43380511 (estimated locally),0.04 per call) UART_Print/32 (22347536 (estimated locally),0.02 per call) Flash_VerifyCRC/43 (65728047 (estimated locally),0.06 per call) UART_Print/32 (65728047 (estimated locally),0.06 per call) UART_Print/32 (65728047 (estimated locally),0.06 per call) UART_Print/32 (33859904 (estimated locally),0.03 per call) Flash_WriteFromBuffer/42 (99587951 (estimated locally),0.09 per call) UART_Print/32 (99587951 (estimated locally),0.09 per call) UART_PrintHex32/34 (99587951 (estimated locally),0.09 per call) UART_Print/32 (99587951 (estimated locally),0.09 per call) UART_Print/32 (99587951 (estimated locally),0.09 per call) UART_PrintHex32/34 (99587951 (estimated locally),0.09 per call) UART_Print/32 (99587951 (estimated locally),0.09 per call) CRC32_Compute.constprop.0/78 (99587951 (estimated locally),0.09 per call) UART_Print/32 (99587951 (estimated locally),0.09 per call) UART_PrintUInt/33 (99587951 (estimated locally),0.09 per call) UART_Print/32 (99587951 (estimated locally),0.09 per call) UART_Print/32 (51302885 (estimated locally),0.05 per call) UART_ReadExact/35 (150890836 (estimated locally),0.14 per call) UART_Print/32 (150890836 (estimated locally),0.14 per call) UART_PrintUInt/33 (150890836 (estimated locally),0.14 per call) UART_Print/32 (150890836 (estimated locally),0.14 per call) UART_Print/32 (150890836 (estimated locally),0.14 per call) UART_Print/32 (150890836 (estimated locally),0.14 per call) Flash_EraseForFile/41 (308696474 (estimated locally),0.29 per call) UART_Print/32 (308696474 (estimated locally),0.29 per call) UART_PrintHex32/34 (308696474 (estimated locally),0.29 per call) UART_Print/32 (308696474 (estimated locally),0.29 per call) UART_Print/32 (159025459 (estimated locally),0.15 per call) UART_Print/32 (159025459 (estimated locally),0.15 per call) UART_PrintUInt.part.0/74 (159025459 (estimated locally),0.15 per call) UART_Print/32 (159025459 (estimated locally),0.15 per call) UART_Print/32 (467721933 (estimated locally),0.44 per call) UART_PrintHex32/34 (467721933 (estimated locally),0.44 per call) UART_Print/32 (467721933 (estimated locally),0.44 per call) UART_PrintUInt/33 (467721933 (estimated locally),0.44 per call) UART_Print/32 (467721933 (estimated locally),0.44 per call) UART_Print/32 (240947666 (estimated locally),0.22 per call) Flash_EraseForFile/41 (240947666 (estimated locally),0.22 per call) UART_Print/32 (240947666 (estimated locally),0.22 per call) ReadHeader/37 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) 
Flash_VerifyCRC/43 (Flash_VerifyCRC) @065f6b60
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: ReadBuf/30 (addr) ReadBuf/30 (read) 
  Referring: 
  Availability: local
  Function flags: count:1766181 (estimated locally) body local optimize_size
  Called by: DoTransfer/44 (65728047 (estimated locally),0.06 per call) 
  Calls: UART_Print/32 (299661 (estimated locally),0.17 per call) UART_Print/32 (908062 (estimated locally),0.51 per call) UART_PrintHex32/34 (908062 (estimated locally),0.51 per call) UART_Print/32 (908062 (estimated locally),0.51 per call) UART_Print/32 (908062 (estimated locally),0.51 per call) UART_PrintHex32/34 (908062 (estimated locally),0.51 per call) UART_Print/32 (908062 (estimated locally),0.51 per call) UART_Print/32 (858119 (estimated locally),0.49 per call) UART_PrintHex32/34 (858119 (estimated locally),0.49 per call) UART_Print/32 (858119 (estimated locally),0.49 per call) C40_Ip_Read/72 (15602163 (estimated locally),8.83 per call) 
Flash_WriteFromBuffer/42 (Flash_WriteFromBuffer) @065f68c0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: PageBuf/29 (addr) RxBuf/28 (addr) PageBuf/29 (addr) PageBuf/29 (addr) 
  Referring: 
  Availability: local
  Function flags: count:13467578 (estimated locally) body local optimize_size
  Called by: DoTransfer/44 (99587951 (estimated locally),0.09 per call) 
  Calls: UART_Print/32 (4322885 (estimated locally),0.32 per call) UART_PrintHex32/34 (4322885 (estimated locally),0.32 per call) UART_Print/32 (4322885 (estimated locally),0.32 per call) C40_Ip_MainInterfaceWriteStatus/71 (1073741824 (estimated locally),79.73 per call) UART_Print/32 (4487113 (estimated locally),0.33 per call) UART_PrintHex32/34 (4487113 (estimated locally),0.33 per call) UART_Print/32 (4487113 (estimated locally),0.33 per call) C40_Ip_MainInterfaceWrite/70 (122598713 (estimated locally),9.10 per call) memcpy/69 (122598713 (estimated locally),9.10 per call) memset/68 (122598713 (estimated locally),9.10 per call) 
Flash_EraseForFile/41 (Flash_EraseForFile) @065f6620
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:113634474 (estimated locally) body local optimize_size
  Called by: DoTransfer/44 (308696474 (estimated locally),0.29 per call) DoTransfer/44 (240947666 (estimated locally),0.22 per call) 
  Calls: UART_Print/32 (39298952 (estimated locally),0.35 per call) UART_Print/32 (960107351 (estimated locally),8.45 per call) UART_PrintUInt/33 (960107351 (estimated locally),8.45 per call) UART_Print/32 (960107351 (estimated locally),8.45 per call) Flash_EraseSector/40 (996582262 (estimated locally),8.77 per call) Flash_UnlockSector/39 (1034442872 (estimated locally),9.10 per call) UART_Print/32 (113634474 (estimated locally),1.00 per call) UART_PrintUInt/33 (113634474 (estimated locally),1.00 per call) UART_Print/32 (113634474 (estimated locally),1.00 per call) 
Flash_EraseSector/40 (Flash_EraseSector) @065f6380
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:138405316 (estimated locally) body local optimize_size
  Called by: Flash_EraseForFile/41 (996582262 (estimated locally),8.77 per call) 
  Calls: UART_Print/32 (27598020 (estimated locally),0.20 per call) UART_Print/32 (27598020 (estimated locally),0.20 per call) UART_PrintUInt/33 (27598020 (estimated locally),0.20 per call) UART_Print/32 (27598020 (estimated locally),0.20 per call) UART_PrintUInt/33 (27598020 (estimated locally),0.20 per call) UART_Print/32 (27598020 (estimated locally),0.20 per call) UART_Print/32 (14006618 (estimated locally),0.10 per call) UART_PrintUInt/33 (14006618 (estimated locally),0.10 per call) UART_Print/32 (14006618 (estimated locally),0.10 per call) UART_PrintUInt/33 (14006618 (estimated locally),0.10 per call) UART_Print/32 (14006618 (estimated locally),0.10 per call) C40_Ip_MainInterfaceSectorEraseStatus/64 (1073741824 (estimated locally),7.76 per call) UART_Print/32 (69202658 (estimated locally),0.50 per call) UART_Print/32 (69202658 (estimated locally),0.50 per call) UART_PrintUInt/33 (69202658 (estimated locally),0.50 per call) UART_Print/32 (69202658 (estimated locally),0.50 per call) UART_PrintUInt/33 (69202658 (estimated locally),0.50 per call) UART_Print/32 (69202658 (estimated locally),0.50 per call) C40_Ip_MainInterfaceSectorErase/63 (138405316 (estimated locally),1.00 per call) UART_Print/32 (138405316 (estimated locally),1.00 per call) UART_PrintUInt/33 (138405316 (estimated locally),1.00 per call) UART_Print/32 (138405316 (estimated locally),1.00 per call) 
Flash_UnlockSector/39 (Flash_UnlockSector) @065f60e0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741823 (estimated locally) body local optimize_size
  Called by: Flash_EraseForFile/41 (1034442872 (estimated locally),9.10 per call) 
  Calls: UART_Print/32 (708669600 (estimated locally),0.66 per call) UART_Print/32 (288516577 (estimated locally),0.27 per call) UART_Print/32 (76555647 (estimated locally),0.07 per call) UART_PrintUInt/33 (76555647 (estimated locally),0.07 per call) UART_Print/32 (76555647 (estimated locally),0.07 per call) C40_Ip_GetLock/61 (365072224 (estimated locally),0.34 per call) C40_Ip_ClearLock/62 (365072224 (estimated locally),0.34 per call) UART_Print/32 (365072224 (estimated locally),0.34 per call) C40_Ip_GetLock/61 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) UART_PrintUInt/33 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) UART_PrintUInt/33 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) 
CRC32_Compute/38 (CRC32_Compute) @065ede00
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:14744044 (estimated locally) body optimize_size
  Called by: 
  Calls: 
ReadHeader/37 (ReadHeader) @065edb60
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:418903057 (estimated locally) body local optimize_size
  Called by: DoTransfer/44 (1073741823 (estimated locally),1.00 per call) 
  Calls: UART_Print/32 (61727650 (estimated locally),0.15 per call) HexNibble/36 (858993457 (estimated locally),2.05 per call) HexNibble/36 (858993457 (estimated locally),2.05 per call) UART_ReadExact/35 (418903057 (estimated locally),1.00 per call) 
HexNibble/36 (HexNibble) @065ed8c0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741823 (estimated locally) body local optimize_size
  Called by: ReadHeader/37 (858993457 (estimated locally),2.05 per call) ReadHeader/37 (858993457 (estimated locally),2.05 per call) 
  Calls: HexNibble.part.0/73 (467721933 (estimated locally),0.44 per call) 
UART_ReadExact/35 (UART_ReadExact) @065ed620
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:177503302 (estimated locally) body local optimize_size
  Called by: DoTransfer/44 (150890836 (estimated locally),0.14 per call) ReadHeader/37 (418903057 (estimated locally),1.00 per call) 
  Calls: UART_Print/32 (14006618 (estimated locally),0.08 per call) Lpuart_Uart_Ip_AbortReceivingData/67 (14006618 (estimated locally),0.08 per call) Lpuart_Uart_Ip_GetReceiveStatus/66 (1073741824 (estimated locally),6.05 per call) UART_Print/32 (17560955 (estimated locally),0.10 per call) Lpuart_Uart_Ip_AsyncReceive/65 (86763613 (estimated locally),0.49 per call) 
UART_PrintHex32/34 (UART_PrintHex32) @065ed380
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:119292720 (estimated locally) body local optimize_size
  Called by: DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (308696474 (estimated locally),0.29 per call) DoTransfer/44 (467721933 (estimated locally),0.44 per call) Flash_VerifyCRC/43 (908062 (estimated locally),0.51 per call) Flash_VerifyCRC/43 (908062 (estimated locally),0.51 per call) Flash_VerifyCRC/43 (858119 (estimated locally),0.49 per call) Flash_WriteFromBuffer/42 (4322885 (estimated locally),0.32 per call) Flash_WriteFromBuffer/42 (4487113 (estimated locally),0.33 per call) 
  Calls: UART_Print/32 (119292720 (estimated locally),1.00 per call) 
UART_PrintUInt/33 (UART_PrintUInt) @065ed0e0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:148083751 (estimated locally) body local optimize_size
  Called by: DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (150890836 (estimated locally),0.14 per call) DoTransfer/44 (467721933 (estimated locally),0.44 per call) Flash_EraseForFile/41 (960107351 (estimated locally),8.45 per call) Flash_EraseForFile/41 (113634474 (estimated locally),1.00 per call) Flash_EraseSector/40 (27598020 (estimated locally),0.20 per call) Flash_EraseSector/40 (27598020 (estimated locally),0.20 per call) Flash_EraseSector/40 (14006618 (estimated locally),0.10 per call) Flash_EraseSector/40 (14006618 (estimated locally),0.10 per call) Flash_EraseSector/40 (69202658 (estimated locally),0.50 per call) Flash_EraseSector/40 (69202658 (estimated locally),0.50 per call) Flash_EraseSector/40 (138405316 (estimated locally),1.00 per call) Flash_UnlockSector/39 (76555647 (estimated locally),0.07 per call) Flash_UnlockSector/39 (1073741823 (estimated locally),1.00 per call) Flash_UnlockSector/39 (1073741823 (estimated locally),1.00 per call) 
  Calls: UART_PrintUInt.part.0/74 (118111600 (estimated locally),0.80 per call) UART_Print/32 (29972151 (estimated locally),0.20 per call) 
UART_Print/32 (UART_Print) @065e6e00
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (22347536 (estimated locally),0.02 per call) DoTransfer/44 (65728047 (estimated locally),0.06 per call) DoTransfer/44 (65728047 (estimated locally),0.06 per call) DoTransfer/44 (33859904 (estimated locally),0.03 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (51302885 (estimated locally),0.05 per call) DoTransfer/44 (150890836 (estimated locally),0.14 per call) DoTransfer/44 (150890836 (estimated locally),0.14 per call) DoTransfer/44 (150890836 (estimated locally),0.14 per call) DoTransfer/44 (150890836 (estimated locally),0.14 per call) DoTransfer/44 (308696474 (estimated locally),0.29 per call) DoTransfer/44 (308696474 (estimated locally),0.29 per call) DoTransfer/44 (159025459 (estimated locally),0.15 per call) DoTransfer/44 (159025459 (estimated locally),0.15 per call) DoTransfer/44 (159025459 (estimated locally),0.15 per call) DoTransfer/44 (467721933 (estimated locally),0.44 per call) DoTransfer/44 (467721933 (estimated locally),0.44 per call) DoTransfer/44 (467721933 (estimated locally),0.44 per call) DoTransfer/44 (240947666 (estimated locally),0.22 per call) DoTransfer/44 (240947666 (estimated locally),0.22 per call) DoTransfer/44 (1073741823 (estimated locally),1.00 per call) DoTransfer/44 (1073741823 (estimated locally),1.00 per call) DoTransfer/44 (1073741823 (estimated locally),1.00 per call) DoTransfer/44 (1073741823 (estimated locally),1.00 per call) DoTransfer/44 (1073741823 (estimated locally),1.00 per call) DoTransfer/44 (1073741823 (estimated locally),1.00 per call) DoTransfer/44 (1073741823 (estimated locally),1.00 per call) Flash_VerifyCRC/43 (299661 (estimated locally),0.17 per call) Flash_VerifyCRC/43 (908062 (estimated locally),0.51 per call) Flash_VerifyCRC/43 (908062 (estimated locally),0.51 per call) Flash_VerifyCRC/43 (908062 (estimated locally),0.51 per call) Flash_VerifyCRC/43 (908062 (estimated locally),0.51 per call) Flash_VerifyCRC/43 (858119 (estimated locally),0.49 per call) Flash_VerifyCRC/43 (858119 (estimated locally),0.49 per call) Flash_WriteFromBuffer/42 (4322885 (estimated locally),0.32 per call) Flash_WriteFromBuffer/42 (4322885 (estimated locally),0.32 per call) Flash_WriteFromBuffer/42 (4487113 (estimated locally),0.33 per call) Flash_WriteFromBuffer/42 (4487113 (estimated locally),0.33 per call) ReadHeader/37 (61727650 (estimated locally),0.15 per call) UART_ReadExact/35 (14006618 (estimated locally),0.08 per call) UART_ReadExact/35 (17560955 (estimated locally),0.10 per call) Flash_EraseForFile/41 (39298952 (estimated locally),0.35 per call) Flash_EraseForFile/41 (960107351 (estimated locally),8.45 per call) Flash_EraseForFile/41 (960107351 (estimated locally),8.45 per call) Flash_EraseForFile/41 (113634474 (estimated locally),1.00 per call) Flash_EraseForFile/41 (113634474 (estimated locally),1.00 per call) Flash_EraseSector/40 (27598020 (estimated locally),0.20 per call) Flash_EraseSector/40 (27598020 (estimated locally),0.20 per call) Flash_EraseSector/40 (27598020 (estimated locally),0.20 per call) Flash_EraseSector/40 (27598020 (estimated locally),0.20 per call) Flash_EraseSector/40 (14006618 (estimated locally),0.10 per call) Flash_EraseSector/40 (14006618 (estimated locally),0.10 per call) Flash_EraseSector/40 (14006618 (estimated locally),0.10 per call) Flash_EraseSector/40 (69202658 (estimated locally),0.50 per call) Flash_EraseSector/40 (69202658 (estimated locally),0.50 per call) Flash_EraseSector/40 (69202658 (estimated locally),0.50 per call) Flash_EraseSector/40 (69202658 (estimated locally),0.50 per call) Flash_EraseSector/40 (138405316 (estimated locally),1.00 per call) Flash_EraseSector/40 (138405316 (estimated locally),1.00 per call) Flash_UnlockSector/39 (708669600 (estimated locally),0.66 per call) Flash_UnlockSector/39 (288516577 (estimated locally),0.27 per call) Flash_UnlockSector/39 (76555647 (estimated locally),0.07 per call) Flash_UnlockSector/39 (76555647 (estimated locally),0.07 per call) Flash_UnlockSector/39 (365072224 (estimated locally),0.34 per call) Flash_UnlockSector/39 (1073741823 (estimated locally),1.00 per call) Flash_UnlockSector/39 (1073741823 (estimated locally),1.00 per call) Flash_UnlockSector/39 (1073741823 (estimated locally),1.00 per call) UART_PrintHex32/34 (119292720 (estimated locally),1.00 per call) UART_PrintUInt/33 (29972151 (estimated locally),0.20 per call) UART_PrintUInt.part.0/74 (118111600 (estimated locally),1.00 per call) 
  Calls: UART_WriteRaw/31 (1073741824 (estimated locally),1.00 per call) strlen/58 (1073741824 (estimated locally),1.00 per call) 
UART_WriteRaw/31 (UART_WriteRaw) @065e6b60
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:104852513 (estimated locally) body local optimize_size
  Called by: UART_Print/32 (1073741824 (estimated locally),1.00 per call) 
  Calls: Lpuart_Uart_Ip_GetTransmitStatus/60 (1073741824 (estimated locally),10.24 per call) Lpuart_Uart_Ip_AsyncSend/59 (104852513 (estimated locally),1.00 per call) 
ReadBuf/30 (ReadBuf) @065e7318
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: Flash_VerifyCRC/43 (addr) Flash_VerifyCRC/43 (read) 
  Availability: available
  Varpool flags:
PageBuf/29 (PageBuf) @065e7288
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: Flash_WriteFromBuffer/42 (addr) Flash_WriteFromBuffer/42 (addr) Flash_WriteFromBuffer/42 (addr) 
  Availability: available
  Varpool flags:
RxBuf/28 (RxBuf) @065e71f8
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly section:.dtcm_bss
  References: 
  Referring: Flash_WriteFromBuffer/42 (addr) DoTransfer/44 (addr) DoTransfer/44 (addr) CRC32_Compute.constprop.0/78 (addr) 
  Availability: available
  Varpool flags:

;; Function UART_Print (UART_Print, funcdef_no=29, decl_uid=7830, cgraph_uid=30, symbol_order=32)

Modification phase of node UART_Print/32
Setting nonnull for 0
UART_Print (const char * msg)
{
  unsigned int _1;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = strlen (msg_3(D));
  UART_WriteRaw (msg_3(D), _1);
  return;

}



;; Function UART_PrintHex32 (UART_PrintHex32, funcdef_no=31, decl_uid=7846, cgraph_uid=32, symbol_order=34)

Modification phase of node UART_PrintHex32/34
UART_PrintHex32 (uint32 v)
{
  uint8 i;
  char h[9];
  unsigned int _1;
  unsigned int _2;
  unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  int _6;
  char _7;

  <bb 2> [local count: 119292720]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG i => 0
  goto <bb 4>; [100.00%]

  <bb 3> [local count: 954449105]:
  # DEBUG BEGIN_STMT
  _1 = (unsigned int) i_8;
  _2 = 7 - _1;
  _3 = _2 * 4;
  _4 = v_14(D) >> _3;
  _5 = _4 & 15;
  _6 = (int) i_8;
  _7 = "0123456789ABCDEF"[_5];
  h[_6] = _7;
  # DEBUG BEGIN_STMT
  i_16 = i_8 + 1;
  # DEBUG i => i_16

  <bb 4> [local count: 1073741824]:
  # i_8 = PHI <0(2), i_16(3)>
  # DEBUG i => i_8
  # DEBUG BEGIN_STMT
  if (i_8 != 8)
    goto <bb 3>; [88.89%]
  else
    goto <bb 5>; [11.11%]

  <bb 5> [local count: 119292720]:
  # DEBUG BEGIN_STMT
  h[8] = 0;
  # DEBUG BEGIN_STMT
  UART_Print (&h);
  h ={v} {CLOBBER};
  return;

}



;; Function UART_ReadExact (UART_ReadExact, funcdef_no=32, decl_uid=7855, cgraph_uid=33, symbol_order=35)

Modification phase of node UART_ReadExact/35
Setting nonnull for 0
UART_ReadExact (uint8 * dest, uint32 count)
{
  uint32 to;
  uint32 rem;
  volatile Lpuart_Uart_Ip_StatusType st;
  <unnamed type> _1;
  <unnamed type> st.18_2;
  <unnamed type> _3;
  <unnamed type> st.19_4;
  <unnamed type> st.21_5;
  uint8 _7;

  <bb 2> [local count: 177503302]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  rem = 0;
  # DEBUG BEGIN_STMT
  # DEBUG to => 4294967295
  # DEBUG BEGIN_STMT
  if (count_12(D) == 0)
    goto <bb 9>; [51.12%]
  else
    goto <bb 3>; [48.88%]

  <bb 3> [local count: 86763613]:
  # DEBUG BEGIN_STMT
  _1 = Lpuart_Uart_Ip_AsyncReceive (2, dest_13(D), count_12(D));
  st ={v} _1;
  # DEBUG BEGIN_STMT
  st.18_2 ={v} st;
  if (st.18_2 != 0)
    goto <bb 4>; [20.24%]
  else
    goto <bb 10>; [79.76%]

  <bb 4> [local count: 17560955]:
  # DEBUG BEGIN_STMT
  UART_Print ("ERROR: RX start failed\r\n");
  # DEBUG BEGIN_STMT
  goto <bb 9>; [100.00%]

  <bb 10> [local count: 69202658]:

  <bb 5> [local count: 1073741824]:
  # to_6 = PHI <4294967295(10), to_18(11)>
  # DEBUG to => to_6
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _3 = Lpuart_Uart_Ip_GetReceiveStatus (2, &rem);
  st ={v} _3;
  # DEBUG BEGIN_STMT
  st.19_4 ={v} st;
  if (st.19_4 == 2)
    goto <bb 6>; [94.50%]
  else
    goto <bb 7>; [5.50%]

  <bb 6> [local count: 1014686024]:
  to_18 = to_6 + 4294967295;
  # DEBUG to => to_18
  if (to_6 != 0)
    goto <bb 11>; [99.00%]
  else
    goto <bb 7>; [1.00%]

  <bb 11> [local count: 1004539166]:
  goto <bb 5>; [100.00%]

  <bb 7> [local count: 69202658]:
  # DEBUG BEGIN_STMT
  st.21_5 ={v} st;
  if (st.21_5 != 0)
    goto <bb 8>; [20.24%]
  else
    goto <bb 9>; [79.76%]

  <bb 8> [local count: 14006618]:
  # DEBUG BEGIN_STMT
  Lpuart_Uart_Ip_AbortReceivingData (2);
  # DEBUG BEGIN_STMT
  UART_Print ("ERROR: RX timeout\r\n");
  # DEBUG BEGIN_STMT

  <bb 9> [local count: 177503302]:
  # _7 = PHI <1(2), 0(4), 0(8), 1(7)>
  rem ={v} {CLOBBER};
  return _7;

}



;; Function HexNibble (HexNibble, funcdef_no=33, decl_uid=7863, cgraph_uid=34, symbol_order=36)

Modification phase of node HexNibble/36
HexNibble (uint8 c)
{
  unsigned char _1;
  unsigned char _2;
  uint8 _3;
  uint8 _5;
  unsigned char _6;

  <bb 2> [local count: 1073741823]:
  # DEBUG BEGIN_STMT
  _1 = c_4(D) + 208;
  if (_1 <= 9)
    goto <bb 6>; [34.00%]
  else
    goto <bb 3>; [66.00%]

  <bb 3> [local count: 708669600]:
  # DEBUG BEGIN_STMT
  _2 = c_4(D) + 191;
  if (_2 <= 5)
    goto <bb 4>; [34.00%]
  else
    goto <bb 5>; [66.00%]

  <bb 4> [local count: 240947666]:
  # DEBUG BEGIN_STMT
  _5 = c_4(D) + 201;
  goto <bb 6>; [100.00%]

  <bb 5> [local count: 467721933]:
  _6 = HexNibble.part.0 (c_4(D));

  <bb 6> [local count: 1073741824]:
  # _3 = PHI <_1(2), _5(4), _6(5)>
  return _3;

}



;; Function UART_PrintUInt.part.0 (UART_PrintUInt.part.0, funcdef_no=44, decl_uid=8080, cgraph_uid=66, symbol_order=74)

Modification phase of node UART_PrintUInt.part.0/74
UART_PrintUInt.part.0 (uint32 v)
{
  char b[12];
  uint8 i;
  uint8 j;
  char t;
  long unsigned int _2;
  char _3;
  int _6;
  char _7;
  int _10;
  int _12;
  unsigned int _14;
  unsigned int _15;
  unsigned int _16;
  unsigned int _17;
  char _18;
  unsigned char _20;

  <bb 9> [local count: 118111600]:
  goto <bb 3>; [100.00%]

  <bb 2> [local count: 955630225]:
  # DEBUG BEGIN_STMT
  _2 = v_1 % 10;
  _3 = (char) _2;
  i_5 = i_4 + 1;
  # DEBUG i => i_5
  _6 = (int) i_4;
  _7 = _3 + 48;
  b[_6] = _7;
  # DEBUG BEGIN_STMT
  v_8 = v_1 / 10;
  # DEBUG v => v_8

  <bb 3> [local count: 1073741824]:
  # v_1 = PHI <v_8(2), v_21(D)(9)>
  # i_4 = PHI <i_5(2), 0(9)>
  # DEBUG i => i_4
  # DEBUG v => v_1
  # DEBUG BEGIN_STMT
  if (v_1 != 0)
    goto <bb 2>; [89.00%]
  else
    goto <bb 4>; [11.00%]

  <bb 4> [local count: 118111600]:
  # i_9 = PHI <i_4(3)>
  # DEBUG BEGIN_STMT
  _10 = (int) i_9;
  b[_10] = 0;
  # DEBUG BEGIN_STMT
  # DEBUG j => 0
  goto <bb 6>; [100.00%]

  <bb 5> [local count: 955630225]:
  # DEBUG BEGIN_STMT
  _12 = (int) j_11;
  t_13 = b[_12];
  # DEBUG t => t_13
  # DEBUG BEGIN_STMT
  _14 = (unsigned int) i_9;
  _15 = (unsigned int) j_11;
  _16 = _14 - _15;
  _17 = _16 + 4294967295;
  _18 = b[_17];
  b[_12] = _18;
  # DEBUG BEGIN_STMT
  b[_17] = t_13;
  # DEBUG BEGIN_STMT
  j_19 = j_11 + 1;
  # DEBUG j => j_19

  <bb 6> [local count: 1073741824]:
  # j_11 = PHI <0(4), j_19(5)>
  # DEBUG j => j_11
  # DEBUG BEGIN_STMT
  _20 = i_9 >> 1;
  if (j_11 < _20)
    goto <bb 5>; [89.00%]
  else
    goto <bb 7>; [11.00%]

  <bb 7> [local count: 118111600]:
  # DEBUG BEGIN_STMT
  UART_Print (&b);
  b ={v} {CLOBBER};

  <bb 8> [local count: 118111600]:
  return;

}



;; Function UART_PrintUInt (UART_PrintUInt, funcdef_no=30, decl_uid=7833, cgraph_uid=31, symbol_order=33)

Modification phase of node UART_PrintUInt/33
UART_PrintUInt (uint32 v)
{
  uint8 i;

  <bb 2> [local count: 148083751]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG i => 0
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  if (v_6(D) == 0)
    goto <bb 3>; [20.24%]
  else
    goto <bb 4>; [79.76%]

  <bb 3> [local count: 29972151]:
  # DEBUG BEGIN_STMT
  UART_Print ("0");
  # DEBUG BEGIN_STMT
  goto <bb 5>; [100.00%]

  <bb 4> [local count: 118111600]:
  # v_3 = PHI <v_6(D)(2)>
  # i_4 = PHI <0(2)>
  UART_PrintUInt.part.0 (v_6(D));

  <bb 5> [local count: 148083751]:
  return;

}



;; Function Flash_EraseForFile (Flash_EraseForFile, funcdef_no=38, decl_uid=7901, cgraph_uid=39, symbol_order=41)

Modification phase of node Flash_EraseForFile/41
Flash_EraseForFile (uint32 fileLen)
{
  uint32 s;
  uint32 n;
  long unsigned int _1;
  unsigned char _2;
  unsigned char _3;
  uint8 _6;

  <bb 2> [local count: 113634474]:
  # DEBUG BEGIN_STMT
  _1 = fileLen_9(D) + 131071;
  n_10 = _1 >> 17;
  # DEBUG n => n_10
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  if (_1 <= 131071)
    goto <bb 3>; [50.00%]
  else
    goto <bb 4>; [50.00%]

  <bb 3> [local count: 56817237]:
  # DEBUG BEGIN_STMT
  # DEBUG n => 1

  <bb 4> [local count: 113634474]:
  # n_4 = PHI <n_10(2), 1(3)>
  # DEBUG n => n_4
  # DEBUG BEGIN_STMT
  UART_Print ("Erasing ");
  # DEBUG BEGIN_STMT
  UART_PrintUInt (n_4);
  # DEBUG BEGIN_STMT
  UART_Print (" PFlash sector(s) x 128 KB each...\r\n");
  # DEBUG BEGIN_STMT
  # DEBUG s => 0
  goto <bb 8>; [100.00%]

  <bb 5> [local count: 1034442872]:
  # DEBUG BEGIN_STMT
  _2 = Flash_UnlockSector (s_5);
  if (_2 == 0)
    goto <bb 10>; [3.66%]
  else
    goto <bb 6>; [96.34%]

  <bb 6> [local count: 996582262]:
  # DEBUG BEGIN_STMT
  _3 = Flash_EraseSector (s_5);
  if (_3 == 0)
    goto <bb 10>; [3.66%]
  else
    goto <bb 7>; [96.34%]

  <bb 7> [local count: 960107351]:
  # DEBUG BEGIN_STMT
  UART_Print ("  Sector ");
  # DEBUG BEGIN_STMT
  UART_PrintUInt (s_5);
  # DEBUG BEGIN_STMT
  UART_Print (" OK\r\n");
  # DEBUG BEGIN_STMT
  s_21 = s_5 + 1;
  # DEBUG s => s_21

  <bb 8> [local count: 1073741824]:
  # s_5 = PHI <0(4), s_21(7)>
  # DEBUG s => s_5
  # DEBUG BEGIN_STMT
  if (n_4 > s_5)
    goto <bb 5>; [96.34%]
  else
    goto <bb 9>; [3.66%]

  <bb 9> [local count: 39298952]:
  # DEBUG BEGIN_STMT
  UART_Print ("Erase complete.\r\n");
  # DEBUG BEGIN_STMT

  <bb 10> [local count: 113634474]:
  # _6 = PHI <0(5), 0(6), 1(9)>
  return _6;

}



;; Function main (main, funcdef_no=42, decl_uid=7944, cgraph_uid=43, symbol_order=45) (executed once)

Modification phase of node main/45
main ()
{
  <unnamed type> _1;

  <bb 2> [local count: 13328872]:
  # DEBUG BEGIN_STMT
  Clock_Ip_Init (&Clock_Ip_aClockConfig[0]);
  # DEBUG BEGIN_STMT
  Siul2_Port_Ip_Init (4, &g_pin_mux_InitConfigArr0);
  # DEBUG BEGIN_STMT
  IntCtrl_Ip_Init (&IntCtrlConfig_0);
  # DEBUG BEGIN_STMT
  IntCtrl_Ip_ConfigIrqRouting (&intRouteConfig);
  # DEBUG BEGIN_STMT
  Lpuart_Uart_Ip_Init (2, &Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS);
  # DEBUG BEGIN_STMT
  _1 = C40_Ip_Init (&C40ConfigSet_BOARD_InitPeripherals_InitCfg);
  if (_1 != 23205)
    goto <bb 6>; [79.76%]
  else
    goto <bb 4>; [20.24%]

  <bb 6> [local count: 10631108]:

  <bb 3> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT

  <bb 7> [local count: 1073741824]:
  goto <bb 3>; [100.00%]

  <bb 4> [local count: 2697764]:
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("==============================================\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  S32K342  UART -> Flash  File Store\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  Target     : PFlash (Code Flash)\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  Flash base : 0x004E0000\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  Sector     : 128 KB each\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  Buffer     : DTCM RAM (128 KB)\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  Max file   : ");
  # DEBUG BEGIN_STMT
  # DEBUG v => 100000
  # DEBUG INLINE_ENTRY UART_PrintUInt
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG i => 0
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  UART_PrintUInt.part.0 (100000);
  # DEBUG v => NULL
  # DEBUG i => NULL
  # DEBUG BEGIN_STMT
  UART_Print (" bytes\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("==============================================\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("HOW TO INCREASE MAX FILE SIZE:\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  Change RX_BUF_SIZE in main.c\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  Max safe value = 120000 (DTCM is 128 KB)\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");

  <bb 5> [local count: 272474102]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  DoTransfer ();
  # DEBUG BEGIN_STMT

  <bb 8> [local count: 272474102]:
  goto <bb 5>; [100.00%]

}


