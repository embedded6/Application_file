src/main.o: ../src/main.c ../RTD/include/Lpuart_Uart_Ip.h \
 ../RTD/include/Lpuart_Uart_Ip_Types.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Platform_Types.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/PlatformTypes.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler_Cfg.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/CompilerDefinition.h \
 ../RTD/include/Lpuart_Uart_Ip_HwAccess.h ../RTD/include/OsIf.h \
 ../RTD/include/OsIf_Internal.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Soc_Ips.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/IpVersionMacros.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/OsIf_Cfg.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/OsIf_ArchCfg.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SYSTICK.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_COMMON.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/BasicTypes.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Base_MemMap.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Lpuart_Uart_Ip_Defines.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcal.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Soc_Ips.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Reg_eSys.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/OsIf_Internal.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_LPUART.h \
 ../RTD/include/SchM_Uart.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Rte_MemMap.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Uart_MemMap.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Lpuart_Uart_Ip_Cfg.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Lpuart_Uart_Ip_Sa_BOARD_InitPeripherals_PBcfg.h \
 ../RTD/include/Lpuart_Uart_Ip_Types.h \
 ../RTD/include/Lpuart_Uart_Ip_Irq.h ../RTD/include/Clock_Ip.h \
 ../RTD/include/Clock_Ip_Types.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Clock_Ip_Cfg_Defines.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_MC_CGM.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_FIRC.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SIRC.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_FXOSC.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SXOSC.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_PLL.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_MC_ME.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_PRAMC.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_FLASH.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_CMU_FC.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_EMIOS.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_RTC.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_CONFIGURATION_GPR.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Clock_Ip_Cfg.h \
 ../RTD/include/Clock_Ip_Types.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcu_MemMap.h \
 ../RTD/include/IntCtrl_Ip.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/IntCtrl_Ip_Cfg.h \
 ../RTD/include/IntCtrl_Ip_TypesDef.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/IntCtrl_Ip_CfgDefines.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_NVIC.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_MSCM.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SCB.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Platform_MemMap.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Devassert.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcal.h \
 ../RTD/include/Siul2_Port_Ip.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/board/Siul2_Port_Ip_Cfg.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SIUL2.h \
 ../RTD/include/Siul2_Port_Ip_Types.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Siul2_Port_Ip_Defines.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_DCM_GPR.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Port_MemMap.h \
 ../RTD/include/Siul2_Port_Ip_Types.h ../RTD/include/C40_Ip.h \
 ../RTD/include/C40_Ip_Types.h \
 F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/C40_Ip_Cfg.h \
 ../RTD/include/OsIf.h ../RTD/include/C40_Ip_Types.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_PFLASH.h \
 F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Fls_MemMap.h
../RTD/include/Lpuart_Uart_Ip.h:
../RTD/include/Lpuart_Uart_Ip_Types.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Platform_Types.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/PlatformTypes.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Compiler_Cfg.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/CompilerDefinition.h:
../RTD/include/Lpuart_Uart_Ip_HwAccess.h:
../RTD/include/OsIf.h:
../RTD/include/OsIf_Internal.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Soc_Ips.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/IpVersionMacros.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/OsIf_Cfg.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/OsIf_ArchCfg.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SYSTICK.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_COMMON.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/BasicTypes.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Base_MemMap.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Lpuart_Uart_Ip_Defines.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcal.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/StandardTypes.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Soc_Ips.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Reg_eSys.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/OsIf_Internal.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_LPUART.h:
../RTD/include/SchM_Uart.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Rte_MemMap.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Uart_MemMap.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Lpuart_Uart_Ip_Cfg.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Lpuart_Uart_Ip_Sa_BOARD_InitPeripherals_PBcfg.h:
../RTD/include/Lpuart_Uart_Ip_Types.h:
../RTD/include/Lpuart_Uart_Ip_Irq.h:
../RTD/include/Clock_Ip.h:
../RTD/include/Clock_Ip_Types.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Clock_Ip_Cfg_Defines.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_MC_CGM.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_FIRC.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SIRC.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_FXOSC.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SXOSC.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_PLL.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_MC_ME.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_PRAMC.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_FLASH.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_CMU_FC.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_EMIOS.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_RTC.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_CONFIGURATION_GPR.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Clock_Ip_Cfg.h:
../RTD/include/Clock_Ip_Types.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcu_MemMap.h:
../RTD/include/IntCtrl_Ip.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/IntCtrl_Ip_Cfg.h:
../RTD/include/IntCtrl_Ip_TypesDef.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/IntCtrl_Ip_CfgDefines.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_NVIC.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_MSCM.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SCB.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Platform_MemMap.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Devassert.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Mcal.h:
../RTD/include/Siul2_Port_Ip.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/board/Siul2_Port_Ip_Cfg.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_SIUL2.h:
../RTD/include/Siul2_Port_Ip_Types.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/Siul2_Port_Ip_Defines.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_DCM_GPR.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Port_MemMap.h:
../RTD/include/Siul2_Port_Ip_Types.h:
../RTD/include/C40_Ip.h:
../RTD/include/C40_Ip_Types.h:
F\:/PROGRAMS/LpuartFlexio_Uart_Ip_Example_S32K342_working_22-04-2026.zip_expanded/LpuartFlexio_Uart_Ip_Example_S32K342/generate/include/C40_Ip_Cfg.h:
../RTD/include/OsIf.h:
../RTD/include/C40_Ip_Types.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/header/S32K342_PFLASH.h:
F\:/S32DS/software/PlatformSDK_S32K3_2022_03/SW32K3_RTD_4_4_2_0_0_D2203/Base_TS_T40D34M20I0R0/include/Fls_MemMap.h:
