Creating summary for UART_PrintUInt.part.0/74:
  Descriptor for parameter 0 vD.8082
    not a candidate for splitting


Creating summary for HexNibble.part.0/73:
  Descriptor for parameter 0 cD.8074
    not a candidate for splitting


Creating summary for main/45:


Creating summary for DoTransfer/44:


Creating summary for Flash_VerifyCRC/43:
  Descriptor for parameter 0 fileLenD.7919
    not a candidate for splitting
  Descriptor for parameter 1 expectedCrcD.7920
    not a candidate for splitting


Creating summary for Flash_WriteFromBuffer/42:
  Descriptor for parameter 0 fileLenD.7908
    not a candidate for splitting


Creating summary for Flash_EraseForFile/41:
  Descriptor for parameter 0 fileLenD.7900
    not a candidate for splitting


Creating summary for Flash_EraseSector/40:
  Descriptor for parameter 0 idxD.7893
    (locally) unused
    not a candidate for splitting


Creating summary for Flash_UnlockSector/39:
  Descriptor for parameter 0 idxD.7889
    (locally) unused
    not a candidate for splitting


Creating summary for CRC32_Compute/38:
  Descriptor for parameter 0 dataD.7876
    not a candidate for splitting
  Descriptor for parameter 1 lenD.7877
    not a candidate for splitting


Creating summary for ReadHeader/37:
  Descriptor for parameter 0 outLenD.7865
    not a candidate for splitting


Creating summary for HexNibble/36:
  Descriptor for parameter 0 cD.7862
    not a candidate for splitting


Creating summary for UART_ReadExact/35:
  Descriptor for parameter 0 destD.7853
    unused with 1 call_uses
    by_ref with 1 pass throughs
  Descriptor for parameter 1 countD.7854
    not a candidate
----------------------------------------
  Descriptor for parameter 0 destD.7853
    (locally) unused
    param_size_limit: 4, size_reached: 0, by_ref
  Descriptor for parameter 1 countD.7854
    not a candidate for splitting


Creating summary for UART_PrintHex32/34:
  Descriptor for parameter 0 vD.7845
    not a candidate for splitting


Creating summary for UART_PrintUInt/33:
  Descriptor for parameter 0 vD.7832
    not a candidate for splitting


Creating summary for UART_Print/32:
  Descriptor for parameter 0 msgD.7829
    unused with 2 call_uses
    by_ref with 2 pass throughs
----------------------------------------
  Descriptor for parameter 0 msgD.7829
    (locally) unused
    param_size_limit: 4, size_reached: 0, by_ref


Creating summary for UART_WriteRaw/31:
  Descriptor for parameter 0 dataD.7820
    unused with 1 call_uses
    by_ref with 1 pass throughs
  Descriptor for parameter 1 lenD.7821
    unused with 1 call_uses
    not a candidate
----------------------------------------
  Descriptor for parameter 0 dataD.7820
    (locally) unused
    param_size_limit: 4, size_reached: 0, by_ref
  Descriptor for parameter 1 lenD.7821
    (locally) unused
    not a candidate for splitting



========== IPA-SRA IPA stage ==========

Summary for node CRC32_Compute.constprop/78:
  Returns value
  Descriptor for parameter 0:
    not a candidate for splitting
  Descriptor for parameter 1:
    not a candidate for splitting


Summary for node UART_PrintUInt.part.0/74:
  Descriptor for parameter 0:
    not a candidate for splitting

  Summary for edge UART_PrintUInt.part.0/74->UART_Print/32:
    return value ignored

Summary for node HexNibble.part.0/73:
  Returns value
  Descriptor for parameter 0:
    not a candidate for splitting


Summary for node main/45:
  Returns value
  No parameter information. 

  Summary for edge main/45->DoTransfer/44:
    return value ignored
  Summary for edge main/45->UART_Print/32:
    return value ignored
  Summary for edge main/45->UART_Print/32:
    return value ignored
  Summary for edge main/45->UART_Print/32:
    return value ignored
  Summary for edge main/45->UART_Print/32:
    return value ignored
  Summary for edge main/45->UART_Print/32:
    return value ignored
  Summary for edge main/45->UART_Print/32:
    return value ignored
  Summary for edge main/45->UART_Print/32:
    return value ignored
  Summary for edge main/45->UART_PrintUInt.part.0/74:
    return value ignored
  Summary for edge main/45->UART_Print/32:
    return value ignored
  Summary for edge main/45->UART_Print/32:
    return value ignored
  Summary for edge main/45->UART_Print/32:
    return value ignored
  Summary for edge main/45->UART_Print/32:
    return value ignored
  Summary for edge main/45->UART_Print/32:
    return value ignored
  Summary for edge main/45->UART_Print/32:
    return value ignored
  Summary for edge main/45->UART_Print/32:
    return value ignored
  Summary for edge main/45->UART_Print/32:
    return value ignored
  Summary for edge main/45->C40_Ip_Init/56:
  Summary for edge main/45->Lpuart_Uart_Ip_Init/54:
    return value ignored
  Summary for edge main/45->IntCtrl_Ip_ConfigIrqRouting/52:
    return value ignored
  Summary for edge main/45->IntCtrl_Ip_Init/50:
    return value ignored
  Summary for edge main/45->Siul2_Port_Ip_Init/48:
    return value ignored
  Summary for edge main/45->Clock_Ip_Init/46:
    return value ignored

Summary for node DoTransfer/44:
  No parameter information. 

  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_PrintHex32/34:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_PrintHex32/34:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_PrintUInt/33:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->Flash_VerifyCRC/43:
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->Flash_WriteFromBuffer/42:
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_PrintHex32/34:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_PrintHex32/34:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->CRC32_Compute.constprop/78:
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_PrintUInt/33:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_ReadExact/35:
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_PrintUInt/33:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->Flash_EraseForFile/41:
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_PrintHex32/34:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_PrintUInt.part.0/74:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_PrintHex32/34:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_PrintUInt/33:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->Flash_EraseForFile/41:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->ReadHeader/37:
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored
  Summary for edge DoTransfer/44->UART_Print/32:
    return value ignored

Summary for node Flash_VerifyCRC/43:
  Returns value
  Descriptor for parameter 0:
    not a candidate for splitting
  Descriptor for parameter 1:
    not a candidate for splitting

  Summary for edge Flash_VerifyCRC/43->UART_Print/32:
    return value ignored
  Summary for edge Flash_VerifyCRC/43->UART_Print/32:
    return value ignored
  Summary for edge Flash_VerifyCRC/43->UART_PrintHex32/34:
    return value ignored
  Summary for edge Flash_VerifyCRC/43->UART_Print/32:
    return value ignored
  Summary for edge Flash_VerifyCRC/43->UART_Print/32:
    return value ignored
  Summary for edge Flash_VerifyCRC/43->UART_PrintHex32/34:
    return value ignored
  Summary for edge Flash_VerifyCRC/43->UART_Print/32:
    return value ignored
  Summary for edge Flash_VerifyCRC/43->UART_Print/32:
    return value ignored
  Summary for edge Flash_VerifyCRC/43->UART_PrintHex32/34:
    return value ignored
  Summary for edge Flash_VerifyCRC/43->UART_Print/32:
    return value ignored
  Summary for edge Flash_VerifyCRC/43->C40_Ip_Read/72:

Summary for node Flash_WriteFromBuffer/42:
  Returns value
  Descriptor for parameter 0:
    not a candidate for splitting

  Summary for edge Flash_WriteFromBuffer/42->UART_Print/32:
    return value ignored
  Summary for edge Flash_WriteFromBuffer/42->UART_PrintHex32/34:
    return value ignored
  Summary for edge Flash_WriteFromBuffer/42->UART_Print/32:
    return value ignored
  Summary for edge Flash_WriteFromBuffer/42->C40_Ip_MainInterfaceWriteStatus/71:
  Summary for edge Flash_WriteFromBuffer/42->UART_Print/32:
    return value ignored
  Summary for edge Flash_WriteFromBuffer/42->UART_PrintHex32/34:
    return value ignored
  Summary for edge Flash_WriteFromBuffer/42->UART_Print/32:
    return value ignored
  Summary for edge Flash_WriteFromBuffer/42->C40_Ip_MainInterfaceWrite/70:
  Summary for edge Flash_WriteFromBuffer/42->memcpy/69:
    return value ignored
    Parameter 0:
    Parameter 1:
    Parameter 2:
      Scalar param sources: 0
  Summary for edge Flash_WriteFromBuffer/42->memset/68:
    return value ignored

Summary for node Flash_EraseForFile/41:
  Returns value
  Descriptor for parameter 0:
    not a candidate for splitting

  Summary for edge Flash_EraseForFile/41->UART_Print/32:
    return value ignored
  Summary for edge Flash_EraseForFile/41->UART_Print/32:
    return value ignored
  Summary for edge Flash_EraseForFile/41->UART_PrintUInt/33:
    return value ignored
  Summary for edge Flash_EraseForFile/41->UART_Print/32:
    return value ignored
  Summary for edge Flash_EraseForFile/41->Flash_EraseSector/40:
  Summary for edge Flash_EraseForFile/41->Flash_UnlockSector/39:
  Summary for edge Flash_EraseForFile/41->UART_Print/32:
    return value ignored
  Summary for edge Flash_EraseForFile/41->UART_PrintUInt/33:
    return value ignored
  Summary for edge Flash_EraseForFile/41->UART_Print/32:
    return value ignored

Summary for node Flash_EraseSector/40:
  Returns value
  Descriptor for parameter 0:
    (locally) unused
    not a candidate for splitting

  Summary for edge Flash_EraseSector/40->UART_Print/32:
    return value ignored
  Summary for edge Flash_EraseSector/40->UART_Print/32:
    return value ignored
  Summary for edge Flash_EraseSector/40->UART_PrintUInt/33:
    return value ignored
  Summary for edge Flash_EraseSector/40->UART_Print/32:
    return value ignored
  Summary for edge Flash_EraseSector/40->UART_PrintUInt/33:
    return value ignored
    Parameter 0:
      Scalar param sources: 0
  Summary for edge Flash_EraseSector/40->UART_Print/32:
    return value ignored
  Summary for edge Flash_EraseSector/40->UART_Print/32:
    return value ignored
  Summary for edge Flash_EraseSector/40->UART_PrintUInt/33:
    return value ignored
  Summary for edge Flash_EraseSector/40->UART_Print/32:
    return value ignored
  Summary for edge Flash_EraseSector/40->UART_PrintUInt/33:
    return value ignored
    Parameter 0:
      Scalar param sources: 0
  Summary for edge Flash_EraseSector/40->UART_Print/32:
    return value ignored
  Summary for edge Flash_EraseSector/40->C40_Ip_MainInterfaceSectorEraseStatus/64:
  Summary for edge Flash_EraseSector/40->UART_Print/32:
    return value ignored
  Summary for edge Flash_EraseSector/40->UART_Print/32:
    return value ignored
  Summary for edge Flash_EraseSector/40->UART_PrintUInt/33:
    return value ignored
  Summary for edge Flash_EraseSector/40->UART_Print/32:
    return value ignored
  Summary for edge Flash_EraseSector/40->UART_PrintUInt/33:
    return value ignored
    Parameter 0:
      Scalar param sources: 0
  Summary for edge Flash_EraseSector/40->UART_Print/32:
    return value ignored
  Summary for edge Flash_EraseSector/40->C40_Ip_MainInterfaceSectorErase/63:
    Parameter 0:
      Scalar param sources: 0
    Parameter 1:
  Summary for edge Flash_EraseSector/40->UART_Print/32:
    return value ignored
  Summary for edge Flash_EraseSector/40->UART_PrintUInt/33:
    return value ignored
    Parameter 0:
      Scalar param sources: 0
  Summary for edge Flash_EraseSector/40->UART_Print/32:
    return value ignored

Summary for node Flash_UnlockSector/39:
  Returns value
  Descriptor for parameter 0:
    (locally) unused
    not a candidate for splitting

  Summary for edge Flash_UnlockSector/39->UART_Print/32:
    return value ignored
  Summary for edge Flash_UnlockSector/39->UART_Print/32:
    return value ignored
  Summary for edge Flash_UnlockSector/39->UART_Print/32:
    return value ignored
  Summary for edge Flash_UnlockSector/39->UART_PrintUInt/33:
    return value ignored
    Parameter 0:
      Scalar param sources: 0
  Summary for edge Flash_UnlockSector/39->UART_Print/32:
    return value ignored
  Summary for edge Flash_UnlockSector/39->C40_Ip_GetLock/61:
    Parameter 0:
      Scalar param sources: 0
  Summary for edge Flash_UnlockSector/39->C40_Ip_ClearLock/62:
    return value ignored
    Parameter 0:
      Scalar param sources: 0
    Parameter 1:
  Summary for edge Flash_UnlockSector/39->UART_Print/32:
    return value ignored
  Summary for edge Flash_UnlockSector/39->C40_Ip_GetLock/61:
    Parameter 0:
      Scalar param sources: 0
  Summary for edge Flash_UnlockSector/39->UART_Print/32:
    return value ignored
  Summary for edge Flash_UnlockSector/39->UART_PrintUInt/33:
    return value ignored
    Parameter 0:
      Scalar param sources: 0
  Summary for edge Flash_UnlockSector/39->UART_Print/32:
    return value ignored
  Summary for edge Flash_UnlockSector/39->UART_PrintUInt/33:
    return value ignored
    Parameter 0:
      Scalar param sources: 0
  Summary for edge Flash_UnlockSector/39->UART_Print/32:
    return value ignored

Summary for node ReadHeader/37:
  Returns value
  Descriptor for parameter 0:
    not a candidate for splitting

  Summary for edge ReadHeader/37->UART_Print/32:
    return value ignored
  Summary for edge ReadHeader/37->HexNibble/36:
  Summary for edge ReadHeader/37->HexNibble/36:
  Summary for edge ReadHeader/37->UART_ReadExact/35:

Summary for node HexNibble/36:
  Returns value
  Descriptor for parameter 0:
    not a candidate for splitting

  Summary for edge HexNibble/36->HexNibble.part.0/73:
    return value used only to compute caller return value
    Parameter 0:
      Scalar param sources: 0

Summary for node UART_ReadExact/35:
  Returns value
  Descriptor for parameter 0:
    (locally) unused
    param_size_limit: 4, size_reached: 0, by_ref
  Descriptor for parameter 1:
    not a candidate for splitting

  Summary for edge UART_ReadExact/35->UART_Print/32:
    return value ignored
    Parameter 0:
  Summary for edge UART_ReadExact/35->Lpuart_Uart_Ip_AbortReceivingData/67:
    return value ignored
    Parameter 0:
  Summary for edge UART_ReadExact/35->Lpuart_Uart_Ip_GetReceiveStatus/66:
    Parameter 0:
    Parameter 1:
  Summary for edge UART_ReadExact/35->UART_Print/32:
    return value ignored
    Parameter 0:
  Summary for edge UART_ReadExact/35->Lpuart_Uart_Ip_AsyncReceive/65:
    Parameter 0:
    Parameter 1:
      Scalar param sources: 0
      Pointer pass through from the param given above, safe_to_import_accesses: 0
    Parameter 2:
      Scalar param sources: 1

Summary for node UART_PrintHex32/34:
  Descriptor for parameter 0:
    not a candidate for splitting

  Summary for edge UART_PrintHex32/34->UART_Print/32:
    return value ignored

Summary for node UART_PrintUInt/33:
  Descriptor for parameter 0:
    not a candidate for splitting

  Summary for edge UART_PrintUInt/33->UART_PrintUInt.part.0/74:
    return value ignored
    Parameter 0:
      Scalar param sources: 0
  Summary for edge UART_PrintUInt/33->UART_Print/32:
    return value ignored

Summary for node UART_Print/32:
  Descriptor for parameter 0:
    (locally) unused
    param_size_limit: 4, size_reached: 0, by_ref

  Summary for edge UART_Print/32->UART_WriteRaw/31:
    return value ignored
    Parameter 0:
      Scalar param sources: 0
      Pointer pass through from the param given above, safe_to_import_accesses: 1
    Parameter 1:
  Summary for edge UART_Print/32->strlen/58:
    Parameter 0:
      Scalar param sources: 0
      Pointer pass through from the param given above, safe_to_import_accesses: 1

Summary for node UART_WriteRaw/31:
  Descriptor for parameter 0:
    (locally) unused
    param_size_limit: 4, size_reached: 0, by_ref
  Descriptor for parameter 1:
    (locally) unused
    not a candidate for splitting

  Summary for edge UART_WriteRaw/31->Lpuart_Uart_Ip_GetTransmitStatus/60:
    Parameter 0:
    Parameter 1:
  Summary for edge UART_WriteRaw/31->Lpuart_Uart_Ip_AsyncSend/59:
    Parameter 0:
    Parameter 1:
      Scalar param sources: 0
      Pointer pass through from the param given above, safe_to_import_accesses: 0
    Parameter 2:
      Scalar param sources: 1


Function main/45 disqualified because it cannot be made local.

========== IPA-SRA decisions ==========

========== IPA SRA IPA analysis done ==========


Reclaiming functions:
Reclaiming variables:
Clearing address taken flags:
Symbol table:

CRC32_Compute.constprop.0/78 (CRC32_Compute.constprop) @067ae620
  Type: function definition analyzed
  Visibility:
  References: RxBuf/28 (addr) 
  Referring: 
  Clone of CRC32_Compute/38
  Availability: local
  Function flags: count:14744044 (estimated locally) local optimize_size
  Called by: DoTransfer/44 (99587951 (estimated locally),0.09 per call) 
  Calls: 
UART_PrintUInt.part.0/74 (UART_PrintUInt.part.0) @066b4b60
  Type: function definition analyzed
  Visibility: prevailing_def_ironly artificial
  References: 
  Referring: 
  Availability: local
  Function flags: count:118111600 (estimated locally) body local split_part optimize_size
  Called by: main/45 (2697764 (estimated locally),0.20 per call) DoTransfer/44 (159025459 (estimated locally),0.15 per call) UART_PrintUInt/33 (118111600 (estimated locally),0.80 per call) 
  Calls: UART_Print/32 (118111600 (estimated locally),1.00 per call) 
HexNibble.part.0/73 (HexNibble.part.0) @0666dee0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly artificial
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local split_part optimize_size
  Called by: HexNibble/36 (467721933 (estimated locally),0.44 per call) 
  Calls: 
C40_Ip_Read/72 (C40_Ip_Read) @06657380
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_VerifyCRC/43 (15602163 (estimated locally),8.83 per call) 
  Calls: 
C40_Ip_MainInterfaceWriteStatus/71 (C40_Ip_MainInterfaceWriteStatus) @066571c0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_WriteFromBuffer/42 (1073741824 (estimated locally),79.73 per call) 
  Calls: 
C40_Ip_MainInterfaceWrite/70 (C40_Ip_MainInterfaceWrite) @066570e0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_WriteFromBuffer/42 (122598713 (estimated locally),9.10 per call) 
  Calls: 
memcpy/69 (memcpy) @06657000
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_WriteFromBuffer/42 (122598713 (estimated locally),9.10 per call) 
  Calls: 
memset/68 (memset) @0661aee0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_WriteFromBuffer/42 (122598713 (estimated locally),9.10 per call) 
  Calls: 
Lpuart_Uart_Ip_AbortReceivingData/67 (Lpuart_Uart_Ip_AbortReceivingData) @0661ac40
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: UART_ReadExact/35 (14006618 (estimated locally),0.08 per call) 
  Calls: 
Lpuart_Uart_Ip_GetReceiveStatus/66 (Lpuart_Uart_Ip_GetReceiveStatus) @0661ab60
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: UART_ReadExact/35 (1073741824 (estimated locally),6.05 per call) 
  Calls: 
Lpuart_Uart_Ip_AsyncReceive/65 (Lpuart_Uart_Ip_AsyncReceive) @0661aa80
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: UART_ReadExact/35 (86763613 (estimated locally),0.49 per call) 
  Calls: 
C40_Ip_MainInterfaceSectorEraseStatus/64 (C40_Ip_MainInterfaceSectorEraseStatus) @0661a8c0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_EraseSector/40 (1073741824 (estimated locally),7.76 per call) 
  Calls: 
C40_Ip_MainInterfaceSectorErase/63 (C40_Ip_MainInterfaceSectorErase) @0661a7e0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_EraseSector/40 (138405316 (estimated locally),1.00 per call) 
  Calls: 
C40_Ip_ClearLock/62 (C40_Ip_ClearLock) @0661a620
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_UnlockSector/39 (365072224 (estimated locally),0.34 per call) 
  Calls: 
C40_Ip_GetLock/61 (C40_Ip_GetLock) @0661a540
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: Flash_UnlockSector/39 (365072224 (estimated locally),0.34 per call) Flash_UnlockSector/39 (1073741823 (estimated locally),1.00 per call) 
  Calls: 
Lpuart_Uart_Ip_GetTransmitStatus/60 (Lpuart_Uart_Ip_GetTransmitStatus) @0661a000
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: UART_WriteRaw/31 (1073741824 (estimated locally),10.24 per call) 
  Calls: 
Lpuart_Uart_Ip_AsyncSend/59 (Lpuart_Uart_Ip_AsyncSend) @0660dee0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: UART_WriteRaw/31 (104852513 (estimated locally),1.00 per call) 
  Calls: 
strlen/58 (strlen) @0660dd20
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: UART_Print/32 (1073741824 (estimated locally),1.00 per call) 
  Calls: 
C40ConfigSet_BOARD_InitPeripherals_InitCfg/57 (C40ConfigSet_BOARD_InitPeripherals_InitCfg) @066121f8
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/45 (addr) 
  Availability: not_available
  Varpool flags: read-only
C40_Ip_Init/56 (C40_Ip_Init) @0660da80
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/45 (13328872 (estimated locally),1.00 per call) 
  Calls: 
Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS/55 (Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS) @06612168
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/45 (addr) 
  Availability: not_available
  Varpool flags: read-only
Lpuart_Uart_Ip_Init/54 (Lpuart_Uart_Ip_Init) @0660d8c0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/45 (13328872 (estimated locally),1.00 per call) 
  Calls: 
intRouteConfig/53 (intRouteConfig) @066120d8
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/45 (addr) 
  Availability: not_available
  Varpool flags: read-only
IntCtrl_Ip_ConfigIrqRouting/52 (IntCtrl_Ip_ConfigIrqRouting) @0660d7e0
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/45 (13328872 (estimated locally),1.00 per call) 
  Calls: 
IntCtrlConfig_0/51 (IntCtrlConfig_0) @06612048
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/45 (addr) 
  Availability: not_available
  Varpool flags: read-only
IntCtrl_Ip_Init/50 (IntCtrl_Ip_Init) @0660d700
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/45 (13328872 (estimated locally),1.00 per call) 
  Calls: 
g_pin_mux_InitConfigArr0/49 (g_pin_mux_InitConfigArr0) @065fef78
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/45 (addr) 
  Availability: not_available
  Varpool flags: read-only
Siul2_Port_Ip_Init/48 (Siul2_Port_Ip_Init) @0660d620
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/45 (13328872 (estimated locally),1.00 per call) 
  Calls: 
Clock_Ip_aClockConfig/47 (Clock_Ip_aClockConfig) @065feee8
  Type: variable
  Body removed by symtab_remove_unreachable_nodes
  Visibility: external public
  References: 
  Referring: main/45 (addr) 
  Availability: not_available
  Varpool flags: read-only
Clock_Ip_Init/46 (Clock_Ip_Init) @0660d540
  Type: function
  Visibility: external public
  References: 
  Referring: 
  Availability: not_available
  Function flags: optimize_size
  Called by: main/45 (13328872 (estimated locally),1.00 per call) 
  Calls: 
main/45 (main) @0660d0e0
  Type: function definition analyzed
  Visibility: externally_visible public
  References: Clock_Ip_aClockConfig/47 (addr) g_pin_mux_InitConfigArr0/49 (addr) IntCtrlConfig_0/51 (addr) intRouteConfig/53 (addr) Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS/55 (addr) C40ConfigSet_BOARD_InitPeripherals_InitCfg/57 (addr) 
  Referring: 
  Availability: available
  Function flags: count:13328872 (estimated locally) body only_called_at_startup executed_once optimize_size
  Called by: 
  Calls: DoTransfer/44 (272474102 (estimated locally),20.44 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_PrintUInt.part.0/74 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) UART_Print/32 (2697764 (estimated locally),0.20 per call) C40_Ip_Init/56 (13328872 (estimated locally),1.00 per call) Lpuart_Uart_Ip_Init/54 (13328872 (estimated locally),1.00 per call) IntCtrl_Ip_ConfigIrqRouting/52 (13328872 (estimated locally),1.00 per call) IntCtrl_Ip_Init/50 (13328872 (estimated locally),1.00 per call) Siul2_Port_Ip_Init/48 (13328872 (estimated locally),1.00 per call) Clock_Ip_Init/46 (13328872 (estimated locally),1.00 per call) 
DoTransfer/44 (DoTransfer) @065f6e00
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: RxBuf/28 (addr) RxBuf/28 (addr) 
  Referring: 
  Availability: local
  Function flags: count:1073741823 (estimated locally) body local optimize_size
  Called by: main/45 (272474102 (estimated locally),20.44 per call) 
  Calls: UART_Print/32 (43380511 (estimated locally),0.04 per call) UART_PrintHex32/34 (43380511 (estimated locally),0.04 per call) UART_Print/32 (43380511 (estimated locally),0.04 per call) UART_PrintHex32/34 (43380511 (estimated locally),0.04 per call) UART_Print/32 (43380511 (estimated locally),0.04 per call) UART_PrintUInt/33 (43380511 (estimated locally),0.04 per call) UART_Print/32 (43380511 (estimated locally),0.04 per call) UART_Print/32 (43380511 (estimated locally),0.04 per call) UART_Print/32 (43380511 (estimated locally),0.04 per call) UART_Print/32 (22347536 (estimated locally),0.02 per call) Flash_VerifyCRC/43 (65728047 (estimated locally),0.06 per call) UART_Print/32 (65728047 (estimated locally),0.06 per call) UART_Print/32 (65728047 (estimated locally),0.06 per call) UART_Print/32 (33859904 (estimated locally),0.03 per call) Flash_WriteFromBuffer/42 (99587951 (estimated locally),0.09 per call) UART_Print/32 (99587951 (estimated locally),0.09 per call) UART_PrintHex32/34 (99587951 (estimated locally),0.09 per call) UART_Print/32 (99587951 (estimated locally),0.09 per call) UART_Print/32 (99587951 (estimated locally),0.09 per call) UART_PrintHex32/34 (99587951 (estimated locally),0.09 per call) UART_Print/32 (99587951 (estimated locally),0.09 per call) CRC32_Compute.constprop.0/78 (99587951 (estimated locally),0.09 per call) UART_Print/32 (99587951 (estimated locally),0.09 per call) UART_PrintUInt/33 (99587951 (estimated locally),0.09 per call) UART_Print/32 (99587951 (estimated locally),0.09 per call) UART_Print/32 (51302885 (estimated locally),0.05 per call) UART_ReadExact/35 (150890836 (estimated locally),0.14 per call) UART_Print/32 (150890836 (estimated locally),0.14 per call) UART_PrintUInt/33 (150890836 (estimated locally),0.14 per call) UART_Print/32 (150890836 (estimated locally),0.14 per call) UART_Print/32 (150890836 (estimated locally),0.14 per call) UART_Print/32 (150890836 (estimated locally),0.14 per call) Flash_EraseForFile/41 (308696474 (estimated locally),0.29 per call) UART_Print/32 (308696474 (estimated locally),0.29 per call) UART_PrintHex32/34 (308696474 (estimated locally),0.29 per call) UART_Print/32 (308696474 (estimated locally),0.29 per call) UART_Print/32 (159025459 (estimated locally),0.15 per call) UART_Print/32 (159025459 (estimated locally),0.15 per call) UART_PrintUInt.part.0/74 (159025459 (estimated locally),0.15 per call) UART_Print/32 (159025459 (estimated locally),0.15 per call) UART_Print/32 (467721933 (estimated locally),0.44 per call) UART_PrintHex32/34 (467721933 (estimated locally),0.44 per call) UART_Print/32 (467721933 (estimated locally),0.44 per call) UART_PrintUInt/33 (467721933 (estimated locally),0.44 per call) UART_Print/32 (467721933 (estimated locally),0.44 per call) UART_Print/32 (240947666 (estimated locally),0.22 per call) Flash_EraseForFile/41 (240947666 (estimated locally),0.22 per call) UART_Print/32 (240947666 (estimated locally),0.22 per call) ReadHeader/37 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) 
Flash_VerifyCRC/43 (Flash_VerifyCRC) @065f6b60
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: ReadBuf/30 (addr) ReadBuf/30 (read) 
  Referring: 
  Availability: local
  Function flags: count:1766181 (estimated locally) body local optimize_size
  Called by: DoTransfer/44 (65728047 (estimated locally),0.06 per call) 
  Calls: UART_Print/32 (299661 (estimated locally),0.17 per call) UART_Print/32 (908062 (estimated locally),0.51 per call) UART_PrintHex32/34 (908062 (estimated locally),0.51 per call) UART_Print/32 (908062 (estimated locally),0.51 per call) UART_Print/32 (908062 (estimated locally),0.51 per call) UART_PrintHex32/34 (908062 (estimated locally),0.51 per call) UART_Print/32 (908062 (estimated locally),0.51 per call) UART_Print/32 (858119 (estimated locally),0.49 per call) UART_PrintHex32/34 (858119 (estimated locally),0.49 per call) UART_Print/32 (858119 (estimated locally),0.49 per call) C40_Ip_Read/72 (15602163 (estimated locally),8.83 per call) 
Flash_WriteFromBuffer/42 (Flash_WriteFromBuffer) @065f68c0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: PageBuf/29 (addr) RxBuf/28 (addr) PageBuf/29 (addr) PageBuf/29 (addr) 
  Referring: 
  Availability: local
  Function flags: count:13467578 (estimated locally) body local optimize_size
  Called by: DoTransfer/44 (99587951 (estimated locally),0.09 per call) 
  Calls: UART_Print/32 (4322885 (estimated locally),0.32 per call) UART_PrintHex32/34 (4322885 (estimated locally),0.32 per call) UART_Print/32 (4322885 (estimated locally),0.32 per call) C40_Ip_MainInterfaceWriteStatus/71 (1073741824 (estimated locally),79.73 per call) UART_Print/32 (4487113 (estimated locally),0.33 per call) UART_PrintHex32/34 (4487113 (estimated locally),0.33 per call) UART_Print/32 (4487113 (estimated locally),0.33 per call) C40_Ip_MainInterfaceWrite/70 (122598713 (estimated locally),9.10 per call) memcpy/69 (122598713 (estimated locally),9.10 per call) memset/68 (122598713 (estimated locally),9.10 per call) 
Flash_EraseForFile/41 (Flash_EraseForFile) @065f6620
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:113634474 (estimated locally) body local optimize_size
  Called by: DoTransfer/44 (308696474 (estimated locally),0.29 per call) DoTransfer/44 (240947666 (estimated locally),0.22 per call) 
  Calls: UART_Print/32 (39298952 (estimated locally),0.35 per call) UART_Print/32 (960107351 (estimated locally),8.45 per call) UART_PrintUInt/33 (960107351 (estimated locally),8.45 per call) UART_Print/32 (960107351 (estimated locally),8.45 per call) Flash_EraseSector/40 (996582262 (estimated locally),8.77 per call) Flash_UnlockSector/39 (1034442872 (estimated locally),9.10 per call) UART_Print/32 (113634474 (estimated locally),1.00 per call) UART_PrintUInt/33 (113634474 (estimated locally),1.00 per call) UART_Print/32 (113634474 (estimated locally),1.00 per call) 
Flash_EraseSector/40 (Flash_EraseSector) @065f6380
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:138405316 (estimated locally) body local optimize_size
  Called by: Flash_EraseForFile/41 (996582262 (estimated locally),8.77 per call) 
  Calls: UART_Print/32 (27598020 (estimated locally),0.20 per call) UART_Print/32 (27598020 (estimated locally),0.20 per call) UART_PrintUInt/33 (27598020 (estimated locally),0.20 per call) UART_Print/32 (27598020 (estimated locally),0.20 per call) UART_PrintUInt/33 (27598020 (estimated locally),0.20 per call) UART_Print/32 (27598020 (estimated locally),0.20 per call) UART_Print/32 (14006618 (estimated locally),0.10 per call) UART_PrintUInt/33 (14006618 (estimated locally),0.10 per call) UART_Print/32 (14006618 (estimated locally),0.10 per call) UART_PrintUInt/33 (14006618 (estimated locally),0.10 per call) UART_Print/32 (14006618 (estimated locally),0.10 per call) C40_Ip_MainInterfaceSectorEraseStatus/64 (1073741824 (estimated locally),7.76 per call) UART_Print/32 (69202658 (estimated locally),0.50 per call) UART_Print/32 (69202658 (estimated locally),0.50 per call) UART_PrintUInt/33 (69202658 (estimated locally),0.50 per call) UART_Print/32 (69202658 (estimated locally),0.50 per call) UART_PrintUInt/33 (69202658 (estimated locally),0.50 per call) UART_Print/32 (69202658 (estimated locally),0.50 per call) C40_Ip_MainInterfaceSectorErase/63 (138405316 (estimated locally),1.00 per call) UART_Print/32 (138405316 (estimated locally),1.00 per call) UART_PrintUInt/33 (138405316 (estimated locally),1.00 per call) UART_Print/32 (138405316 (estimated locally),1.00 per call) 
Flash_UnlockSector/39 (Flash_UnlockSector) @065f60e0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741823 (estimated locally) body local optimize_size
  Called by: Flash_EraseForFile/41 (1034442872 (estimated locally),9.10 per call) 
  Calls: UART_Print/32 (708669600 (estimated locally),0.66 per call) UART_Print/32 (288516577 (estimated locally),0.27 per call) UART_Print/32 (76555647 (estimated locally),0.07 per call) UART_PrintUInt/33 (76555647 (estimated locally),0.07 per call) UART_Print/32 (76555647 (estimated locally),0.07 per call) C40_Ip_GetLock/61 (365072224 (estimated locally),0.34 per call) C40_Ip_ClearLock/62 (365072224 (estimated locally),0.34 per call) UART_Print/32 (365072224 (estimated locally),0.34 per call) C40_Ip_GetLock/61 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) UART_PrintUInt/33 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) UART_PrintUInt/33 (1073741823 (estimated locally),1.00 per call) UART_Print/32 (1073741823 (estimated locally),1.00 per call) 
CRC32_Compute/38 (CRC32_Compute) @065ede00
  Type: function
  Body removed by symtab_remove_unreachable_nodes
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: not_available
  Function flags: count:14744044 (estimated locally) body optimize_size
  Called by: 
  Calls: 
ReadHeader/37 (ReadHeader) @065edb60
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:418903057 (estimated locally) body local optimize_size
  Called by: DoTransfer/44 (1073741823 (estimated locally),1.00 per call) 
  Calls: UART_Print/32 (61727650 (estimated locally),0.15 per call) HexNibble/36 (858993457 (estimated locally),2.05 per call) HexNibble/36 (858993457 (estimated locally),2.05 per call) UART_ReadExact/35 (418903057 (estimated locally),1.00 per call) 
HexNibble/36 (HexNibble) @065ed8c0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741823 (estimated locally) body local optimize_size
  Called by: ReadHeader/37 (858993457 (estimated locally),2.05 per call) ReadHeader/37 (858993457 (estimated locally),2.05 per call) 
  Calls: HexNibble.part.0/73 (467721933 (estimated locally),0.44 per call) 
UART_ReadExact/35 (UART_ReadExact) @065ed620
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:177503302 (estimated locally) body local optimize_size
  Called by: DoTransfer/44 (150890836 (estimated locally),0.14 per call) ReadHeader/37 (418903057 (estimated locally),1.00 per call) 
  Calls: UART_Print/32 (14006618 (estimated locally),0.08 per call) Lpuart_Uart_Ip_AbortReceivingData/67 (14006618 (estimated locally),0.08 per call) Lpuart_Uart_Ip_GetReceiveStatus/66 (1073741824 (estimated locally),6.05 per call) UART_Print/32 (17560955 (estimated locally),0.10 per call) Lpuart_Uart_Ip_AsyncReceive/65 (86763613 (estimated locally),0.49 per call) 
UART_PrintHex32/34 (UART_PrintHex32) @065ed380
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:119292720 (estimated locally) body local optimize_size
  Called by: DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (308696474 (estimated locally),0.29 per call) DoTransfer/44 (467721933 (estimated locally),0.44 per call) Flash_VerifyCRC/43 (908062 (estimated locally),0.51 per call) Flash_VerifyCRC/43 (908062 (estimated locally),0.51 per call) Flash_VerifyCRC/43 (858119 (estimated locally),0.49 per call) Flash_WriteFromBuffer/42 (4322885 (estimated locally),0.32 per call) Flash_WriteFromBuffer/42 (4487113 (estimated locally),0.33 per call) 
  Calls: UART_Print/32 (119292720 (estimated locally),1.00 per call) 
UART_PrintUInt/33 (UART_PrintUInt) @065ed0e0
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:148083751 (estimated locally) body local optimize_size
  Called by: DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (150890836 (estimated locally),0.14 per call) DoTransfer/44 (467721933 (estimated locally),0.44 per call) Flash_EraseForFile/41 (960107351 (estimated locally),8.45 per call) Flash_EraseForFile/41 (113634474 (estimated locally),1.00 per call) Flash_EraseSector/40 (27598020 (estimated locally),0.20 per call) Flash_EraseSector/40 (27598020 (estimated locally),0.20 per call) Flash_EraseSector/40 (14006618 (estimated locally),0.10 per call) Flash_EraseSector/40 (14006618 (estimated locally),0.10 per call) Flash_EraseSector/40 (69202658 (estimated locally),0.50 per call) Flash_EraseSector/40 (69202658 (estimated locally),0.50 per call) Flash_EraseSector/40 (138405316 (estimated locally),1.00 per call) Flash_UnlockSector/39 (76555647 (estimated locally),0.07 per call) Flash_UnlockSector/39 (1073741823 (estimated locally),1.00 per call) Flash_UnlockSector/39 (1073741823 (estimated locally),1.00 per call) 
  Calls: UART_PrintUInt.part.0/74 (118111600 (estimated locally),0.80 per call) UART_Print/32 (29972151 (estimated locally),0.20 per call) 
UART_Print/32 (UART_Print) @065e6e00
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:1073741824 (estimated locally) body local optimize_size
  Called by: main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) main/45 (2697764 (estimated locally),0.20 per call) DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (43380511 (estimated locally),0.04 per call) DoTransfer/44 (22347536 (estimated locally),0.02 per call) DoTransfer/44 (65728047 (estimated locally),0.06 per call) DoTransfer/44 (65728047 (estimated locally),0.06 per call) DoTransfer/44 (33859904 (estimated locally),0.03 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (99587951 (estimated locally),0.09 per call) DoTransfer/44 (51302885 (estimated locally),0.05 per call) DoTransfer/44 (150890836 (estimated locally),0.14 per call) DoTransfer/44 (150890836 (estimated locally),0.14 per call) DoTransfer/44 (150890836 (estimated locally),0.14 per call) DoTransfer/44 (150890836 (estimated locally),0.14 per call) DoTransfer/44 (308696474 (estimated locally),0.29 per call) DoTransfer/44 (308696474 (estimated locally),0.29 per call) DoTransfer/44 (159025459 (estimated locally),0.15 per call) DoTransfer/44 (159025459 (estimated locally),0.15 per call) DoTransfer/44 (159025459 (estimated locally),0.15 per call) DoTransfer/44 (467721933 (estimated locally),0.44 per call) DoTransfer/44 (467721933 (estimated locally),0.44 per call) DoTransfer/44 (467721933 (estimated locally),0.44 per call) DoTransfer/44 (240947666 (estimated locally),0.22 per call) DoTransfer/44 (240947666 (estimated locally),0.22 per call) DoTransfer/44 (1073741823 (estimated locally),1.00 per call) DoTransfer/44 (1073741823 (estimated locally),1.00 per call) DoTransfer/44 (1073741823 (estimated locally),1.00 per call) DoTransfer/44 (1073741823 (estimated locally),1.00 per call) DoTransfer/44 (1073741823 (estimated locally),1.00 per call) DoTransfer/44 (1073741823 (estimated locally),1.00 per call) DoTransfer/44 (1073741823 (estimated locally),1.00 per call) Flash_VerifyCRC/43 (299661 (estimated locally),0.17 per call) Flash_VerifyCRC/43 (908062 (estimated locally),0.51 per call) Flash_VerifyCRC/43 (908062 (estimated locally),0.51 per call) Flash_VerifyCRC/43 (908062 (estimated locally),0.51 per call) Flash_VerifyCRC/43 (908062 (estimated locally),0.51 per call) Flash_VerifyCRC/43 (858119 (estimated locally),0.49 per call) Flash_VerifyCRC/43 (858119 (estimated locally),0.49 per call) Flash_WriteFromBuffer/42 (4322885 (estimated locally),0.32 per call) Flash_WriteFromBuffer/42 (4322885 (estimated locally),0.32 per call) Flash_WriteFromBuffer/42 (4487113 (estimated locally),0.33 per call) Flash_WriteFromBuffer/42 (4487113 (estimated locally),0.33 per call) ReadHeader/37 (61727650 (estimated locally),0.15 per call) UART_ReadExact/35 (14006618 (estimated locally),0.08 per call) UART_ReadExact/35 (17560955 (estimated locally),0.10 per call) Flash_EraseForFile/41 (39298952 (estimated locally),0.35 per call) Flash_EraseForFile/41 (960107351 (estimated locally),8.45 per call) Flash_EraseForFile/41 (960107351 (estimated locally),8.45 per call) Flash_EraseForFile/41 (113634474 (estimated locally),1.00 per call) Flash_EraseForFile/41 (113634474 (estimated locally),1.00 per call) Flash_EraseSector/40 (27598020 (estimated locally),0.20 per call) Flash_EraseSector/40 (27598020 (estimated locally),0.20 per call) Flash_EraseSector/40 (27598020 (estimated locally),0.20 per call) Flash_EraseSector/40 (27598020 (estimated locally),0.20 per call) Flash_EraseSector/40 (14006618 (estimated locally),0.10 per call) Flash_EraseSector/40 (14006618 (estimated locally),0.10 per call) Flash_EraseSector/40 (14006618 (estimated locally),0.10 per call) Flash_EraseSector/40 (69202658 (estimated locally),0.50 per call) Flash_EraseSector/40 (69202658 (estimated locally),0.50 per call) Flash_EraseSector/40 (69202658 (estimated locally),0.50 per call) Flash_EraseSector/40 (69202658 (estimated locally),0.50 per call) Flash_EraseSector/40 (138405316 (estimated locally),1.00 per call) Flash_EraseSector/40 (138405316 (estimated locally),1.00 per call) Flash_UnlockSector/39 (708669600 (estimated locally),0.66 per call) Flash_UnlockSector/39 (288516577 (estimated locally),0.27 per call) Flash_UnlockSector/39 (76555647 (estimated locally),0.07 per call) Flash_UnlockSector/39 (76555647 (estimated locally),0.07 per call) Flash_UnlockSector/39 (365072224 (estimated locally),0.34 per call) Flash_UnlockSector/39 (1073741823 (estimated locally),1.00 per call) Flash_UnlockSector/39 (1073741823 (estimated locally),1.00 per call) Flash_UnlockSector/39 (1073741823 (estimated locally),1.00 per call) UART_PrintHex32/34 (119292720 (estimated locally),1.00 per call) UART_PrintUInt/33 (29972151 (estimated locally),0.20 per call) UART_PrintUInt.part.0/74 (118111600 (estimated locally),1.00 per call) 
  Calls: UART_WriteRaw/31 (1073741824 (estimated locally),1.00 per call) strlen/58 (1073741824 (estimated locally),1.00 per call) 
UART_WriteRaw/31 (UART_WriteRaw) @065e6b60
  Type: function definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: 
  Availability: local
  Function flags: count:104852513 (estimated locally) body local optimize_size
  Called by: UART_Print/32 (1073741824 (estimated locally),1.00 per call) 
  Calls: Lpuart_Uart_Ip_GetTransmitStatus/60 (1073741824 (estimated locally),10.24 per call) Lpuart_Uart_Ip_AsyncSend/59 (104852513 (estimated locally),1.00 per call) 
ReadBuf/30 (ReadBuf) @065e7318
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: Flash_VerifyCRC/43 (addr) Flash_VerifyCRC/43 (read) 
  Availability: available
  Varpool flags:
PageBuf/29 (PageBuf) @065e7288
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly
  References: 
  Referring: Flash_WriteFromBuffer/42 (addr) Flash_WriteFromBuffer/42 (addr) Flash_WriteFromBuffer/42 (addr) 
  Availability: available
  Varpool flags:
RxBuf/28 (RxBuf) @065e71f8
  Type: variable definition analyzed
  Visibility: prevailing_def_ironly section:.dtcm_bss
  References: 
  Referring: Flash_WriteFromBuffer/42 (addr) DoTransfer/44 (addr) DoTransfer/44 (addr) CRC32_Compute.constprop.0/78 (addr) 
  Availability: available
  Varpool flags:
UART_PrintUInt.part.0 (uint32 v)
{
  char b[12];
  uint8 i;
  uint8 j;
  char t;
  long unsigned int _2;
  char _3;
  int _6;
  char _7;
  int _10;
  int _12;
  unsigned int _14;
  unsigned int _15;
  unsigned int _16;
  unsigned int _17;
  char _18;
  unsigned char _20;

  <bb 9> [local count: 118111600]:
  goto <bb 3>; [100.00%]

  <bb 2> [local count: 955630225]:
  # DEBUG BEGIN_STMT
  _2 = v_1 % 10;
  _3 = (char) _2;
  i_5 = i_4 + 1;
  # DEBUG i => i_5
  _6 = (int) i_4;
  _7 = _3 + 48;
  b[_6] = _7;
  # DEBUG BEGIN_STMT
  v_8 = v_1 / 10;
  # DEBUG v => v_8

  <bb 3> [local count: 1073741824]:
  # v_1 = PHI <v_8(2), v_21(D)(9)>
  # i_4 = PHI <i_5(2), 0(9)>
  # DEBUG i => i_4
  # DEBUG v => v_1
  # DEBUG BEGIN_STMT
  if (v_1 != 0)
    goto <bb 2>; [89.00%]
  else
    goto <bb 4>; [11.00%]

  <bb 4> [local count: 118111600]:
  # i_9 = PHI <i_4(3)>
  # DEBUG BEGIN_STMT
  _10 = (int) i_9;
  b[_10] = 0;
  # DEBUG BEGIN_STMT
  # DEBUG j => 0
  goto <bb 6>; [100.00%]

  <bb 5> [local count: 955630225]:
  # DEBUG BEGIN_STMT
  _12 = (int) j_11;
  t_13 = b[_12];
  # DEBUG t => t_13
  # DEBUG BEGIN_STMT
  _14 = (unsigned int) i_9;
  _15 = (unsigned int) j_11;
  _16 = _14 - _15;
  _17 = _16 + 4294967295;
  _18 = b[_17];
  b[_12] = _18;
  # DEBUG BEGIN_STMT
  b[_17] = t_13;
  # DEBUG BEGIN_STMT
  j_19 = j_11 + 1;
  # DEBUG j => j_19

  <bb 6> [local count: 1073741824]:
  # j_11 = PHI <0(4), j_19(5)>
  # DEBUG j => j_11
  # DEBUG BEGIN_STMT
  _20 = i_9 >> 1;
  if (j_11 < _20)
    goto <bb 5>; [89.00%]
  else
    goto <bb 7>; [11.00%]

  <bb 7> [local count: 118111600]:
  # DEBUG BEGIN_STMT
  UART_Print (&b);
  b ={v} {CLOBBER};

  <bb 8> [local count: 118111600]:
  return;

}


HexNibble.part.0 (uint8 c)
{
  unsigned char _2;
  unsigned char _3;
  unsigned char _4;

  <bb 5> [local count: 1073741824]:

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _2 = c_1(D) + 159;
  if (_2 <= 5)
    goto <bb 3>; [48.89%]
  else
    goto <bb 4>; [51.11%]

  <bb 3> [local count: 524952376]:
  # DEBUG BEGIN_STMT
  _3 = c_1(D) + 169;
  // predicted unlikely by early return (on trees) predictor.

  <bb 4> [local count: 1073741824]:
  # _4 = PHI <255(2), _3(3)>
  return _4;

}


main ()
{
  <unnamed type> _1;

  <bb 2> [local count: 13328872]:
  # DEBUG BEGIN_STMT
  Clock_Ip_Init (&Clock_Ip_aClockConfig[0]);
  # DEBUG BEGIN_STMT
  Siul2_Port_Ip_Init (4, &g_pin_mux_InitConfigArr0);
  # DEBUG BEGIN_STMT
  IntCtrl_Ip_Init (&IntCtrlConfig_0);
  # DEBUG BEGIN_STMT
  IntCtrl_Ip_ConfigIrqRouting (&intRouteConfig);
  # DEBUG BEGIN_STMT
  Lpuart_Uart_Ip_Init (2, &Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS);
  # DEBUG BEGIN_STMT
  _1 = C40_Ip_Init (&C40ConfigSet_BOARD_InitPeripherals_InitCfg);
  if (_1 != 23205)
    goto <bb 6>; [79.76%]
  else
    goto <bb 4>; [20.24%]

  <bb 6> [local count: 10631108]:

  <bb 3> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT

  <bb 7> [local count: 1073741824]:
  goto <bb 3>; [100.00%]

  <bb 4> [local count: 2697764]:
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("==============================================\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  S32K342  UART -> Flash  File Store\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  Target     : PFlash (Code Flash)\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  Flash base : 0x004E0000\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  Sector     : 128 KB each\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  Buffer     : DTCM RAM (128 KB)\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  Max file   : ");
  # DEBUG BEGIN_STMT
  # DEBUG v => 100000
  # DEBUG INLINE_ENTRY UART_PrintUInt
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG i => 0
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  UART_PrintUInt.part.0 (100000);
  # DEBUG v => NULL
  # DEBUG i => NULL
  # DEBUG BEGIN_STMT
  UART_Print (" bytes\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("==============================================\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("HOW TO INCREASE MAX FILE SIZE:\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  Change RX_BUF_SIZE in main.c\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  Max safe value = 120000 (DTCM is 128 KB)\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");

  <bb 5> [local count: 272474102]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  DoTransfer ();
  # DEBUG BEGIN_STMT

  <bb 8> [local count: 272474102]:
  goto <bb 5>; [100.00%]

}


DoTransfer ()
{
  uint32 fileCrc;
  uint32 fileLen;
  unsigned char _1;
  long unsigned int fileLen.5_2;
  long unsigned int fileLen.6_3;
  long unsigned int fileLen.7_4;
  long unsigned int fileLen.8_5;
  long unsigned int fileLen.9_6;
  unsigned char _7;
  long unsigned int fileLen.10_8;
  long unsigned int fileLen.11_9;
  unsigned char _10;
  long unsigned int fileLen.12_11;
  long unsigned int fileLen.13_12;
  long unsigned int fileLen.14_13;
  unsigned char _14;
  long unsigned int fileLen.15_15;
  unsigned char _16;
  long unsigned int fileLen.16_17;
  long unsigned int fileLen.17_18;
  long unsigned int _19;

  <bb 2> [local count: 1073741823]:
  # DEBUG BEGIN_STMT
  fileLen = 0;
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n----------------------------------------------\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("Type 8 hex chars = file size (no Enter):\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  38000 bytes  ->  00009470\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  65000 bytes  ->  0000FDE8\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  100000 bytes ->  000186A0\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  Reset/erase  ->  00000000\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("----------------------------------------------\r\n");
  # DEBUG BEGIN_STMT
  _1 = ReadHeader (&fileLen);
  if (_1 == 0)
    goto <bb 15>; [34.00%]
  else
    goto <bb 3>; [66.00%]

  <bb 3> [local count: 708669600]:
  # DEBUG BEGIN_STMT
  fileLen.5_2 = fileLen;
  if (fileLen.5_2 == 0)
    goto <bb 4>; [34.00%]
  else
    goto <bb 5>; [66.00%]

  <bb 4> [local count: 240947666]:
  # DEBUG BEGIN_STMT
  UART_Print ("Reset: erasing sectors...\r\n");
  # DEBUG BEGIN_STMT
  Flash_EraseForFile (100000);
  # DEBUG BEGIN_STMT
  UART_Print ("Erase done. Ready for new file.\r\n");
  # DEBUG BEGIN_STMT
  goto <bb 15>; [100.00%]

  <bb 5> [local count: 467721933]:
  # DEBUG BEGIN_STMT
  UART_Print ("File size : ");
  # DEBUG BEGIN_STMT
  fileLen.6_3 = fileLen;
  UART_PrintUInt (fileLen.6_3);
  # DEBUG BEGIN_STMT
  UART_Print (" bytes  (0x");
  # DEBUG BEGIN_STMT
  fileLen.7_4 = fileLen;
  UART_PrintHex32 (fileLen.7_4);
  # DEBUG BEGIN_STMT
  UART_Print (")\r\n");
  # DEBUG BEGIN_STMT
  fileLen.8_5 = fileLen;
  if (fileLen.8_5 > 100000)
    goto <bb 6>; [34.00%]
  else
    goto <bb 7>; [66.00%]

  <bb 6> [local count: 159025459]:
  # DEBUG BEGIN_STMT
  UART_Print ("ERROR: file too large. Max = ");
  # DEBUG BEGIN_STMT
  # DEBUG v => 100000
  # DEBUG INLINE_ENTRY UART_PrintUInt
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG i => 0
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  UART_PrintUInt.part.0 (100000);
  # DEBUG v => NULL
  # DEBUG i => NULL
  # DEBUG BEGIN_STMT
  UART_Print (" bytes.\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("Increase RX_BUF_SIZE in main.c (max ~120000)\r\n");
  # DEBUG BEGIN_STMT
  goto <bb 15>; [100.00%]

  <bb 7> [local count: 308696474]:
  # DEBUG BEGIN_STMT
  UART_Print ("Flash target : 0x");
  # DEBUG BEGIN_STMT
  UART_PrintHex32 (5111808);
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  fileLen.9_6 = fileLen;
  _7 = Flash_EraseForFile (fileLen.9_6);
  if (_7 == 0)
    goto <bb 15>; [51.12%]
  else
    goto <bb 8>; [48.88%]

  <bb 8> [local count: 150890836]:
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  UART_Print (">>> ERASE DONE.  NOW: File -> Send File -> tick Binary -> Send <<<\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("Waiting for ");
  # DEBUG BEGIN_STMT
  fileLen.10_8 = fileLen;
  UART_PrintUInt (fileLen.10_8);
  # DEBUG BEGIN_STMT
  UART_Print (" bytes...\r\n");
  # DEBUG BEGIN_STMT
  fileLen.11_9 = fileLen;
  _10 = UART_ReadExact (&RxBuf, fileLen.11_9);
  if (_10 == 0)
    goto <bb 9>; [34.00%]
  else
    goto <bb 10>; [66.00%]

  <bb 9> [local count: 51302885]:
  # DEBUG BEGIN_STMT
  UART_Print (">>> RECEIVE FAILED <<<\r\n");
  # DEBUG BEGIN_STMT
  goto <bb 15>; [100.00%]

  <bb 10> [local count: 99587951]:
  # DEBUG BEGIN_STMT
  UART_Print ("Receive OK -- ");
  # DEBUG BEGIN_STMT
  fileLen.12_11 = fileLen;
  UART_PrintUInt (fileLen.12_11);
  # DEBUG BEGIN_STMT
  UART_Print (" bytes in DTCM RAM.\r\n");
  # DEBUG BEGIN_STMT
  fileLen.13_12 = fileLen;
  fileCrc_50 = CRC32_Compute (&RxBuf, fileLen.13_12);
  # DEBUG fileCrc => fileCrc_50
  # DEBUG BEGIN_STMT
  UART_Print ("CRC32 received : 0x");
  # DEBUG BEGIN_STMT
  UART_PrintHex32 (fileCrc_50);
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("Writing to flash 0x");
  # DEBUG BEGIN_STMT
  UART_PrintHex32 (5111808);
  # DEBUG BEGIN_STMT
  UART_Print ("...\r\n");
  # DEBUG BEGIN_STMT
  fileLen.14_13 = fileLen;
  _14 = Flash_WriteFromBuffer (fileLen.14_13);
  if (_14 == 0)
    goto <bb 11>; [34.00%]
  else
    goto <bb 12>; [66.00%]

  <bb 11> [local count: 33859904]:
  # DEBUG BEGIN_STMT
  UART_Print (">>> FLASH WRITE FAILED <<<\r\n");
  # DEBUG BEGIN_STMT
  goto <bb 15>; [100.00%]

  <bb 12> [local count: 65728047]:
  # DEBUG BEGIN_STMT
  UART_Print ("Flash write done.\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("Verifying...\r\n");
  # DEBUG BEGIN_STMT
  fileLen.15_15 = fileLen;
  _16 = Flash_VerifyCRC (fileLen.15_15, fileCrc_50);
  if (_16 == 0)
    goto <bb 13>; [34.00%]
  else
    goto <bb 14>; [66.00%]

  <bb 13> [local count: 22347536]:
  # DEBUG BEGIN_STMT
  UART_Print (">>> FLASH VERIFY FAILED <<<\r\n");
  # DEBUG BEGIN_STMT
  goto <bb 15>; [100.00%]

  <bb 14> [local count: 43380511]:
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  UART_Print (">>> FLASH STORE SUCCESS <<<\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  ");
  # DEBUG BEGIN_STMT
  fileLen.16_17 = fileLen;
  UART_PrintUInt (fileLen.16_17);
  # DEBUG BEGIN_STMT
  UART_Print (" bytes stored at 0x");
  # DEBUG BEGIN_STMT
  UART_PrintHex32 (5111808);
  # DEBUG BEGIN_STMT
  UART_Print (" -- 0x");
  # DEBUG BEGIN_STMT
  fileLen.17_18 = fileLen;
  _19 = fileLen.17_18 + 5111807;
  UART_PrintHex32 (_19);
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  fileLen ={v} {CLOBBER};
  goto <bb 16>; [100.00%]

  <bb 15> [local count: 1030361313]:
  fileLen ={v} {CLOBBER};

  <bb 16> [local count: 1073741824]:
  return;

}


Flash_VerifyCRC (uint32 fileLen, uint32 expectedCrc)
{
  uint32 j;
  uint32 i;
  uint32 btp;
  uint32 offset;
  uint32 remaining;
  uint32 crc;
  long unsigned int _1;
  <unnamed type> _2;
  unsigned char _3;
  long unsigned int _4;
  long unsigned int _5;
  long unsigned int _6;
  uint8 _14;
  long unsigned int iftmp.23_15;
  long unsigned int iftmp.23_38;
  long unsigned int iftmp.23_39;

  <bb 2> [local count: 1766181]:
  # DEBUG BEGIN_STMT
  # DEBUG crc => 4294967295
  # DEBUG BEGIN_STMT
  # DEBUG remaining => fileLen_19(D)
  # DEBUG BEGIN_STMT
  # DEBUG offset => 0
  # DEBUG BEGIN_STMT
  goto <bb 14>; [100.00%]

  <bb 3> [local count: 15602163]:
  # DEBUG BEGIN_STMT
  btp_32 = MIN_EXPR <remaining_10, 16>;
  # DEBUG btp => btp_32
  # DEBUG BEGIN_STMT
  _1 = offset_11 + 5111808;
  _2 = C40_Ip_Read (_1, 16, &ReadBuf);
  if (_2 != 23205)
    goto <bb 4>; [5.50%]
  else
    goto <bb 18>; [94.50%]

  <bb 18> [local count: 14744044]:
  goto <bb 12>; [100.00%]

  <bb 4> [local count: 858119]:
  # offset_21 = PHI <offset_11(3)>
  # DEBUG BEGIN_STMT
  UART_Print ("ERROR: readback failed offset=0x");
  # DEBUG BEGIN_STMT
  UART_PrintHex32 (offset_21);
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  goto <bb 17>; [100.00%]

  <bb 5> [local count: 119292720]:
  # DEBUG BEGIN_STMT
  _3 = ReadBuf[i_12];
  _4 = (long unsigned int) _3;
  crc_36 = _4 ^ crc_8;
  # DEBUG crc => crc_36
  # DEBUG BEGIN_STMT
  # DEBUG j => 0
  goto <bb 10>; [100.00%]

  <bb 6> [local count: 954449104]:
  # DEBUG BEGIN_STMT
  _5 = crc_7 & 1;
  if (_5 != 0)
    goto <bb 7>; [50.00%]
  else
    goto <bb 8>; [50.00%]

  <bb 7> [local count: 477224552]:
  _6 = crc_7 >> 1;
  iftmp.23_39 = _6 ^ 3988292384;
  goto <bb 9>; [100.00%]

  <bb 8> [local count: 477224552]:
  iftmp.23_38 = crc_7 >> 1;

  <bb 9> [local count: 954449104]:
  # iftmp.23_15 = PHI <iftmp.23_39(7), iftmp.23_38(8)>
  # DEBUG crc => iftmp.23_15
  # DEBUG BEGIN_STMT
  j_41 = j_13 + 1;
  # DEBUG j => j_41

  <bb 10> [local count: 1073741824]:
  # crc_7 = PHI <crc_36(5), iftmp.23_15(9)>
  # j_13 = PHI <0(5), j_41(9)>
  # DEBUG j => j_13
  # DEBUG crc => crc_7
  # DEBUG BEGIN_STMT
  if (j_13 != 8)
    goto <bb 6>; [88.89%]
  else
    goto <bb 11>; [11.11%]

  <bb 11> [local count: 119292720]:
  # crc_40 = PHI <crc_7(10)>
  # DEBUG BEGIN_STMT
  i_37 = i_12 + 1;
  # DEBUG i => i_37

  <bb 12> [local count: 134036764]:
  # crc_8 = PHI <crc_40(11), crc_9(18)>
  # i_12 = PHI <i_37(11), 0(18)>
  # DEBUG i => i_12
  # DEBUG crc => crc_8
  # DEBUG BEGIN_STMT
  if (i_12 < btp_32)
    goto <bb 5>; [89.00%]
  else
    goto <bb 13>; [11.00%]

  <bb 13> [local count: 14744044]:
  # crc_18 = PHI <crc_8(12)>
  # DEBUG BEGIN_STMT
  offset_34 = offset_11 + 16;
  # DEBUG offset => offset_34
  # DEBUG BEGIN_STMT
  remaining_35 = remaining_10 - btp_32;
  # DEBUG remaining => remaining_35

  <bb 14> [local count: 16510225]:
  # crc_9 = PHI <4294967295(2), crc_18(13)>
  # remaining_10 = PHI <fileLen_19(D)(2), remaining_35(13)>
  # offset_11 = PHI <0(2), offset_34(13)>
  # DEBUG offset => offset_11
  # DEBUG remaining => remaining_10
  # DEBUG crc => crc_9
  # DEBUG BEGIN_STMT
  if (remaining_10 != 0)
    goto <bb 3>; [94.50%]
  else
    goto <bb 15>; [5.50%]

  <bb 15> [local count: 908062]:
  # crc_20 = PHI <crc_9(14)>
  # DEBUG BEGIN_STMT
  crc_23 = ~crc_20;
  # DEBUG crc => crc_23
  # DEBUG BEGIN_STMT
  UART_Print ("  CRC32 received : 0x");
  # DEBUG BEGIN_STMT
  UART_PrintHex32 (expectedCrc_25(D));
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  UART_Print ("  CRC32 in flash : 0x");
  # DEBUG BEGIN_STMT
  UART_PrintHex32 (crc_23);
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  if (crc_23 != expectedCrc_25(D))
    goto <bb 16>; [33.00%]
  else
    goto <bb 17>; [67.00%]

  <bb 16> [local count: 299661]:
  # DEBUG BEGIN_STMT
  UART_Print ("ERROR: CRC MISMATCH\r\n");
  # DEBUG BEGIN_STMT

  <bb 17> [local count: 1766181]:
  # _14 = PHI <0(4), 0(16), 1(15)>
  return _14;

}


Flash_WriteFromBuffer (uint32 fileLen)
{
  C40_Ip_StatusType st;
  uint32 btp;
  uint32 written;
  long unsigned int _1;
  uint8 * _2;
  long unsigned int _3;
  uint8 _5;

  <bb 2> [local count: 13467578]:
  # DEBUG BEGIN_STMT
  # DEBUG written => 0
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  goto <bb 9>; [100.00%]

  <bb 3> [local count: 122598713]:
  # DEBUG BEGIN_STMT
  _1 = fileLen_11(D) - written_4;
  btp_13 = MIN_EXPR <_1, 16>;
  # DEBUG btp => btp_13
  # DEBUG BEGIN_STMT
  memset (&PageBuf, 255, 16);
  # DEBUG BEGIN_STMT
  _2 = &RxBuf[written_4];
  memcpy (&PageBuf, _2, btp_13);
  # DEBUG BEGIN_STMT
  _3 = written_4 + 5111808;
  st_17 = C40_Ip_MainInterfaceWrite (_3, 16, &PageBuf, 0);
  # DEBUG st => st_17
  # DEBUG BEGIN_STMT
  if (st_17 != 23205)
    goto <bb 4>; [3.66%]
  else
    goto <bb 11>; [96.34%]

  <bb 4> [local count: 4487113]:
  # written_9 = PHI <written_4(3)>
  # DEBUG BEGIN_STMT
  UART_Print ("ERROR: write start failed offset=0x");
  # DEBUG BEGIN_STMT
  UART_PrintHex32 (written_9);
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  goto <bb 10>; [100.00%]

  <bb 11> [local count: 118111600]:

  <bb 5> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  st_19 = C40_Ip_MainInterfaceWriteStatus ();
  # DEBUG st => st_19
  # DEBUG BEGIN_STMT
  if (st_19 == 59202)
    goto <bb 12>; [89.00%]
  else
    goto <bb 6>; [11.00%]

  <bb 12> [local count: 955630224]:
  goto <bb 5>; [100.00%]

  <bb 6> [local count: 118111600]:
  # st_24 = PHI <st_19(5)>
  # DEBUG BEGIN_STMT
  if (st_24 != 23205)
    goto <bb 7>; [3.66%]
  else
    goto <bb 8>; [96.34%]

  <bb 7> [local count: 4322885]:
  # written_12 = PHI <written_4(6)>
  # DEBUG BEGIN_STMT
  UART_Print ("ERROR: write failed offset=0x");
  # DEBUG BEGIN_STMT
  UART_PrintHex32 (written_12);
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  goto <bb 10>; [100.00%]

  <bb 8> [local count: 113788715]:
  # DEBUG BEGIN_STMT
  written_20 = written_4 + 16;
  # DEBUG written => written_20

  <bb 9> [local count: 127256294]:
  # written_4 = PHI <0(2), written_20(8)>
  # DEBUG written => written_4
  # DEBUG BEGIN_STMT
  if (written_4 < fileLen_11(D))
    goto <bb 3>; [96.34%]
  else
    goto <bb 10>; [3.66%]

  <bb 10> [local count: 13467578]:
  # _5 = PHI <0(4), 0(7), 1(9)>
  return _5;

}


Flash_EraseForFile (uint32 fileLen)
{
  uint32 s;
  uint32 n;
  long unsigned int _1;
  unsigned char _2;
  unsigned char _3;
  uint8 _6;

  <bb 2> [local count: 113634474]:
  # DEBUG BEGIN_STMT
  _1 = fileLen_9(D) + 131071;
  n_10 = _1 >> 17;
  # DEBUG n => n_10
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  if (_1 <= 131071)
    goto <bb 3>; [50.00%]
  else
    goto <bb 4>; [50.00%]

  <bb 3> [local count: 56817237]:
  # DEBUG BEGIN_STMT
  # DEBUG n => 1

  <bb 4> [local count: 113634474]:
  # n_4 = PHI <n_10(2), 1(3)>
  # DEBUG n => n_4
  # DEBUG BEGIN_STMT
  UART_Print ("Erasing ");
  # DEBUG BEGIN_STMT
  UART_PrintUInt (n_4);
  # DEBUG BEGIN_STMT
  UART_Print (" PFlash sector(s) x 128 KB each...\r\n");
  # DEBUG BEGIN_STMT
  # DEBUG s => 0
  goto <bb 8>; [100.00%]

  <bb 5> [local count: 1034442872]:
  # DEBUG BEGIN_STMT
  _2 = Flash_UnlockSector (s_5);
  if (_2 == 0)
    goto <bb 10>; [3.66%]
  else
    goto <bb 6>; [96.34%]

  <bb 6> [local count: 996582262]:
  # DEBUG BEGIN_STMT
  _3 = Flash_EraseSector (s_5);
  if (_3 == 0)
    goto <bb 10>; [3.66%]
  else
    goto <bb 7>; [96.34%]

  <bb 7> [local count: 960107351]:
  # DEBUG BEGIN_STMT
  UART_Print ("  Sector ");
  # DEBUG BEGIN_STMT
  UART_PrintUInt (s_5);
  # DEBUG BEGIN_STMT
  UART_Print (" OK\r\n");
  # DEBUG BEGIN_STMT
  s_21 = s_5 + 1;
  # DEBUG s => s_21

  <bb 8> [local count: 1073741824]:
  # s_5 = PHI <0(4), s_21(7)>
  # DEBUG s => s_5
  # DEBUG BEGIN_STMT
  if (n_4 > s_5)
    goto <bb 5>; [96.34%]
  else
    goto <bb 9>; [3.66%]

  <bb 9> [local count: 39298952]:
  # DEBUG BEGIN_STMT
  UART_Print ("Erase complete.\r\n");
  # DEBUG BEGIN_STMT

  <bb 10> [local count: 113634474]:
  # _6 = PHI <0(5), 0(6), 1(9)>
  return _6;

}


Flash_EraseSector (uint32 idx)
{
  uint32 to;
  C40_Ip_StatusType st;
  long unsigned int _1;
  uint8 _3;

  <bb 2> [local count: 138405316]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG to => 16777215
  # DEBUG BEGIN_STMT
  UART_Print ("  Starting erase sector=");
  # DEBUG BEGIN_STMT
  UART_PrintUInt (idx_9(D));
  # DEBUG BEGIN_STMT
  UART_Print ("...\r\n");
  # DEBUG BEGIN_STMT
  _1 = idx_9(D) + 23;
  st_13 = C40_Ip_MainInterfaceSectorErase (_1, 0);
  # DEBUG st => st_13
  # DEBUG BEGIN_STMT
  if (st_13 != 23205)
    goto <bb 3>; [50.00%]
  else
    goto <bb 4>; [50.00%]

  <bb 3> [local count: 69202658]:
  # DEBUG BEGIN_STMT
  UART_Print ("ERROR: erase start failed sector=");
  # DEBUG BEGIN_STMT
  UART_PrintUInt (idx_9(D));
  # DEBUG BEGIN_STMT
  UART_Print (" status=");
  # DEBUG BEGIN_STMT
  UART_PrintUInt (st_13);
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  goto <bb 12>; [100.00%]

  <bb 4> [local count: 69202658]:
  # DEBUG BEGIN_STMT
  UART_Print ("  Erase started, polling status...\r\n");

  <bb 5> [local count: 1073741824]:
  # to_2 = PHI <16777215(4), to_17(13)>
  # DEBUG to => to_2
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  st_16 = C40_Ip_MainInterfaceSectorEraseStatus ();
  # DEBUG st => st_16
  # DEBUG BEGIN_STMT
  to_17 = to_2 + 4294967295;
  # DEBUG to => to_17
  # DEBUG BEGIN_STMT
  if (st_16 == 59202)
    goto <bb 6>; [94.50%]
  else
    goto <bb 7>; [5.50%]

  <bb 6> [local count: 1014686026]:
  if (to_17 != 0)
    goto <bb 13>; [99.00%]
  else
    goto <bb 7>; [1.00%]

  <bb 13> [local count: 1004539168]:
  goto <bb 5>; [100.00%]

  <bb 7> [local count: 69202658]:
  # st_6 = PHI <st_16(5), 59202(6)>
  # to_19 = PHI <to_17(5), to_17(6)>
  # DEBUG BEGIN_STMT
  if (to_19 == 0)
    goto <bb 8>; [20.24%]
  else
    goto <bb 9>; [79.76%]

  <bb 8> [local count: 14006618]:
  # DEBUG BEGIN_STMT
  UART_Print ("ERROR: erase TIMEOUT sector=");
  # DEBUG BEGIN_STMT
  UART_PrintUInt (idx_9(D));
  # DEBUG BEGIN_STMT
  UART_Print (" last_status=");
  # DEBUG BEGIN_STMT
  UART_PrintUInt (st_6);
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  goto <bb 12>; [100.00%]

  <bb 9> [local count: 55196040]:
  # DEBUG BEGIN_STMT
  if (st_6 != 23205)
    goto <bb 10>; [50.00%]
  else
    goto <bb 11>; [50.00%]

  <bb 10> [local count: 27598020]:
  # DEBUG BEGIN_STMT
  UART_Print ("ERROR: erase failed sector=");
  # DEBUG BEGIN_STMT
  UART_PrintUInt (idx_9(D));
  # DEBUG BEGIN_STMT
  UART_Print (" status=");
  # DEBUG BEGIN_STMT
  UART_PrintUInt (st_6);
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  goto <bb 12>; [100.00%]

  <bb 11> [local count: 27598020]:
  # DEBUG BEGIN_STMT
  UART_Print ("  Erase status OK\r\n");
  # DEBUG BEGIN_STMT

  <bb 12> [local count: 138405316]:
  # _3 = PHI <0(3), 0(8), 0(10), 1(11)>
  return _3;

}


Flash_UnlockSector (uint32 idx)
{
  C40_Ip_StatusType lockSt;
  long unsigned int _1;
  uint8 _2;

  <bb 2> [local count: 1073741823]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  UART_Print ("  Checking lock for sector=");
  # DEBUG BEGIN_STMT
  UART_PrintUInt (idx_6(D));
  # DEBUG BEGIN_STMT
  UART_Print (" (index=");
  # DEBUG BEGIN_STMT
  _1 = idx_6(D) + 23;
  UART_PrintUInt (_1);
  # DEBUG BEGIN_STMT
  UART_Print (")...\r\n");
  # DEBUG BEGIN_STMT
  lockSt_12 = C40_Ip_GetLock (_1);
  # DEBUG lockSt => lockSt_12
  # DEBUG BEGIN_STMT
  if (lockSt_12 == 59576)
    goto <bb 3>; [34.00%]
  else
    goto <bb 6>; [66.00%]

  <bb 3> [local count: 365072224]:
  # DEBUG BEGIN_STMT
  UART_Print ("  Sector locked, clearing...\r\n");
  # DEBUG BEGIN_STMT
  C40_Ip_ClearLock (_1, 0);
  # DEBUG BEGIN_STMT
  lockSt_17 = C40_Ip_GetLock (_1);
  # DEBUG lockSt => lockSt_17
  # DEBUG BEGIN_STMT
  if (lockSt_17 == 59576)
    goto <bb 4>; [20.97%]
  else
    goto <bb 5>; [79.03%]

  <bb 4> [local count: 76555647]:
  # DEBUG BEGIN_STMT
  UART_Print ("ERROR: unlock failed sector=");
  # DEBUG BEGIN_STMT
  UART_PrintUInt (idx_6(D));
  # DEBUG BEGIN_STMT
  UART_Print ("\r\n");
  # DEBUG BEGIN_STMT
  goto <bb 7>; [100.00%]

  <bb 5> [local count: 288516577]:
  # DEBUG BEGIN_STMT
  UART_Print ("  Sector unlocked OK\r\n");
  goto <bb 7>; [100.00%]

  <bb 6> [local count: 708669600]:
  # DEBUG BEGIN_STMT
  UART_Print ("  Sector already unlocked\r\n");

  <bb 7> [local count: 1073741824]:
  # _2 = PHI <0(4), 1(6), 1(5)>
  return _2;

}


ReadHeader (uint32 * outLen)
{
  uint8 lo;
  uint8 hi;
  uint32 v;
  uint32 i;
  uint8 hdr[8];
  unsigned char _1;
  unsigned char _2;
  long unsigned int _3;
  unsigned char _4;
  long unsigned int _5;
  int _6;
  int _7;
  long unsigned int _8;
  long unsigned int _9;
  long unsigned int _10;
  uint8 _13;

  <bb 2> [local count: 418903057]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG v => 0
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _1 = UART_ReadExact (&hdr, 8);
  if (_1 == 0)
    goto <bb 9>; [34.00%]
  else
    goto <bb 10>; [66.00%]

  <bb 10> [local count: 276476016]:
  goto <bb 7>; [100.00%]

  <bb 3> [local count: 858993457]:
  # DEBUG BEGIN_STMT
  _2 = hdr[i_11];
  hi_21 = HexNibble (_2);
  # DEBUG hi => hi_21
  # DEBUG BEGIN_STMT
  _3 = i_11 + 1;
  _4 = hdr[_3];
  lo_22 = HexNibble (_4);
  # DEBUG lo => lo_22
  # DEBUG BEGIN_STMT
  if (hi_21 == 255)
    goto <bb 5>; [3.66%]
  else
    goto <bb 4>; [96.34%]

  <bb 4> [local count: 827554296]:
  if (lo_22 == 255)
    goto <bb 5>; [3.66%]
  else
    goto <bb 6>; [96.34%]

  <bb 5> [local count: 61727650]:
  # DEBUG BEGIN_STMT
  UART_Print ("ERROR: non-hex character in header\r\n");
  # DEBUG BEGIN_STMT
  goto <bb 9>; [100.00%]

  <bb 6> [local count: 797265808]:
  # DEBUG BEGIN_STMT
  _5 = v_12 << 8;
  _6 = (int) hi_21;
  _7 = _6 << 4;
  _8 = (long unsigned int) _7;
  _9 = (long unsigned int) lo_22;
  _10 = _8 | _9;
  v_23 = _5 | _10;
  # DEBUG v => v_23
  # DEBUG BEGIN_STMT
  i_24 = i_11 + 2;
  # DEBUG i => i_24

  <bb 7> [local count: 1073741824]:
  # i_11 = PHI <i_24(6), 0(10)>
  # v_12 = PHI <v_23(6), 0(10)>
  # DEBUG v => v_12
  # DEBUG i => i_11
  # DEBUG BEGIN_STMT
  if (i_11 != 8)
    goto <bb 3>; [80.00%]
  else
    goto <bb 8>; [20.00%]

  <bb 8> [local count: 214748368]:
  # v_16 = PHI <v_12(7)>
  # DEBUG BEGIN_STMT
  *outLen_19(D) = v_16;
  # DEBUG BEGIN_STMT

  <bb 9> [local count: 418903059]:
  # _13 = PHI <0(2), 0(5), 1(8)>
  hdr ={v} {CLOBBER};
  return _13;

}


HexNibble (uint8 c)
{
  unsigned char _1;
  unsigned char _2;
  uint8 _3;
  uint8 _5;
  unsigned char _6;

  <bb 2> [local count: 1073741823]:
  # DEBUG BEGIN_STMT
  _1 = c_4(D) + 208;
  if (_1 <= 9)
    goto <bb 6>; [34.00%]
  else
    goto <bb 3>; [66.00%]

  <bb 3> [local count: 708669600]:
  # DEBUG BEGIN_STMT
  _2 = c_4(D) + 191;
  if (_2 <= 5)
    goto <bb 4>; [34.00%]
  else
    goto <bb 5>; [66.00%]

  <bb 4> [local count: 240947666]:
  # DEBUG BEGIN_STMT
  _5 = c_4(D) + 201;
  goto <bb 6>; [100.00%]

  <bb 5> [local count: 467721933]:
  _6 = HexNibble.part.0 (c_4(D));

  <bb 6> [local count: 1073741824]:
  # _3 = PHI <_1(2), _5(4), _6(5)>
  return _3;

}


UART_ReadExact (uint8 * dest, uint32 count)
{
  uint32 to;
  uint32 rem;
  volatile Lpuart_Uart_Ip_StatusType st;
  <unnamed type> _1;
  <unnamed type> st.18_2;
  <unnamed type> _3;
  <unnamed type> st.19_4;
  <unnamed type> st.21_5;
  uint8 _7;

  <bb 2> [local count: 177503302]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  rem = 0;
  # DEBUG BEGIN_STMT
  # DEBUG to => 4294967295
  # DEBUG BEGIN_STMT
  if (count_12(D) == 0)
    goto <bb 9>; [51.12%]
  else
    goto <bb 3>; [48.88%]

  <bb 3> [local count: 86763613]:
  # DEBUG BEGIN_STMT
  _1 = Lpuart_Uart_Ip_AsyncReceive (2, dest_13(D), count_12(D));
  st ={v} _1;
  # DEBUG BEGIN_STMT
  st.18_2 ={v} st;
  if (st.18_2 != 0)
    goto <bb 4>; [20.24%]
  else
    goto <bb 10>; [79.76%]

  <bb 4> [local count: 17560955]:
  # DEBUG BEGIN_STMT
  UART_Print ("ERROR: RX start failed\r\n");
  # DEBUG BEGIN_STMT
  goto <bb 9>; [100.00%]

  <bb 10> [local count: 69202658]:

  <bb 5> [local count: 1073741824]:
  # to_6 = PHI <4294967295(10), to_18(11)>
  # DEBUG to => to_6
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _3 = Lpuart_Uart_Ip_GetReceiveStatus (2, &rem);
  st ={v} _3;
  # DEBUG BEGIN_STMT
  st.19_4 ={v} st;
  if (st.19_4 == 2)
    goto <bb 6>; [94.50%]
  else
    goto <bb 7>; [5.50%]

  <bb 6> [local count: 1014686024]:
  to_18 = to_6 + 4294967295;
  # DEBUG to => to_18
  if (to_6 != 0)
    goto <bb 11>; [99.00%]
  else
    goto <bb 7>; [1.00%]

  <bb 11> [local count: 1004539166]:
  goto <bb 5>; [100.00%]

  <bb 7> [local count: 69202658]:
  # DEBUG BEGIN_STMT
  st.21_5 ={v} st;
  if (st.21_5 != 0)
    goto <bb 8>; [20.24%]
  else
    goto <bb 9>; [79.76%]

  <bb 8> [local count: 14006618]:
  # DEBUG BEGIN_STMT
  Lpuart_Uart_Ip_AbortReceivingData (2);
  # DEBUG BEGIN_STMT
  UART_Print ("ERROR: RX timeout\r\n");
  # DEBUG BEGIN_STMT

  <bb 9> [local count: 177503302]:
  # _7 = PHI <1(2), 0(4), 0(8), 1(7)>
  rem ={v} {CLOBBER};
  return _7;

}


UART_PrintHex32 (uint32 v)
{
  uint8 i;
  char h[9];
  unsigned int _1;
  unsigned int _2;
  unsigned int _3;
  long unsigned int _4;
  long unsigned int _5;
  int _6;
  char _7;

  <bb 2> [local count: 119292720]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG i => 0
  goto <bb 4>; [100.00%]

  <bb 3> [local count: 954449105]:
  # DEBUG BEGIN_STMT
  _1 = (unsigned int) i_8;
  _2 = 7 - _1;
  _3 = _2 * 4;
  _4 = v_14(D) >> _3;
  _5 = _4 & 15;
  _6 = (int) i_8;
  _7 = "0123456789ABCDEF"[_5];
  h[_6] = _7;
  # DEBUG BEGIN_STMT
  i_16 = i_8 + 1;
  # DEBUG i => i_16

  <bb 4> [local count: 1073741824]:
  # i_8 = PHI <0(2), i_16(3)>
  # DEBUG i => i_8
  # DEBUG BEGIN_STMT
  if (i_8 != 8)
    goto <bb 3>; [88.89%]
  else
    goto <bb 5>; [11.11%]

  <bb 5> [local count: 119292720]:
  # DEBUG BEGIN_STMT
  h[8] = 0;
  # DEBUG BEGIN_STMT
  UART_Print (&h);
  h ={v} {CLOBBER};
  return;

}


UART_PrintUInt (uint32 v)
{
  uint8 i;

  <bb 2> [local count: 148083751]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  # DEBUG i => 0
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  if (v_6(D) == 0)
    goto <bb 3>; [20.24%]
  else
    goto <bb 4>; [79.76%]

  <bb 3> [local count: 29972151]:
  # DEBUG BEGIN_STMT
  UART_Print ("0");
  # DEBUG BEGIN_STMT
  goto <bb 5>; [100.00%]

  <bb 4> [local count: 118111600]:
  # v_3 = PHI <v_6(D)(2)>
  # i_4 = PHI <0(2)>
  UART_PrintUInt.part.0 (v_6(D));

  <bb 5> [local count: 148083751]:
  return;

}


UART_Print (const char * msg)
{
  unsigned int _1;

  <bb 2> [local count: 1073741824]:
  # DEBUG BEGIN_STMT
  _1 = strlen (msg_3(D));
  UART_WriteRaw (msg_3(D), _1);
  return;

}


UART_WriteRaw (const uint8 * data, uint32 len)
{
  uint32 to;
  uint32 rem;
  volatile Lpuart_Uart_Ip_StatusType st;
  <unnamed type> _1;
  <unnamed type> st.2_2;
  <unnamed type> _3;
  <unnamed type> st.3_4;

  <bb 2> [local count: 104852513]:
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  rem = 0;
  # DEBUG BEGIN_STMT
  # DEBUG to => 16777215
  # DEBUG BEGIN_STMT
  _1 = Lpuart_Uart_Ip_AsyncSend (2, data_10(D), len_11(D));
  st ={v} _1;
  # DEBUG BEGIN_STMT
  st.2_2 ={v} st;
  if (st.2_2 != 0)
    goto <bb 3>; [34.00%]
  else
    goto <bb 8>; [66.00%]

  <bb 3> [local count: 35649855]:
  # DEBUG BEGIN_STMT
  rem ={v} {CLOBBER};
  goto <bb 7>; [100.00%]

  <bb 8> [local count: 69202658]:

  <bb 4> [local count: 1073741824]:
  # to_5 = PHI <16777215(8), to_16(9)>
  # DEBUG to => to_5
  # DEBUG BEGIN_STMT
  # DEBUG BEGIN_STMT
  _3 = Lpuart_Uart_Ip_GetTransmitStatus (2, &rem);
  st ={v} _3;
  # DEBUG BEGIN_STMT
  st.3_4 ={v} st;
  if (st.3_4 == 2)
    goto <bb 5>; [94.50%]
  else
    goto <bb 6>; [5.50%]

  <bb 5> [local count: 1014686025]:
  to_16 = to_5 + 4294967295;
  # DEBUG to => to_16
  if (to_5 != 0)
    goto <bb 9>; [99.00%]
  else
    goto <bb 6>; [1.00%]

  <bb 9> [local count: 1004539167]:
  goto <bb 4>; [100.00%]

  <bb 6> [local count: 69202658]:
  rem ={v} {CLOBBER};

  <bb 7> [local count: 104852513]:
  return;

}


