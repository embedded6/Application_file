/*
 * ============================================================
 *  S32K342  UART -> PFlash / DFlash file store
 * ============================================================
 *
 * CHANGES FROM DFLASH VERSION:
 * ---------------------------------------------------------------
 * 1. PFLASH selected:
 *    - FLS_BASE_ADDR  = 0x00700000  (upper PFlash, safe region)
 *    - FLS_SECTOR_BASE = C40_CODE_ARRAY_0_BLOCK_2_S000
 *    - SECTOR_SIZE    = 0x20000UL  (128 KB per PFlash sector)
 *      (DFlash was 0x2000 = 8 KB per sector)
 *
 * 2. LARGER FILE SUPPORT:
 *    - RX_BUF_SIZE increased to 100000 bytes (100 KB)
 *    - DTCM has 128 KB free, 100 KB uses 78% of it safely
 *    - To support even larger: increase RX_BUF_SIZE up to ~120000
 *
 * ---------------------------------------------------------------
 * IMPORTANT NOTE ON PFLASH ADDRESS:
 *   0x004E0000 is chosen assuming firmware is in lower blocks.
 *   Check your .map file to confirm your code ends well below
 *   0x004E0000. If not, move FLS_BASE_ADDR and FLS_SECTOR_OFFSET higher.
 *
 * ---------------------------------------------------------------
 * HOW TO USE (Tera Term, no tools needed):
 *
 *  1. Open Tera Term -> COM port -> 115200, 8, N, 1
 *  2. Type exactly 8 hex chars = your file size (no Enter).
 *     Examples:
 *       38000 bytes  ->  type  00009470
 *       65000 bytes  ->  type  0000FDE8
 *       100000 bytes ->  type  000186A0
 *  3. Wait for:
 *        >>> ERASE DONE.  NOW: File -> Send File -> tick Binary -> Send <<<
 *  4. Tera Term: File -> Send File -> select .bin -> tick Binary -> Send
 *  5. Wait for:  >>> FLASH STORE SUCCESS <<<
 *
 *  To erase and reset: type  00000000
 * ============================================================
 */

#include "Lpuart_Uart_Ip.h"
#include "Lpuart_Uart_Ip_Irq.h"
#include "Clock_Ip.h"
#include "IntCtrl_Ip.h"
#include "Siul2_Port_Ip.h"
#include "C40_Ip.h"
#include "string.h"

/* ================================================================
 *  CONFIGURATION -- change these two blocks to switch target
 * ================================================================ */

/* ---- OPTION A: PFlash (uncomment this block, comment out B) ---- */
#define USE_PFLASH
#define FLS_SECTOR_BASE    C40_CODE_ARRAY_0_BLOCK_0_S000
#define FLS_BASE_ADDR      0x004E0000UL
#define SECTOR_SIZE        0x20000UL   /* 128 KB / sector */
#define FLS_SECTOR_OFFSET  7U          /* sector 7 = 0x004E0000, safe above firmware */

/* ---- OPTION B: DFlash (comment out A, uncomment this block) ----
#define USE_DFLASH
#define FLS_SECTOR_BASE   C40_DATA_ARRAY_0_BLOCK_2_S000
#define FLS_BASE_ADDR     0x10000000UL
#define SECTOR_SIZE       0x2000UL    // 8 KB / sector
#define FLS_SECTOR_OFFSET 0U
------------------------------------------------------------------- */

/* ---- UART ---- */
#define UART_CHANNEL      2U

/*
 * RX buffer in DTCM (128 KB free).
 * Set RX_BUF_SIZE to the largest file you will ever send.
 *
 *  38 KB  ->  40000
 *  64 KB  ->  65536
 *  100 KB ->  100000   (maximum safe value for DTCM on S32K342)
 *
 * Do NOT exceed 120000 -- DTCM is only 128 KB total.
 */
#define RX_BUF_SIZE       100000U

/* ---- Flash common ---- */
#define FLS_MASTER_ID     0U
#define PAGE_SIZE         16U
#define TOTAL_SECTORS     ((RX_BUF_SIZE + SECTOR_SIZE - 1UL) / SECTOR_SIZE)

/* 8 ASCII hex chars = uint32 file size */
#define HDR_CHARS         8U
#define RX_TIMEOUT        0xFFFFFFFFUL

/* ================================================================
 *  BUFFERS
 *
 *  RxBuf   -- entire file received here (DTCM, 128 KB free region)
 *  PageBuf -- one 16-byte page for flash write
 *  ReadBuf -- one 16-byte page for flash readback
 * ================================================================ */
static uint8 RxBuf[RX_BUF_SIZE]  __attribute__((section(".dtcm_bss")));
static uint8 PageBuf[PAGE_SIZE];
static uint8 ReadBuf[PAGE_SIZE];

/* ================================================================
 *  UART TX
 * ================================================================ */
static void UART_WriteRaw(const uint8 *data, uint32 len)
{
    volatile Lpuart_Uart_Ip_StatusType st;
    uint32 rem = 0U;
    uint32 to  = 0x00FFFFFFU;

    st = Lpuart_Uart_Ip_AsyncSend(UART_CHANNEL, data, len);
    if (st != LPUART_UART_IP_STATUS_SUCCESS) { return; }
    do
    {
        st = Lpuart_Uart_Ip_GetTransmitStatus(UART_CHANNEL, &rem);
    } while ((st == LPUART_UART_IP_STATUS_BUSY) && (to-- > 0U));
}

static void UART_Print(const char *msg)
{
    UART_WriteRaw((const uint8 *)msg, (uint32)strlen(msg));
}

static void UART_PrintUInt(uint32 v)
{
    char  b[12];
    uint8 i = 0U, j;
    char  t;

    if (v == 0U) { UART_Print("0"); return; }
    while (v > 0U) { b[i++] = (char)('0' + (v % 10U)); v /= 10U; }
    b[i] = '\0';
    for (j = 0U; j < (i / 2U); j++)
    {
        t = b[j]; b[j] = b[i-1U-j]; b[i-1U-j] = t;
    }
    UART_Print(b);
}

static void UART_PrintHex32(uint32 v)
{
    char  h[9];
    uint8 i;
    for (i = 0U; i < 8U; i++)
    {
        h[i] = "0123456789ABCDEF"[(v >> (28U - (i * 4U))) & 0x0FU];
    }
    h[8] = '\0';
    UART_Print(h);
}

/* ================================================================
 *  UART RX  --  single call for the whole file
 *               UART fills RxBuf while MCU does nothing else.
 *               Flash is only touched AFTER this returns.
 * ================================================================ */
static uint8 UART_ReadExact(uint8 *dest, uint32 count)
{
    volatile Lpuart_Uart_Ip_StatusType st;
    uint32 rem = 0U;
    uint32 to  = RX_TIMEOUT;

    if (count == 0U) { return 1U; }

    st = Lpuart_Uart_Ip_AsyncReceive(UART_CHANNEL, dest, count);
    if (st != LPUART_UART_IP_STATUS_SUCCESS)
    {
        UART_Print("ERROR: RX start failed\r\n");
        return 0U;
    }

    do
    {
        st = Lpuart_Uart_Ip_GetReceiveStatus(UART_CHANNEL, &rem);
    } while ((st == LPUART_UART_IP_STATUS_BUSY) && (to-- > 0U));

    if (st != LPUART_UART_IP_STATUS_SUCCESS)
    {
        Lpuart_Uart_Ip_AbortReceivingData(UART_CHANNEL);
        UART_Print("ERROR: RX timeout\r\n");
        return 0U;
    }
    return 1U;
}

/* ================================================================
 *  HEX HEADER  (8 ASCII hex chars -> uint32)
 * ================================================================ */
static uint8 HexNibble(uint8 c)
{
    if ((c >= (uint8)'0') && (c <= (uint8)'9')) return (uint8)(c - (uint8)'0');
    if ((c >= (uint8)'A') && (c <= (uint8)'F')) return (uint8)(c - (uint8)'A' + 10U);
    if ((c >= (uint8)'a') && (c <= (uint8)'f')) return (uint8)(c - (uint8)'a' + 10U);
    return 0xFFU;
}

static uint8 ReadHeader(uint32 *outLen)
{
    uint8  hdr[HDR_CHARS];
    uint32 i, v = 0U;
    uint8  hi, lo;

    if (UART_ReadExact(hdr, HDR_CHARS) == 0U) { return 0U; }

    for (i = 0U; i < HDR_CHARS; i += 2U)
    {
        hi = HexNibble(hdr[i]);
        lo = HexNibble(hdr[i + 1U]);
        if ((hi == 0xFFU) || (lo == 0xFFU))
        {
            UART_Print("ERROR: non-hex character in header\r\n");
            return 0U;
        }
        v = (v << 8U) | (uint32)((uint32)(hi << 4U) | (uint32)lo);
    }

    *outLen = v;
    return 1U;
}

/* ================================================================
 *  CRC32  (standard PKZIP poly 0xEDB88320)
 * ================================================================ */
static uint32 CRC32_Compute(const uint8 *data, uint32 len)
{
    uint32 crc = 0xFFFFFFFFUL;
    uint32 i, j;

    for (i = 0U; i < len; i++)
    {
        crc ^= (uint32)data[i];
        for (j = 0U; j < 8U; j++)
        {
            crc = (crc & 1U) ? ((crc >> 1U) ^ 0xEDB88320UL) : (crc >> 1U);
        }
    }
    return crc ^ 0xFFFFFFFFUL;
}

/* ================================================================
 *  FLASH -- UNLOCK + ERASE
 *
 *  FIX: Three bugs were here in the original:
 *  1. Extra ')' before '==' in the if-condition:
 *       WRONG:  if (C40_Ip_GetLock(...)) == STATUS_...)
 *       FIXED:  if (C40_Ip_GetLock(...) == STATUS_...)
 *  2. C40_Ip_MainInterfaceSectorErase was being called inside
 *     UnlockSector -- that is ERASE, not UNLOCK.
 *     Correct API to clear a lock is C40_Ip_ClearLock().
 *  3. Missing closing ')' on the inner call.
 * ================================================================ */
static uint8 Flash_UnlockSector(uint32 idx)
{
    C40_Ip_StatusType lockSt;

    UART_Print("  Checking lock for sector=");
    UART_PrintUInt(idx);
    UART_Print(" (index=");
    UART_PrintUInt(FLS_SECTOR_BASE + FLS_SECTOR_OFFSET + idx);
    UART_Print(")...\r\n");

    lockSt = C40_Ip_GetLock(FLS_SECTOR_BASE + FLS_SECTOR_OFFSET + idx);

    if (lockSt == STATUS_C40_IP_SECTOR_PROTECTED)
    {
        UART_Print("  Sector locked, clearing...\r\n");

        /* C40_Ip_ClearLock returns void on some SDK versions.
         * If you get a compile error here, just call it without checking. */
        C40_Ip_ClearLock(FLS_SECTOR_BASE + FLS_SECTOR_OFFSET + idx, FLS_MASTER_ID);

        lockSt = C40_Ip_GetLock(FLS_SECTOR_BASE + FLS_SECTOR_OFFSET + idx);
        if (lockSt == STATUS_C40_IP_SECTOR_PROTECTED)
        {
            UART_Print("ERROR: unlock failed sector=");
            UART_PrintUInt(idx);
            UART_Print("\r\n");
            return 0U;
        }
        UART_Print("  Sector unlocked OK\r\n");
    }
    else
    {
        UART_Print("  Sector already unlocked\r\n");
    }
    return 1U;
}

static uint8 Flash_EraseSector(uint32 idx)
{
    C40_Ip_StatusType st;
    uint32 to = 0x00FFFFFFu;   /* ~1-2 second timeout at 160 MHz */

    UART_Print("  Starting erase sector=");
    UART_PrintUInt(idx);
    UART_Print("...\r\n");

    st = C40_Ip_MainInterfaceSectorErase(FLS_SECTOR_BASE + FLS_SECTOR_OFFSET + idx, FLS_MASTER_ID);
    if (st != STATUS_C40_IP_SUCCESS)
    {
        UART_Print("ERROR: erase start failed sector=");
        UART_PrintUInt(idx);
        UART_Print(" status=");
        UART_PrintUInt((uint32)st);
        UART_Print("\r\n");
        return 0U;
    }

    UART_Print("  Erase started, polling status...\r\n");

    do
    {
        st = C40_Ip_MainInterfaceSectorEraseStatus();
        to--;
    } while ((st == STATUS_C40_IP_BUSY) && (to > 0U));

    if (to == 0U)
    {
        UART_Print("ERROR: erase TIMEOUT sector=");
        UART_PrintUInt(idx);
        UART_Print(" last_status=");
        UART_PrintUInt((uint32)st);
        UART_Print("\r\n");
        return 0U;
    }

    if (st != STATUS_C40_IP_SUCCESS)
    {
        UART_Print("ERROR: erase failed sector=");
        UART_PrintUInt(idx);
        UART_Print(" status=");
        UART_PrintUInt((uint32)st);
        UART_Print("\r\n");
        return 0U;
    }

    UART_Print("  Erase status OK\r\n");
    return 1U;
}

static uint8 Flash_EraseForFile(uint32 fileLen)
{
    /*
     *  PFlash sector = 128 KB -> 38 KB needs only 1 sector erased
     *  DFlash sector =   8 KB -> 38 KB needs 5 sectors erased
     */
    uint32 n = (fileLen + (SECTOR_SIZE - 1UL)) / SECTOR_SIZE;
    uint32 s;

    if (n == 0U) { n = 1U; }

    UART_Print("Erasing ");
    UART_PrintUInt(n);
#ifdef USE_PFLASH
    UART_Print(" PFlash sector(s) x 128 KB each...\r\n");
#else
    UART_Print(" DFlash sector(s) x 8 KB each...\r\n");
#endif

    for (s = 0U; s < n; s++)
    {
        if (Flash_UnlockSector(s) == 0U) { return 0U; }
        if (Flash_EraseSector(s)  == 0U) { return 0U; }
        UART_Print("  Sector ");
        UART_PrintUInt(s);
        UART_Print(" OK\r\n");
    }

    UART_Print("Erase complete.\r\n");
    return 1U;
}

/* ================================================================
 *  FLASH -- WRITE  (from RxBuf, full file already in RAM)
 * ================================================================ */
static uint8 Flash_WriteFromBuffer(uint32 fileLen)
{
    uint32 written = 0U, btp;
    C40_Ip_StatusType st;

    while (written < fileLen)
    {
        btp = ((fileLen - written) >= PAGE_SIZE) ? PAGE_SIZE : (fileLen - written);

        memset(PageBuf, 0xFFU, PAGE_SIZE);
        memcpy(PageBuf, &RxBuf[written], btp);

        st = C40_Ip_MainInterfaceWrite(FLS_BASE_ADDR + written,
                                       PAGE_SIZE, PageBuf, FLS_MASTER_ID);
        if (st != STATUS_C40_IP_SUCCESS)
        {
            UART_Print("ERROR: write start failed offset=0x");
            UART_PrintHex32(written);
            UART_Print("\r\n");
            return 0U;
        }
        do { st = C40_Ip_MainInterfaceWriteStatus(); } while (st == STATUS_C40_IP_BUSY);
        if (st != STATUS_C40_IP_SUCCESS)
        {
            UART_Print("ERROR: write failed offset=0x");
            UART_PrintHex32(written);
            UART_Print("\r\n");
            return 0U;
        }

        written += PAGE_SIZE;
    }
    return 1U;
}

/* ================================================================
 *  FLASH -- VERIFY  (read back page by page, compare CRC)
 * ================================================================ */
static uint8 Flash_VerifyCRC(uint32 fileLen, uint32 expectedCrc)
{
    uint32 crc       = 0xFFFFFFFFUL;
    uint32 remaining = fileLen;
    uint32 offset    = 0U, btp, i, j;

    while (remaining > 0U)
    {
        btp = (remaining >= PAGE_SIZE) ? PAGE_SIZE : remaining;

        if (C40_Ip_Read(FLS_BASE_ADDR + offset, PAGE_SIZE, ReadBuf)
            != STATUS_C40_IP_SUCCESS)
        {
            UART_Print("ERROR: readback failed offset=0x");
            UART_PrintHex32(offset);
            UART_Print("\r\n");
            return 0U;
        }

        for (i = 0U; i < btp; i++)
        {
            crc ^= (uint32)ReadBuf[i];
            for (j = 0U; j < 8U; j++)
            {
                crc = (crc & 1U) ? ((crc >> 1U) ^ 0xEDB88320UL) : (crc >> 1U);
            }
        }

        offset    += PAGE_SIZE;
        remaining -= btp;
    }

    crc ^= 0xFFFFFFFFUL;

    UART_Print("  CRC32 received : 0x"); UART_PrintHex32(expectedCrc); UART_Print("\r\n");
    UART_Print("  CRC32 in flash : 0x"); UART_PrintHex32(crc);         UART_Print("\r\n");

    if (crc != expectedCrc)
    {
        UART_Print("ERROR: CRC MISMATCH\r\n");
        return 0U;
    }
    return 1U;
}

/* ================================================================
 *  ONE FULL TRANSFER
 * ================================================================ */
static void DoTransfer(void)
{
    uint32 fileLen = 0U;
    uint32 fileCrc;

    UART_Print("\r\n----------------------------------------------\r\n");
    UART_Print("Type 8 hex chars = file size (no Enter):\r\n");
    UART_Print("  38000 bytes  ->  00009470\r\n");
    UART_Print("  65000 bytes  ->  0000FDE8\r\n");
    UART_Print("  100000 bytes ->  000186A0\r\n");
    UART_Print("  Reset/erase  ->  00000000\r\n");
    UART_Print("----------------------------------------------\r\n");

    /* 1. Read 8-char hex size */
    if (ReadHeader(&fileLen) == 0U) { return; }

    /* 1a. Reset command */
    if (fileLen == 0U)
    {
        UART_Print("Reset: erasing sectors...\r\n");
        (void)Flash_EraseForFile(RX_BUF_SIZE);
        UART_Print("Erase done. Ready for new file.\r\n");
        return;
    }

    UART_Print("File size : ");
    UART_PrintUInt(fileLen);
    UART_Print(" bytes  (0x");
    UART_PrintHex32(fileLen);
    UART_Print(")\r\n");

    /* 2. Validate against buffer */
    if (fileLen > RX_BUF_SIZE)
    {
        UART_Print("ERROR: file too large. Max = ");
        UART_PrintUInt(RX_BUF_SIZE);
        UART_Print(" bytes.\r\n");
        UART_Print("Increase RX_BUF_SIZE in main.c (max ~120000)\r\n");
        return;
    }

    /* 3. Erase flash */
    UART_Print("Flash target : 0x");
    UART_PrintHex32(FLS_BASE_ADDR);
    UART_Print("\r\n");

    if (Flash_EraseForFile(fileLen) == 0U) { return; }

    /* 4. Prompt user to send file */
    UART_Print("\r\n");
    UART_Print(">>> ERASE DONE.  NOW: File -> Send File -> tick Binary -> Send <<<\r\n");
    UART_Print("Waiting for ");
    UART_PrintUInt(fileLen);
    UART_Print(" bytes...\r\n");

    /* 5. Receive ENTIRE file into DTCM RAM.
     *    Single AsyncReceive call -- MCU does nothing else while
     *    Tera Term streams the file. No flash activity = no lost bytes.
     */
    if (UART_ReadExact(RxBuf, fileLen) == 0U)
    {
        UART_Print(">>> RECEIVE FAILED <<<\r\n");
        return;
    }

    UART_Print("Receive OK -- ");
    UART_PrintUInt(fileLen);
    UART_Print(" bytes in DTCM RAM.\r\n");

    /* 6. CRC of received data */
    fileCrc = CRC32_Compute(RxBuf, fileLen);
    UART_Print("CRC32 received : 0x");
    UART_PrintHex32(fileCrc);
    UART_Print("\r\n");

    /* 7. Write RAM -> Flash (Tera Term is idle now, nothing to lose) */
    UART_Print("Writing to flash 0x");
    UART_PrintHex32(FLS_BASE_ADDR);
    UART_Print("...\r\n");

    if (Flash_WriteFromBuffer(fileLen) == 0U)
    {
        UART_Print(">>> FLASH WRITE FAILED <<<\r\n");
        return;
    }
    UART_Print("Flash write done.\r\n");

    /* 8. Verify */
    UART_Print("Verifying...\r\n");
    if (Flash_VerifyCRC(fileLen, fileCrc) == 0U)
    {
        UART_Print(">>> FLASH VERIFY FAILED <<<\r\n");
        return;
    }

    /* 9. Success */
    UART_Print("\r\n");
    UART_Print(">>> FLASH STORE SUCCESS <<<\r\n");
    UART_Print("  ");
    UART_PrintUInt(fileLen);
    UART_Print(" bytes stored at 0x");
    UART_PrintHex32(FLS_BASE_ADDR);
    UART_Print(" -- 0x");
    UART_PrintHex32(FLS_BASE_ADDR + fileLen - 1U);
    UART_Print("\r\n");
}

/* ================================================================
 *  MAIN
 * ================================================================ */
int main(void)
{
    Clock_Ip_Init(&Clock_Ip_aClockConfig[0]);

#if defined(FEATURE_CLOCK_IP_HAS_SPLL_CLK)
    while (CLOCK_IP_PLL_LOCKED != Clock_Ip_GetPllStatus()) {}
    Clock_Ip_DistributePll();
#endif

    Siul2_Port_Ip_Init(NUM_OF_CONFIGURED_PINS0, g_pin_mux_InitConfigArr0);
    IntCtrl_Ip_Init(&IntCtrlConfig_0);
    IntCtrl_Ip_ConfigIrqRouting(&intRouteConfig);
    Lpuart_Uart_Ip_Init(UART_CHANNEL,
                        &Lpuart_Uart_Ip_xHwConfigPB_2_BOARD_INITPERIPHERALS);

    if (C40_Ip_Init(&C40ConfigSet_BOARD_InitPeripherals_InitCfg) != STATUS_C40_IP_SUCCESS)
    {
        while (1) {}
    }

    /* Banner */
    UART_Print("\r\n");
    UART_Print("==============================================\r\n");
    UART_Print("  S32K342  UART -> Flash  File Store\r\n");
#ifdef USE_PFLASH
    UART_Print("  Target     : PFlash (Code Flash)\r\n");
    UART_Print("  Flash base : 0x004E0000\r\n");
    UART_Print("  Sector     : 128 KB each\r\n");
#else
    UART_Print("  Target     : DFlash (Data Flash)\r\n");
    UART_Print("  Flash base : 0x10000000\r\n");
    UART_Print("  Sector     : 8 KB each\r\n");
#endif
    UART_Print("  Buffer     : DTCM RAM (128 KB)\r\n");
    UART_Print("  Max file   : ");
    UART_PrintUInt(RX_BUF_SIZE);
    UART_Print(" bytes\r\n");
    UART_Print("==============================================\r\n");
    UART_Print("\r\n");
    UART_Print("HOW TO INCREASE MAX FILE SIZE:\r\n");
    UART_Print("  Change RX_BUF_SIZE in main.c\r\n");
    UART_Print("  Max safe value = 120000 (DTCM is 128 KB)\r\n");
    UART_Print("\r\n");

    while (1)
    {
        DoTransfer();
    }
}
